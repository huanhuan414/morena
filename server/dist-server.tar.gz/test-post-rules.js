"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const supabase_client_1 = require("./src/storage/database/supabase-client");
async function testPostRules() {
    const client = (0, supabase_client_1.getSupabaseClient)();
    const { data: avatar, error } = await client
        .from('avatars')
        .select('*')
        .ilike('name', '%肖乾%')
        .single();
    if (error || !avatar) {
        console.error('找不到肖乾分身:', error);
        return;
    }
    console.log('找到分身:', avatar.name, '当前等级:', avatar.level);
    console.log('\n=== 测试1: Lv.8 图文帖子 ===');
    await client.from('avatars').update({ level: 8 }).eq('id', avatar.id);
    console.log('等级已设置为 Lv.8');
    console.log('\n=== 测试2: 尊享版 视频帖子 ===');
}
testPostRules().catch(console.error);
//# sourceMappingURL=test-post-rules.js.map