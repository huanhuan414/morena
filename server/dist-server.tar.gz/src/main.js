"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const app_module_1 = require("./app.module");
const express = require("express");
const http_status_interceptor_1 = require("./interceptors/http-status.interceptor");
const http_exception_filter_1 = require("./common/filters/http-exception.filter");
const dotenv = require("dotenv");
const path = require("path");
const envPath = path.resolve(__dirname, '../../.env');
const result = dotenv.config({ path: envPath });
if (result.error) {
    console.warn('[main.ts] Warning: Failed to load .env file:', result.error.message);
}
else {
    console.log('[main.ts] Successfully loaded .env file from:', envPath);
}
function parsePort() {
    const args = process.argv.slice(2);
    const portIndex = args.indexOf('-p');
    if (portIndex !== -1 && args[portIndex + 1]) {
        const port = parseInt(args[portIndex + 1], 10);
        if (!isNaN(port) && port > 0 && port < 65536) {
            return port;
        }
    }
    return 3000;
}
async function bootstrap() {
    const app = await core_1.NestFactory.create(app_module_1.AppModule, {
        logger: ['error', 'warn', 'log'],
        rawBody: true
    });
    const httpServer = app.getHttpServer();
    httpServer.setTimeout(15 * 60 * 1000);
    httpServer.keepAliveTimeout = 15 * 60 * 1000;
    httpServer.headersTimeout = 16 * 60 * 1000;
    app.enableCors({
        origin: true,
        credentials: true,
    });
    app.setGlobalPrefix('api');
    app.use(express.json({ limit: '50mb' }));
    app.use(express.urlencoded({ limit: '50mb', extended: true }));
    const projectRoot = process.cwd().includes('server') ? path.join(process.cwd(), '..') : process.cwd();
    app.use('/uploads', express.static(path.join(projectRoot, 'uploads')));
    app.useGlobalFilters(new http_exception_filter_1.HttpExceptionFilter());
    app.useGlobalInterceptors(new http_status_interceptor_1.HttpStatusInterceptor());
    app.enableShutdownHooks();
    const port = parsePort();
    try {
        await app.listen(port);
        console.log(`Server running on http://localhost:${port}`);
    }
    catch (err) {
        if (err.code === 'EADDRINUSE') {
            console.error(`❌ 端口 ${port} 被占用! 请运行 'npx kill-port ${port}' 然后重试。`);
            process.exit(1);
        }
        else {
            throw err;
        }
    }
    console.log(`Application is running on: http://localhost:3000`);
}
bootstrap();
//# sourceMappingURL=main.js.map