export declare const commentsRelations: import("drizzle-orm/relations").Relations<"comments", {
    post: import("drizzle-orm/relations").One<"posts", true>;
    user: import("drizzle-orm/relations").One<"users", true>;
    comment: import("drizzle-orm/relations").One<"comments", false>;
    comments: import("drizzle-orm/relations").Many<"comments">;
    avatar: import("drizzle-orm/relations").One<"avatars", false>;
}>;
export declare const postsRelations: import("drizzle-orm/relations").Relations<"posts", {
    comments: import("drizzle-orm/relations").Many<"comments">;
    user: import("drizzle-orm/relations").One<"users", true>;
    avatar: import("drizzle-orm/relations").One<"avatars", false>;
}>;
export declare const usersRelations: import("drizzle-orm/relations").Relations<"users", {
    comments: import("drizzle-orm/relations").Many<"comments">;
    conversations: import("drizzle-orm/relations").Many<"conversations">;
    user: import("drizzle-orm/relations").One<"users", false>;
    users: import("drizzle-orm/relations").Many<"users">;
    follows_followerId: import("drizzle-orm/relations").Many<"follows">;
    follows_followingId: import("drizzle-orm/relations").Many<"follows">;
    posts: import("drizzle-orm/relations").Many<"posts">;
    orders: import("drizzle-orm/relations").Many<"orders">;
    likes: import("drizzle-orm/relations").Many<"likes">;
    notifications: import("drizzle-orm/relations").Many<"notifications">;
    earnings: import("drizzle-orm/relations").Many<"earnings">;
    withdrawals: import("drizzle-orm/relations").Many<"withdrawals">;
    referrals_inviterId: import("drizzle-orm/relations").Many<"referrals">;
    referrals_inviteeId: import("drizzle-orm/relations").Many<"referrals">;
    platformConfigs: import("drizzle-orm/relations").Many<"platform_configs">;
}>;
export declare const avatarsRelations: import("drizzle-orm/relations").Relations<"avatars", {
    comments: import("drizzle-orm/relations").Many<"comments">;
    conversations: import("drizzle-orm/relations").Many<"conversations">;
    orderResults: import("drizzle-orm/relations").Many<"order_results">;
    avatarEvolutions: import("drizzle-orm/relations").Many<"avatar_evolution">;
    posts: import("drizzle-orm/relations").Many<"posts">;
    orders: import("drizzle-orm/relations").Many<"orders">;
    orderExecutions: import("drizzle-orm/relations").Many<"order_executions">;
    earnings: import("drizzle-orm/relations").Many<"earnings">;
    avatarAccounts: import("drizzle-orm/relations").Many<"avatar_accounts">;
    avatarSkills: import("drizzle-orm/relations").Many<"avatar_skills">;
    avatarFriends_avatarId: import("drizzle-orm/relations").Many<"avatar_friends">;
    avatarFriends_friendAvatarId: import("drizzle-orm/relations").Many<"avatar_friends">;
    agentTaskLogs: import("drizzle-orm/relations").Many<"agent_task_logs">;
    avatarMemories: import("drizzle-orm/relations").Many<"avatar_memories">;
    avatarContexts: import("drizzle-orm/relations").Many<"avatar_contexts">;
    avatarAgentConfigs: import("drizzle-orm/relations").Many<"avatar_agent_configs">;
    avatarLearningRecords: import("drizzle-orm/relations").Many<"avatar_learning_records">;
    publishedWorks: import("drizzle-orm/relations").Many<"published_works">;
}>;
export declare const conversationsRelations: import("drizzle-orm/relations").Relations<"conversations", {
    user: import("drizzle-orm/relations").One<"users", true>;
    avatar: import("drizzle-orm/relations").One<"avatars", true>;
    messages: import("drizzle-orm/relations").Many<"messages">;
}>;
export declare const messagesRelations: import("drizzle-orm/relations").Relations<"messages", {
    conversation: import("drizzle-orm/relations").One<"conversations", true>;
}>;
export declare const orderResultsRelations: import("drizzle-orm/relations").Relations<"order_results", {
    order: import("drizzle-orm/relations").One<"orders", true>;
    avatar: import("drizzle-orm/relations").One<"avatars", true>;
}>;
export declare const ordersRelations: import("drizzle-orm/relations").Relations<"orders", {
    orderResults: import("drizzle-orm/relations").Many<"order_results">;
    user: import("drizzle-orm/relations").One<"users", true>;
    avatar: import("drizzle-orm/relations").One<"avatars", false>;
    orderExecutions: import("drizzle-orm/relations").Many<"order_executions">;
    earnings: import("drizzle-orm/relations").Many<"earnings">;
    publishedWorks: import("drizzle-orm/relations").Many<"published_works">;
}>;
export declare const followsRelations: import("drizzle-orm/relations").Relations<"follows", {
    user_followerId: import("drizzle-orm/relations").One<"users", true>;
    user_followingId: import("drizzle-orm/relations").One<"users", true>;
}>;
export declare const avatarEvolutionRelations: import("drizzle-orm/relations").Relations<"avatar_evolution", {
    avatar: import("drizzle-orm/relations").One<"avatars", true>;
}>;
export declare const likesRelations: import("drizzle-orm/relations").Relations<"likes", {
    user: import("drizzle-orm/relations").One<"users", true>;
}>;
export declare const notificationsRelations: import("drizzle-orm/relations").Relations<"notifications", {
    user: import("drizzle-orm/relations").One<"users", true>;
}>;
export declare const orderExecutionsRelations: import("drizzle-orm/relations").Relations<"order_executions", {
    order: import("drizzle-orm/relations").One<"orders", true>;
    avatar: import("drizzle-orm/relations").One<"avatars", true>;
}>;
export declare const earningsRelations: import("drizzle-orm/relations").Relations<"earnings", {
    user: import("drizzle-orm/relations").One<"users", true>;
    avatar: import("drizzle-orm/relations").One<"avatars", false>;
    order: import("drizzle-orm/relations").One<"orders", false>;
}>;
export declare const withdrawalsRelations: import("drizzle-orm/relations").Relations<"withdrawals", {
    user: import("drizzle-orm/relations").One<"users", true>;
}>;
export declare const referralsRelations: import("drizzle-orm/relations").Relations<"referrals", {
    user_inviterId: import("drizzle-orm/relations").One<"users", true>;
    user_inviteeId: import("drizzle-orm/relations").One<"users", true>;
}>;
export declare const platformConfigsRelations: import("drizzle-orm/relations").Relations<"platform_configs", {
    user: import("drizzle-orm/relations").One<"users", true>;
}>;
export declare const avatarAccountsRelations: import("drizzle-orm/relations").Relations<"avatar_accounts", {
    avatar: import("drizzle-orm/relations").One<"avatars", true>;
}>;
export declare const avatarSkillsRelations: import("drizzle-orm/relations").Relations<"avatar_skills", {
    avatar: import("drizzle-orm/relations").One<"avatars", true>;
}>;
export declare const avatarFriendsRelations: import("drizzle-orm/relations").Relations<"avatar_friends", {
    avatar_avatarId: import("drizzle-orm/relations").One<"avatars", true>;
    avatar_friendAvatarId: import("drizzle-orm/relations").One<"avatars", true>;
}>;
export declare const agentTaskLogsRelations: import("drizzle-orm/relations").Relations<"agent_task_logs", {
    avatar: import("drizzle-orm/relations").One<"avatars", true>;
}>;
export declare const userSubscriptionsRelations: import("drizzle-orm/relations").Relations<"user_subscriptions", {
    subscriptionPlan: import("drizzle-orm/relations").One<"subscription_plans", true>;
}>;
export declare const subscriptionPlansRelations: import("drizzle-orm/relations").Relations<"subscription_plans", {
    userSubscriptions: import("drizzle-orm/relations").Many<"user_subscriptions">;
}>;
export declare const avatarMemoriesRelations: import("drizzle-orm/relations").Relations<"avatar_memories", {
    avatar: import("drizzle-orm/relations").One<"avatars", true>;
}>;
export declare const avatarContextsRelations: import("drizzle-orm/relations").Relations<"avatar_contexts", {
    avatar: import("drizzle-orm/relations").One<"avatars", true>;
}>;
export declare const avatarAgentConfigsRelations: import("drizzle-orm/relations").Relations<"avatar_agent_configs", {
    avatar: import("drizzle-orm/relations").One<"avatars", true>;
}>;
export declare const avatarLearningRecordsRelations: import("drizzle-orm/relations").Relations<"avatar_learning_records", {
    avatar: import("drizzle-orm/relations").One<"avatars", true>;
}>;
export declare const publishedWorksRelations: import("drizzle-orm/relations").Relations<"published_works", {
    order: import("drizzle-orm/relations").One<"orders", true>;
    avatar: import("drizzle-orm/relations").One<"avatars", true>;
}>;
