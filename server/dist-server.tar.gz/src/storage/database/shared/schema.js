"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.publishedWorks = exports.avatarAffinity = exports.avatarFollows = exports.generatedContent = exports.orderDispatchRequests = exports.avatarBlocks = exports.skills = exports.avatarLearningRecords = exports.avatarAgentConfigs = exports.avatarContexts = exports.avatarMemories = exports.avatarSubscriptions = exports.userSubscriptions = exports.subscriptionPlans = exports.agentTaskLogs = exports.avatarFriends = exports.avatarSkills = exports.avatarAccounts = exports.platformConfigs = exports.referrals = exports.withdrawals = exports.earnings = exports.orderExecutions = exports.notifications = exports.likes = exports.tasks = exports.orders = exports.posts = exports.avatarEvolution = exports.follows = exports.avatars = exports.orderResults = exports.users = exports.messages = exports.conversations = exports.healthCheck = exports.comments = void 0;
const pg_core_1 = require("drizzle-orm/pg-core");
const drizzle_orm_1 = require("drizzle-orm");
const gen_random_uuid = () => (0, drizzle_orm_1.sql) `gen_random_uuid()`;
exports.comments = (0, pg_core_1.pgTable)("comments", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    postId: (0, pg_core_1.varchar)("post_id", { length: 36 }).notNull(),
    userId: (0, pg_core_1.varchar)("user_id", { length: 36 }).notNull(),
    parentId: (0, pg_core_1.varchar)("parent_id", { length: 36 }),
    content: (0, pg_core_1.text)().notNull(),
    likesCount: (0, pg_core_1.integer)("likes_count").default(0).notNull(),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }),
}, (table) => [
    (0, pg_core_1.index)("comments_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("comments_parent_id_idx").using("btree", table.parentId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("comments_post_id_idx").using("btree", table.postId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("comments_user_id_idx").using("btree", table.userId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.postId],
        foreignColumns: [exports.posts.id],
        name: "comments_post_id_posts_id_fk"
    }).onDelete("cascade"),
    (0, pg_core_1.foreignKey)({
        columns: [table.userId],
        foreignColumns: [exports.users.id],
        name: "comments_user_id_users_id_fk"
    }).onDelete("cascade"),
    (0, pg_core_1.foreignKey)({
        columns: [table.parentId],
        foreignColumns: [table.id],
        name: "comments_parent_id_comments_id_fk"
    }).onDelete("cascade"),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "comments_avatar_id_fkey"
    }).onDelete("set null"),
    (0, pg_core_1.pgPolicy)("comments_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: (0, drizzle_orm_1.sql) `true` }),
    (0, pg_core_1.pgPolicy)("comments_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("comments_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("comments_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);
exports.healthCheck = (0, pg_core_1.pgTable)("health_check", {
    id: (0, pg_core_1.serial)().notNull(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});
exports.conversations = (0, pg_core_1.pgTable)("conversations", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    userId: (0, pg_core_1.varchar)("user_id", { length: 36 }).notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }).notNull(),
    title: (0, pg_core_1.varchar)({ length: 200 }),
    context: (0, pg_core_1.jsonb)().default([]),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
    (0, pg_core_1.index)("conversations_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("conversations_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
    (0, pg_core_1.index)("conversations_user_id_idx").using("btree", table.userId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.userId],
        foreignColumns: [exports.users.id],
        name: "conversations_user_id_users_id_fk"
    }).onDelete("cascade"),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "conversations_avatar_id_avatars_id_fk"
    }).onDelete("cascade"),
    (0, pg_core_1.pgPolicy)("conversations_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: (0, drizzle_orm_1.sql) `true` }),
    (0, pg_core_1.pgPolicy)("conversations_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("conversations_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("conversations_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);
exports.messages = (0, pg_core_1.pgTable)("messages", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    conversationId: (0, pg_core_1.varchar)("conversation_id", { length: 36 }).notNull(),
    role: (0, pg_core_1.varchar)({ length: 20 }).notNull(),
    content: (0, pg_core_1.text)().notNull(),
    metadata: (0, pg_core_1.jsonb)().default({}),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
    (0, pg_core_1.index)("messages_conversation_id_idx").using("btree", table.conversationId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("messages_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.conversationId],
        foreignColumns: [exports.conversations.id],
        name: "messages_conversation_id_conversations_id_fk"
    }).onDelete("cascade"),
    (0, pg_core_1.pgPolicy)("messages_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: (0, drizzle_orm_1.sql) `true` }),
    (0, pg_core_1.pgPolicy)("messages_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("messages_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("messages_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);
exports.users = (0, pg_core_1.pgTable)("users", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    openid: (0, pg_core_1.varchar)({ length: 100 }).notNull(),
    nickname: (0, pg_core_1.varchar)({ length: 100 }),
    avatar: (0, pg_core_1.varchar)({ length: 500 }),
    phone: (0, pg_core_1.varchar)({ length: 20 }),
    bio: (0, pg_core_1.text)(),
    level: (0, pg_core_1.integer)().default(1).notNull(),
    exp: (0, pg_core_1.integer)().default(0).notNull(),
    credits: (0, pg_core_1.integer)().default(0).notNull(),
    settings: (0, pg_core_1.jsonb)().default({}),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }),
    referralCode: (0, pg_core_1.varchar)("referral_code", { length: 20 }),
    invitedBy: (0, pg_core_1.varchar)("invited_by", { length: 36 }),
    balance: (0, pg_core_1.numeric)({ precision: 10, scale: 2 }).default('0'),
    totalEarnings: (0, pg_core_1.numeric)("total_earnings", { precision: 10, scale: 2 }).default('0'),
}, (table) => [
    (0, pg_core_1.index)("users_level_idx").using("btree", table.level.asc().nullsLast().op("int4_ops")),
    (0, pg_core_1.index)("users_openid_idx").using("btree", table.openid.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.invitedBy],
        foreignColumns: [table.id],
        name: "users_invited_by_fkey"
    }),
    (0, pg_core_1.unique)("users_openid_unique").on(table.openid),
    (0, pg_core_1.unique)("users_referral_code_key").on(table.referralCode),
    (0, pg_core_1.pgPolicy)("users_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: (0, drizzle_orm_1.sql) `true` }),
    (0, pg_core_1.pgPolicy)("users_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("users_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("users_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);
exports.orderResults = (0, pg_core_1.pgTable)("order_results", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    orderId: (0, pg_core_1.varchar)("order_id", { length: 36 }).notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }).notNull(),
    platform: (0, pg_core_1.varchar)({ length: 30 }).notNull(),
    taskDescription: (0, pg_core_1.text)("task_description"),
    actualExposure: (0, pg_core_1.integer)("actual_exposure").default(0).notNull(),
    actualLikes: (0, pg_core_1.integer)("actual_likes").default(0).notNull(),
    actualComments: (0, pg_core_1.integer)("actual_comments").default(0).notNull(),
    actualShares: (0, pg_core_1.integer)("actual_shares").default(0).notNull(),
    actualViews: (0, pg_core_1.integer)("actual_views").default(0).notNull(),
    completionTimeHours: (0, pg_core_1.numeric)("completion_time_hours", { precision: 5, scale: 2 }).default('0'),
    qualityScore: (0, pg_core_1.integer)("quality_score").default(0).notNull(),
    customerRating: (0, pg_core_1.integer)("customer_rating"),
    notes: (0, pg_core_1.text)(),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    screenshots: (0, pg_core_1.jsonb)().default([]),
}, (table) => [
    (0, pg_core_1.index)("order_results_actual_exposure_idx").using("btree", table.actualExposure.asc().nullsLast().op("int4_ops")),
    (0, pg_core_1.index)("order_results_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("order_results_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
    (0, pg_core_1.index)("order_results_order_id_idx").using("btree", table.orderId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("order_results_platform_idx").using("btree", table.platform.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.orderId],
        foreignColumns: [exports.orders.id],
        name: "order_results_order_id_fkey"
    }).onDelete("cascade"),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "order_results_avatar_id_fkey"
    }).onDelete("cascade"),
]);
exports.avatars = (0, pg_core_1.pgTable)("avatars", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    userId: (0, pg_core_1.varchar)("user_id", { length: 36 }).notNull(),
    name: (0, pg_core_1.varchar)({ length: 100 }).notNull(),
    description: (0, pg_core_1.text)(),
    avatarUrl: (0, pg_core_1.varchar)("avatar_url", { length: 500 }),
    personality: (0, pg_core_1.text)(),
    skills: (0, pg_core_1.jsonb)().default([]),
    config: (0, pg_core_1.jsonb)().default({}),
    level: (0, pg_core_1.integer)().default(1).notNull(),
    exp: (0, pg_core_1.integer)().default(0).notNull(),
    status: (0, pg_core_1.varchar)({ length: 20 }).default('active').notNull(),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }),
    completionRate: (0, pg_core_1.numeric)("completion_rate", { precision: 5, scale: 2 }).default('100'),
    totalOrders: (0, pg_core_1.integer)("total_orders").default(0),
    completedOrders: (0, pg_core_1.integer)("completed_orders").default(0),
    learningData: (0, pg_core_1.jsonb)("learning_data").default({}),
    isHosted: (0, pg_core_1.boolean)("is_hosted").default(false),
    latitude: (0, pg_core_1.numeric)(),
    longitude: (0, pg_core_1.numeric)(),
    locationText: (0, pg_core_1.varchar)("location_text"),
    appearanceStyle: (0, pg_core_1.varchar)("appearance_style"),
    speakingStyle: (0, pg_core_1.varchar)("speaking_style"),
    photoAnalysis: (0, pg_core_1.jsonb)("photo_analysis"),
}, (table) => [
    (0, pg_core_1.index)("avatars_level_idx").using("btree", table.level.asc().nullsLast().op("int4_ops")),
    (0, pg_core_1.index)("avatars_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("avatars_user_id_idx").using("btree", table.userId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.pgPolicy)("avatars_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: (0, drizzle_orm_1.sql) `true` }),
    (0, pg_core_1.pgPolicy)("avatars_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("avatars_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("avatars_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);
exports.follows = (0, pg_core_1.pgTable)("follows", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    followerId: (0, pg_core_1.varchar)("follower_id", { length: 36 }).notNull(),
    followingId: (0, pg_core_1.varchar)("following_id", { length: 36 }).notNull(),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
    (0, pg_core_1.index)("follows_follower_id_idx").using("btree", table.followerId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("follows_following_id_idx").using("btree", table.followingId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.followerId],
        foreignColumns: [exports.users.id],
        name: "follows_follower_id_users_id_fk"
    }).onDelete("cascade"),
    (0, pg_core_1.foreignKey)({
        columns: [table.followingId],
        foreignColumns: [exports.users.id],
        name: "follows_following_id_users_id_fk"
    }).onDelete("cascade"),
    (0, pg_core_1.pgPolicy)("follows_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: (0, drizzle_orm_1.sql) `true` }),
    (0, pg_core_1.pgPolicy)("follows_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("follows_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("follows_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);
exports.avatarEvolution = (0, pg_core_1.pgTable)("avatar_evolution", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }).notNull(),
    levelFrom: (0, pg_core_1.integer)("level_from").notNull(),
    levelTo: (0, pg_core_1.integer)("level_to").notNull(),
    expGained: (0, pg_core_1.integer)("exp_gained").notNull(),
    source: (0, pg_core_1.varchar)({ length: 50 }).notNull(),
    rewards: (0, pg_core_1.jsonb)().default({}),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
    (0, pg_core_1.index)("avatar_evolution_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("avatar_evolution_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "avatar_evolution_avatar_id_avatars_id_fk"
    }).onDelete("cascade"),
    (0, pg_core_1.pgPolicy)("avatar_evolution_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: (0, drizzle_orm_1.sql) `true` }),
    (0, pg_core_1.pgPolicy)("avatar_evolution_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("avatar_evolution_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("avatar_evolution_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);
exports.posts = (0, pg_core_1.pgTable)("posts", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    userId: (0, pg_core_1.varchar)("user_id", { length: 36 }).notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }),
    content: (0, pg_core_1.text)().notNull(),
    images: (0, pg_core_1.jsonb)().default([]),
    videos: (0, pg_core_1.jsonb)().default([]),
    tags: (0, pg_core_1.jsonb)().default([]),
    likesCount: (0, pg_core_1.integer)("likes_count").default(0).notNull(),
    commentsCount: (0, pg_core_1.integer)("comments_count").default(0).notNull(),
    sharesCount: (0, pg_core_1.integer)("shares_count").default(0).notNull(),
    isPublic: (0, pg_core_1.boolean)("is_public").default(true).notNull(),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }),
    isAiGenerated: (0, pg_core_1.boolean)("is_ai_generated").default(false),
}, (table) => [
    (0, pg_core_1.index)("posts_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("posts_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
    (0, pg_core_1.index)("posts_is_public_idx").using("btree", table.isPublic.asc().nullsLast().op("bool_ops")),
    (0, pg_core_1.index)("posts_user_id_idx").using("btree", table.userId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.userId],
        foreignColumns: [exports.users.id],
        name: "posts_user_id_users_id_fk"
    }).onDelete("cascade"),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "posts_avatar_id_avatars_id_fk"
    }).onDelete("set null"),
    (0, pg_core_1.pgPolicy)("posts_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: (0, drizzle_orm_1.sql) `true` }),
    (0, pg_core_1.pgPolicy)("posts_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("posts_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("posts_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);
exports.orders = (0, pg_core_1.pgTable)("orders", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    userId: (0, pg_core_1.varchar)("user_id", { length: 36 }).notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }),
    title: (0, pg_core_1.varchar)({ length: 200 }).notNull(),
    description: (0, pg_core_1.text)(),
    requirements: (0, pg_core_1.jsonb)().default({}),
    budget: (0, pg_core_1.numeric)({ precision: 10, scale: 2 }),
    status: (0, pg_core_1.varchar)({ length: 20 }).default('open').notNull(),
    result: (0, pg_core_1.jsonb)().default({}),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }),
    completedAt: (0, pg_core_1.timestamp)("completed_at", { withTimezone: true, mode: 'string' }),
    latitude: (0, pg_core_1.numeric)(),
    longitude: (0, pg_core_1.numeric)(),
    locationText: (0, pg_core_1.varchar)("location_text"),
    contentType: (0, pg_core_1.varchar)("content_type", { length: 50 }),
    platforms: (0, pg_core_1.text)().array(),
    targetAudience: (0, pg_core_1.text)("target_audience"),
    expectedQuantity: (0, pg_core_1.integer)("expected_quantity").default(1),
    deadline: (0, pg_core_1.timestamp)({ withTimezone: true, mode: 'string' }),
}, (table) => [
    (0, pg_core_1.index)("orders_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("orders_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
    (0, pg_core_1.index)("orders_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("orders_user_id_idx").using("btree", table.userId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.userId],
        foreignColumns: [exports.users.id],
        name: "orders_user_id_users_id_fk"
    }).onDelete("cascade"),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "orders_avatar_id_avatars_id_fk"
    }).onDelete("set null"),
    (0, pg_core_1.pgPolicy)("orders_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: (0, drizzle_orm_1.sql) `true` }),
    (0, pg_core_1.pgPolicy)("orders_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("orders_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("orders_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);
exports.tasks = (0, pg_core_1.pgTable)("tasks", {
    id: (0, pg_core_1.uuid)().defaultRandom().primaryKey().notNull(),
    userId: (0, pg_core_1.text)("user_id").notNull(),
    avatarId: (0, pg_core_1.uuid)("avatar_id"),
    title: (0, pg_core_1.text)().notNull(),
    description: (0, pg_core_1.text)(),
    taskType: (0, pg_core_1.text)("task_type").default('general'),
    priority: (0, pg_core_1.text)().default('normal'),
    status: (0, pg_core_1.text)().default('pending'),
    params: (0, pg_core_1.jsonb)().default({}),
    progress: (0, pg_core_1.integer)().default(0),
    result: (0, pg_core_1.jsonb)(),
    logs: (0, pg_core_1.jsonb)().default([]),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    startedAt: (0, pg_core_1.timestamp)("started_at", { withTimezone: true, mode: 'string' }),
    completedAt: (0, pg_core_1.timestamp)("completed_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
    (0, pg_core_1.index)("idx_tasks_created_at").using("btree", table.createdAt.desc().nullsFirst().op("timestamptz_ops")),
    (0, pg_core_1.index)("idx_tasks_status").using("btree", table.status.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("idx_tasks_user_id").using("btree", table.userId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.pgPolicy)("Allow all access to tasks", { as: "permissive", for: "all", to: ["public"], using: (0, drizzle_orm_1.sql) `true`, withCheck: (0, drizzle_orm_1.sql) `true` }),
]);
exports.likes = (0, pg_core_1.pgTable)("likes", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    userId: (0, pg_core_1.varchar)("user_id", { length: 36 }).notNull(),
    targetType: (0, pg_core_1.varchar)("target_type", { length: 20 }).notNull(),
    targetId: (0, pg_core_1.varchar)("target_id", { length: 36 }).notNull(),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id"),
}, (table) => [
    (0, pg_core_1.index)("likes_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("likes_target_idx").using("btree", table.targetType.asc().nullsLast().op("text_ops"), table.targetId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("likes_user_id_idx").using("btree", table.userId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.userId],
        foreignColumns: [exports.users.id],
        name: "likes_user_id_users_id_fk"
    }).onDelete("cascade"),
    (0, pg_core_1.pgPolicy)("likes_允许公开读取", { as: "permissive", for: "select", to: ["public"], using: (0, drizzle_orm_1.sql) `true` }),
    (0, pg_core_1.pgPolicy)("likes_允许公开写入", { as: "permissive", for: "insert", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("likes_允许公开更新", { as: "permissive", for: "update", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("likes_允许公开删除", { as: "permissive", for: "delete", to: ["public"] }),
]);
exports.notifications = (0, pg_core_1.pgTable)("notifications", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    userId: (0, pg_core_1.varchar)("user_id", { length: 36 }).notNull(),
    type: (0, pg_core_1.varchar)({ length: 20 }).notNull(),
    title: (0, pg_core_1.varchar)({ length: 200 }).notNull(),
    content: (0, pg_core_1.text)().notNull(),
    isRead: (0, pg_core_1.boolean)("is_read").default(false).notNull(),
    data: (0, pg_core_1.jsonb)().default({}),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
    (0, pg_core_1.index)("notifications_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
    (0, pg_core_1.index)("notifications_is_read_idx").using("btree", table.isRead.asc().nullsLast().op("bool_ops")),
    (0, pg_core_1.index)("notifications_user_id_idx").using("btree", table.userId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.userId],
        foreignColumns: [exports.users.id],
        name: "notifications_user_id_fkey"
    }).onDelete("cascade"),
]);
exports.orderExecutions = (0, pg_core_1.pgTable)("order_executions", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    orderId: (0, pg_core_1.varchar)("order_id", { length: 36 }).notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }).notNull(),
    stepType: (0, pg_core_1.varchar)("step_type", { length: 50 }).notNull(),
    stepName: (0, pg_core_1.varchar)("step_name", { length: 200 }).notNull(),
    status: (0, pg_core_1.varchar)({ length: 20 }).default('pending').notNull(),
    result: (0, pg_core_1.jsonb)().default({}),
    startedAt: (0, pg_core_1.timestamp)("started_at", { withTimezone: true, mode: 'string' }),
    completedAt: (0, pg_core_1.timestamp)("completed_at", { withTimezone: true, mode: 'string' }),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    stepNumber: (0, pg_core_1.integer)("step_number").default(1).notNull(),
    description: (0, pg_core_1.text)(),
}, (table) => [
    (0, pg_core_1.index)("idx_order_executions_avatar_id").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("idx_order_executions_order_id").using("btree", table.orderId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("idx_order_executions_status").using("btree", table.status.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("order_executions_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("order_executions_order_id_idx").using("btree", table.orderId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.orderId],
        foreignColumns: [exports.orders.id],
        name: "order_executions_order_id_fkey"
    }).onDelete("cascade"),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "order_executions_avatar_id_fkey"
    }).onDelete("cascade"),
]);
exports.earnings = (0, pg_core_1.pgTable)("earnings", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    userId: (0, pg_core_1.varchar)("user_id", { length: 36 }).notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }),
    orderId: (0, pg_core_1.varchar)("order_id", { length: 36 }),
    type: (0, pg_core_1.varchar)({ length: 20 }).notNull(),
    amount: (0, pg_core_1.numeric)({ precision: 10, scale: 2 }).notNull(),
    status: (0, pg_core_1.varchar)({ length: 20 }).default('pending').notNull(),
    description: (0, pg_core_1.text)(),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
    (0, pg_core_1.index)("earnings_order_id_idx").using("btree", table.orderId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("earnings_user_id_idx").using("btree", table.userId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.userId],
        foreignColumns: [exports.users.id],
        name: "earnings_user_id_fkey"
    }).onDelete("cascade"),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "earnings_avatar_id_fkey"
    }).onDelete("set null"),
    (0, pg_core_1.foreignKey)({
        columns: [table.orderId],
        foreignColumns: [exports.orders.id],
        name: "earnings_order_id_fkey"
    }).onDelete("set null"),
]);
exports.withdrawals = (0, pg_core_1.pgTable)("withdrawals", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    userId: (0, pg_core_1.varchar)("user_id", { length: 36 }).notNull(),
    amount: (0, pg_core_1.numeric)({ precision: 10, scale: 2 }).notNull(),
    status: (0, pg_core_1.varchar)({ length: 20 }).default('pending').notNull(),
    method: (0, pg_core_1.varchar)({ length: 20 }).notNull(),
    accountInfo: (0, pg_core_1.jsonb)("account_info").default({}),
    transactionId: (0, pg_core_1.varchar)("transaction_id", { length: 100 }),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    processedAt: (0, pg_core_1.timestamp)("processed_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
    (0, pg_core_1.index)("withdrawals_user_id_idx").using("btree", table.userId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.userId],
        foreignColumns: [exports.users.id],
        name: "withdrawals_user_id_fkey"
    }).onDelete("cascade"),
]);
exports.referrals = (0, pg_core_1.pgTable)("referrals", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    inviterId: (0, pg_core_1.varchar)("inviter_id", { length: 36 }).notNull(),
    inviteeId: (0, pg_core_1.varchar)("invitee_id", { length: 36 }).notNull(),
    inviteeOpenid: (0, pg_core_1.varchar)("invitee_openid", { length: 100 }),
    status: (0, pg_core_1.varchar)({ length: 20 }).default('registered').notNull(),
    rewardAmount: (0, pg_core_1.numeric)("reward_amount", { precision: 10, scale: 2 }).default('0'),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    rewardedAt: (0, pg_core_1.timestamp)("rewarded_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
    (0, pg_core_1.index)("referrals_invitee_id_idx").using("btree", table.inviteeId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("referrals_inviter_id_idx").using("btree", table.inviterId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.inviterId],
        foreignColumns: [exports.users.id],
        name: "referrals_inviter_id_fkey"
    }).onDelete("cascade"),
    (0, pg_core_1.foreignKey)({
        columns: [table.inviteeId],
        foreignColumns: [exports.users.id],
        name: "referrals_invitee_id_fkey"
    }).onDelete("cascade"),
    (0, pg_core_1.unique)("referrals_invitee_id_key").on(table.inviteeId),
]);
exports.platformConfigs = (0, pg_core_1.pgTable)("platform_configs", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    userId: (0, pg_core_1.varchar)("user_id", { length: 36 }).notNull(),
    platformType: (0, pg_core_1.varchar)("platform_type", { length: 30 }).notNull(),
    configData: (0, pg_core_1.jsonb)("config_data").default({}),
    status: (0, pg_core_1.varchar)({ length: 20 }).default('active').notNull(),
    lastUsedAt: (0, pg_core_1.timestamp)("last_used_at", { withTimezone: true, mode: 'string' }),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
    (0, pg_core_1.index)("platform_configs_platform_type_idx").using("btree", table.platformType.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("platform_configs_user_id_idx").using("btree", table.userId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.uniqueIndex)("platform_configs_user_platform_idx").using("btree", table.userId.asc().nullsLast().op("text_ops"), table.platformType.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.userId],
        foreignColumns: [exports.users.id],
        name: "platform_configs_user_id_fkey"
    }).onDelete("cascade"),
]);
exports.avatarAccounts = (0, pg_core_1.pgTable)("avatar_accounts", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }).notNull(),
    platform: (0, pg_core_1.varchar)({ length: 30 }).notNull(),
    accountName: (0, pg_core_1.varchar)("account_name", { length: 100 }),
    followers: (0, pg_core_1.integer)().default(0).notNull(),
    totalExposure: (0, pg_core_1.integer)("total_exposure").default(0).notNull(),
    totalWorks: (0, pg_core_1.integer)("total_works").default(0).notNull(),
    avgLikesPerWork: (0, pg_core_1.integer)("avg_likes_per_work").default(0).notNull(),
    avgCommentsPerWork: (0, pg_core_1.integer)("avg_comments_per_work").default(0).notNull(),
    avgSharesPerWork: (0, pg_core_1.integer)("avg_shares_per_work").default(0).notNull(),
    engagementRate: (0, pg_core_1.numeric)("engagement_rate", { precision: 5, scale: 2 }).default('0'),
    lastUpdatedAt: (0, pg_core_1.timestamp)("last_updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    appid: (0, pg_core_1.varchar)(),
    appkey: (0, pg_core_1.varchar)(),
    accountUrl: (0, pg_core_1.text)("account_url"),
    extraInfo: (0, pg_core_1.jsonb)("extra_info"),
}, (table) => [
    (0, pg_core_1.index)("avatar_accounts_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("avatar_accounts_followers_idx").using("btree", table.followers.asc().nullsLast().op("int4_ops")),
    (0, pg_core_1.index)("avatar_accounts_platform_idx").using("btree", table.platform.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("avatar_accounts_total_exposure_idx").using("btree", table.totalExposure.asc().nullsLast().op("int4_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "avatar_accounts_avatar_id_fkey"
    }).onDelete("cascade"),
]);
exports.avatarSkills = (0, pg_core_1.pgTable)("avatar_skills", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }).notNull(),
    skillType: (0, pg_core_1.varchar)("skill_type", { length: 50 }).notNull(),
    skillLevel: (0, pg_core_1.integer)("skill_level").default(1).notNull(),
    usageCount: (0, pg_core_1.integer)("usage_count").default(0).notNull(),
    lastUsedAt: (0, pg_core_1.timestamp)("last_used_at", { withTimezone: true, mode: 'string' }),
    metadata: (0, pg_core_1.jsonb)().default({}),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
    (0, pg_core_1.index)("avatar_skills_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.uniqueIndex)("avatar_skills_avatar_skill_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops"), table.skillType.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("avatar_skills_skill_type_idx").using("btree", table.skillType.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "avatar_skills_avatar_id_fkey"
    }).onDelete("cascade"),
]);
exports.avatarFriends = (0, pg_core_1.pgTable)("avatar_friends", {
    id: (0, pg_core_1.serial)().primaryKey().notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id").notNull(),
    friendAvatarId: (0, pg_core_1.varchar)("friend_avatar_id").notNull(),
    status: (0, pg_core_1.varchar)().default('pending'),
    matchReason: (0, pg_core_1.text)("match_reason"),
    compatibilityScore: (0, pg_core_1.numeric)("compatibility_score", { precision: 5, scale: 2 }),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    conversationId: (0, pg_core_1.varchar)("conversation_id"),
    benefits: (0, pg_core_1.text)(),
}, (table) => [
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "avatar_friends_avatar_id_fkey"
    }).onDelete("cascade"),
    (0, pg_core_1.foreignKey)({
        columns: [table.friendAvatarId],
        foreignColumns: [exports.avatars.id],
        name: "avatar_friends_friend_avatar_id_fkey"
    }).onDelete("cascade"),
    (0, pg_core_1.unique)("avatar_friends_avatar_id_friend_avatar_id_key").on(table.avatarId, table.friendAvatarId),
]);
exports.agentTaskLogs = (0, pg_core_1.pgTable)("agent_task_logs", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    taskId: (0, pg_core_1.varchar)("task_id", { length: 36 }).notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }).notNull(),
    stepIndex: (0, pg_core_1.integer)("step_index").notNull(),
    stepType: (0, pg_core_1.varchar)("step_type", { length: 20 }).notNull(),
    content: (0, pg_core_1.text)(),
    toolName: (0, pg_core_1.varchar)("tool_name", { length: 100 }),
    toolParams: (0, pg_core_1.jsonb)("tool_params").default({}),
    toolResult: (0, pg_core_1.jsonb)("tool_result").default({}),
    requiresConfig: (0, pg_core_1.boolean)("requires_config").default(false),
    configPlatform: (0, pg_core_1.varchar)("config_platform", { length: 30 }),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
    (0, pg_core_1.index)("agent_task_logs_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("agent_task_logs_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
    (0, pg_core_1.index)("agent_task_logs_task_id_idx").using("btree", table.taskId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "agent_task_logs_avatar_id_fkey"
    }).onDelete("cascade"),
]);
exports.subscriptionPlans = (0, pg_core_1.pgTable)("subscription_plans", {
    id: (0, pg_core_1.uuid)().defaultRandom().primaryKey().notNull(),
    name: (0, pg_core_1.text)().notNull(),
    description: (0, pg_core_1.text)(),
    price: (0, pg_core_1.numeric)({ precision: 10, scale: 2 }).default('0').notNull(),
    durationDays: (0, pg_core_1.integer)("duration_days").notNull(),
    maxAvatars: (0, pg_core_1.integer)("max_avatars").default(1).notNull(),
    canReceiveOrders: (0, pg_core_1.boolean)("can_receive_orders").default(false).notNull(),
    orderPriority: (0, pg_core_1.integer)("order_priority").default(0).notNull(),
    features: (0, pg_core_1.jsonb)().default({}),
    displayOrder: (0, pg_core_1.integer)("display_order").default(0).notNull(),
    isActive: (0, pg_core_1.boolean)("is_active").default(true).notNull(),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
}, (table) => [
    (0, pg_core_1.index)("idx_subscription_plans_display_order").using("btree", table.displayOrder.asc().nullsLast().op("int4_ops")),
    (0, pg_core_1.index)("idx_subscription_plans_is_active").using("btree", table.isActive.asc().nullsLast().op("bool_ops")),
]);
exports.userSubscriptions = (0, pg_core_1.pgTable)("user_subscriptions", {
    id: (0, pg_core_1.uuid)().defaultRandom().primaryKey().notNull(),
    userId: (0, pg_core_1.varchar)("user_id", { length: 255 }).notNull(),
    planId: (0, pg_core_1.uuid)("plan_id").notNull(),
    startDate: (0, pg_core_1.timestamp)("start_date", { withTimezone: true, mode: 'string' }).notNull(),
    endDate: (0, pg_core_1.timestamp)("end_date", { withTimezone: true, mode: 'string' }).notNull(),
    status: (0, pg_core_1.varchar)({ length: 50 }).default('active').notNull(),
    paymentId: (0, pg_core_1.varchar)("payment_id", { length: 255 }),
    paymentMethod: (0, pg_core_1.varchar)("payment_method", { length: 50 }),
    autoRenew: (0, pg_core_1.boolean)("auto_renew").default(false),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
}, (table) => [
    (0, pg_core_1.index)("idx_user_subscriptions_plan_id").using("btree", table.planId.asc().nullsLast().op("uuid_ops")),
    (0, pg_core_1.index)("idx_user_subscriptions_status").using("btree", table.status.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("idx_user_subscriptions_user_id").using("btree", table.userId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.planId],
        foreignColumns: [exports.subscriptionPlans.id],
        name: "user_subscriptions_plan_id_fkey"
    }),
    (0, pg_core_1.pgPolicy)("允许所有人读取用户订阅", { as: "permissive", for: "select", to: ["public"], using: (0, drizzle_orm_1.sql) `true` }),
    (0, pg_core_1.pgPolicy)("允许所有人插入用户订阅", { as: "permissive", for: "insert", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("允许所有人更新用户订阅", { as: "permissive", for: "update", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("允许所有人删除用户订阅", { as: "permissive", for: "delete", to: ["public"] }),
]);
exports.avatarSubscriptions = (0, pg_core_1.pgTable)("avatar_subscriptions", {
    id: (0, pg_core_1.varchar)({ length: 255 }).default((0, drizzle_orm_1.sql) `(gen_random_uuid())::character varying(255)`).primaryKey().notNull(),
    userId: (0, pg_core_1.varchar)("user_id", { length: 255 }).notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 255 }).notNull(),
    subscriptionId: (0, pg_core_1.varchar)("subscription_id", { length: 255 }),
    subscriptionLevel: (0, pg_core_1.varchar)("subscription_level", { length: 50 }).default('free').notNull(),
    canReceiveOrders: (0, pg_core_1.boolean)("can_receive_orders").default(false),
    orderPriority: (0, pg_core_1.integer)("order_priority").default(0),
    isActive: (0, pg_core_1.boolean)("is_active").default(true),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
}, (table) => [
    (0, pg_core_1.index)("idx_avatar_subscriptions_avatar_id").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("idx_avatar_subscriptions_subscription_id").using("btree", table.subscriptionId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("idx_avatar_subscriptions_subscription_level").using("btree", table.subscriptionLevel.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("idx_avatar_subscriptions_user_id").using("btree", table.userId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.pgPolicy)("允许所有人读取分身订阅", { as: "permissive", for: "select", to: ["public"], using: (0, drizzle_orm_1.sql) `true` }),
    (0, pg_core_1.pgPolicy)("允许所有人插入分身订阅", { as: "permissive", for: "insert", to: ["public"] }),
    (0, pg_core_1.pgPolicy)("允许所有人更新分身订阅", { as: "permissive", for: "update", to: ["public"] }),
]);
exports.avatarMemories = (0, pg_core_1.pgTable)("avatar_memories", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }).notNull(),
    memoryType: (0, pg_core_1.varchar)("memory_type", { length: 50 }).notNull(),
    content: (0, pg_core_1.text)().notNull(),
    embedding: (0, pg_core_1.jsonb)(),
    metadata: (0, pg_core_1.jsonb)().default({}),
    accessCount: (0, pg_core_1.integer)("access_count").default(0).notNull(),
    lastAccessedAt: (0, pg_core_1.timestamp)("last_accessed_at", { withTimezone: true, mode: 'string' }),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
    (0, pg_core_1.index)("avatar_memories_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("avatar_memories_memory_type_idx").using("btree", table.memoryType.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "avatar_memories_avatar_id_fkey"
    }).onDelete("cascade"),
]);
exports.avatarContexts = (0, pg_core_1.pgTable)("avatar_contexts", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }).notNull(),
    contextType: (0, pg_core_1.varchar)("context_type", { length: 50 }).notNull(),
    contextData: (0, pg_core_1.jsonb)("context_data").notNull(),
    priority: (0, pg_core_1.integer)().default(0).notNull(),
    expiresAt: (0, pg_core_1.timestamp)("expires_at", { withTimezone: true, mode: 'string' }),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
    (0, pg_core_1.index)("avatar_contexts_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("avatar_contexts_context_type_idx").using("btree", table.contextType.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("avatar_contexts_priority_idx").using("btree", table.priority.asc().nullsLast().op("int4_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "avatar_contexts_avatar_id_fkey"
    }).onDelete("cascade"),
]);
exports.avatarAgentConfigs = (0, pg_core_1.pgTable)("avatar_agent_configs", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }).notNull(),
    systemPrompt: (0, pg_core_1.text)("system_prompt").notNull(),
    rolePrompt: (0, pg_core_1.text)("role_prompt"),
    temperature: (0, pg_core_1.numeric)({ precision: 3, scale: 2 }).default('0.7'),
    maxTokens: (0, pg_core_1.integer)("max_tokens").default(2000),
    enabledTools: (0, pg_core_1.jsonb)("enabled_tools").default([]).notNull(),
    knowledgeBases: (0, pg_core_1.jsonb)("knowledge_bases").default([]).notNull(),
    reasoningMode: (0, pg_core_1.varchar)("reasoning_mode", { length: 50 }).default('react').notNull(),
    learningEnabled: (0, pg_core_1.boolean)("learning_enabled").default(true).notNull(),
    memoryConfig: (0, pg_core_1.jsonb)("memory_config").default({}).notNull(),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
    (0, pg_core_1.index)("avatar_agent_configs_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "avatar_agent_configs_avatar_id_fkey"
    }).onDelete("cascade"),
    (0, pg_core_1.unique)("avatar_agent_configs_avatar_id_key").on(table.avatarId),
]);
exports.avatarLearningRecords = (0, pg_core_1.pgTable)("avatar_learning_records", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }).notNull(),
    learningType: (0, pg_core_1.varchar)("learning_type", { length: 50 }).notNull(),
    inputData: (0, pg_core_1.jsonb)("input_data").notNull(),
    outputData: (0, pg_core_1.jsonb)("output_data").notNull(),
    feedbackScore: (0, pg_core_1.integer)("feedback_score"),
    learnedKnowledge: (0, pg_core_1.text)("learned_knowledge"),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
    (0, pg_core_1.index)("avatar_learning_records_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("avatar_learning_records_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
    (0, pg_core_1.index)("avatar_learning_records_learning_type_idx").using("btree", table.learningType.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "avatar_learning_records_avatar_id_fkey"
    }).onDelete("cascade"),
]);
exports.skills = (0, pg_core_1.pgTable)("skills", {
    id: (0, pg_core_1.uuid)().defaultRandom().primaryKey().notNull(),
    name: (0, pg_core_1.text)().notNull(),
    description: (0, pg_core_1.text)().notNull(),
    category: (0, pg_core_1.text)().notNull(),
    price: (0, pg_core_1.numeric)({ precision: 10, scale: 2 }).default('0.00').notNull(),
    icon: (0, pg_core_1.text)(),
    tags: (0, pg_core_1.jsonb)().default([]),
    capabilities: (0, pg_core_1.jsonb)().default({}),
    requirements: (0, pg_core_1.text)(),
    status: (0, pg_core_1.text)().default('active'),
    rating: (0, pg_core_1.numeric)({ precision: 3, scale: 2 }).default('0.00'),
    ratingCount: (0, pg_core_1.integer)("rating_count").default(0),
    purchaseCount: (0, pg_core_1.integer)("purchase_count").default(0),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    toolName: (0, pg_core_1.text)("tool_name"),
    type: (0, pg_core_1.text)().default('prebuilt'),
}, (table) => [
    (0, pg_core_1.check)("skills_type_check", (0, drizzle_orm_1.sql) `type = ANY (ARRAY['prebuilt'::text, 'custom'::text, 'paid'::text])`),
]);
exports.avatarBlocks = (0, pg_core_1.pgTable)("avatar_blocks", {
    id: (0, pg_core_1.integer)().primaryKey().generatedAlwaysAsIdentity({ name: "avatar_blocks_id_seq", startWith: 1, increment: 1, minValue: 1, maxValue: 2147483647, cache: 1 }),
    avatarId: (0, pg_core_1.varchar)("avatar_id").notNull(),
    blockedAvatarId: (0, pg_core_1.varchar)("blocked_avatar_id").notNull(),
    reason: (0, pg_core_1.text)(),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
}, (table) => [
    (0, pg_core_1.unique)("unique_block").on(table.avatarId, table.blockedAvatarId),
    (0, pg_core_1.check)("not_self_block", (0, drizzle_orm_1.sql) `(avatar_id)::text <> (blocked_avatar_id)::text`),
]);
exports.orderDispatchRequests = (0, pg_core_1.pgTable)("order_dispatch_requests", {
    id: (0, pg_core_1.uuid)().defaultRandom().primaryKey().notNull(),
    orderId: (0, pg_core_1.uuid)("order_id").notNull(),
    avatarId: (0, pg_core_1.uuid)("avatar_id").notNull(),
    userId: (0, pg_core_1.uuid)("user_id").notNull(),
    status: (0, pg_core_1.varchar)({ length: 20 }).default('pending').notNull(),
    score: (0, pg_core_1.integer)().default(0),
    matchReasons: (0, pg_core_1.text)("match_reasons").array(),
    expiresAt: (0, pg_core_1.timestamp)("expires_at", { withTimezone: true, mode: 'string' }),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    generatedContent: (0, pg_core_1.text)("generated_content"),
    confirmedContent: (0, pg_core_1.text)("confirmed_content"),
    publishStatus: (0, pg_core_1.jsonb)("publish_status"),
    publishFeedback: (0, pg_core_1.jsonb)("publish_feedback"),
});
exports.generatedContent = (0, pg_core_1.pgTable)("generated_content", {
    id: (0, pg_core_1.uuid)().defaultRandom().primaryKey().notNull(),
    orderId: (0, pg_core_1.uuid)("order_id").notNull(),
    requestId: (0, pg_core_1.uuid)("request_id").notNull(),
    avatarId: (0, pg_core_1.uuid)("avatar_id").notNull(),
    platform: (0, pg_core_1.text)().notNull(),
    title: (0, pg_core_1.text)(),
    content: (0, pg_core_1.text)().notNull(),
    hashtags: (0, pg_core_1.jsonb)().default([]),
    imageSuggestions: (0, pg_core_1.jsonb)("image_suggestions").default([]),
    videoSuggestions: (0, pg_core_1.jsonb)("video_suggestions").default([]),
    status: (0, pg_core_1.text)().default('draft'),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
}, (table) => [
    (0, pg_core_1.index)("idx_generated_content_avatar_id").using("btree", table.avatarId.asc().nullsLast().op("uuid_ops")),
    (0, pg_core_1.index)("idx_generated_content_order_id").using("btree", table.orderId.asc().nullsLast().op("uuid_ops")),
    (0, pg_core_1.index)("idx_generated_content_request_id").using("btree", table.requestId.asc().nullsLast().op("uuid_ops")),
    (0, pg_core_1.index)("idx_generated_content_status").using("btree", table.status.asc().nullsLast().op("text_ops")),
]);
exports.avatarFollows = (0, pg_core_1.pgTable)("avatar_follows", {
    id: (0, pg_core_1.uuid)().defaultRandom().primaryKey().notNull(),
    avatarId: (0, pg_core_1.uuid)("avatar_id").notNull(),
    targetAvatarId: (0, pg_core_1.uuid)("target_avatar_id").notNull(),
    followLevel: (0, pg_core_1.varchar)("follow_level", { length: 50 }).default('normal'),
    followReason: (0, pg_core_1.text)("follow_reason"),
    interactionScore: (0, pg_core_1.numeric)("interaction_score", { precision: 5, scale: 2 }).default('0'),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
}, (table) => [
    (0, pg_core_1.unique)("avatar_follows_avatar_id_target_avatar_id_key").on(table.avatarId, table.targetAvatarId),
]);
exports.avatarAffinity = (0, pg_core_1.pgTable)("avatar_affinity", {
    id: (0, pg_core_1.uuid)().defaultRandom().primaryKey().notNull(),
    avatarId: (0, pg_core_1.uuid)("avatar_id").notNull(),
    targetAvatarId: (0, pg_core_1.uuid)("target_avatar_id").notNull(),
    affinityScore: (0, pg_core_1.numeric)("affinity_score", { precision: 5, scale: 2 }).default('0'),
    trustScore: (0, pg_core_1.numeric)("trust_score", { precision: 5, scale: 2 }).default('0'),
    sharedInterests: (0, pg_core_1.jsonb)("shared_interests"),
    personalityCompatibility: (0, pg_core_1.numeric)("personality_compatibility", { precision: 5, scale: 2 }).default('0'),
    potentialValue: (0, pg_core_1.text)("potential_value"),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
}, (table) => [
    (0, pg_core_1.unique)("avatar_affinity_avatar_id_target_avatar_id_key").on(table.avatarId, table.targetAvatarId),
]);
exports.publishedWorks = (0, pg_core_1.pgTable)("published_works", {
    id: (0, pg_core_1.varchar)({ length: 36 }).default(gen_random_uuid()).primaryKey().notNull(),
    orderId: (0, pg_core_1.varchar)("order_id", { length: 36 }).notNull(),
    avatarId: (0, pg_core_1.varchar)("avatar_id", { length: 36 }).notNull(),
    platform: (0, pg_core_1.varchar)({ length: 30 }).notNull(),
    workTitle: (0, pg_core_1.varchar)("work_title", { length: 500 }),
    workUrl: (0, pg_core_1.varchar)("work_url", { length: 1000 }).notNull(),
    authorNickname: (0, pg_core_1.varchar)("author_nickname", { length: 200 }),
    coverImage: (0, pg_core_1.varchar)("cover_image", { length: 1000 }),
    description: (0, pg_core_1.text)(),
    extraData: (0, pg_core_1.jsonb)("extra_data").default({}),
    status: (0, pg_core_1.varchar)({ length: 20 }).default('verified').notNull(),
    feedbackImage: (0, pg_core_1.varchar)("feedback_image", { length: 1000 }),
    createdAt: (0, pg_core_1.timestamp)("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
    (0, pg_core_1.index)("published_works_avatar_id_idx").using("btree", table.avatarId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("published_works_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
    (0, pg_core_1.index)("published_works_order_id_idx").using("btree", table.orderId.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("published_works_platform_idx").using("btree", table.platform.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.index)("published_works_work_url_idx").using("btree", table.workUrl.asc().nullsLast().op("text_ops")),
    (0, pg_core_1.foreignKey)({
        columns: [table.orderId],
        foreignColumns: [exports.orders.id],
        name: "published_works_order_id_fkey"
    }).onDelete("cascade"),
    (0, pg_core_1.foreignKey)({
        columns: [table.avatarId],
        foreignColumns: [exports.avatars.id],
        name: "published_works_avatar_id_fkey"
    }).onDelete("cascade"),
]);
//# sourceMappingURL=schema.js.map