import type { Pool } from 'mysql2/promise';
export interface QueryResult {
    data: any[] | null;
    error: Error | null;
}
export interface SingleQueryResult {
    data: any | null;
    error: Error | null;
}
export interface InsertResult {
    data: {
        id: string;
    } | null;
    error: Error | null;
}
export interface CountResult {
    data: number | null;
    error: Error | null;
}
export interface UpdateResult {
    data: {
        affectedRows: number;
    } | null;
    error: Error | null;
}
export interface DeleteResult {
    data: {
        affectedRows: number;
    } | null;
    error: Error | null;
}
declare function getPool(): Pool;
declare class QueryBuilder {
    private tableName;
    private jsonFields;
    private conditions;
    private conditionValues;
    private selectedColumns;
    private orderByClause;
    private limitClause;
    private offsetClause;
    private groupByClause;
    private joinClause;
    constructor(tableName: string, jsonFields?: string[]);
    where(conditions: Record<string, any>, operator?: string): this;
    whereIn(column: string, values: any[]): this;
    select(columns: string): this;
    orderBy(column: string, direction?: 'ASC' | 'DESC'): this;
    limit(count: number): this;
    offset(count: number): this;
    groupBy(column: string): this;
    join(table: string, condition: string, type?: 'LEFT' | 'RIGHT' | 'INNER'): this;
    first(): Promise<SingleQueryResult>;
    then(resolve: (value: QueryResult) => void): Promise<void>;
    execute(): Promise<QueryResult>;
    count(): Promise<{
        data: number | null;
        error: Error | null;
    }>;
    update(data: Record<string, any>): Promise<UpdateResult>;
    delete(): Promise<UpdateResult>;
}
export declare class MysqlClient {
    private tableName;
    private jsonFields;
    constructor(tableName: string, jsonFields?: string[]);
    select(columns?: string): QueryBuilder;
    where(conditions: Record<string, any>, operator?: string): QueryBuilder;
    whereIn(column: string, values: any[]): QueryBuilder;
    findById(id: string): Promise<QueryResult>;
    insert(data: Record<string, any>): Promise<InsertResult>;
    update(id: string, data: Record<string, any>): Promise<UpdateResult>;
    upsert(data: Record<string, any>, uniqueKey?: string): Promise<InsertResult>;
    delete(id: string): Promise<UpdateResult>;
    query(sql: string, params?: any[]): Promise<QueryResult>;
}
export declare function usersTable(): MysqlClient;
export declare function avatarsTable(): MysqlClient;
export declare function conversationsTable(): MysqlClient;
export declare function messagesTable(): MysqlClient;
export declare function commentsTable(): MysqlClient;
export declare function followsTable(): MysqlClient;
export declare function postsTable(): MysqlClient;
export declare function ordersTable(): MysqlClient;
export declare function orderResultsTable(): MysqlClient;
export declare function tasksTable(): MysqlClient;
export declare function likesTable(): MysqlClient;
export declare function notificationsTable(): MysqlClient;
export declare function earningsTable(): MysqlClient;
export declare function withdrawalRequestsTable(): MysqlClient;
export declare function healthCheckTable(): MysqlClient;
export { getPool };
export declare function query(sql: string, params?: any[]): Promise<QueryResult>;
export declare function insert(sql: string, params?: any[]): Promise<InsertResult>;
export declare function updateData(sql: string, params?: any[]): Promise<UpdateResult>;
export declare function execute(sql: string, params?: any[]): Promise<QueryResult>;
export declare function skillsTable(): MysqlClient;
export declare function avatarSkillsTable(): MysqlClient;
export declare function skillReviewsTable(): void;
export declare function friendshipsTable(): MysqlClient;
export declare function avatarOrdersTable(): MysqlClient;
export declare function orderItemsTable(): MysqlClient;
