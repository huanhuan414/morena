import type { Pool } from 'mysql2/promise';
interface QueryResult {
    data: any[] | null;
    error: Error | null;
}
interface InsertResult {
    data: {
        id: string;
    } | null;
    error: Error | null;
}
interface UpdateResult {
    data: {
        affected_rows: number;
    } | null;
    error: Error | null;
}
declare function getPool(): Pool;
export declare class MysqlClient {
    private tableName;
    private jsonFields;
    constructor(tableName: string, jsonFields?: string[]);
    select(columns?: string): Promise<QueryResult>;
    where(conditions: Record<string, any>, operator?: string): Promise<QueryResult>;
    findById(id: string): Promise<QueryResult>;
    insert(data: Record<string, any>): Promise<InsertResult>;
    update(id: string, data: Record<string, any>): Promise<UpdateResult>;
    upsert(data: Record<string, any>, uniqueKey?: string): Promise<InsertResult>;
    delete(id: string): Promise<UpdateResult>;
    query(sql: string, params?: any[]): Promise<QueryResult>;
}
export declare function usersTable(): MysqlClient;
export declare function avatarsTable(): MysqlClient;
export declare function conversationsTable(): MysqlClient;
export declare function messagesTable(): MysqlClient;
export declare function commentsTable(): MysqlClient;
export declare function followsTable(): MysqlClient;
export declare function postsTable(): MysqlClient;
export declare function ordersTable(): MysqlClient;
export declare function orderResultsTable(): MysqlClient;
export declare function tasksTable(): MysqlClient;
export declare function likesTable(): MysqlClient;
export declare function notificationsTable(): MysqlClient;
export declare function earningsTable(): MysqlClient;
export declare function withdrawalRequestsTable(): MysqlClient;
export declare function healthCheckTable(): MysqlClient;
export { getPool };
