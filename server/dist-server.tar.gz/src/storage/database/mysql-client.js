"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MysqlClient = void 0;
exports.usersTable = usersTable;
exports.avatarsTable = avatarsTable;
exports.conversationsTable = conversationsTable;
exports.messagesTable = messagesTable;
exports.commentsTable = commentsTable;
exports.followsTable = followsTable;
exports.postsTable = postsTable;
exports.ordersTable = ordersTable;
exports.orderResultsTable = orderResultsTable;
exports.tasksTable = tasksTable;
exports.likesTable = likesTable;
exports.notificationsTable = notificationsTable;
exports.earningsTable = earningsTable;
exports.withdrawalRequestsTable = withdrawalRequestsTable;
exports.healthCheckTable = healthCheckTable;
exports.getPool = getPool;
const mysql = require("mysql2/promise");
const uuid_1 = require("uuid");
let pool = null;
let envLoaded = false;
function loadEnv() {
    if (envLoaded)
        return;
    try {
        const fs = require('fs');
        const path = require('path');
        const envPath = path.join(process.cwd(), '.env');
        if (fs.existsSync(envPath)) {
            const content = fs.readFileSync(envPath, 'utf-8');
            const lines = content.split('\n');
            for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed || trimmed.startsWith('#'))
                    continue;
                const eqIndex = trimmed.indexOf('=');
                if (eqIndex > 0) {
                    const key = trimmed.substring(0, eqIndex);
                    const value = trimmed.substring(eqIndex + 1);
                    if (!process.env[key]) {
                        process.env[key] = value;
                    }
                }
            }
        }
    }
    catch {
    }
    envLoaded = true;
}
function getMysqlConfig() {
    loadEnv();
    const host = process.env.MYSQL_HOST || '127.0.0.1';
    const port = parseInt(process.env.MYSQL_PORT || '3306');
    const user = process.env.MYSQL_USER || 'root';
    const password = process.env.MYSQL_PASSWORD || '';
    const database = process.env.MYSQL_DATABASE || 'mrl';
    return { host, port, user, password, database };
}
function getPool() {
    if (!pool) {
        const config = getMysqlConfig();
        pool = mysql.createPool({
            host: config.host,
            port: config.port,
            user: config.user,
            password: config.password,
            database: config.database,
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0,
            timezone: '+08:00',
        });
    }
    return pool;
}
function toSnakeCase(str) {
    return str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
}
function toCamelCase(str) {
    return str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
}
function convertKeysToCamel(obj) {
    if (obj === null || obj === undefined)
        return obj;
    if (Array.isArray(obj)) {
        return obj.map(convertKeysToCamel);
    }
    if (typeof obj === 'object') {
        const result = {};
        for (const key in obj) {
            result[toCamelCase(key)] = convertKeysToCamel(obj[key]);
        }
        return result;
    }
    return obj;
}
function convertKeysToSnake(obj) {
    if (obj === null || obj === undefined)
        return obj;
    if (Array.isArray(obj)) {
        return obj.map(convertKeysToSnake);
    }
    if (typeof obj === 'object') {
        const result = {};
        for (const key in obj) {
            result[toSnakeCase(key)] = convertKeysToSnake(obj[key]);
        }
        return result;
    }
    return obj;
}
function parseJsonFields(row, jsonFields) {
    if (!row)
        return row;
    const result = { ...row };
    for (const field of jsonFields) {
        if (result[field] && typeof result[field] === 'string') {
            try {
                result[field] = JSON.parse(result[field]);
            }
            catch {
            }
        }
    }
    return result;
}
class MysqlClient {
    constructor(tableName, jsonFields = []) {
        this.jsonFields = [];
        this.tableName = tableName;
        this.jsonFields = jsonFields;
    }
    async select(columns = '*') {
        try {
            const pool = getPool();
            const [rows] = await pool.query(`SELECT ${columns} FROM ${this.tableName}`);
            const data = rows.map(row => {
                const converted = convertKeysToCamel(row);
                return parseJsonFields(converted, this.jsonFields);
            });
            return { data, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async where(conditions, operator = '=') {
        try {
            const pool = getPool();
            const keys = Object.keys(conditions);
            const clauses = keys.map(key => `${toSnakeCase(key)} ${operator} ?`).join(' AND ');
            const values = keys.map(key => {
                const val = conditions[key];
                if (typeof val === 'object' && val !== null) {
                    return JSON.stringify(val);
                }
                return val;
            });
            const [rows] = await pool.query(`SELECT * FROM ${this.tableName} WHERE ${clauses}`, values);
            const data = rows.map(row => {
                const converted = convertKeysToCamel(row);
                return parseJsonFields(converted, this.jsonFields);
            });
            return { data, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async findById(id) {
        try {
            const pool = getPool();
            const [rows] = await pool.query(`SELECT * FROM ${this.tableName} WHERE id = ?`, [id]);
            if (rows.length === 0) {
                return { data: null, error: null };
            }
            const converted = convertKeysToCamel(rows[0]);
            const data = parseJsonFields(converted, this.jsonFields);
            return { data, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async insert(data) {
        try {
            const pool = getPool();
            const id = data.id || (0, uuid_1.v4)();
            const { id: _, ...restData } = data;
            const keys = Object.keys(restData);
            const snakeData = convertKeysToSnake(restData);
            const columns = ['id', ...keys.map(k => toSnakeCase(k))].join(', ');
            const placeholders = ['?', ...keys.map(() => '?')].join(', ');
            const values = [id, ...keys.map(k => {
                    const val = snakeData[toSnakeCase(k)];
                    if (typeof val === 'object' && val !== null) {
                        return JSON.stringify(val);
                    }
                    return val;
                })];
            await pool.query(`INSERT INTO ${this.tableName} (${columns}) VALUES (${placeholders})`, values);
            return { data: { id }, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async update(id, data) {
        try {
            const pool = getPool();
            const keys = Object.keys(data);
            const snakeData = convertKeysToSnake(data);
            const setClause = keys.map(k => `${toSnakeCase(k)} = ?`).join(', ');
            const values = [...keys.map(k => {
                    const val = snakeData[k];
                    if (typeof val === 'object' && val !== null) {
                        return JSON.stringify(val);
                    }
                    return val;
                }), id];
            const [result] = await pool.query(`UPDATE ${this.tableName} SET ${setClause} WHERE id = ?`, values);
            return { data: { affected_rows: result.affectedRows }, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async upsert(data, uniqueKey = 'id') {
        try {
            const pool = getPool();
            const id = data.id || (0, uuid_1.v4)();
            const keys = Object.keys(data);
            const snakeData = convertKeysToSnake(data);
            const columns = ['id', ...keys.map(k => toSnakeCase(k))].join(', ');
            const placeholders = ['?', ...keys.map(() => '?')].join(', ');
            const values = [id, ...keys.map(k => {
                    const val = snakeData[k];
                    if (typeof val === 'object' && val !== null) {
                        return JSON.stringify(val);
                    }
                    return val;
                })];
            const setClause = keys.map(k => `${toSnakeCase(k)} = VALUES(${toSnakeCase(k)})`).join(', ');
            await pool.query(`INSERT INTO ${this.tableName} (${columns}) VALUES (${placeholders}) ON DUPLICATE KEY UPDATE ${setClause}`, [...values, ...values]);
            return { data: { id }, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async delete(id) {
        try {
            const pool = getPool();
            const [result] = await pool.query(`DELETE FROM ${this.tableName} WHERE id = ?`, [id]);
            return { data: { affected_rows: result.affectedRows }, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async query(sql, params = []) {
        try {
            const pool = getPool();
            const [rows] = await pool.query(sql, params);
            const data = rows.map(row => {
                const converted = convertKeysToCamel(row);
                return parseJsonFields(converted, this.jsonFields);
            });
            return { data, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
}
exports.MysqlClient = MysqlClient;
function usersTable() {
    return new MysqlClient('users', ['settings']);
}
function avatarsTable() {
    return new MysqlClient('avatars', ['skills', 'config', 'learningData', 'photoAnalysis']);
}
function conversationsTable() {
    return new MysqlClient('conversations', ['context']);
}
function messagesTable() {
    return new MysqlClient('messages', ['metadata']);
}
function commentsTable() {
    return new MysqlClient('comments');
}
function followsTable() {
    return new MysqlClient('follows');
}
function postsTable() {
    return new MysqlClient('posts', ['images', 'videos', 'tags']);
}
function ordersTable() {
    return new MysqlClient('orders', ['requirements', 'result']);
}
function orderResultsTable() {
    return new MysqlClient('order_results', ['screenshots']);
}
function tasksTable() {
    return new MysqlClient('tasks', ['params', 'result', 'logs']);
}
function likesTable() {
    return new MysqlClient('likes');
}
function notificationsTable() {
    return new MysqlClient('notifications', ['data']);
}
function earningsTable() {
    return new MysqlClient('earnings');
}
function withdrawalRequestsTable() {
    return new MysqlClient('withdrawal_requests');
}
function healthCheckTable() {
    return new MysqlClient('health_check');
}
//# sourceMappingURL=mysql-client.js.map