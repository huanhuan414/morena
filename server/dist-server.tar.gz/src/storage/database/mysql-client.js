"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MysqlClient = void 0;
exports.usersTable = usersTable;
exports.avatarsTable = avatarsTable;
exports.conversationsTable = conversationsTable;
exports.messagesTable = messagesTable;
exports.commentsTable = commentsTable;
exports.followsTable = followsTable;
exports.postsTable = postsTable;
exports.ordersTable = ordersTable;
exports.orderResultsTable = orderResultsTable;
exports.tasksTable = tasksTable;
exports.likesTable = likesTable;
exports.notificationsTable = notificationsTable;
exports.earningsTable = earningsTable;
exports.withdrawalRequestsTable = withdrawalRequestsTable;
exports.healthCheckTable = healthCheckTable;
exports.getPool = getPool;
exports.query = query;
exports.insert = insert;
exports.updateData = updateData;
exports.execute = execute;
exports.skillsTable = skillsTable;
exports.avatarSkillsTable = avatarSkillsTable;
exports.skillReviewsTable = skillReviewsTable;
exports.friendshipsTable = friendshipsTable;
exports.avatarOrdersTable = avatarOrdersTable;
exports.orderItemsTable = orderItemsTable;
const mysql = require("mysql2/promise");
const uuid_1 = require("uuid");
let pool = null;
let envLoaded = false;
function loadEnv() {
    if (envLoaded)
        return;
    try {
        const fs = require('fs');
        const path = require('path');
        const envPath = path.join(process.cwd(), '.env');
        if (fs.existsSync(envPath)) {
            const content = fs.readFileSync(envPath, 'utf-8');
            const lines = content.split('\n');
            for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed || trimmed.startsWith('#'))
                    continue;
                const eqIndex = trimmed.indexOf('=');
                if (eqIndex > 0) {
                    const key = trimmed.substring(0, eqIndex);
                    const value = trimmed.substring(eqIndex + 1);
                    if (!process.env[key]) {
                        process.env[key] = value;
                    }
                }
            }
        }
    }
    catch {
    }
    envLoaded = true;
}
function getMysqlConfig() {
    loadEnv();
    const host = process.env.MYSQL_HOST || '127.0.0.1';
    const port = parseInt(process.env.MYSQL_PORT || '3306');
    const user = process.env.MYSQL_USER || 'root';
    const password = process.env.MYSQL_PASSWORD || '';
    const database = process.env.MYSQL_DATABASE || 'mrl';
    return { host, port, user, password, database };
}
function getPool() {
    if (!pool) {
        const config = getMysqlConfig();
        pool = mysql.createPool({
            host: config.host,
            port: config.port,
            user: config.user,
            password: config.password,
            database: config.database,
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0,
            timezone: '+08:00',
        });
    }
    return pool;
}
function toSnakeCase(str) {
    return str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
}
function toCamelCase(str) {
    return str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
}
function convertKeysToCamel(obj) {
    if (obj === null || obj === undefined)
        return obj;
    if (Array.isArray(obj)) {
        return obj.map(convertKeysToCamel);
    }
    if (typeof obj === 'object') {
        const result = {};
        for (const key in obj) {
            result[toCamelCase(key)] = convertKeysToCamel(obj[key]);
        }
        return result;
    }
    return obj;
}
function convertKeysToSnake(obj) {
    if (obj === null || obj === undefined)
        return obj;
    if (Array.isArray(obj)) {
        return obj.map(convertKeysToSnake);
    }
    if (typeof obj === 'object') {
        const result = {};
        for (const key in obj) {
            result[toSnakeCase(key)] = convertKeysToSnake(obj[key]);
        }
        return result;
    }
    return obj;
}
function parseJsonFields(row, jsonFields) {
    if (!row)
        return row;
    const result = { ...row };
    for (const field of jsonFields) {
        if (result[field] && typeof result[field] === 'string') {
            try {
                result[field] = JSON.parse(result[field]);
            }
            catch {
            }
        }
    }
    return result;
}
class QueryBuilder {
    constructor(tableName, jsonFields = []) {
        this.jsonFields = [];
        this.conditions = '';
        this.conditionValues = [];
        this.selectedColumns = '*';
        this.orderByClause = '';
        this.limitClause = '';
        this.offsetClause = '';
        this.groupByClause = '';
        this.joinClause = '';
        this.tableName = tableName;
        this.jsonFields = jsonFields;
    }
    where(conditions, operator = '=') {
        const keys = Object.keys(conditions);
        if (keys.length === 0)
            return this;
        const clauses = keys.map(key => `${toSnakeCase(key)} ${operator} ?`).join(' AND ');
        const values = keys.map(key => {
            const val = conditions[key];
            if (Array.isArray(val)) {
                return JSON.stringify(val);
            }
            if (typeof val === 'object' && val !== null) {
                return JSON.stringify(val);
            }
            return val;
        });
        if (this.conditions) {
            this.conditions += ' AND ' + clauses;
        }
        else {
            this.conditions = clauses;
        }
        this.conditionValues.push(...values);
        return this;
    }
    whereIn(column, values) {
        const placeholders = values.map(() => '?').join(', ');
        if (this.conditions) {
            this.conditions += ` AND ${toSnakeCase(column)} IN (${placeholders})`;
        }
        else {
            this.conditions = `${toSnakeCase(column)} IN (${placeholders})`;
        }
        this.conditionValues.push(...values);
        return this;
    }
    select(columns) {
        this.selectedColumns = columns;
        return this;
    }
    orderBy(column, direction = 'ASC') {
        this.orderByClause = `ORDER BY ${toSnakeCase(column)} ${direction}`;
        return this;
    }
    limit(count) {
        this.limitClause = `LIMIT ${count}`;
        return this;
    }
    offset(count) {
        this.offsetClause = `OFFSET ${count}`;
        return this;
    }
    groupBy(column) {
        this.groupByClause = `GROUP BY ${toSnakeCase(column)}`;
        return this;
    }
    join(table, condition, type = 'INNER') {
        this.joinClause += ` ${type} JOIN ${table} ON ${condition}`;
        return this;
    }
    async first() {
        const result = await this.execute();
        if (result.data && result.data.length > 0) {
            return { data: result.data[0], error: null };
        }
        return { data: null, error: null };
    }
    async then(resolve) {
        const result = await this.execute();
        resolve(result);
    }
    async execute() {
        try {
            const pool = getPool();
            let sql = `SELECT ${this.selectedColumns} FROM ${this.tableName}${this.joinClause}`;
            if (this.conditions) {
                sql += ` WHERE ${this.conditions}`;
            }
            if (this.groupByClause) {
                sql += ` ${this.groupByClause}`;
            }
            if (this.orderByClause) {
                sql += ` ${this.orderByClause}`;
            }
            if (this.limitClause) {
                sql += ` ${this.limitClause}`;
            }
            if (this.offsetClause) {
                sql += ` ${this.offsetClause}`;
            }
            const [rows] = await pool.query(sql, this.conditionValues);
            const data = rows.map(row => {
                const converted = convertKeysToCamel(row);
                return parseJsonFields(converted, this.jsonFields);
            });
            return { data, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async count() {
        try {
            const pool = getPool();
            let sql = `SELECT COUNT(*) as count FROM ${this.tableName}${this.joinClause}`;
            if (this.conditions) {
                sql += ` WHERE ${this.conditions}`;
            }
            if (this.groupByClause) {
                sql = sql.replace('SELECT COUNT(*) as count', 'SELECT COUNT(*) as count FROM (SELECT 1');
                sql += `) as subquery`;
            }
            const [rows] = await pool.query(sql, this.conditionValues);
            return { data: rows[0]?.count || 0, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async update(data) {
        try {
            const pool = getPool();
            const keys = Object.keys(data);
            const snakeData = convertKeysToSnake(data);
            const setClause = keys.map(k => `${toSnakeCase(k)} = ?`).join(', ');
            const values = [...keys.map(k => {
                    const val = snakeData[k];
                    if (typeof val === 'object' && val !== null) {
                        return JSON.stringify(val);
                    }
                    return val;
                }), ...this.conditionValues];
            let sql = `UPDATE ${this.tableName} SET ${setClause}`;
            if (this.conditions) {
                sql += ` WHERE ${this.conditions}`;
            }
            const [result] = await pool.query(sql, values);
            return { data: { affectedRows: result.affectedRows }, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async delete() {
        try {
            const pool = getPool();
            let sql = `DELETE FROM ${this.tableName}`;
            if (this.conditions) {
                sql += ` WHERE ${this.conditions}`;
            }
            const [result] = await pool.query(sql, this.conditionValues);
            return { data: { affectedRows: result.affectedRows }, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
}
class MysqlClient {
    constructor(tableName, jsonFields = []) {
        this.jsonFields = [];
        this.tableName = tableName;
        this.jsonFields = jsonFields;
    }
    select(columns = '*') {
        const builder = new QueryBuilder(this.tableName, this.jsonFields);
        return builder.select(columns);
    }
    where(conditions, operator = '=') {
        const builder = new QueryBuilder(this.tableName, this.jsonFields);
        return builder.where(conditions, operator);
    }
    whereIn(column, values) {
        const builder = new QueryBuilder(this.tableName, this.jsonFields);
        return builder.whereIn(column, values);
    }
    async findById(id) {
        try {
            const pool = getPool();
            const [rows] = await pool.query(`SELECT * FROM ${this.tableName} WHERE id = ?`, [id]);
            if (rows.length === 0) {
                return { data: null, error: null };
            }
            const converted = convertKeysToCamel(rows[0]);
            const data = parseJsonFields(converted, this.jsonFields);
            return { data, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async insert(data) {
        try {
            const pool = getPool();
            const id = data.id || (0, uuid_1.v4)();
            const { id: _, ...restData } = data;
            const keys = Object.keys(restData);
            const snakeData = convertKeysToSnake(restData);
            const columns = ['id', ...keys.map(k => toSnakeCase(k))].join(', ');
            const placeholders = ['?', ...keys.map(() => '?')].join(', ');
            const values = [id, ...keys.map(k => {
                    const val = snakeData[toSnakeCase(k)];
                    if (typeof val === 'object' && val !== null) {
                        return JSON.stringify(val);
                    }
                    return val;
                })];
            await pool.query(`INSERT INTO ${this.tableName} (${columns}) VALUES (${placeholders})`, values);
            return { data: { id }, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async update(id, data) {
        try {
            const pool = getPool();
            const keys = Object.keys(data);
            const snakeData = convertKeysToSnake(data);
            const setClause = keys.map(k => `${toSnakeCase(k)} = ?`).join(', ');
            const values = [...keys.map(k => {
                    const val = snakeData[k];
                    if (typeof val === 'object' && val !== null) {
                        return JSON.stringify(val);
                    }
                    return val;
                }), id];
            const [result] = await pool.query(`UPDATE ${this.tableName} SET ${setClause} WHERE id = ?`, values);
            return { data: { affectedRows: result.affectedRows }, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async upsert(data, uniqueKey = 'id') {
        try {
            const pool = getPool();
            const id = data.id || (0, uuid_1.v4)();
            const keys = Object.keys(data);
            const snakeData = convertKeysToSnake(data);
            const columns = ['id', ...keys.map(k => toSnakeCase(k))].join(', ');
            const placeholders = ['?', ...keys.map(() => '?')].join(', ');
            const values = [id, ...keys.map(k => {
                    const val = snakeData[k];
                    if (typeof val === 'object' && val !== null) {
                        return JSON.stringify(val);
                    }
                    return val;
                })];
            const setClause = keys.map(k => `${toSnakeCase(k)} = VALUES(${toSnakeCase(k)})`).join(', ');
            await pool.query(`INSERT INTO ${this.tableName} (${columns}) VALUES (${placeholders}) ON DUPLICATE KEY UPDATE ${setClause}`, [...values, ...values]);
            return { data: { id }, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async delete(id) {
        try {
            const pool = getPool();
            const [result] = await pool.query(`DELETE FROM ${this.tableName} WHERE id = ?`, [id]);
            return { data: { affectedRows: result.affectedRows }, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
    async query(sql, params = []) {
        try {
            const pool = getPool();
            const [rows] = await pool.query(sql, params);
            const data = rows.map(row => {
                const converted = convertKeysToCamel(row);
                return parseJsonFields(converted, this.jsonFields);
            });
            return { data, error: null };
        }
        catch (error) {
            return { data: null, error };
        }
    }
}
exports.MysqlClient = MysqlClient;
function usersTable() {
    return new MysqlClient('users', ['settings']);
}
function avatarsTable() {
    return new MysqlClient('avatars', ['skills', 'config', 'learningData', 'photoAnalysis']);
}
function conversationsTable() {
    return new MysqlClient('conversations', ['context']);
}
function messagesTable() {
    return new MysqlClient('messages', ['metadata']);
}
function commentsTable() {
    return new MysqlClient('comments');
}
function followsTable() {
    return new MysqlClient('follows');
}
function postsTable() {
    return new MysqlClient('posts', ['images', 'videos', 'tags']);
}
function ordersTable() {
    return new MysqlClient('orders', ['requirements', 'result']);
}
function orderResultsTable() {
    return new MysqlClient('order_results', ['screenshots']);
}
function tasksTable() {
    return new MysqlClient('tasks', ['params', 'result', 'logs']);
}
function likesTable() {
    return new MysqlClient('likes');
}
function notificationsTable() {
    return new MysqlClient('notifications', ['data']);
}
function earningsTable() {
    return new MysqlClient('earnings');
}
function withdrawalRequestsTable() {
    return new MysqlClient('withdrawal_requests');
}
function healthCheckTable() {
    return new MysqlClient('health_check');
}
async function query(sql, params = []) {
    const client = getPool();
    try {
        const [rows] = await client.query(sql, params);
        return { data: rows, error: null };
    }
    catch (error) {
        console.error('Query error:', error.message);
        return { data: null, error };
    }
}
async function insert(sql, params = []) {
    const client = getPool();
    try {
        const [result] = await client.query(sql, params);
        return { data: { id: result.insertId?.toString() || '' }, error: null };
    }
    catch (error) {
        console.error('Insert error:', error.message);
        return { data: null, error };
    }
}
async function updateData(sql, params = []) {
    const client = getPool();
    try {
        const [result] = await client.query(sql, params);
        return { data: { affectedRows: result.affectedRows || 0 }, error: null };
    }
    catch (error) {
        console.error('Update error:', error.message);
        return { data: null, error };
    }
}
async function execute(sql, params) {
    return query(sql, params || []);
}
function skillsTable() {
    return new MysqlClient('skills');
}
function avatarSkillsTable() {
    return new MysqlClient('avatar_skills');
}
function skillReviewsTable() {
}
function friendshipsTable() {
    return new MysqlClient('friendships');
}
function avatarOrdersTable() {
    return new MysqlClient('avatar_orders');
}
function orderItemsTable() {
    return new MysqlClient('order_items');
}
//# sourceMappingURL=mysql-client.js.map