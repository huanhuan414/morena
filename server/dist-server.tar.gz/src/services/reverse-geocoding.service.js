"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReverseGeocodingService = void 0;
const common_1 = require("@nestjs/common");
let ReverseGeocodingService = class ReverseGeocodingService {
    constructor() {
        this.AMAP_WEB_SERVICE_KEY = '5f5b139f9cce3da88b6813304541b47d';
        this.AMAP_MINIPROGRAM_KEY = 'a2fd21655a31c73e42294c459123adf5';
        this.AMAP_BASE_URL = 'https://restapi.amap.com';
    }
    async convertWGS84ToGCJ02(latitude, longitude) {
        try {
            const response = await fetch(`${this.AMAP_BASE_URL}/v3/assistant/coordinate/convert?key=${this.AMAP_WEB_SERVICE_KEY}&locations=${longitude},${latitude}&coordsys=gps&output=json`);
            if (!response.ok) {
                throw new Error(`坐标转换请求失败: ${response.statusText}`);
            }
            const data = await response.json();
            if (data.status === '1' && data.locations) {
                const [lon, lat] = data.locations.split(',');
                return {
                    lat: parseFloat(lat),
                    lon: parseFloat(lon)
                };
            }
            throw new Error('坐标转换失败');
        }
        catch (error) {
            console.warn('[逆地理编码] 坐标转换失败，使用原始坐标:', error);
            return { lat: latitude, lon: longitude };
        }
    }
    async reverseGeocode(latitude, longitude) {
        try {
            const response = await fetch(`${this.AMAP_BASE_URL}/v3/geocode/regeo?key=${this.AMAP_WEB_SERVICE_KEY}&location=${longitude},${latitude}&extensions=all&output=json`, {
                signal: AbortSignal.timeout(10000)
            });
            if (!response.ok) {
                throw new Error(`逆地理编码请求失败: ${response.statusText}`);
            }
            const data = await response.json();
            if (data.status !== '1') {
                throw new Error(`逆地理编码API返回错误: ${data.info}`);
            }
            const regeocode = data.regeocode;
            const addressComponent = regeocode.addressComponent || {};
            const formattedAddress = regeocode.formatted_address || '';
            const country = addressComponent.country || '';
            const province = addressComponent.province || '';
            const city = (Array.isArray(addressComponent.city) ? '' : (addressComponent.city || addressComponent.province || ''));
            const district = addressComponent.district || '';
            const street = addressComponent.township || '';
            const streetNumber = addressComponent.streetNumber?.street || '';
            const adcode = addressComponent.adcode || '';
            const pois = regeocode.pois?.map((poi) => ({
                name: poi.name,
                address: poi.address,
                distance: poi.distance
            })) || [];
            const formatted_address_parts = [];
            if (country)
                formatted_address_parts.push(country);
            if (province)
                formatted_address_parts.push(province);
            if (city)
                formatted_address_parts.push(city);
            if (district)
                formatted_address_parts.push(district);
            if (street)
                formatted_address_parts.push(street);
            if (streetNumber)
                formatted_address_parts.push(streetNumber);
            const formatted_address = formatted_address_parts.join('') || formattedAddress;
            console.log('[逆地理编码] 高德API返回:', {
                formatted_address,
                formattedAddress,
                province,
                city,
                district,
                pois: pois.length,
                adcode
            });
            return {
                formatted_address,
                country,
                province,
                city,
                district,
                street: streetNumber,
                full_location_text: formattedAddress,
                adcode,
                pois
            };
        }
        catch (error) {
            console.error('[逆地理编码] 高德API失败，使用本地坐标范围判断:', error);
            const location = this.getLocationByCoordinates(latitude, longitude);
            if (location) {
                const formatted_address = `中国 ${location.province} ${location.city}`;
                return {
                    formatted_address,
                    country: '中国',
                    province: location.province,
                    city: location.city,
                    district: '',
                    street: '',
                    full_location_text: formatted_address
                };
            }
            else {
                return {
                    formatted_address: `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`,
                    full_location_text: `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`
                };
            }
        }
    }
    getLocationByCoordinates(latitude, longitude) {
        const CITY_REGIONS = [
            { name: '北京市', latRange: [39.4, 41.0], lonRange: [115.7, 117.4], province: '北京市' },
            { name: '上海市', latRange: [30.7, 31.9], lonRange: [120.9, 122.2], province: '上海市' },
            { name: '广州市', latRange: [22.5, 24.0], lonRange: [112.9, 114.5], province: '广东省' },
            { name: '深圳市', latRange: [22.4, 22.9], lonRange: [113.8, 114.6], province: '广东省' },
            { name: '成都市', latRange: [30.0, 31.0], lonRange: [103.5, 104.9], province: '四川省' },
            { name: '杭州市', latRange: [29.8, 30.6], lonRange: [119.8, 120.9], province: '浙江省' },
            { name: '武汉市', latRange: [29.9, 30.9], lonRange: [113.6, 115.1], province: '湖北省' },
            { name: '西安市', latRange: [33.8, 34.5], lonRange: [107.8, 109.5], province: '陕西省' },
            { name: '重庆市', latRange: [28.5, 30.4], lonRange: [105.3, 107.5], province: '重庆市' },
            { name: '南京市', latRange: [31.6, 32.6], lonRange: [118.3, 119.5], province: '江苏省' },
            { name: '天津市', latRange: [38.5, 40.2], lonRange: [116.7, 118.0], province: '天津市' },
            { name: '苏州市', latRange: [30.7, 31.9], lonRange: [119.8, 121.0], province: '江苏省' },
            { name: '长沙市', latRange: [27.7, 28.9], lonRange: [112.3, 113.9], province: '湖南省' },
            { name: '郑州市', latRange: [34.3, 35.3], lonRange: [112.8, 114.5], province: '河南省' },
            { name: '贵阳市', latRange: [26.0, 27.0], lonRange: [106.3, 107.3], province: '贵州省' },
            { name: '昆明市', latRange: [24.5, 26.5], lonRange: [102.3, 103.5], province: '云南省' },
            { name: '沈阳市', latRange: [41.3, 42.2], lonRange: [122.7, 124.0], province: '辽宁省' },
            { name: '青岛市', latRange: [35.5, 36.5], lonRange: [119.8, 121.0], province: '山东省' },
            { name: '大连市', latRange: [38.7, 39.5], lonRange: [121.0, 122.5], province: '辽宁省' },
            { name: '厦门市', latRange: [24.3, 24.9], lonRange: [117.8, 118.5], province: '福建省' },
        ];
        for (const region of CITY_REGIONS) {
            if (latitude >= region.latRange[0] && latitude <= region.latRange[1] &&
                longitude >= region.lonRange[0] && longitude <= region.lonRange[1]) {
                return {
                    province: region.province,
                    city: region.name
                };
            }
        }
        return null;
    }
    async batchReverseGeocode(locations) {
        const results = await Promise.all(locations.map(loc => this.reverseGeocode(loc.latitude, loc.longitude)));
        return results;
    }
};
exports.ReverseGeocodingService = ReverseGeocodingService;
exports.ReverseGeocodingService = ReverseGeocodingService = __decorate([
    (0, common_1.Injectable)()
], ReverseGeocodingService);
//# sourceMappingURL=reverse-geocoding.service.js.map