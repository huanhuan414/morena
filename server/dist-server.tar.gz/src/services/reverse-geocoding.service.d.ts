export interface ReverseGeocodingResult {
    formatted_address: string;
    country?: string;
    province?: string;
    city?: string;
    district?: string;
    street?: string;
    full_location_text: string;
    adcode?: string;
    pois?: Array<{
        name: string;
        address: string;
        distance: string;
    }>;
}
export declare class ReverseGeocodingService {
    private readonly AMAP_WEB_SERVICE_KEY;
    private readonly AMAP_MINIPROGRAM_KEY;
    private readonly AMAP_BASE_URL;
    private convertWGS84ToGCJ02;
    reverseGeocode(latitude: number, longitude: number): Promise<ReverseGeocodingResult>;
    private getLocationByCoordinates;
    batchReverseGeocode(locations: Array<{
        latitude: number;
        longitude: number;
    }>): Promise<ReverseGeocodingResult[]>;
}
