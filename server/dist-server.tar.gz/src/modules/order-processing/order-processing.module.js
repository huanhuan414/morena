"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderProcessingModule = void 0;
const common_1 = require("@nestjs/common");
const order_processing_controller_1 = require("./order-processing.controller");
const order_processing_service_1 = require("./order-processing.service");
const link_validation_service_1 = require("./link-validation.service");
const content_generation_module_1 = require("../content-generation/content-generation.module");
const avatar_agent_module_1 = require("../avatar-agent/avatar-agent.module");
const tikhub_module_1 = require("../tikhub/tikhub.module");
let OrderProcessingModule = class OrderProcessingModule {
};
exports.OrderProcessingModule = OrderProcessingModule;
exports.OrderProcessingModule = OrderProcessingModule = __decorate([
    (0, common_1.Module)({
        imports: [content_generation_module_1.ContentGenerationModule, avatar_agent_module_1.AvatarAgentModule, tikhub_module_1.TikHubModule],
        controllers: [order_processing_controller_1.OrderProcessingController],
        providers: [order_processing_service_1.OrderProcessingService, link_validation_service_1.LinkValidationService],
        exports: [order_processing_service_1.OrderProcessingService]
    })
], OrderProcessingModule);
//# sourceMappingURL=order-processing.module.js.map