export declare class OrderProcessingModule {
}
