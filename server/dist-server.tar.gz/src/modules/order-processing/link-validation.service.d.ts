import { TikHubService } from '../tikhub/tikhub.service';
export interface ValidateResult {
    success: boolean;
    platform: string;
    data?: {
        title?: string;
        author?: string;
        cover?: string;
        description?: string;
        url?: string;
        views?: number;
        likes?: number;
        comments?: number;
        shares?: number;
    };
    error?: string;
}
export interface SaveWorkParams {
    orderId: string;
    avatarId: string;
    platform: string;
    workTitle: string;
    workUrl: string;
    authorNickname?: string;
    coverImage?: string;
    description?: string;
    extraData?: any;
    feedbackImage?: string;
}
export declare class LinkValidationService {
    private readonly tikHubService;
    private readonly logger;
    constructor(tikHubService: TikHubService);
    validateLink(url: string, orderId?: string, avatarId?: string): Promise<ValidateResult>;
    private detectPlatform;
    private validateDouyin;
    private validateXiaohongshu;
    private validateWechatMp;
    saveWork(params: SaveWorkParams): Promise<void>;
    getWorksByOrderId(orderId: string): Promise<any[]>;
}
