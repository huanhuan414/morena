"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var LinkValidationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LinkValidationService = void 0;
const common_1 = require("@nestjs/common");
const tikhub_service_1 = require("../tikhub/tikhub.service");
const supabase_client_1 = require("../../storage/database/supabase-client");
let LinkValidationService = LinkValidationService_1 = class LinkValidationService {
    constructor(tikHubService) {
        this.tikHubService = tikHubService;
        this.logger = new common_1.Logger(LinkValidationService_1.name);
    }
    async validateLink(url, orderId, avatarId) {
        try {
            if (!url || typeof url !== 'string') {
                return {
                    success: false,
                    platform: 'unknown',
                    error: '链接不能为空'
                };
            }
            this.logger.log(`[LinkValidation] 开始验证链接: ${url}`);
            const platform = this.detectPlatform(url);
            if (!platform) {
                return {
                    success: false,
                    platform: 'unknown',
                    error: '无法识别链接所属平台'
                };
            }
            this.logger.log(`[LinkValidation] 识别到平台: ${platform}`);
            let result;
            switch (platform) {
                case 'douyin':
                    result = await this.validateDouyin(url);
                    break;
                case 'xiaohongshu':
                    result = await this.validateXiaohongshu(url);
                    break;
                case 'wechat_mp':
                    result = await this.validateWechatMp(url);
                    break;
                default:
                    result = {
                        success: false,
                        platform,
                        error: '暂不支持该平台'
                    };
            }
            if (result.success && orderId && avatarId && result.data) {
                try {
                    await this.saveWork({
                        orderId,
                        avatarId,
                        platform,
                        workTitle: result.data.title || '',
                        workUrl: result.data.url || url,
                        authorNickname: result.data.author,
                        coverImage: result.data.cover,
                        description: result.data.description,
                        extraData: result.data
                    });
                    this.logger.log(`[LinkValidation] 作品信息已保存到数据库`);
                }
                catch (saveError) {
                    this.logger.error(`[LinkValidation] 保存作品信息到数据库失败:`, saveError);
                }
            }
            return result;
        }
        catch (error) {
            this.logger.error(`[LinkValidation] 验证链接失败:`, error);
            return {
                success: false,
                platform: 'unknown',
                error: error.message || '验证失败，请检查链接是否正确'
            };
        }
    }
    detectPlatform(url) {
        if (url.includes('douyin.com') || url.includes('iesdouyin.com')) {
            return 'douyin';
        }
        if (url.includes('xiaohongshu.com') || url.includes('xhslink.com')) {
            return 'xiaohongshu';
        }
        if (url.includes('mp.weixin.qq.com') || url.includes('weixin.qq.com')) {
            return 'wechat_mp';
        }
        return null;
    }
    async validateDouyin(url) {
        try {
            this.logger.log(`[LinkValidation] 验证抖音链接: ${url}`);
            const response = await this.tikHubService.callTikHubAPI('/douyin/app/v3/fetch_one_video_by_share_url', { share_url: url });
            this.logger.log(`[LinkValidation] 抖音响应:`, response);
            if (!response || !response.data) {
                return {
                    success: false,
                    platform: 'douyin',
                    error: '获取抖音视频信息失败'
                };
            }
            const videoData = response.data;
            const statistics = videoData.statistics || videoData.aweme_stats || {};
            return {
                success: true,
                platform: 'douyin',
                data: {
                    title: videoData.desc || videoData.title || '',
                    author: videoData.author?.nickname || videoData.author?.unique_id || '',
                    cover: videoData.cover || videoData.origin_cover || '',
                    description: videoData.desc || '',
                    url,
                    views: statistics.play_count || statistics.views || 0,
                    likes: statistics.digg_count || statistics.likes || 0,
                    comments: statistics.comment_count || statistics.comments || 0,
                    shares: statistics.share_count || statistics.shares || 0
                }
            };
        }
        catch (error) {
            this.logger.error(`[LinkValidation] 抖音验证失败:`, error);
            return {
                success: false,
                platform: 'douyin',
                error: error.message || '抖音链接验证失败'
            };
        }
    }
    async validateXiaohongshu(url) {
        try {
            this.logger.log(`[LinkValidation] 验证小红书链接: ${url}`);
            const response = await this.tikHubService.callTikHubAPI('/xiaohongshu/app/fetch_one_note_by_url', { url });
            this.logger.log(`[LinkValidation] 小红书响应:`, response);
            if (!response || !response.data) {
                return {
                    success: false,
                    platform: 'xiaohongshu',
                    error: '获取小红书笔记信息失败'
                };
            }
            const noteData = response.data;
            const noteInfo = noteData.items?.[0]?.note_card || noteData;
            const statistics = noteInfo.interact_info || noteInfo.statistics || {};
            return {
                success: true,
                platform: 'xiaohongshu',
                data: {
                    title: noteInfo.title || noteInfo.desc || '',
                    author: noteInfo.user?.nickname || noteInfo.author?.nickname || '',
                    cover: noteInfo.cover?.url_default || noteInfo.cover?.url || noteInfo.image_list?.[0] || '',
                    description: noteInfo.desc || noteInfo.title || '',
                    url,
                    views: statistics.view_count || statistics.views || 0,
                    likes: statistics.liked_count || statistics.likes || 0,
                    comments: statistics.comment_count || statistics.comments || 0,
                    shares: statistics.share_count || statistics.shares || 0
                }
            };
        }
        catch (error) {
            this.logger.error(`[LinkValidation] 小红书验证失败:`, error);
            return {
                success: false,
                platform: 'xiaohongshu',
                error: error.message || '小红书链接验证失败'
            };
        }
    }
    async validateWechatMp(url) {
        try {
            this.logger.log(`[LinkValidation] 验证微信公众号链接: ${url}`);
            const response = await this.tikHubService.callTikHubAPI('/wechat_mp/web/fetch_mp_article_detail_json', { url });
            this.logger.log(`[LinkValidation] 微信公众号响应:`, response);
            if (!response || !response.data) {
                return {
                    success: false,
                    platform: 'wechat_mp',
                    error: '获取微信公众号文章信息失败'
                };
            }
            const articleData = response.data;
            return {
                success: true,
                platform: 'wechat_mp',
                data: {
                    title: articleData.title || articleData.msg_title || '',
                    author: articleData.author || articleData.msg_cdn_url || '',
                    cover: articleData.cover || articleData.msg_cdn_url || '',
                    description: articleData.digest || '',
                    url,
                    views: articleData.read_num || articleData.views || 0,
                    likes: articleData.like_num || articleData.likes || 0,
                    comments: articleData.comment_count || articleData.comments || 0,
                    shares: articleData.share_count || articleData.shares || 0
                }
            };
        }
        catch (error) {
            this.logger.error(`[LinkValidation] 微信公众号验证失败:`, error);
            return {
                success: false,
                platform: 'wechat_mp',
                error: error.message || '微信公众号链接验证失败'
            };
        }
    }
    async saveWork(params) {
        try {
            const supabase = (0, supabase_client_1.getSupabaseClient)();
            const workData = {
                order_id: params.orderId,
                avatar_id: params.avatarId,
                platform: params.platform,
                work_title: params.workTitle,
                work_url: params.workUrl,
                author_nickname: params.authorNickname,
                cover_image: params.coverImage,
                description: params.description,
                extra_data: params.extraData || {},
                status: 'verified',
                feedback_image: params.feedbackImage,
                updated_at: new Date().toISOString()
            };
            this.logger.log(`[LinkValidation] 保存作品信息:`, workData);
            const { data, error } = await supabase
                .from('published_works')
                .insert(workData)
                .select()
                .single();
            if (error) {
                this.logger.error(`[LinkValidation] 保存作品信息失败:`, error);
                throw error;
            }
            this.logger.log(`[LinkValidation] 作品信息保存成功，ID: ${data.id}`);
        }
        catch (error) {
            this.logger.error(`[LinkValidation] 保存作品信息到数据库失败:`, error);
            throw error;
        }
    }
    async getWorksByOrderId(orderId) {
        try {
            const supabase = (0, supabase_client_1.getSupabaseClient)();
            const { data, error } = await supabase
                .from('published_works')
                .select('*')
                .eq('order_id', orderId)
                .order('created_at', { ascending: false });
            if (error) {
                this.logger.error(`[LinkValidation] 获取作品列表失败:`, error);
                throw error;
            }
            return data || [];
        }
        catch (error) {
            this.logger.error(`[LinkValidation] 获取作品列表失败:`, error);
            throw error;
        }
    }
};
exports.LinkValidationService = LinkValidationService;
exports.LinkValidationService = LinkValidationService = LinkValidationService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [tikhub_service_1.TikHubService])
], LinkValidationService);
//# sourceMappingURL=link-validation.service.js.map