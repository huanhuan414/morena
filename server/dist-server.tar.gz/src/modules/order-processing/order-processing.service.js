"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderProcessingService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
const content_generation_service_1 = require("../content-generation/content-generation.service");
const avatar_agent_service_1 = require("../avatar-agent/avatar-agent.service");
const link_validation_service_1 = require("./link-validation.service");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
class TaskQueue {
    constructor(contentGenerationService, checkGenerateSkill) {
        this.contentGenerationService = contentGenerationService;
        this.checkGenerateSkill = checkGenerateSkill;
        this.maxConcurrentTasks = 3;
        this.activeTasks = new Set();
        this.queue = [];
        setInterval(() => this.processQueue(), 30000);
        setTimeout(() => this.recoverZombieTasks(), 5000);
    }
    async recoverZombieTasks() {
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
            const { data: zombieTasks } = await client
                .from('order_dispatch_requests')
                .select('id, order_id, avatar_id')
                .eq('status', 'generating')
                .lt('updated_at', fiveMinutesAgo)
                .is('generated_content', null);
            if (zombieTasks && zombieTasks.length > 0) {
                console.log('[TaskQueue] 发现僵尸任务，恢复中:', zombieTasks.length);
                for (const task of zombieTasks) {
                    this.queue.push({ requestId: task.id, timestamp: Date.now() });
                    console.log('[TaskQueue] 僵尸任务已重新加入队列:', task.id);
                }
                this.processQueue();
            }
        }
        catch (error) {
            console.error('[TaskQueue] 恢复僵尸任务失败:', error);
        }
    }
    async enqueue(requestId) {
        const position = this.queue.length;
        this.queue.push({ requestId, timestamp: Date.now() });
        const estimatedTime = position * 60;
        console.log('[TaskQueue] 任务加入队列:', {
            requestId,
            position,
            estimatedTime
        });
        this.processQueue();
        return { position, estimatedTime };
    }
    async processQueue() {
        const client = (0, supabase_client_1.getSupabaseClient)();
        console.log('[TaskQueue] 检查队列:', {
            activeTasks: this.activeTasks.size,
            queueLength: this.queue.length,
            maxConcurrent: this.maxConcurrentTasks
        });
        while (this.activeTasks.size < this.maxConcurrentTasks && this.queue.length > 0) {
            const task = this.queue.shift();
            if (!task)
                break;
            const { data: request } = await client
                .from('order_dispatch_requests')
                .select('id, status, order_id, avatar_id')
                .eq('id', task.requestId)
                .single();
            if (!request || request.status !== 'accepted') {
                console.log('[TaskQueue] 任务已取消或不存在:', task.requestId);
                continue;
            }
            this.activeTasks.add(task.requestId);
            console.log('[TaskQueue] 开始执行任务:', task.requestId);
            await client
                .from('order_dispatch_requests')
                .update({ status: 'generating' })
                .eq('id', task.requestId);
            this.executeTask(task.requestId, request.order_id, request.avatar_id).catch(error => {
                console.error('[TaskQueue] 任务执行失败:', task.requestId, error);
                this.activeTasks.delete(task.requestId);
            });
        }
    }
    async executeTask(requestId, orderId, avatarId) {
        try {
            console.log('[TaskQueue] 正在生成内容:', { requestId, orderId, avatarId });
            const client = (0, supabase_client_1.getSupabaseClient)();
            const [{ data: order }, { data: avatar }] = await Promise.all([
                client.from('orders').select('*').eq('id', orderId).single(),
                client.from('avatars').select('*').eq('id', avatarId).single()
            ]);
            if (!order || !avatar) {
                throw new Error('订单或分身不存在');
            }
            const orderRequirements = order.requirements || {};
            const quantityPerAvatar = orderRequirements.quantity_per_avatar || 1;
            const platforms = order.platforms || [];
            const firstPlatform = platforms[0];
            const hasGenerateSkill = await this.checkGenerateSkill(firstPlatform, avatarId);
            console.log('[TaskQueue] 分身技能检查:', {
                avatarId,
                avatarName: avatar.name,
                platform: firstPlatform,
                hasGenerateSkill,
                message: hasGenerateSkill
                    ? '分身具有内容生成技能，可以使用技能生成内容'
                    : '分身暂无对应的内容生成技能，使用默认内容生成服务'
            });
            if (hasGenerateSkill) {
                console.log('[TaskQueue] 检测到分身技能，但尚未实现技能调用，使用默认服务生成');
            }
            const generatedContents = await this.contentGenerationService.generateContent({
                orderId,
                requestId,
                avatarId,
                orderTitle: order.title,
                orderDescription: order.description,
                platforms: platforms,
                contentType: order.content_type,
                targetAudience: order.target_audience || '',
                avatarName: avatar.name,
                avatarPersonality: avatar.personality,
                quantity: quantityPerAvatar
            });
            console.log('[TaskQueue] 内容生成完成:', {
                requestId,
                quantityPerAvatar,
                generatedCount: generatedContents.length
            });
            console.log('[TaskQueue] 内容生成成功:', {
                requestId,
                contentCount: generatedContents.length,
                usedSkill: hasGenerateSkill
            });
            let generatedContent = '';
            if (generatedContents.length > 0 && generatedContents[0].content) {
                generatedContent = generatedContents[0].content;
            }
            if (!generatedContent || generatedContent.trim().length === 0) {
                console.error('[TaskQueue] 生成的内容为空，标记为失败:', requestId);
                await client
                    .from('order_dispatch_requests')
                    .update({ status: 'failed' })
                    .eq('id', requestId);
                throw new Error('生成的内容为空');
            }
            await client
                .from('order_dispatch_requests')
                .update({
                status: 'preview',
                generated_content: generatedContent
            })
                .eq('id', requestId);
        }
        catch (error) {
            console.error('[TaskQueue] 任务执行失败:', error);
            const client = (0, supabase_client_1.getSupabaseClient)();
            await client
                .from('order_dispatch_requests')
                .update({ status: 'failed' })
                .eq('id', requestId);
        }
        finally {
            this.activeTasks.delete(requestId);
            this.processQueue();
        }
    }
    getQueuePosition(requestId) {
        const position = this.queue.findIndex(t => t.requestId === requestId);
        return position >= 0 ? position + 1 : 0;
    }
    getActiveTaskCount() {
        return this.activeTasks.size;
    }
}
let OrderProcessingService = class OrderProcessingService {
    constructor(contentGenerationService, avatarAgentService, linkValidationService) {
        this.contentGenerationService = contentGenerationService;
        this.avatarAgentService = avatarAgentService;
        this.linkValidationService = linkValidationService;
        const config = new coze_coding_dev_sdk_1.Config();
        this.llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
        this.queue = new TaskQueue(contentGenerationService, this.checkGenerateSkill.bind(this));
    }
    async enqueueTask(requestId) {
        return this.queue.enqueue(requestId);
    }
    async getProcessingStatus(requestId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        console.log('[OrderProcessing] 查询订单状态:', { requestId });
        const { data: request, error: requestError } = await client
            .from('order_dispatch_requests')
            .select('id, order_id, avatar_id, user_id, status, generated_content, publish_status, publish_feedback, confirmed_content, updated_at')
            .eq('id', requestId)
            .single();
        const { data: genContents } = await client
            .from('generated_content')
            .select('image_suggestions')
            .eq('request_id', requestId)
            .order('created_at', { ascending: false });
        const imageSuggestions = [];
        if (genContents && genContents.length > 0) {
            for (const gc of genContents) {
                if (gc.image_suggestions && Array.isArray(gc.image_suggestions)) {
                    for (const img of gc.image_suggestions) {
                        if (img && !imageSuggestions.includes(img)) {
                            imageSuggestions.push(img);
                        }
                    }
                }
            }
        }
        if (requestError) {
            console.error('[OrderProcessing] 查询订单请求失败:', requestError);
            throw new Error(`查询订单请求失败: ${requestError.message}`);
        }
        if (!request) {
            console.error('[OrderProcessing] 订单请求不存在:', { requestId });
            throw new Error(`订单请求不存在: ${requestId}`);
        }
        console.log('[OrderProcessing] 订单请求查询成功:', {
            requestId,
            status: request.status,
            orderId: request.order_id,
            avatarId: request.avatar_id
        });
        let orderData = null;
        let budget = 0;
        let isPaid = true;
        if (request.order_id) {
            const { data: order, error: orderError } = await client
                .from('orders')
                .select('id, title, platforms, content_type, deadline, budget, is_paid')
                .eq('id', request.order_id)
                .maybeSingle();
            if (orderError) {
                console.warn('[OrderProcessing] 查询订单信息失败:', orderError);
            }
            else if (order) {
                orderData = order;
                budget = parseFloat(order.budget) || 0;
                isPaid = order.is_paid !== false;
                console.log('[OrderProcessing] 订单信息查询成功:', order);
            }
            else {
                console.warn('[OrderProcessing] 未找到订单信息，order_id:', request.order_id);
            }
        }
        let avatarData = null;
        if (request.avatar_id) {
            const { data: avatar, error: avatarError } = await client
                .from('avatars')
                .select('id, name, avatar_url, level')
                .eq('id', request.avatar_id)
                .single();
            if (avatarError) {
                console.warn('[OrderProcessing] 查询分身信息失败:', avatarError);
            }
            else {
                avatarData = avatar;
            }
        }
        let avatarAccounts = [];
        if (request.avatar_id) {
            const { data: accounts } = await client
                .from('avatar_accounts')
                .select('id, platform, account_name, account_url, appid')
                .eq('avatar_id', request.avatar_id);
            if (accounts) {
                avatarAccounts = accounts;
                console.log('[OrderProcessing] 分身账号信息:', avatarAccounts);
            }
        }
        console.log('[OrderProcessing] 所有数据查询完成:', {
            hasOrder: !!orderData,
            hasAvatar: !!avatarData,
            accountCount: avatarAccounts.length
        });
        const status = {
            requestId,
            orderId: request.order_id,
            issuerId: request.user_id,
            status: request.status,
            isPaid,
            generatedContent: request.generated_content ? {
                title: orderData?.title || '未知订单',
                content: request.generated_content,
                images: imageSuggestions,
                platforms: orderData?.platforms || [],
                contentType: orderData?.content_type || '图文'
            } : undefined,
            publishStatus: request.publish_status,
            publishFeedback: request.publish_feedback ? {
                screenshot_urls: this.extractScreenshotUrls(request.publish_feedback),
                link: this.extractLink(request.publish_feedback),
                note: request.publish_feedback.note,
                feedbackSubmittedAt: request.publish_feedback.feedbackSubmittedAt
            } : undefined,
            avatarAccounts
        };
        if (request.status === 'completed' && request.order_id && budget > 0) {
            const { data: participatingRequests } = await client
                .from('order_dispatch_requests')
                .select('avatar_id')
                .eq('order_id', request.order_id)
                .not('status', 'in', '(rejected,cancelled)');
            const participantCount = participatingRequests?.length || 1;
            const earningsPerAvatar = budget / participantCount;
            status.earnings = earningsPerAvatar;
            status.earningsStatus = 'settled';
            status.completedAt = request.updated_at || new Date().toISOString();
            console.log(`[OrderProcessing] 计算收益: 预算 ${budget} / 参与分身 ${participantCount} = ${earningsPerAvatar}`);
        }
        if (request.status === 'accepted') {
            const position = this.queue.getQueuePosition(requestId);
            const estimatedTime = position * 60;
            status.status = 'queuing';
            status.queuePosition = position;
            status.estimatedTime = estimatedTime;
        }
        console.log('[OrderProcessing] 返回状态数据:', {
            requestId,
            status: status.status,
            hasGeneratedContent: !!status.generatedContent,
            generatedContent: status.generatedContent,
            orderDataTitle: orderData?.title,
            orderDataPlatforms: orderData?.platforms
        });
        return status;
    }
    async triggerTask(requestId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: request } = await client
            .from('order_dispatch_requests')
            .select('id, order_id, avatar_id, status')
            .eq('id', requestId)
            .single();
        if (!request) {
            return { success: false, message: '任务不存在' };
        }
        await client
            .from('order_dispatch_requests')
            .update({ status: 'accepted' })
            .eq('id', requestId);
        await this.queue.enqueue(requestId);
        return { success: true, message: '任务已触发' };
    }
    extractScreenshotUrls(publishFeedback) {
        const urls = [];
        for (const feedback of Object.values(publishFeedback)) {
            if (feedback && typeof feedback === 'object') {
                if (feedback.images && Array.isArray(feedback.images)) {
                    urls.push(...feedback.images.filter((url) => url));
                }
                if (feedback.image) {
                    urls.push(feedback.image);
                }
            }
        }
        return urls;
    }
    extractLink(publishFeedback) {
        for (const feedback of Object.values(publishFeedback)) {
            if (feedback && typeof feedback === 'object' && feedback.link) {
                return feedback.link;
            }
        }
        return undefined;
    }
    async confirmContent(requestId, content) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: request, error: requestError } = await client
            .from('order_dispatch_requests')
            .select('id, order_id')
            .eq('id', requestId)
            .single();
        if (requestError || !request) {
            throw new Error('获取订单请求失败');
        }
        const { error: updateError } = await client
            .from('order_dispatch_requests')
            .update({
            status: 'published',
            confirmed_content: content
        })
            .eq('id', requestId);
        if (updateError) {
            throw new Error('确认内容失败');
        }
        await client
            .from('orders')
            .update({ status: 'awaiting_acceptance' })
            .eq('id', request.order_id);
        return { success: true };
    }
    async publishContent(requestId, content) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: request, error: requestError } = await client
            .from('order_dispatch_requests')
            .select('id, order_id, avatar_id, status, generated_content, publish_status, confirmed_content')
            .eq('id', requestId)
            .single();
        if (requestError || !request) {
            throw new Error('获取订单请求失败');
        }
        const { data: order, error: orderError } = await client
            .from('orders')
            .select('*')
            .eq('id', request.order_id)
            .single();
        if (orderError || !order) {
            throw new Error('获取订单信息失败');
        }
        const finalContent = content || request.confirmed_content || request.generated_content;
        if (!finalContent) {
            throw new Error('没有可发布的内容');
        }
        const platforms = order.platforms || [];
        if (platforms.length === 0) {
            throw new Error('订单没有指定发布平台');
        }
        const publishResults = [];
        for (const platform of platforms) {
            console.log('[OrderProcessing] 开始发布到平台:', { platform, requestId, avatarId: request.avatar_id });
            try {
                const hasPublishSkill = await this.checkPublishSkill(platform, request.avatar_id);
                console.log('[OrderProcessing] 发布技能检查结果:', {
                    platform,
                    avatarId: request.avatar_id,
                    hasPublishSkill
                });
                if (platform === 'wechat_mp') {
                    if (hasPublishSkill) {
                        console.log('[OrderProcessing] 分身有公众号发布技能，尝试自动发布');
                        await this.autoPublish(platform, order, finalContent, request.avatar_id);
                        publishResults.push({
                            platform,
                            status: 'success',
                            message: '已使用分身技能发布到公众号草稿箱',
                            publishedAt: new Date().toISOString()
                        });
                    }
                    else {
                        console.log('[OrderProcessing] 分身无公众号发布技能');
                        publishResults.push({
                            platform,
                            status: 'manual',
                            message: '分身暂未配置公众号发布技能，请手动复制内容发布到公众号草稿箱'
                        });
                    }
                }
                else if (platform === 'wechat_moments') {
                    publishResults.push({
                        platform,
                        status: 'manual',
                        message: '朋友圈暂不支持自动发布，请手动复制内容后发布'
                    });
                }
                else if (platform === 'wechat_video') {
                    publishResults.push({
                        platform,
                        status: 'manual',
                        message: '视频号暂不支持自动发布，请手动复制内容后发布'
                    });
                }
                else {
                    if (hasPublishSkill) {
                        console.log('[OrderProcessing] 分身有发布技能，尝试自动发布');
                        await this.autoPublish(platform, order, finalContent, request.avatar_id);
                        publishResults.push({
                            platform,
                            status: 'success',
                            message: '已使用分身技能自动发布',
                            publishedAt: new Date().toISOString()
                        });
                    }
                    else {
                        console.log('[OrderProcessing] 分身无发布技能');
                        publishResults.push({
                            platform,
                            status: 'manual',
                            message: '分身暂未配置该平台的发布技能，请手动发布'
                        });
                    }
                }
            }
            catch (error) {
                console.error('[OrderProcessing] 平台发布失败:', { platform, error: error.message });
                publishResults.push({
                    platform,
                    status: 'manual',
                    message: `自动发布失败（${error.message}），请手动发布`
                });
            }
        }
        const hasSuccess = publishResults.some(r => r.status === 'success');
        const hasManual = publishResults.some(r => r.status === 'manual');
        await client
            .from('order_dispatch_requests')
            .update({
            status: 'published',
            confirmed_content: finalContent,
            publish_status: {
                platforms: publishResults,
                summary: hasSuccess
                    ? '部分或全部平台发布成功，请反馈发布效果'
                    : '需要手动发布，请发布后反馈效果'
            }
        })
            .eq('id', requestId);
        if (hasSuccess || hasManual) {
            await client
                .from('orders')
                .update({ status: 'published' })
                .eq('id', request.order_id);
        }
        return {
            success: true,
            publishResults,
            content: finalContent,
            summary: hasSuccess
                ? '部分或全部平台发布成功'
                : '需要手动发布'
        };
    }
    async regenerateContent(requestId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        console.log('[OrderProcessing] 开始重新生成内容:', { requestId });
        const { data: request, error: requestError } = await client
            .from('order_dispatch_requests')
            .select('id, order_id, avatar_id, status')
            .eq('id', requestId)
            .single();
        if (requestError || !request) {
            throw new Error('获取订单请求失败');
        }
        const { data: order, error: orderError } = await client
            .from('orders')
            .select('*')
            .eq('id', request.order_id)
            .single();
        if (orderError || !order) {
            throw new Error('获取订单信息失败');
        }
        const { data: avatar, error: avatarError } = await client
            .from('avatars')
            .select('*')
            .eq('id', request.avatar_id)
            .single();
        if (avatarError || !avatar) {
            throw new Error('获取分身信息失败');
        }
        console.log('[OrderProcessing] 订单和分身信息:', {
            orderId: order.id,
            orderTitle: order.title,
            avatarId: avatar.id,
            avatarName: avatar.name
        });
        await client
            .from('order_dispatch_requests')
            .update({
            status: 'accepted',
            generated_content: null,
            confirmed_content: null,
            publish_status: null
        })
            .eq('id', requestId);
        const { position, estimatedTime } = await this.queue.enqueue(requestId);
        console.log('[OrderProcessing] 重新生成任务已加入队列:', {
            requestId,
            position,
            estimatedTime
        });
        return {
            success: true,
            position,
            estimatedTime
        };
    }
    async checkGenerateSkill(platform, avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: skills } = await client
            .from('avatar_skills')
            .select('*')
            .eq('avatar_id', avatarId);
        if (!skills || skills.length === 0) {
            return false;
        }
        const platformSkillMap = {
            'wechat_mp': 'write_wechat_mp_article',
            'xiaohongshu': 'write_xiaohongshu_note',
            'douyin': 'write_article',
            'weibo': 'write_article',
            'bilibili': 'write_article',
            'wechat_video': 'write_article',
            'wechat_moments': 'write_wechat_moments_content'
        };
        const skillType = platformSkillMap[platform] || 'write_article';
        const hasGenerateSkill = skills.some(skill => {
            const skillTypeFromDb = skill.skill_type;
            return skillTypeFromDb === skillType || skillTypeFromDb === 'write_article';
        });
        console.log('[OrderProcessing] 检查内容生成技能:', {
            avatarId,
            platform,
            skillType,
            hasGenerateSkill,
            availableSkills: skills.map(s => s.skill_type)
        });
        return hasGenerateSkill;
    }
    async checkPublishSkill(platform, avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: skills } = await client
            .from('avatar_skills')
            .select('*')
            .eq('avatar_id', avatarId);
        if (!skills || skills.length === 0) {
            return false;
        }
        const platformSkillMap = {
            'wechat_mp': 'publish_wechat_mp',
            'xiaohongshu': 'publish_xiaohongshu',
            'douyin': 'publish_douyin',
            'weibo': 'publish_weibo',
            'bilibili': 'publish_bilibili',
            'wechat_video': 'publish_wechat_video'
        };
        const skillType = platformSkillMap[platform];
        if (!skillType) {
            console.log('[OrderProcessing] 平台未映射发布技能:', { platform });
            return false;
        }
        const hasPublishSkill = skills.some(skill => {
            return skill.skill_type === skillType;
        });
        console.log('[OrderProcessing] 检查发布技能:', {
            avatarId,
            platform,
            skillType,
            hasPublishSkill,
            availableSkills: skills.map(s => s.skill_type)
        });
        return hasPublishSkill;
    }
    async autoPublish(platform, order, content, avatarId) {
        console.log('[OrderProcessing] 开始自动发布（调用分身技能）:', {
            platform,
            orderId: order.id,
            title: order.title,
            contentLength: content.length,
            avatarId
        });
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data: avatar, error: avatarError } = await client
                .from('avatars')
                .select('id, user_id, name')
                .eq('id', avatarId)
                .single();
            if (avatarError || !avatar) {
                console.error('[OrderProcessing] 获取分身信息失败:', avatarError);
                throw new Error('分身不存在');
            }
            const userId = avatar.user_id;
            console.log('[OrderProcessing] 分身信息:', { avatarId, userId, avatarName: avatar.name });
            const toolMap = {
                'wechat_mp': 'publish_wechat_mp',
                'xiaohongshu': 'publish_xiaohongshu',
                'douyin': 'publish_douyin',
                'weibo': 'publish_weibo',
                'bilibili': 'publish_bilibili',
                'wechat_video': 'publish_wechat_video'
            };
            const toolName = toolMap[platform];
            if (!toolName) {
                console.error('[OrderProcessing] 不支持的平台:', platform);
                throw new Error(`不支持的平台: ${platform}`);
            }
            console.log('[OrderProcessing] 调用分身发布工具:', { toolName, avatarId, userId });
            let publishParams = {
                title: order.title,
                content
            };
            if (platform === 'wechat_mp') {
                publishParams.auto_image = false;
            }
            console.log('[OrderProcessing] 发布参数:', {
                title: publishParams.title,
                contentLength: publishParams.content.length,
                auto_image: publishParams.auto_image
            });
            const thoughtContent = `发布内容到${platform}，标题：${order.title}，内容长度：${content.length}字`;
            const thought = {
                id: `publish_${order.id}_${Date.now()}`,
                avatarId,
                userId,
                content: thoughtContent,
                reasoning: `根据订单要求，将发布内容到${platform}平台`,
                intent: {
                    type: 'publish',
                    toolName,
                    params: publishParams,
                    confidence: 0.9
                },
                requiresTool: true,
                createdAt: new Date().toISOString()
            };
            console.log('[OrderProcessing] AvatarThought:', thought);
            const avatarContext = {
                userId,
                conversationId: `order_${order.id}`,
                metadata: {
                    orderId: order.id,
                    platform
                }
            };
            const result = await this.avatarAgentService.act(avatarId, thought, avatarContext);
            console.log('[OrderProcessing] 发布工具执行结果:', result);
            if (result.success) {
                console.log('[OrderProcessing] 发布成功');
                return result;
            }
            else {
                console.error('[OrderProcessing] 发布失败:', result.error);
                throw new Error(result.error || '发布失败');
            }
        }
        catch (error) {
            console.error('[OrderProcessing] 自动发布异常:', error);
            throw error;
        }
    }
    async submitPublishFeedback(requestId, feedback) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        console.log('[OrderProcessing] 开始提交发布反馈:', { requestId, feedback });
        const { data: request, error: requestError } = await client
            .from('order_dispatch_requests')
            .select('id, order_id, avatar_id, status, publish_status')
            .eq('id', requestId)
            .single();
        if (requestError || !request) {
            throw new Error('获取订单请求失败');
        }
        console.log('[OrderProcessing] 订单请求信息:', request);
        if (request.status !== 'published') {
            throw new Error('订单状态不允许提交反馈');
        }
        const enhancedFeedback = {};
        for (const [platform, feedbackData] of Object.entries(feedback)) {
            enhancedFeedback[platform] = { ...feedbackData };
            if (feedbackData.link) {
                console.log(`[OrderProcessing] 开始抓取平台 ${platform} 的链接数据: ${feedbackData.link}`);
                try {
                    const result = await this.linkValidationService.validateLink(feedbackData.link, request.order_id, request.avatar_id);
                    if (result.success && result.data) {
                        enhancedFeedback[platform] = {
                            ...feedbackData,
                            ...result.data
                        };
                        console.log(`[OrderProcessing] 平台 ${platform} 数据抓取成功:`, result.data);
                    }
                    else {
                        console.warn(`[OrderProcessing] 平台 ${platform} 数据抓取失败:`, result.error);
                    }
                }
                catch (error) {
                    console.error(`[OrderProcessing] 平台 ${platform} 数据抓取异常:`, error);
                }
            }
        }
        console.log('[OrderProcessing] 增强后的反馈数据:', enhancedFeedback);
        const { error: updateError } = await client
            .from('order_dispatch_requests')
            .update({
            publish_feedback: enhancedFeedback,
            status: 'awaiting_acceptance',
            publish_status: {
                ...request.publish_status,
                summary: '已提交发布反馈，等待发单者验收',
                feedbackSubmittedAt: new Date().toISOString()
            },
            updated_at: new Date().toISOString()
        })
            .eq('id', requestId);
        if (updateError) {
            console.error('[OrderProcessing] 更新反馈失败:', updateError);
            throw new Error('更新反馈失败');
        }
        const { error: orderUpdateError } = await client
            .from('orders')
            .update({
            status: 'reviewing',
            updated_at: new Date().toISOString()
        })
            .eq('id', request.order_id);
        if (orderUpdateError) {
            console.error('[OrderProcessing] 更新订单状态失败:', orderUpdateError);
        }
        console.log('[OrderProcessing] 订单状态已更新为 reviewing');
        for (const [platform, feedbackData] of Object.entries(enhancedFeedback)) {
            const screenshotUrls = feedbackData.images || (feedbackData.image ? [feedbackData.image] : []);
            if (screenshotUrls.length > 0) {
                const { data: workData, error: workError } = await client
                    .from('published_works')
                    .select('id')
                    .eq('order_id', request.order_id)
                    .eq('platform', platform)
                    .single();
                if (!workError && workData) {
                    await client
                        .from('published_works')
                        .update({
                        feedback_image: screenshotUrls[0],
                        feedback_images: screenshotUrls,
                        updated_at: new Date().toISOString()
                    })
                        .eq('id', workData.id);
                    console.log(`[OrderProcessing] 已更新平台 ${platform} 的反馈截图，共 ${screenshotUrls.length} 张`);
                }
            }
        }
        console.log('[OrderProcessing] 提交发布反馈成功');
        return {
            requestId,
            feedback: enhancedFeedback,
            status: 'awaiting_acceptance'
        };
    }
    async refreshFeedbackData(requestId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        console.log('[OrderProcessing] 开始刷新反馈数据:', { requestId });
        const { data: request, error: requestError } = await client
            .from('order_dispatch_requests')
            .select('id, order_id, avatar_id, status, publish_feedback')
            .eq('id', requestId)
            .single();
        if (requestError || !request) {
            throw new Error('获取订单请求失败');
        }
        if (!request.publish_feedback) {
            throw new Error('该订单没有提交反馈');
        }
        const enhancedFeedback = {};
        for (const [platform, feedbackData] of Object.entries(request.publish_feedback)) {
            const platformFeedback = feedbackData;
            enhancedFeedback[platform] = { ...platformFeedback };
            if (platformFeedback.link) {
                console.log(`[OrderProcessing] 开始抓取平台 ${platform} 的链接数据: ${platformFeedback.link}`);
                try {
                    const result = await this.linkValidationService.validateLink(platformFeedback.link, request.order_id, request.avatar_id);
                    if (result.success && result.data) {
                        enhancedFeedback[platform] = {
                            ...platformFeedback,
                            ...result.data
                        };
                        console.log(`[OrderProcessing] 平台 ${platform} 数据抓取成功:`, result.data);
                    }
                    else {
                        console.warn(`[OrderProcessing] 平台 ${platform} 数据抓取失败:`, result.error);
                    }
                }
                catch (error) {
                    console.error(`[OrderProcessing] 平台 ${platform} 数据抓取异常:`, error);
                }
            }
        }
        console.log('[OrderProcessing] 刷新后的反馈数据:', enhancedFeedback);
        const { error: updateError } = await client
            .from('order_dispatch_requests')
            .update({
            publish_feedback: enhancedFeedback,
            updated_at: new Date().toISOString()
        })
            .eq('id', requestId);
        if (updateError) {
            console.error('[OrderProcessing] 更新反馈失败:', updateError);
            throw new Error('更新反馈失败');
        }
        console.log('[OrderProcessing] 刷新反馈数据成功');
        return {
            requestId,
            feedback: enhancedFeedback
        };
    }
    async acceptContent(requestId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        console.log('[OrderProcessing] 发单者验收:', { requestId });
        const { data: request, error: requestError } = await client
            .from('order_dispatch_requests')
            .select('id, order_id, status, avatar_id')
            .eq('id', requestId)
            .single();
        if (requestError || !request) {
            console.error('[OrderProcessing] 查询分身请求失败:', requestError);
            throw new Error('分身请求不存在');
        }
        if (request.status !== 'awaiting_acceptance') {
            console.warn('[OrderProcessing] 当前状态不允许验收:', request.status);
            throw new Error(`当前状态不允许验收，当前状态: ${request.status}`);
        }
        const { data: orderData } = await client
            .from('orders')
            .select('id, is_paid, budget')
            .eq('id', request.order_id)
            .single();
        if (orderData && !orderData.is_paid) {
            console.warn('[OrderProcessing] 订单未支付，无法验收');
            throw new Error('订单尚未支付，请先完成支付后再验收');
        }
        const { error: updateError } = await client
            .from('order_dispatch_requests')
            .update({
            status: 'completed',
            updated_at: new Date().toISOString()
        })
            .eq('id', requestId);
        if (updateError) {
            console.error('[OrderProcessing] 更新分身请求状态失败:', updateError);
            throw new Error('验收失败');
        }
        try {
            const { data: orderData } = await client
                .from('orders')
                .select('budget')
                .eq('id', request.order_id)
                .single();
            if (orderData && orderData.budget && parseFloat(orderData.budget) > 0) {
                const { data: participatingRequests } = await client
                    .from('order_dispatch_requests')
                    .select('avatar_id')
                    .eq('order_id', request.order_id)
                    .not('status', 'in', '(rejected,cancelled)');
                const participantCount = participatingRequests?.length || 1;
                const budget = parseFloat(orderData.budget);
                const earningsPerAvatar = budget / participantCount;
                if (request.avatar_id) {
                    const { data: avatarData } = await client
                        .from('avatars')
                        .select('total_earnings')
                        .eq('id', request.avatar_id)
                        .single();
                    const currentEarnings = avatarData?.total_earnings || 0;
                    const newTotalEarnings = parseFloat(currentEarnings) + earningsPerAvatar;
                    await client
                        .from('avatars')
                        .update({ total_earnings: newTotalEarnings })
                        .eq('id', request.avatar_id);
                    console.log(`[OrderProcessing] 分身 ${request.avatar_id} 获得收益 ${earningsPerAvatar.toFixed(2)}（预算 ${budget} / 参与分身 ${participantCount} 个），总收益: ${newTotalEarnings.toFixed(2)}`);
                }
            }
        }
        catch (earningsError) {
            console.error('[OrderProcessing] 计算收益失败:', earningsError);
        }
        const { data: otherRequests } = await client
            .from('order_dispatch_requests')
            .select('id, status')
            .eq('order_id', request.order_id)
            .neq('status', 'completed');
        if (!otherRequests || otherRequests.length === 0) {
            await client
                .from('orders')
                .update({
                status: 'completed',
                updated_at: new Date().toISOString()
            })
                .eq('id', request.order_id);
            console.log('[OrderProcessing] 主订单状态更新为 completed');
        }
        console.log('[OrderProcessing] 验收成功');
        return {
            requestId,
            status: 'completed'
        };
    }
};
exports.OrderProcessingService = OrderProcessingService;
exports.OrderProcessingService = OrderProcessingService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [content_generation_service_1.ContentGenerationService,
        avatar_agent_service_1.AvatarAgentService,
        link_validation_service_1.LinkValidationService])
], OrderProcessingService);
//# sourceMappingURL=order-processing.service.js.map