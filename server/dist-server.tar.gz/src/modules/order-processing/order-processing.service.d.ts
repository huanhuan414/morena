import { ContentGenerationService } from '../content-generation/content-generation.service';
import { AvatarAgentService } from '../avatar-agent/avatar-agent.service';
import { LinkValidationService } from './link-validation.service';
export interface ProcessingStatus {
    requestId: string;
    orderId?: string;
    issuerId?: string;
    status: 'queuing' | 'generating' | 'preview' | 'publishing' | 'completed' | 'failed';
    isPaid?: boolean;
    queuePosition?: number;
    estimatedTime?: number;
    generatedContent?: {
        title: string;
        content: string;
        images?: string[];
        platforms: string[];
        contentType?: string;
    };
    publishStatus?: {
        platforms: Array<{
            platform: string;
            status: 'success' | 'failed' | 'manual';
            message: string;
            publishedAt?: string;
        }>;
        summary: string;
    };
    publishFeedback?: {
        screenshot_urls?: string[];
        link?: string;
        note?: string;
        feedbackSubmittedAt?: string;
    };
    avatarAccounts?: Array<{
        id: string;
        platform: string;
        account_name: string;
        account_url?: string;
        appid?: string;
    }>;
    earnings?: number;
    earningsStatus?: 'settled' | 'pending' | 'withdrawn';
    completedAt?: string;
}
export declare class OrderProcessingService {
    private readonly contentGenerationService;
    private readonly avatarAgentService;
    private readonly linkValidationService;
    private queue;
    private llmClient;
    constructor(contentGenerationService: ContentGenerationService, avatarAgentService: AvatarAgentService, linkValidationService: LinkValidationService);
    enqueueTask(requestId: string): Promise<{
        position: number;
        estimatedTime: number;
    }>;
    getProcessingStatus(requestId: string): Promise<ProcessingStatus>;
    triggerTask(requestId: string): Promise<{
        success: boolean;
        message: string;
    }>;
    private extractScreenshotUrls;
    private extractLink;
    confirmContent(requestId: string, content: string): Promise<{
        success: boolean;
    }>;
    publishContent(requestId: string, content?: string): Promise<{
        success: boolean;
        publishResults: {
            platform: string;
            status: "success" | "manual";
            message: string;
            publishedAt?: string;
        }[];
        content: any;
        summary: string;
    }>;
    regenerateContent(requestId: string): Promise<{
        success: boolean;
        position: number;
        estimatedTime: number;
    }>;
    private checkGenerateSkill;
    private checkPublishSkill;
    private autoPublish;
    submitPublishFeedback(requestId: string, feedback: Record<string, {
        image?: string;
        link?: string;
    }>): Promise<{
        requestId: string;
        feedback: Record<string, any>;
        status: string;
    }>;
    refreshFeedbackData(requestId: string): Promise<{
        requestId: string;
        feedback: Record<string, any>;
    }>;
    acceptContent(requestId: string): Promise<{
        requestId: string;
        status: string;
    }>;
}
