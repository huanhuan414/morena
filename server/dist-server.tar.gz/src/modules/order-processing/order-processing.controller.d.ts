import { OrderProcessingService, ProcessingStatus } from './order-processing.service';
import { LinkValidationService } from './link-validation.service';
export declare class OrderProcessingController {
    private readonly processingService;
    private readonly linkValidationService;
    constructor(processingService: OrderProcessingService, linkValidationService: LinkValidationService);
    getStatus(requestId: string): Promise<{
        code: number;
        data: ProcessingStatus;
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    validateLink(url: string, orderId?: string, avatarId?: string): Promise<{
        code: number;
        data: import("./link-validation.service").ValidateResult;
        message: string;
    } | {
        code: number;
        data: {
            success: boolean;
            platform: string;
            error: any;
        };
        message: any;
    }>;
    getWorksByOrderId(orderId: string): Promise<{
        code: number;
        data: any[];
        message: string;
    } | {
        code: number;
        data: never[];
        message: any;
    }>;
    updateStatus(requestId: string, status: string): Promise<{
        code: number;
        data: {
            success: boolean;
        };
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    confirm(requestId: string, content: string): Promise<{
        code: number;
        data: {
            success: boolean;
        };
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    publish(requestId: string, content?: string): Promise<{
        code: number;
        data: {
            success: boolean;
            publishResults: {
                platform: string;
                status: "success" | "manual";
                message: string;
                publishedAt?: string;
            }[];
            content: any;
            summary: string;
        };
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    regenerate(requestId: string): Promise<{
        code: number;
        data: {
            success: boolean;
            position: number;
            estimatedTime: number;
        };
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    submitFeedback(requestId: string, feedback: Record<string, {
        images?: string[];
        image?: string;
        link?: string;
    }>): Promise<{
        code: number;
        data: {
            requestId: string;
            feedback: Record<string, any>;
            status: string;
        };
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    refreshFeedback(requestId: string): Promise<{
        code: number;
        data: {
            requestId: string;
            feedback: Record<string, any>;
        };
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    acceptContent(requestId: string): Promise<{
        code: number;
        data: {
            requestId: string;
            status: string;
        };
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    triggerTask(requestId: string): Promise<{
        code: number;
        data: {
            success: boolean;
            message: string;
        };
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
}
