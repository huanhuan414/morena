"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderProcessingController = void 0;
const common_1 = require("@nestjs/common");
const order_processing_service_1 = require("./order-processing.service");
const link_validation_service_1 = require("./link-validation.service");
const supabase_client_1 = require("../../storage/database/supabase-client");
let OrderProcessingController = class OrderProcessingController {
    constructor(processingService, linkValidationService) {
        this.processingService = processingService;
        this.linkValidationService = linkValidationService;
    }
    async getStatus(requestId) {
        try {
            const status = await this.processingService.getProcessingStatus(requestId);
            return {
                code: 200,
                data: status,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '获取失败'
            };
        }
    }
    async validateLink(url, orderId, avatarId) {
        try {
            const result = await this.linkValidationService.validateLink(url, orderId, avatarId);
            return {
                code: 200,
                data: result,
                message: result.success ? '验证成功' : '验证失败'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: {
                    success: false,
                    platform: 'unknown',
                    error: error.message || '验证失败'
                },
                message: error.message || '验证失败'
            };
        }
    }
    async getWorksByOrderId(orderId) {
        try {
            const works = await this.linkValidationService.getWorksByOrderId(orderId);
            return {
                code: 200,
                data: works,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: [],
                message: error.message || '获取失败'
            };
        }
    }
    async updateStatus(requestId, status) {
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { error } = await client
                .from('order_dispatch_requests')
                .update({ status })
                .eq('id', requestId);
            if (error) {
                throw new Error('更新状态失败');
            }
            return {
                code: 200,
                data: { success: true },
                message: '状态更新成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '更新失败'
            };
        }
    }
    async confirm(requestId, content) {
        try {
            const result = await this.processingService.confirmContent(requestId, content);
            return {
                code: 200,
                data: result,
                message: '确认成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '确认失败'
            };
        }
    }
    async publish(requestId, content) {
        try {
            const result = await this.processingService.publishContent(requestId, content);
            return {
                code: 200,
                data: result,
                message: '发布成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '发布失败'
            };
        }
    }
    async regenerate(requestId) {
        try {
            const result = await this.processingService.regenerateContent(requestId);
            return {
                code: 200,
                data: result,
                message: '重新生成成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '重新生成失败'
            };
        }
    }
    async submitFeedback(requestId, feedback) {
        try {
            const result = await this.processingService.submitPublishFeedback(requestId, feedback);
            return {
                code: 200,
                data: result,
                message: '反馈成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '反馈失败'
            };
        }
    }
    async refreshFeedback(requestId) {
        try {
            const result = await this.processingService.refreshFeedbackData(requestId);
            return {
                code: 200,
                data: result,
                message: '刷新成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '刷新失败'
            };
        }
    }
    async acceptContent(requestId) {
        try {
            console.log('[OrderProcessing] 发单者验收:', { requestId });
            const result = await this.processingService.acceptContent(requestId);
            return {
                code: 200,
                data: result,
                message: '验收成功'
            };
        }
        catch (error) {
            console.error('[OrderProcessing] 验收失败:', error);
            return {
                code: 500,
                data: null,
                message: error.message || '验收失败'
            };
        }
    }
    async triggerTask(requestId) {
        try {
            const result = await this.processingService.triggerTask(requestId);
            return {
                code: 200,
                data: result,
                message: '任务已触发'
            };
        }
        catch (error) {
            console.error('[OrderProcessing] 触发任务失败:', error);
            return {
                code: 500,
                data: null,
                message: error.message || '触发失败'
            };
        }
    }
};
exports.OrderProcessingController = OrderProcessingController;
__decorate([
    (0, common_1.Get)('status/:requestId'),
    __param(0, (0, common_1.Param)('requestId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "getStatus", null);
__decorate([
    (0, common_1.Post)('validate-link'),
    __param(0, (0, common_1.Body)('url')),
    __param(1, (0, common_1.Body)('orderId')),
    __param(2, (0, common_1.Body)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "validateLink", null);
__decorate([
    (0, common_1.Get)('works/:orderId'),
    __param(0, (0, common_1.Param)('orderId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "getWorksByOrderId", null);
__decorate([
    (0, common_1.Put)('status/:requestId'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, common_1.Body)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Post)('confirm/:requestId'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, common_1.Body)('content')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "confirm", null);
__decorate([
    (0, common_1.Post)('publish/:requestId'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, common_1.Body)('content')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "publish", null);
__decorate([
    (0, common_1.Post)('regenerate/:requestId'),
    __param(0, (0, common_1.Param)('requestId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "regenerate", null);
__decorate([
    (0, common_1.Post)('feedback/:requestId'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, common_1.Body)('feedback')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "submitFeedback", null);
__decorate([
    (0, common_1.Post)('refresh-feedback/:requestId'),
    __param(0, (0, common_1.Param)('requestId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "refreshFeedback", null);
__decorate([
    (0, common_1.Post)('accept/:requestId'),
    __param(0, (0, common_1.Param)('requestId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "acceptContent", null);
__decorate([
    (0, common_1.Post)('trigger-task/:requestId'),
    __param(0, (0, common_1.Param)('requestId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "triggerTask", null);
exports.OrderProcessingController = OrderProcessingController = __decorate([
    (0, common_1.Controller)('order-processing'),
    __metadata("design:paramtypes", [order_processing_service_1.OrderProcessingService,
        link_validation_service_1.LinkValidationService])
], OrderProcessingController);
//# sourceMappingURL=order-processing.controller.js.map