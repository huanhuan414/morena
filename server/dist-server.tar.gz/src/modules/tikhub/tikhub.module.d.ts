export declare class TikHubModule {
}
