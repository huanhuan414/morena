import { TikHubService } from './tikhub.service';
export declare class TikHubController {
    private readonly tikhubService;
    constructor(tikhubService: TikHubService);
    getDouyinUserInfo(body: {
        douyinId: string;
    }): Promise<{
        code: number;
        message: string;
        data: {
            sec_uid: any;
            nickname: any;
            avatar_url: any;
            signature: any;
            follower_count: any;
            following_count: any;
            aweme_count: any;
            total_favorited: number;
            favoriting_count: any;
        } | undefined;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
    getXiaohongshuUserInfo(body: {
        shareUrl: string;
    }): Promise<{
        code: number;
        message: string;
        data: {
            nickname: any;
            avatar_url: any;
            desc: any;
            follower_count: any;
            following_count: any;
            notes_count: any;
            interaction_count: any;
            total_favorited: any;
        } | undefined;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
}
