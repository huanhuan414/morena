import { ConfigService } from '@nestjs/config';
export declare class TikHubService {
    private configService;
    private readonly axios;
    private readonly apiKey;
    constructor(configService: ConfigService);
    callTikHubAPI(endpoint: string, params?: any, method?: 'GET' | 'POST'): Promise<any>;
    getDouyinUserInfo(douyinId: string): Promise<{
        success: boolean;
        data: {
            sec_uid: any;
            nickname: any;
            avatar_url: any;
            signature: any;
            follower_count: any;
            following_count: any;
            aweme_count: any;
            total_favorited: number;
            favoriting_count: any;
        };
        message?: undefined;
    } | {
        success: boolean;
        message: any;
        data?: undefined;
    }>;
    getXiaohongshuUserInfo(shareUrl: string): Promise<{
        success: boolean;
        message: any;
        data?: undefined;
    } | {
        success: boolean;
        data: {
            nickname: any;
            avatar_url: any;
            desc: any;
            follower_count: any;
            following_count: any;
            notes_count: any;
            interaction_count: any;
            total_favorited: any;
        };
        message?: undefined;
    }>;
}
