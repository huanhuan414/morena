"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TikHubService = void 0;
const common_1 = require("@nestjs/common");
const axios_1 = require("axios");
const config_1 = require("@nestjs/config");
let TikHubService = class TikHubService {
    constructor(configService) {
        this.configService = configService;
        this.apiKey = this.configService.get('TIKHUB_API_KEY') || 'iawtA+4A7Gr1hkOTKq2M5SfzahTUd5h4uUjatHyZS/m90wqBB2yqURXBKw==';
        this.axios = axios_1.default.create({
            baseURL: 'https://api.tikhub.io/api/v1',
            headers: {
                'Authorization': `Bearer ${this.apiKey}`,
                'Content-Type': 'application/json',
            },
            timeout: 30000,
        });
    }
    async callTikHubAPI(endpoint, params = {}, method = 'GET') {
        try {
            console.log(`[TikHubService] 调用 TikHub API: ${endpoint}`, params);
            console.log('[TikHubService] API Key 是否存在:', !!this.apiKey);
            if (!this.apiKey) {
                throw new Error('TikHub API Key 未配置');
            }
            let response;
            if (method === 'GET') {
                response = await this.axios.get(endpoint, { params });
            }
            else {
                response = await this.axios.post(endpoint, params);
            }
            console.log(`[TikHubService] TikHub API 响应状态:`, response.status);
            console.log(`[TikHubService] TikHub API 响应数据:`, JSON.stringify(response.data, null, 2));
            return response.data;
        }
        catch (error) {
            console.error(`[TikHubService] TikHub API 调用失败 (${endpoint}):`, error);
            console.error(`[TikHubService] 错误详情:`, error.response?.data || error.message);
            throw new Error(error.response?.data?.message || error.response?.data?.detail || error.message || 'API 调用失败');
        }
    }
    async getDouyinUserInfo(douyinId) {
        try {
            console.log('[TikHubService] 获取抖音用户信息，输入值:', douyinId);
            console.log('[TikHubService] API Key 是否存在:', !!this.apiKey);
            if (!this.apiKey) {
                return {
                    success: false,
                    message: 'TikHub API Key 未配置',
                };
            }
            const response = await this.axios.get('/douyin/web/handler_user_profile_v2', {
                params: {
                    unique_id: douyinId,
                },
            });
            console.log('[TikHubService] 抖音用户信息响应状态:', response.status);
            console.log('[TikHubService] 抖音用户信息响应数据:', JSON.stringify(response.data, null, 2));
            if (response.data?.code === 200 && response.data?.data?.user_info) {
                const userInfo = response.data.data.user_info;
                const totalFavorited = parseInt(userInfo.total_favorited || '0', 10);
                return {
                    success: true,
                    data: {
                        sec_uid: userInfo.sec_uid,
                        nickname: userInfo.nickname,
                        avatar_url: userInfo.avatar_medium?.url_list?.[0] || userInfo.avatar_thumb?.url_list?.[0] || '',
                        signature: userInfo.signature || '',
                        follower_count: userInfo.mplatform_followers_count || userInfo.follower_count || 0,
                        following_count: userInfo.following_count || 0,
                        aweme_count: userInfo.aweme_count || 0,
                        total_favorited: totalFavorited,
                        favoriting_count: userInfo.favoriting_count || 0,
                    },
                };
            }
            return {
                success: false,
                message: response.data?.message || response.data?.msg || '获取用户信息失败',
            };
        }
        catch (error) {
            console.error('[TikHubService] 获取抖音用户信息失败:', error);
            console.error('[TikHubService] 错误状态码:', error.response?.status);
            console.error('[TikHubService] 错误详情:', error.response?.data || error.message);
            const errorMsg = error.response?.data?.message ||
                error.response?.data?.msg ||
                error.response?.data?.detail ||
                '请检查抖音号是否正确';
            return {
                success: false,
                message: `获取失败 (${error.response?.status}): ${errorMsg}`,
            };
        }
    }
    async getXiaohongshuUserInfo(shareUrl) {
        try {
            console.log('[TikHubService] 获取小红书用户信息，分享链接:', shareUrl);
            console.log('[TikHubService] API Key 是否存在:', !!this.apiKey);
            if (!this.apiKey) {
                return {
                    success: false,
                    message: 'TikHub API Key 未配置',
                };
            }
            const tokenResponse = await this.axios.get('/xiaohongshu/app/get_user_id_and_xsec_token', {
                params: {
                    share_link: shareUrl,
                },
            });
            console.log('[TikHubService] 第一步获取token响应:', JSON.stringify(tokenResponse.data, null, 2));
            if (tokenResponse.data?.code !== 200 || !tokenResponse.data?.data) {
                return {
                    success: false,
                    message: tokenResponse.data?.message || '获取用户ID失败，请检查分享链接是否正确',
                };
            }
            const tokenData = tokenResponse.data.data;
            const userId = tokenData.user_id;
            const xsecToken = tokenData.xsec_token;
            console.log('[TikHubService] 获取到用户ID:', userId);
            const userResponse = await this.axios.get('/xiaohongshu/app/get_user_info', {
                params: {
                    user_id: userId,
                },
            });
            console.log('[TikHubService] 第二步获取用户信息响应:', JSON.stringify(userResponse.data, null, 2));
            if (userResponse.data?.code === 200 && userResponse.data?.data?.data) {
                const data = userResponse.data.data.data;
                const interaction = data.interactions?.find((item) => item.name === '获赞与收藏');
                const totalFavorited = interaction?.count || 0;
                return {
                    success: true,
                    data: {
                        nickname: data.nickname,
                        avatar_url: data.images || data.imageb,
                        desc: data.desc,
                        follower_count: data.fans || data.follower_count || 0,
                        following_count: data.follows || data.following_count || 0,
                        notes_count: data.note_num_stat?.posted || data.notes_count || 0,
                        interaction_count: totalFavorited,
                        total_favorited: totalFavorited,
                    },
                };
            }
            return {
                success: false,
                message: userResponse.data?.message || '获取用户详细信息失败',
            };
        }
        catch (error) {
            console.error('[TikHubService] 获取小红书用户信息失败:', error);
            console.error('[TikHubService] 错误详情:', error.response?.data || error.message);
            const errorMsg = error.response?.data?.detail ||
                error.response?.data?.message ||
                '请检查分享链接是否正确，确保使用完整的小红书分享链接';
            return {
                success: false,
                message: `获取失败: ${errorMsg}`,
            };
        }
    }
};
exports.TikHubService = TikHubService;
exports.TikHubService = TikHubService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], TikHubService);
//# sourceMappingURL=tikhub.service.js.map