export declare class OrderResultsModule {
}
