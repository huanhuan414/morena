"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderResultsController = void 0;
const common_1 = require("@nestjs/common");
const order_results_service_1 = require("./order-results.service");
let OrderResultsController = class OrderResultsController {
    constructor(orderResultsService) {
        this.orderResultsService = orderResultsService;
    }
    async createResult(dto) {
        const result = await this.orderResultsService.createResult(dto);
        return {
            code: 200,
            data: result,
            message: '提交成功'
        };
    }
    async getOrderResults(orderId) {
        const results = await this.orderResultsService.getOrderResults(orderId);
        return {
            code: 200,
            data: results,
            message: '获取成功'
        };
    }
    async getAvatarResults(avatarId) {
        const results = await this.orderResultsService.getAvatarResults(avatarId);
        return {
            code: 200,
            data: results,
            message: '获取成功'
        };
    }
};
exports.OrderResultsController = OrderResultsController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], OrderResultsController.prototype, "createResult", null);
__decorate([
    (0, common_1.Get)('order/:orderId'),
    __param(0, (0, common_1.Param)('orderId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderResultsController.prototype, "getOrderResults", null);
__decorate([
    (0, common_1.Get)('avatar/:avatarId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderResultsController.prototype, "getAvatarResults", null);
exports.OrderResultsController = OrderResultsController = __decorate([
    (0, common_1.Controller)('order-results'),
    __metadata("design:paramtypes", [order_results_service_1.OrderResultsService])
], OrderResultsController);
//# sourceMappingURL=order-results.controller.js.map