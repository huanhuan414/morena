import { OrderResultsService, CreateResultDto } from './order-results.service';
export declare class OrderResultsController {
    private readonly orderResultsService;
    constructor(orderResultsService: OrderResultsService);
    createResult(dto: CreateResultDto): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getOrderResults(orderId: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
    getAvatarResults(avatarId: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
}
