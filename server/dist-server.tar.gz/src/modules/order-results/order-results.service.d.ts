export interface CreateResultDto {
    order_id: string;
    avatar_id: string;
    exposure: number;
    likes: number;
    comments?: number;
    shares?: number;
    link_url?: string;
    description?: string;
}
export declare class OrderResultsService {
    createResult(dto: CreateResultDto): Promise<any>;
    getOrderResults(orderId: string): Promise<any[]>;
    getAvatarResults(avatarId: string): Promise<any[]>;
}
