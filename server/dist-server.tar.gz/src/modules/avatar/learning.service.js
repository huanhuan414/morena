"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LearningService = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const supabase_client_1 = require("../../storage/database/supabase-client");
let LearningService = class LearningService {
    async analyzeAndUpdate(avatarId, userId, userMessage, aiResponse, conversationContext) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        try {
            const { data: avatar } = await client
                .from('avatars')
                .select('config, learning_data')
                .eq('id', avatarId)
                .single();
            if (!avatar) {
                console.error('[LearningService] 分身不存在:', avatarId);
                return;
            }
            const rawLearningData = avatar?.learning_data;
            const currentLearning = (rawLearningData && typeof rawLearningData === 'object' && 'messageCount' in rawLearningData)
                ? rawLearningData
                : this.getDefaultLearningData();
            const analysis = await this.analyzeMessage(userMessage, conversationContext);
            const styleAnalysis = this.analyzeStyleFingerprint(userMessage, currentLearning.styleFingerprint);
            const updatedLearning = this.mergeLearningData(currentLearning, analysis, styleAnalysis, userMessage);
            const progressMetrics = this.calculateProgressMetrics(updatedLearning);
            await client
                .from('avatars')
                .update({
                learning_data: updatedLearning,
                config: {
                    ...avatar?.config,
                    learning: {
                        messageCount: updatedLearning.messageCount,
                        avgMessageLength: updatedLearning.avgMessageLength,
                        masteryLevel: progressMetrics.masteryLevel,
                        learningDays: progressMetrics.learningDays,
                        styleMatch: progressMetrics.styleMatch
                    },
                    lastInteraction: new Date().toISOString(),
                    learningVersion: 2
                },
                level: progressMetrics.level,
                exp: progressMetrics.totalExp,
                updated_at: new Date().toISOString()
            })
                .eq('id', avatarId);
            console.log('[LearningService] 学习数据已更新:', avatarId, {
                messageCount: updatedLearning.messageCount,
                masteryLevel: progressMetrics.masteryLevel,
                level: progressMetrics.level,
                totalExp: progressMetrics.totalExp
            });
        }
        catch (error) {
            console.error('[LearningService] 学习分析失败:', error);
        }
    }
    async analyzeMessage(message, context) {
        const config = new coze_coding_dev_sdk_1.Config();
        const llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
        const prompt = `你是一个专业的用户行为分析专家。请分析以下用户消息，提取用户的深层特征。

用户消息：${message}
${context && context.length > 0 ? `对话上下文：${context.slice(-3).join('\n')}` : ''}

请以JSON格式返回分析结果，格式如下：
{
  "userIdentity": {
    "occupation": "创业者",
    "education": "硕士",
    "personalityType": "开朗",
    "lifeEvents": ["结婚了", "媳妇是医生"]
  },
  "tone": {
    "formal": 0.7,
    "casual": 0.3,
    "humorous": 0.2,
    "emotional": 0.5
  },
  "personality": {
    "openness": 0.8,
    "conscientiousness": 0.6,
    "extraversion": 0.5,
    "agreeableness": 0.7,
    "neuroticism": 0.3
  },
  "logic": {
    "analytical": 0.6,
    "intuitive": 0.4,
    "structured": 0.5,
    "creative": 0.7
  },
  "decision": {
    "decisive": 0.5,
    "deliberative": 0.6,
    "riskTaking": 0.4,
    "cautious": 0.6
  },
  "communication": {
    "direct": 0.6,
    "polite": 0.7,
    "detailed": 0.5,
    "concise": 0.5
  },
  "interests": ["AI", "科技", "学习"],
  "keyPhrases": ["帮我", "分析一下", "好的"]
}

分析要点：
1. userIdentity 提取用户的职业、性格类型、重要生活事件
   - occupation: 用户提到的职业或身份（如：创业者、程序员、医生、学生）
   - personalityType: 用户自称的性格特点（如：开朗、内向、幽默）
   - lifeEvents: 用户提到的重要生活事件（如：结婚了、媳妇是医生）
2. tone 分析用户说话的语气风格
3. personality 基于大五人格模型分析（用户自称开朗时，extraversion应较高）
4. logic 分析用户的思维方式
5. decision 分析用户的决策风格
6. communication 分析用户的沟通偏好
7. interests 提取用户感兴趣的话题
8. keyPhrases 提取用户常用的表达方式

只返回JSON，不要有其他内容。`;
        try {
            const response = await llmClient.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-6-vision-250815',
                temperature: 0.3
            });
            const jsonMatch = response.content.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                return JSON.parse(jsonMatch[0]);
            }
        }
        catch (error) {
            console.error('[LearningService] LLM分析失败:', error);
        }
        return {};
    }
    analyzeStyleFingerprint(message, current) {
        const sentences = message.split(/[。！？.!?]+/).filter(s => s.trim());
        const avgSentenceLength = sentences.length > 0
            ? sentences.reduce((sum, s) => sum + s.length, 0) / sentences.length
            : 0;
        const emojiCount = (message.match(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu) || []).length;
        const questionCount = (message.match(/[？?]/g) || []).length;
        const exclamationCount = (message.match(/[！!]/g) || []).length;
        const charCount = message.length;
        const punctuationCount = (message.match(/[，。！？、；：""''（）【】,.!?;:()\[\]]/g) || []).length;
        const punctuationDensity = charCount > 0 ? punctuationCount / charCount : 0;
        return {
            sentenceLength: avgSentenceLength < 10 ? 'short' : avgSentenceLength < 25 ? 'medium' : 'long',
            punctuationStyle: punctuationDensity < 0.05 ? 'minimal' : punctuationDensity < 0.12 ? 'normal' : 'expressive',
            emojiFrequency: charCount > 0 ? Math.min(1, emojiCount / (charCount / 20)) : 0,
            questionFrequency: sentences.length > 0 ? Math.min(1, questionCount / sentences.length) : 0,
            exclamationFrequency: sentences.length > 0 ? Math.min(1, exclamationCount / sentences.length) : 0,
            vocabularyLevel: this.assessVocabularyLevel(message)
        };
    }
    assessVocabularyLevel(message) {
        const sophisticatedWords = ['因此', '然而', '综上所述', '鉴于', '由此可见', '本质上', '根本上', '从某种意义上'];
        const moderateWords = ['但是', '而且', '因为', '所以', '如果', '虽然', '但是', '可能'];
        let sophisticatedCount = 0;
        let moderateCount = 0;
        sophisticatedWords.forEach(word => {
            if (message.includes(word))
                sophisticatedCount++;
        });
        moderateWords.forEach(word => {
            if (message.includes(word))
                moderateCount++;
        });
        if (sophisticatedCount >= 2)
            return 'sophisticated';
        if (moderateCount >= 2 || sophisticatedCount >= 1)
            return 'moderate';
        return 'simple';
    }
    mergeLearningData(current, analysis, styleAnalysis, message) {
        const learningRate = 0.15;
        const newMessageCount = current.messageCount + 1;
        const newIdentity = { ...(current.userIdentity || {}) };
        if (analysis.userIdentity) {
            if (analysis.userIdentity.occupation) {
                console.log('[LearningService] 学习到职业:', analysis.userIdentity.occupation);
                newIdentity.occupation = analysis.userIdentity.occupation;
            }
            if (analysis.userIdentity.education) {
                console.log('[LearningService] 学习到学历:', analysis.userIdentity.education);
                newIdentity.education = analysis.userIdentity.education;
            }
            if (analysis.userIdentity.personalityType) {
                console.log('[LearningService] 学习到性格:', analysis.userIdentity.personalityType);
                newIdentity.personalityType = analysis.userIdentity.personalityType;
            }
            if (analysis.userIdentity.lifeEvents && analysis.userIdentity.lifeEvents.length > 0) {
                console.log('[LearningService] 学习到生活事件:', analysis.userIdentity.lifeEvents);
                newIdentity.lifeEvents = [
                    ...(newIdentity.lifeEvents || []),
                    ...analysis.userIdentity.lifeEvents.filter((e) => !(newIdentity.lifeEvents || []).includes(e))
                ].slice(0, 10);
            }
        }
        return {
            messageCount: newMessageCount,
            avgMessageLength: this.updateAverage(current.avgMessageLength, message.length, current.messageCount),
            totalInteractionTime: current.totalInteractionTime + 1,
            userIdentity: newIdentity,
            toneProfile: {
                formal: this.mergeValue(current.toneProfile.formal, analysis.tone?.formal, learningRate),
                casual: this.mergeValue(current.toneProfile.casual, analysis.tone?.casual, learningRate),
                humorous: this.mergeValue(current.toneProfile.humorous, analysis.tone?.humorous, learningRate),
                emotional: this.mergeValue(current.toneProfile.emotional, analysis.tone?.emotional, learningRate),
            },
            personalityTraits: {
                openness: this.mergeValue(current.personalityTraits.openness, analysis.personality?.openness, learningRate),
                conscientiousness: this.mergeValue(current.personalityTraits.conscientiousness, analysis.personality?.conscientiousness, learningRate),
                extraversion: this.mergeValue(current.personalityTraits.extraversion, analysis.personality?.extraversion, learningRate),
                agreeableness: this.mergeValue(current.personalityTraits.agreeableness, analysis.personality?.agreeableness, learningRate),
                neuroticism: this.mergeValue(current.personalityTraits.neuroticism, analysis.personality?.neuroticism, learningRate),
            },
            logicPattern: {
                analytical: this.mergeValue(current.logicPattern.analytical, analysis.logic?.analytical, learningRate),
                intuitive: this.mergeValue(current.logicPattern.intuitive, analysis.logic?.intuitive, learningRate),
                structured: this.mergeValue(current.logicPattern.structured, analysis.logic?.structured, learningRate),
                creative: this.mergeValue(current.logicPattern.creative, analysis.logic?.creative, learningRate),
            },
            decisionStyle: {
                decisive: this.mergeValue(current.decisionStyle.decisive, analysis.decision?.decisive, learningRate),
                deliberative: this.mergeValue(current.decisionStyle.deliberative, analysis.decision?.deliberative, learningRate),
                riskTaking: this.mergeValue(current.decisionStyle.riskTaking, analysis.decision?.riskTaking, learningRate),
                cautious: this.mergeValue(current.decisionStyle.cautious, analysis.decision?.cautious, learningRate),
            },
            communicationStyle: {
                direct: this.mergeValue(current.communicationStyle.direct, analysis.communication?.direct, learningRate),
                polite: this.mergeValue(current.communicationStyle.polite, analysis.communication?.polite, learningRate),
                detailed: this.mergeValue(current.communicationStyle.detailed, analysis.communication?.detailed, learningRate),
                concise: this.mergeValue(current.communicationStyle.concise, analysis.communication?.concise, learningRate),
            },
            interests: this.mergeLists(current.interests, analysis.interests || [], 20),
            commonPhrases: this.mergeLists(current.commonPhrases, analysis.keyPhrases || [], 30),
            emojiUsage: this.extractEmojis(message, current.emojiUsage),
            styleFingerprint: {
                ...current.styleFingerprint,
                ...styleAnalysis
            },
            experiences: this.addExperience(current.experiences, message),
            learningHistory: current.learningHistory
        };
    }
    calculateProgressMetrics(learning) {
        const messageScore = Math.min(50, learning.messageCount * 2);
        const convergenceScore = this.calculateConvergenceScore(learning);
        const styleConsistency = this.calculateStyleConsistency(learning);
        const masteryLevel = Math.min(100, Math.round(messageScore + convergenceScore * 30 + styleConsistency * 20));
        const learningDays = Math.max(1, Math.floor(learning.messageCount / 10));
        const styleMatch = Math.round(styleConsistency * 100);
        const totalExp = learning.messageCount * 10 + masteryLevel * 5;
        const level = Math.min(10, Math.floor(totalExp / 100) + 1);
        return {
            masteryLevel,
            learningDays,
            styleMatch,
            level,
            totalExp
        };
    }
    calculateConvergenceScore(learning) {
        const features = [
            ...Object.values(learning.toneProfile),
            ...Object.values(learning.personalityTraits),
            ...Object.values(learning.logicPattern),
            ...Object.values(learning.decisionStyle),
            ...Object.values(learning.communicationStyle)
        ];
        const avgDeviation = features.reduce((sum, value) => {
            return sum + Math.abs(value - 0.5) * 2;
        }, 0) / features.length;
        return avgDeviation;
    }
    calculateStyleConsistency(learning) {
        const fingerprint = learning.styleFingerprint;
        let consistency = 0.5;
        if (fingerprint.emojiFrequency > 0)
            consistency += 0.1;
        if (fingerprint.sentenceLength !== 'medium')
            consistency += 0.1;
        if (fingerprint.punctuationStyle !== 'normal')
            consistency += 0.1;
        if (fingerprint.vocabularyLevel !== 'moderate')
            consistency += 0.1;
        return Math.min(1, consistency);
    }
    mergeValue(current, update, rate) {
        if (update === undefined)
            return current;
        return current * (1 - rate) + update * rate;
    }
    mergeLists(current, update, maxLength) {
        const merged = [...new Set([...update, ...current])];
        return merged.slice(0, maxLength);
    }
    updateAverage(current, newValue, count) {
        return (current * count + newValue) / (count + 1);
    }
    extractEmojis(message, current) {
        const emojiRegex = /[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu;
        const emojis = message.match(emojiRegex) || [];
        return [...new Set([...emojis, ...current])].slice(0, 30);
    }
    addExperience(experiences, message) {
        const newExperience = {
            topic: message.slice(0, 50),
            context: message,
            timestamp: new Date().toISOString()
        };
        return [newExperience, ...experiences].slice(0, 100);
    }
    getDefaultLearningData() {
        return {
            messageCount: 0,
            avgMessageLength: 0,
            totalInteractionTime: 0,
            userIdentity: {
                occupation: undefined,
                personalityType: undefined,
                lifeEvents: []
            },
            toneProfile: {
                formal: 0.5,
                casual: 0.5,
                humorous: 0.3,
                emotional: 0.5
            },
            personalityTraits: {
                openness: 0.5,
                conscientiousness: 0.5,
                extraversion: 0.5,
                agreeableness: 0.5,
                neuroticism: 0.5
            },
            logicPattern: {
                analytical: 0.5,
                intuitive: 0.5,
                structured: 0.5,
                creative: 0.5
            },
            decisionStyle: {
                decisive: 0.5,
                deliberative: 0.5,
                riskTaking: 0.3,
                cautious: 0.5
            },
            interests: [],
            commonPhrases: [],
            emojiUsage: [],
            communicationStyle: {
                direct: 0.5,
                polite: 0.6,
                detailed: 0.5,
                concise: 0.5
            },
            styleFingerprint: {
                sentenceLength: 'medium',
                punctuationStyle: 'normal',
                emojiFrequency: 0,
                questionFrequency: 0,
                exclamationFrequency: 0,
                vocabularyLevel: 'moderate'
            },
            experiences: [],
            learningHistory: []
        };
    }
    async buildPersonalizedPrompt(avatarId, avatar) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        try {
            const { data: avatarData } = await client
                .from('avatars')
                .select('learning_data')
                .eq('id', avatarId)
                .single();
            const learning = avatarData?.learning_data || this.getDefaultLearningData();
            if (learning.messageCount < 5) {
                return this.buildBasicPrompt(avatar);
            }
            const personality = avatar?.personality || '友好、专业、乐于助人';
            const name = avatar?.name || 'AI助手';
            const dominantTraits = this.extractDominantTraits(learning);
            const styleGuide = this.buildStyleGuide(learning);
            const languageHabits = this.buildLanguageHabits(learning);
            const identityInfo = this.buildIdentityInfo(learning);
            return `你是${name}，一个正在学习用户风格的AI分身。

【基础设定】
性格特点：${personality}
当前等级：Lv.${avatar?.level || 1}
已学习对话：${learning.messageCount}条
风格掌握度：${Math.round(this.calculateConvergenceScore(learning) * 100)}%

【用户画像】
${identityInfo}

【你的主导性格特征】
${dominantTraits}

【说话风格指南】
${styleGuide}

【语言习惯】
${languageHabits}

【兴趣话题】
${learning.interests.length > 0 ? learning.interests.slice(0, 5).join('、') : '暂无特定偏好'}

【重要规则】
1. 你正在学习用户的说话风格，请根据上述特征调整你的表达方式
2. 保持自然流畅，不要刻意模仿，而是让风格自然融入
3. 随着对话增多，你会越来越像用户
4. 使用用户习惯的表达方式和语气
5. 在回复中体现用户的思维方式和决策风格
6. 记住用户告诉你的身份信息（职业、性格、生活事件），在对话中体现对这些的了解

记住：你不是在扮演用户，而是在学习用户的风格特点，让对话更加自然和谐。`;
        }
        catch (error) {
            console.error('[LearningService] 构建个性化提示词失败:', error);
            return this.buildBasicPrompt(avatar);
        }
    }
    buildBasicPrompt(avatar) {
        const personality = avatar?.personality || '友好、专业、乐于助人';
        const name = avatar?.name || 'AI助手';
        return `你是${name}，一个AI分身。
性格特点：${personality}
当前等级：Lv.${avatar?.level || 1}

你的能力：
1. 智能对话 - 与用户进行自然流畅的交流
2. 任务执行 - 帮助用户完成各种任务（生成图片、视频、文章等）
3. 知识问答 - 回答用户的问题

回复时使用自然的语言，避免过于机械。`;
    }
    extractDominantTraits(learning) {
        const traits = [];
        if (learning.toneProfile.formal > 0.6)
            traits.push('说话较为正式');
        if (learning.toneProfile.casual > 0.6)
            traits.push('说话较为随性');
        if (learning.toneProfile.humorous > 0.6)
            traits.push('喜欢幽默表达');
        if (learning.toneProfile.emotional > 0.6)
            traits.push('情感表达丰富');
        if (learning.personalityTraits.openness > 0.6)
            traits.push('思维开放，乐于接受新事物');
        if (learning.personalityTraits.conscientiousness > 0.6)
            traits.push('做事认真负责');
        if (learning.personalityTraits.extraversion > 0.6)
            traits.push('性格外向，善于表达');
        if (learning.personalityTraits.agreeableness > 0.6)
            traits.push('待人友善');
        if (learning.logicPattern.analytical > 0.6)
            traits.push('善于分析问题');
        if (learning.logicPattern.creative > 0.6)
            traits.push('思维有创造力');
        if (learning.logicPattern.structured > 0.6)
            traits.push('喜欢有条理的表达');
        if (learning.decisionStyle.decisive > 0.6)
            traits.push('决策果断');
        if (learning.decisionStyle.cautious > 0.6)
            traits.push('做事谨慎');
        return traits.length > 0 ? traits.join('；') : '风格特征正在形成中...';
    }
    buildStyleGuide(learning) {
        const guide = [];
        const comm = learning.communicationStyle;
        if (comm.direct > 0.6) {
            guide.push('- 回答要直接了当，不要绕弯子');
        }
        else if (comm.polite > 0.6) {
            guide.push('- 回答要礼貌周到，注意用词');
        }
        if (comm.detailed > 0.6) {
            guide.push('- 回答要详细完整，提供足够信息');
        }
        else if (comm.concise > 0.6) {
            guide.push('- 回答要简洁明了，抓住要点');
        }
        const fp = learning.styleFingerprint;
        if (fp.sentenceLength === 'short') {
            guide.push('- 使用短句表达，简洁有力');
        }
        else if (fp.sentenceLength === 'long') {
            guide.push('- 可以使用较长的句子，表达完整');
        }
        if (fp.emojiFrequency > 0.3) {
            guide.push('- 适当使用表情符号增加亲和力');
        }
        if (fp.questionFrequency > 0.3) {
            guide.push('- 可以适当提问，引导对话');
        }
        return guide.length > 0 ? guide.join('\n') : '- 保持自然流畅的对话风格';
    }
    buildIdentityInfo(learning) {
        const identity = learning.userIdentity;
        if (!identity) {
            return '暂未学习到用户身份信息';
        }
        const parts = [];
        if (identity.occupation) {
            parts.push(`职业：${identity.occupation}`);
        }
        if (identity.personalityType) {
            parts.push(`性格：${identity.personalityType}`);
        }
        if (identity.lifeEvents && identity.lifeEvents.length > 0) {
            parts.push(`重要事件：${identity.lifeEvents.join('、')}`);
        }
        return parts.length > 0 ? parts.join('\n') : '暂未学习到用户身份信息';
    }
    buildLanguageHabits(learning) {
        const habits = [];
        if (learning.commonPhrases.length > 0) {
            habits.push(`常用表达：${learning.commonPhrases.slice(0, 5).join('、')}`);
        }
        if (learning.emojiUsage.length > 0) {
            habits.push(`常用表情：${learning.emojiUsage.slice(0, 5).join('')}`);
        }
        if (learning.styleFingerprint.vocabularyLevel === 'sophisticated') {
            habits.push('词汇使用：偏向使用书面语和专业术语');
        }
        else if (learning.styleFingerprint.vocabularyLevel === 'simple') {
            habits.push('词汇使用：偏向使用简单通俗的表达');
        }
        return habits.length > 0 ? habits.join('\n') : '暂无明显习惯';
    }
    async getUserProfile(avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: avatar } = await client
            .from('avatars')
            .select('learning_data, level')
            .eq('id', avatarId)
            .single();
        let rawLearning = avatar?.learning_data;
        if (rawLearning && typeof rawLearning === 'object' && !Array.isArray(rawLearning) && !('messageCount' in rawLearning)) {
            console.log('[LearningService] learning_data 格式不正确，使用空数据:', typeof rawLearning);
            rawLearning = null;
        }
        if (!rawLearning || !rawLearning.messageCount || rawLearning.messageCount === 0) {
            return { learning: null, metrics: null };
        }
        const learning = rawLearning;
        const metrics = this.calculateProgressMetrics(learning);
        return {
            learning,
            metrics: {
                masteryLevel: metrics.masteryLevel,
                learningDays: metrics.learningDays,
                styleMatch: metrics.styleMatch,
                level: avatar?.level || metrics.level
            }
        };
    }
};
exports.LearningService = LearningService;
exports.LearningService = LearningService = __decorate([
    (0, common_1.Injectable)()
], LearningService);
//# sourceMappingURL=learning.service.js.map