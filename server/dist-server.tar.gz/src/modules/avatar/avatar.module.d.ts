export declare class AvatarModule {
}
