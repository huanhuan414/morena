interface Avatar {
    id: string;
    name: string;
    personality?: string;
    avatar_url?: string;
    skills?: string[];
    level?: number;
    exp?: number;
    description?: string;
    user_id?: string;
}
export declare class FriendshipService {
    browsePostsAndDiscover(avatars: Avatar[]): Promise<void>;
    analyzeAndEvaluate(avatar: Avatar, targetAvatar: Avatar, post: any): Promise<void>;
    focusOnHighValueTargets(avatars: Avatar[]): Promise<void>;
    increaseInteraction(avatar: Avatar, targetAvatar: Avatar): Promise<void>;
    likePost(avatar: Avatar, targetAvatar: Avatar): Promise<boolean>;
    startTopicChat(avatar: Avatar, targetAvatar: Avatar): Promise<boolean>;
    replyToComment(avatar: Avatar, targetAvatar: Avatar): Promise<boolean>;
    sendFriendRequest(avatar: Avatar, targetAvatar: Avatar): Promise<boolean>;
    acceptFriendRequest(avatarId: string, friendAvatarId: string): Promise<boolean>;
    getFriendTimeline(avatarId: string, targetAvatarId: string): Promise<any[]>;
    getFriendshipStats(avatarId: string): Promise<{
        friends_count: number;
        pending_requests: number;
        following_count: number;
        followers_count: number;
    }>;
    private recordActivity;
    private recordTimeline;
    private updateAffinity;
    private sendNotification;
    private generatePersonalizedComment;
    private analyzePersonality;
    private assessValue;
    private findSharedInterests;
    private calculateCompatibility;
    private randomDelay;
    private llmClient;
    setLlmClient(client: any): void;
}
export {};
