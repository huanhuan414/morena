import { OnGatewayConnection, OnGatewayDisconnect } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { VoiceCallService } from './voice-call.service';
export declare class VoiceCallGateway implements OnGatewayConnection, OnGatewayDisconnect {
    private readonly voiceCallService;
    server: Server;
    private readonly logger;
    private callSessions;
    private socketCallMap;
    constructor(voiceCallService: VoiceCallService);
    handleConnection(client: Socket): void;
    handleDisconnect(client: Socket): void;
    private doEndCall;
    handleStartCall(client: Socket, payload: {
        avatarId: string;
        friendAvatarId: string;
        userId: string;
    }): Promise<{
        success: boolean;
        callId: string;
        greeting: {
            text: string;
            audioUrl: string;
            friendName: any;
        };
        error?: undefined;
    } | {
        success: boolean;
        error: any;
        callId?: undefined;
        greeting?: undefined;
    }>;
    handleSendAudio(client: Socket, payload: {
        callId: string;
        audioUrl: string;
    }): Promise<{
        success: boolean;
        userText: string;
        replyText: string;
        audioUrl: string;
        error?: undefined;
    } | {
        success: boolean;
        error: any;
        userText?: undefined;
        replyText?: undefined;
        audioUrl?: undefined;
    }>;
    handleSendText(client: Socket, payload: {
        callId: string;
        text: string;
    }): Promise<{
        success: boolean;
        replyText: string;
        audioUrl: string;
        error?: undefined;
    } | {
        success: boolean;
        error: any;
        replyText?: undefined;
        audioUrl?: undefined;
    }>;
    handleEndCall(client: Socket, payload: {
        callId: string;
    }): {
        success: boolean;
    };
    handleGetCallStatus(client: Socket, payload: {
        callId: string;
    }): {
        success: boolean;
        error: string;
        status?: undefined;
        messageCount?: undefined;
        duration?: undefined;
    } | {
        success: boolean;
        status: "active" | "connecting" | "ended";
        messageCount: number;
        duration: number;
        error?: undefined;
    };
}
