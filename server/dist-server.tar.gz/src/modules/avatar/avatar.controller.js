"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const avatar_service_1 = require("./avatar.service");
let AvatarController = class AvatarController {
    constructor(avatarService) {
        this.avatarService = avatarService;
    }
    async analyzePhoto(file) {
        try {
            const result = await this.avatarService.analyzePhoto(file);
            return { code: 200, msg: 'success', data: result };
        }
        catch (err) {
            console.error('分析照片失败:', err);
            return { code: 500, msg: err.message || '分析失败', data: null };
        }
    }
    async createAvatar(userId, body) {
        try {
            console.log('创建分身请求:', { userId, name: body.name, platform: body.platform });
            const avatar = await this.avatarService.createAvatar(userId, {
                name: body.name,
                avatar_url: body.avatar_url,
                description: body.description || '',
                platform: body.platform || '通用'
            });
            if (body.accounts && body.accounts.length > 0 && avatar && avatar.id) {
                for (const account of body.accounts) {
                    await this.avatarService.createAccount(avatar.id, account);
                }
            }
            return { code: 200, msg: 'success', data: avatar };
        }
        catch (err) {
            console.error('创建分身失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: null };
        }
    }
    async getAllAvatars() {
        try {
            const avatars = await this.avatarService.findAll();
            return { code: 200, msg: 'success', data: avatars };
        }
        catch (err) {
            console.error('获取所有分身失败:', err);
            return { code: 500, msg: '服务器错误', data: [] };
        }
    }
    async getMyAvatars(userId) {
        try {
            const avatars = await this.avatarService.getAvatarsByUserId(userId);
            return { code: 200, msg: 'success', data: avatars };
        }
        catch (err) {
            console.error('获取我的分身失败:', err);
            return { code: 500, msg: '服务器错误', data: [] };
        }
    }
    async getActiveAvatars() {
        try {
            const avatars = await this.avatarService.getActiveAvatars(10);
            return { code: 200, msg: 'success', data: avatars };
        }
        catch (err) {
            console.error('获取活跃分身失败:', err);
            return { code: 500, msg: '服务器错误', data: [] };
        }
    }
    async getAvatarDetail(id) {
        try {
            const avatar = await this.avatarService.findById(id);
            if (!avatar) {
                return { code: 404, msg: '分身不存在', data: null };
            }
            const formattedAvatar = {
                id: avatar.id,
                name: avatar.name,
                avatar_url: avatar.avatar_url,
                level: avatar.level || 1,
                description: avatar.description || '',
                completed_orders: avatar.completed_orders || 0,
                total_earnings: 0,
                rating: 5.0
            };
            return { code: 200, msg: 'success', data: formattedAvatar };
        }
        catch (err) {
            console.error('获取分身详情失败:', err);
            return { code: 500, msg: '服务器错误', data: null };
        }
    }
    async updateAvatar(id, userId, body) {
        try {
            console.log('[AvatarController] 更新分身:', id, body);
            const avatar = await this.avatarService.updateAvatar(id, userId, body);
            if (!avatar) {
                return { code: 404, msg: '分身不存在', data: null };
            }
            return { code: 200, msg: 'success', data: avatar };
        }
        catch (err) {
            console.error('更新分身失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: null };
        }
    }
    async getAvatarOrders(id) {
        try {
            const orders = await this.avatarService.getAvatarOrders(id);
            return { code: 200, msg: 'success', data: orders };
        }
        catch (err) {
            console.error('获取分身订单失败:', err);
            return { code: 500, msg: '服务器错误', data: [] };
        }
    }
    async getAvatarFriends(id, userId) {
        try {
            const friends = await this.avatarService.getAvatarFriends(id, userId);
            return { code: 200, msg: 'success', data: friends };
        }
        catch (err) {
            console.error('获取好友列表失败:', err);
            return { code: 500, msg: '服务器错误', data: [] };
        }
    }
    async acceptFriendRequest(id, friendId, userId) {
        try {
            await this.avatarService.acceptFriendRequest(id, friendId, userId);
            return { code: 200, msg: '已接受好友请求' };
        }
        catch (err) {
            console.error('接受好友请求失败:', err);
            return { code: 500, msg: '服务器错误' };
        }
    }
    async rejectFriendRequest(id, friendId, userId) {
        try {
            await this.avatarService.rejectFriendRequest(id, friendId, userId);
            return { code: 200, msg: '已拒绝好友请求' };
        }
        catch (err) {
            console.error('拒绝好友请求失败:', err);
            return { code: 500, msg: '服务器错误' };
        }
    }
    async sendFriendRequest(body, userId) {
        try {
            const { avatar_id, target_avatar_id } = body;
            const success = await this.avatarService.sendFriendRequest(avatar_id, target_avatar_id, userId);
            if (success) {
                return { code: 200, msg: '好友请求已发送' };
            }
            else {
                return { code: 400, msg: '发送失败，可能已是好友或请求已存在' };
            }
        }
        catch (err) {
            console.error('发送好友请求失败:', err);
            return { code: 500, msg: '服务器错误' };
        }
    }
    async getRecommendations(body, userId) {
        try {
            const { location, limit = 20 } = body;
            const recommendations = await this.avatarService.getActiveAvatars(limit);
            return { code: 200, data: recommendations };
        }
        catch (err) {
            console.error('获取推荐分身失败:', err);
            return { code: 500, msg: '服务器错误', data: [] };
        }
    }
    async toggleHosting(id, userId, body) {
        try {
            const { enabled, settings } = body;
            const avatar = await this.avatarService.findById(id);
            if (!avatar) {
                return { code: 404, msg: '分身不存在', data: null };
            }
            await this.avatarService.updateAvatar(id, userId, {
                is_hosted: enabled
            });
            if (settings) {
                await this.avatarService.updateHostingSettings(id, userId, settings);
            }
            return {
                code: 200,
                msg: enabled ? '托管已开启' : '托管已关闭',
                data: { enabled }
            };
        }
        catch (err) {
            console.error('托管操作失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: null };
        }
    }
    async updateHostingSettings(id, userId, body) {
        try {
            const result = await this.avatarService.updateHostingSettings(id, userId, body);
            return { code: 200, msg: '设置已更新', data: result };
        }
        catch (err) {
            console.error('更新托管设置失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: null };
        }
    }
    async createAccount(userId, body) {
        try {
            console.log('[AvatarController] 创建账号:', body);
            const account = await this.avatarService.createAccount(userId, body);
            return { code: 200, msg: 'success', data: account };
        }
        catch (err) {
            console.error('[AvatarController] 创建账号失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: null };
        }
    }
    async updateAccount(id, body) {
        try {
            console.log('[AvatarController] 更新账号:', id, body);
            const account = await this.avatarService.updateAccount(id, body);
            return { code: 200, msg: 'success', data: account };
        }
        catch (err) {
            console.error('[AvatarController] 更新账号失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: null };
        }
    }
    async deleteAccount(id) {
        try {
            console.log('[AvatarController] 删除账号:', id);
            await this.avatarService.deleteAccount(id);
            return { code: 200, msg: 'success' };
        }
        catch (err) {
            console.error('[AvatarController] 删除账号失败:', err);
            return { code: 500, msg: err.message || '服务器错误' };
        }
    }
    async deleteAvatar(id, userId) {
        try {
            console.log('[AvatarController] 删除分身:', id, 'userId:', userId);
            await this.avatarService.deleteAvatar(id, userId);
            return { code: 200, msg: '删除成功' };
        }
        catch (err) {
            console.error('[AvatarController] 删除分身失败:', err);
            return { code: 500, msg: err.message || '服务器错误' };
        }
    }
    async getLearningData(id) {
        try {
            const avatar = await this.avatarService.findById(id);
            if (!avatar) {
                return { code: 404, msg: '分身不存在', data: null };
            }
            const learningData = avatar.learning_data || {
                messageCount: 0,
                avgMessageLength: 0,
                toneProfile: {},
                personalityTraits: {},
                communicationStyle: {},
                interests: [],
                commonPhrases: [],
                userIdentity: {}
            };
            const configLearning = avatar.config?.learning || {};
            const learningDays = configLearning.learningDays !== undefined
                ? configLearning.learningDays
                : Math.floor((Date.now() - new Date(avatar.created_at).getTime()) / (1000 * 60 * 60 * 24));
            const metrics = {
                learningDays,
                masteryLevel: configLearning.masteryLevel || 0,
                messageCount: configLearning.messageCount || 0,
                styleMatch: configLearning.styleMatch || 0,
                lastActiveTime: avatar.updated_at
            };
            return {
                code: 200,
                msg: 'success',
                data: {
                    learning: learningData,
                    metrics
                }
            };
        }
        catch (err) {
            console.error('获取学习数据失败:', err);
            return { code: 500, msg: '服务器错误', data: null };
        }
    }
};
exports.AvatarController = AvatarController;
__decorate([
    (0, common_1.Post)('analyze-photo'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('photo')),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "analyzePhoto", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "createAvatar", null);
__decorate([
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getAllAvatars", null);
__decorate([
    (0, common_1.Get)('my'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getMyAvatars", null);
__decorate([
    (0, common_1.Get)('active'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getActiveAvatars", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getAvatarDetail", null);
__decorate([
    (0, common_1.Put)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "updateAvatar", null);
__decorate([
    (0, common_1.Get)(':id/orders'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getAvatarOrders", null);
__decorate([
    (0, common_1.Get)(':id/friends'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getAvatarFriends", null);
__decorate([
    (0, common_1.Post)(':id/friends/:friendId/accept'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('friendId')),
    __param(2, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "acceptFriendRequest", null);
__decorate([
    (0, common_1.Post)(':id/friends/:friendId/reject'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('friendId')),
    __param(2, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "rejectFriendRequest", null);
__decorate([
    (0, common_1.Post)('friend-request'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "sendFriendRequest", null);
__decorate([
    (0, common_1.Post)('recommendations'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getRecommendations", null);
__decorate([
    (0, common_1.Post)(':id/hosting'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "toggleHosting", null);
__decorate([
    (0, common_1.Put)(':id/hosting/settings'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "updateHostingSettings", null);
__decorate([
    (0, common_1.Post)('accounts'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "createAccount", null);
__decorate([
    (0, common_1.Put)('accounts/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "updateAccount", null);
__decorate([
    (0, common_1.Delete)('accounts/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "deleteAccount", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "deleteAvatar", null);
__decorate([
    (0, common_1.Get)(':id/learning'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getLearningData", null);
exports.AvatarController = AvatarController = __decorate([
    (0, common_1.Controller)('avatar'),
    __metadata("design:paramtypes", [avatar_service_1.AvatarService])
], AvatarController);
//# sourceMappingURL=avatar.controller.js.map