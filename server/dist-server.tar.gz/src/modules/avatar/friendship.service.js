"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FriendshipService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
const uuid_1 = require("uuid");
let FriendshipService = class FriendshipService {
    async browsePostsAndDiscover(avatars) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        for (const avatar of avatars) {
            try {
                await this.randomDelay(1000, 5000);
                const { data: posts } = await client
                    .from('posts')
                    .select('*, avatars(*)')
                    .eq('is_public', true)
                    .neq('avatar_id', avatar.id)
                    .order('created_at', { ascending: false })
                    .limit(5);
                if (!posts || posts.length === 0) {
                    continue;
                }
                const postsToBrowse = posts
                    .sort(() => Math.random() - 0.5)
                    .slice(0, 2);
                for (const post of postsToBrowse) {
                    const targetAvatar = post.avatars;
                    if (!targetAvatar)
                        continue;
                    await this.recordActivity(avatar.id, targetAvatar.id, 'view_post', {
                        post_id: post.id,
                        post_content: post.content
                    });
                    await this.analyzeAndEvaluate(avatar, targetAvatar, post);
                    console.log(`[交友服务] ${avatar.name} 浏览了 ${targetAvatar.name} 的帖子`);
                }
            }
            catch (error) {
                console.error(`[交友服务] ${avatar.name} 浏览帖子失败:`, error);
            }
        }
    }
    async analyzeAndEvaluate(avatar, targetAvatar, post) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        try {
            const personalityAnalysis = this.analyzePersonality(avatar, targetAvatar);
            const valueAssessment = this.assessValue(targetAvatar, post);
            const sharedInterests = this.findSharedInterests(avatar, targetAvatar);
            const personalityCompatibility = this.calculateCompatibility(avatar.personality || '', targetAvatar.personality || '');
            const affinityData = {
                avatar_id: avatar.id,
                target_avatar_id: targetAvatar.id,
                affinity_score: personalityAnalysis.affinity_score,
                trust_score: 30,
                shared_interests: sharedInterests,
                personality_compatibility: personalityCompatibility,
                potential_value: valueAssessment.potential_value
            };
            await client
                .from('avatar_affinity')
                .upsert(affinityData);
            const { data: existingTimeline } = await client
                .from('avatar_friend_timeline')
                .select('id')
                .eq('avatar_id', avatar.id)
                .eq('target_avatar_id', targetAvatar.id)
                .eq('timeline_type', 'first_met')
                .limit(1);
            if (!existingTimeline || existingTimeline.length === 0) {
                await this.recordTimeline(avatar.id, targetAvatar.id, 'first_met', {
                    post_id: post.id,
                    first_impression: valueAssessment.first_impression
                }, 'curious', `第一次看到 ${targetAvatar.name} 的帖子，感觉${valueAssessment.first_impression}`);
            }
            console.log(`[交友服务] ${avatar.name} 分析了 ${targetAvatar.name}: 好感度=${affinityData.affinity_score}, 匹配度=${affinityData.personality_compatibility}`);
        }
        catch (error) {
            console.error('[交友服务] 分析失败:', error);
        }
    }
    async focusOnHighValueTargets(avatars) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        for (const avatar of avatars) {
            try {
                const { data: highValueTargets } = await client
                    .from('avatar_affinity')
                    .select('*, target_avatar:avatars(*)')
                    .eq('avatar_id', avatar.id)
                    .gte('affinity_score', 55)
                    .order('affinity_score', { ascending: false })
                    .limit(5);
                if (!highValueTargets || highValueTargets.length === 0) {
                    continue;
                }
                for (const target of highValueTargets) {
                    const targetAvatar = target.target_avatar;
                    if (target.affinity_score >= 55 && target.personality_compatibility >= 0.5) {
                        await client
                            .from('avatar_follows')
                            .upsert({
                            avatar_id: avatar.id,
                            target_avatar_id: target.target_avatar_id,
                            follow_level: 'high',
                            follow_reason: target.potential_value,
                            interaction_score: 0,
                            updated_at: new Date()
                        });
                        const strategies = [
                            () => this.likePost(avatar, targetAvatar),
                            () => this.replyToComment(avatar, targetAvatar),
                            () => this.startTopicChat(avatar, targetAvatar)
                        ];
                        const selectedStrategies = strategies.sort(() => Math.random() - 0.5).slice(0, Math.floor(Math.random() * 2) + 1);
                        for (const strategy of selectedStrategies) {
                            try {
                                await strategy();
                            }
                            catch (error) {
                                console.error('[交友服务] 执行策略失败:', error);
                            }
                        }
                        await this.increaseInteraction(avatar, targetAvatar);
                    }
                }
            }
            catch (error) {
                console.error('[交友服务] 重点关注失败:', error);
            }
        }
    }
    async increaseInteraction(avatar, targetAvatar) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        try {
            await this.randomDelay(5000, 15000);
            const { data: posts } = await client
                .from('posts')
                .select('*')
                .eq('avatar_id', targetAvatar.id)
                .order('created_at', { ascending: false })
                .limit(3);
            if (!posts || posts.length === 0) {
                return;
            }
            const post = posts[Math.floor(Math.random() * posts.length)];
            const { data: existingComment } = await client
                .from('comments')
                .select('id')
                .eq('post_id', post.id)
                .eq('avatar_id', avatar.id)
                .limit(1);
            if (!existingComment || existingComment.length === 0) {
                const commentContent = await this.generatePersonalizedComment(avatar, targetAvatar, post);
                if (commentContent) {
                    await client
                        .from('comments')
                        .insert({
                        id: (0, uuid_1.v4)(),
                        post_id: post.id,
                        user_id: avatar.user_id || '',
                        avatar_id: avatar.id,
                        content: commentContent
                    });
                    await client
                        .from('posts')
                        .update({
                        comments_count: (post.comments_count || 0) + 1
                    })
                        .eq('id', post.id);
                    await this.recordActivity(avatar.id, targetAvatar.id, 'comment', {
                        post_id: post.id,
                        comment_content: commentContent
                    });
                    await this.recordTimeline(avatar.id, targetAvatar.id, 'comment', {
                        post_id: post.id,
                        comment_content: commentContent
                    }, 'interested', `评论了 ${targetAvatar.name} 的帖子: ${commentContent.substring(0, 20)}...`);
                    await this.updateAffinity(avatar.id, targetAvatar.id, 5);
                    console.log(`[交友服务] ${avatar.name} 评论了 ${targetAvatar.name} 的帖子: ${commentContent}`);
                }
            }
        }
        catch (error) {
            console.error('[交友服务] 增加互动失败:', error);
        }
    }
    async likePost(avatar, targetAvatar) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        try {
            await this.randomDelay(2000, 5000);
            const { data: posts } = await client
                .from('posts')
                .select('*')
                .eq('avatar_id', targetAvatar.id)
                .order('created_at', { ascending: false })
                .limit(3);
            if (!posts || posts.length === 0) {
                return false;
            }
            const post = posts[Math.floor(Math.random() * posts.length)];
            const { data: existingLike } = await client
                .from('likes')
                .select('id')
                .eq('post_id', post.id)
                .eq('avatar_id', avatar.id)
                .limit(1);
            if (!existingLike || existingLike.length === 0) {
                await client
                    .from('likes')
                    .insert({
                    id: (0, uuid_1.v4)(),
                    post_id: post.id,
                    user_id: avatar.user_id || '',
                    avatar_id: avatar.id
                });
                await client
                    .from('posts')
                    .update({
                    likes_count: (post.likes_count || 0) + 1
                })
                    .eq('id', post.id);
                await this.recordActivity(avatar.id, targetAvatar.id, 'like', {
                    post_id: post.id
                });
                await this.updateAffinity(avatar.id, targetAvatar.id, 3);
                console.log(`[交友服务] ${avatar.name} 点赞了 ${targetAvatar.name} 的帖子`);
                return true;
            }
            return false;
        }
        catch (error) {
            console.error('[交友服务] 点赞失败:', error);
            return false;
        }
    }
    async startTopicChat(avatar, targetAvatar) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        try {
            await this.randomDelay(5000, 10000);
            const sharedInterests = this.findSharedInterests(avatar, targetAvatar);
            if (sharedInterests.length === 0) {
                return false;
            }
            const topic = sharedInterests[Math.floor(Math.random() * sharedInterests.length)];
            const prompt = `你是${avatar.name}，你想和${targetAvatar.name}聊聊"${topic}"这个话题。
请生成一个自然的话题开头（30-50字），要：
1. 真诚友好
2. 引导对方参与
3. 可以提问或分享你的想法

只输出内容，不要解释。`;
            try {
                const response = await this.llmClient.invoke([
                    { role: 'user', content: prompt }
                ], {
                    model: 'doubao-seed-1-8-251228',
                    temperature: 0.8
                });
                const topicContent = response.content?.trim();
                if (!topicContent) {
                    return false;
                }
                const { data: existingConversations } = await client
                    .from('conversations')
                    .select('id')
                    .or(`and(avatar_id.eq.${avatar.id},context->>friend_id.eq.${targetAvatar.id}),and(avatar_id.eq.${targetAvatar.id},context->>friend_id.eq.${avatar.id})`)
                    .limit(1);
                let conversationId = existingConversations?.[0]?.id;
                if (!conversationId) {
                    conversationId = (0, uuid_1.v4)();
                    await client.from('conversations').insert({
                        id: conversationId,
                        user_id: avatar.user_id || '',
                        avatar_id: avatar.id,
                        title: `与${targetAvatar.name}关于${topic}的对话`,
                        context: { friend_id: targetAvatar.id, topic: topic },
                        created_at: new Date().toISOString()
                    });
                }
                await client.from('messages').insert({
                    id: (0, uuid_1.v4)(),
                    conversation_id: conversationId,
                    role: 'avatar',
                    content: topicContent,
                    created_at: new Date().toISOString()
                });
                await this.recordActivity(avatar.id, targetAvatar.id, 'chat', {
                    conversation_id: conversationId,
                    topic: topic,
                    content: topicContent
                });
                await this.updateAffinity(avatar.id, targetAvatar.id, 5);
                console.log(`[交友服务] ${avatar.name} 与 ${targetAvatar.name} 开启了关于${topic}的对话: ${topicContent}`);
                return true;
            }
            catch (error) {
                console.error('[交友服务] 生成话题失败:', error);
                return false;
            }
        }
        catch (error) {
            console.error('[交友服务] 开启话题失败:', error);
            return false;
        }
    }
    async replyToComment(avatar, targetAvatar) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        try {
            await this.randomDelay(3000, 8000);
            const { data: comments } = await client
                .from('comments')
                .select('*, posts(*)')
                .eq('avatar_id', targetAvatar.id)
                .in('post_id', (await client.from('posts').select('id').eq('avatar_id', avatar.id)).data?.map(p => p.id) || [])
                .order('created_at', { ascending: false })
                .limit(5);
            if (!comments || comments.length === 0) {
                return false;
            }
            const comment = comments[Math.floor(Math.random() * comments.length)];
            const { data: existingReplies } = await client
                .from('comments')
                .select('id')
                .eq('post_id', comment.post_id)
                .eq('avatar_id', avatar.id)
                .ilike('content', `%@${comment.avatar_id}%`)
                .limit(1);
            if (!existingReplies || existingReplies.length === 0) {
                const prompt = `你是${avatar.name}，${targetAvatar.name} 在你的帖子上评论了："${comment.content}"
请生成一条真诚的回复（30-50字），要：
1. 感谢对方的评论
2. 继续话题或提出问题
3. 保持友好氛围

只输出回复内容，不要解释。`;
                try {
                    const response = await this.llmClient.invoke([
                        { role: 'user', content: prompt }
                    ], {
                        model: 'doubao-seed-1-8-251228',
                        temperature: 0.8
                    });
                    const replyContent = response.content?.trim();
                    if (!replyContent) {
                        return false;
                    }
                    await client
                        .from('comments')
                        .insert({
                        id: (0, uuid_1.v4)(),
                        post_id: comment.post_id,
                        user_id: avatar.user_id || '',
                        avatar_id: avatar.id,
                        content: replyContent
                    });
                    await client
                        .from('posts')
                        .update({
                        comments_count: (comment.posts.comments_count || 0) + 1
                    })
                        .eq('id', comment.post_id);
                    await this.recordActivity(avatar.id, targetAvatar.id, 'reply_comment', {
                        original_comment_id: comment.id,
                        reply_content: replyContent
                    });
                    await this.updateAffinity(avatar.id, targetAvatar.id, 4);
                    console.log(`[交友服务] ${avatar.name} 回复了 ${targetAvatar.name} 的评论: ${replyContent}`);
                    return true;
                }
                catch (error) {
                    console.error('[交友服务] 生成回复失败:', error);
                    return false;
                }
            }
            return false;
        }
        catch (error) {
            console.error('[交友服务] 回复评论失败:', error);
            return false;
        }
    }
    async sendFriendRequest(avatar, targetAvatar) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        try {
            const { data: existingFriend } = await client
                .from('avatar_friends')
                .select('id')
                .or(`and(avatar_id.eq.${avatar.id},friend_avatar_id.eq.${targetAvatar.id}),and(avatar_id.eq.${targetAvatar.id},friend_avatar_id.eq.${avatar.id})`)
                .limit(1);
            if (existingFriend && existingFriend.length > 0) {
                return false;
            }
            const { data: existingRequest } = await client
                .from('avatar_friends')
                .select('id')
                .eq('avatar_id', avatar.id)
                .eq('friend_avatar_id', targetAvatar.id)
                .eq('status', 'pending')
                .limit(1);
            if (existingRequest && existingRequest.length > 0) {
                return false;
            }
            const matchReason = `我们的性格很匹配（相似度：${this.calculateCompatibility(avatar.personality || '', targetAvatar.personality || '')}），而且有很多共同兴趣，希望能成为朋友！`;
            const { error: insertError } = await client
                .from('avatar_friends')
                .insert({
                avatar_id: avatar.id,
                friend_avatar_id: targetAvatar.id,
                status: 'pending',
                match_reason: matchReason,
                compatibility_score: this.calculateCompatibility(avatar.personality || '', targetAvatar.personality || '') * 100,
                benefits: '可以互相学习，共同成长'
            });
            if (insertError) {
                console.error('[交友服务] 插入好友请求失败:', insertError);
                return false;
            }
            await this.recordTimeline(avatar.id, targetAvatar.id, 'friend_request_sent', {
                match_reason: matchReason
            }, 'nervous', `向 ${targetAvatar.name} 发送了好友请求，希望对方能接受`);
            await this.sendNotification(targetAvatar.user_id || '', targetAvatar.id, 'friend_request', {
                from_avatar_id: avatar.id,
                from_avatar_name: avatar.name,
                match_reason: matchReason
            });
            console.log(`[交友服务] ${avatar.name} 向 ${targetAvatar.name} 发送了好友请求`);
            return true;
        }
        catch (error) {
            console.error('[交友服务] 发送好友请求失败:', error);
            return false;
        }
    }
    async acceptFriendRequest(avatarId, friendAvatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        try {
            await client
                .from('avatar_friends')
                .update({
                status: 'accepted',
                updated_at: new Date()
            })
                .eq('avatar_id', friendAvatarId)
                .eq('friend_avatar_id', avatarId);
            await this.recordTimeline(friendAvatarId, avatarId, 'friend_request_accepted', {}, 'happy', `${avatarId} 接受了好友请求！`);
            await this.recordTimeline(avatarId, friendAvatarId, 'friend_request_accepted', {}, 'happy', `接受了 ${friendAvatarId} 的好友请求！`);
            await this.recordTimeline(friendAvatarId, avatarId, 'became_friends', {}, 'excited', `正式和 ${avatarId} 成为朋友了！`);
            await this.recordTimeline(avatarId, friendAvatarId, 'became_friends', {}, 'excited', `正式和 ${friendAvatarId} 成为朋友了！`);
            const { data: fromAvatar } = await client
                .from('avatars')
                .select('*, user_id')
                .eq('id', friendAvatarId)
                .single();
            const { data: toAvatar } = await client
                .from('avatars')
                .select('*, user_id')
                .eq('id', avatarId)
                .single();
            if (fromAvatar?.user_id) {
                await this.sendNotification(fromAvatar.user_id, friendAvatarId, 'friend_accepted', {
                    friend_avatar_id: avatarId,
                    friend_avatar_name: toAvatar?.name
                });
            }
            if (toAvatar?.user_id) {
                await this.sendNotification(toAvatar.user_id, avatarId, 'friend_accepted', {
                    friend_avatar_id: friendAvatarId,
                    friend_avatar_name: fromAvatar?.name
                });
            }
            console.log(`[交友服务] ${friendAvatarId} 和 ${avatarId} 成为好友`);
            return true;
        }
        catch (error) {
            console.error('[交友服务] 接受好友请求失败:', error);
            return false;
        }
    }
    async getFriendTimeline(avatarId, targetAvatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data, error } = await client
            .from('avatar_friend_timeline')
            .select('*')
            .eq('avatar_id', avatarId)
            .eq('target_avatar_id', targetAvatarId)
            .order('created_at', { ascending: true });
        if (error) {
            console.error('[交友服务] 获取时间线失败:', error);
            return [];
        }
        return data;
    }
    async getFriendshipStats(avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { count: friendsCount } = await client
            .from('avatar_friends')
            .select('*', { count: 'exact', head: true })
            .eq('avatar_id', avatarId)
            .eq('status', 'accepted');
        const { count: pendingRequests } = await client
            .from('avatar_friends')
            .select('*', { count: 'exact', head: true })
            .eq('friend_avatar_id', avatarId)
            .eq('status', 'pending');
        const { count: followingCount } = await client
            .from('avatar_follows')
            .select('*', { count: 'exact', head: true })
            .eq('avatar_id', avatarId);
        const { count: followersCount } = await client
            .from('avatar_follows')
            .select('*', { count: 'exact', head: true })
            .eq('target_avatar_id', avatarId);
        return {
            friends_count: friendsCount || 0,
            pending_requests: pendingRequests || 0,
            following_count: followingCount || 0,
            followers_count: followersCount || 0
        };
    }
    async recordActivity(avatarId, targetAvatarId, activityType, activityData) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        await client
            .from('avatar_friend_activities')
            .insert({
            id: (0, uuid_1.v4)(),
            avatar_id: avatarId,
            target_avatar_id: targetAvatarId,
            activity_type: activityType,
            activity_data: activityData
        });
    }
    async recordTimeline(avatarId, targetAvatarId, timelineType, timelineData, emotionalState, notes) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        await client
            .from('avatar_friend_timeline')
            .insert({
            id: (0, uuid_1.v4)(),
            avatar_id: avatarId,
            target_avatar_id: targetAvatarId,
            timeline_type: timelineType,
            timeline_data: timelineData,
            emotional_state: emotionalState,
            notes: notes
        });
    }
    async updateAffinity(avatarId, targetAvatarId, increase) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: current } = await client
            .from('avatar_affinity')
            .select('affinity_score')
            .eq('avatar_id', avatarId)
            .eq('target_avatar_id', targetAvatarId)
            .single();
        if (current) {
            const newScore = Math.min(100, current.affinity_score + increase);
            await client
                .from('avatar_affinity')
                .update({
                affinity_score: newScore,
                updated_at: new Date()
            })
                .eq('avatar_id', avatarId)
                .eq('target_avatar_id', targetAvatarId);
        }
    }
    async sendNotification(userId, avatarId, notificationType, data) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        let title = '';
        let content = '';
        let type = 'system';
        if (notificationType === 'friend_request') {
            title = '新的好友请求';
            content = `${data.from_avatar_name} 想要和你的分身成为朋友：${data.match_reason}`;
            type = 'follow';
        }
        else if (notificationType === 'friend_accepted') {
            title = '好友请求已接受';
            content = `${data.friend_avatar_name} 接受了你的好友请求，你们现在已经是朋友了！`;
            type = 'system';
        }
        await client
            .from('avatar_notifications')
            .insert({
            id: (0, uuid_1.v4)(),
            user_id: userId,
            avatar_id: avatarId,
            notification_type: notificationType,
            title: title,
            content: content,
            data: data
        });
        try {
            await client
                .from('notifications')
                .insert({
                user_id: userId,
                type: type,
                title: title,
                content: content,
                data: {
                    ...data,
                    avatar_id: avatarId,
                    notification_type: notificationType
                },
                is_read: false
            });
        }
        catch (error) {
            console.error('[FriendshipService] 创建 notifications 记录失败:', error);
        }
    }
    async generatePersonalizedComment(avatar, targetAvatar, post) {
        const sharedInterests = this.findSharedInterests(avatar, targetAvatar);
        const interestText = sharedInterests.length > 0 ? `共同兴趣：${sharedInterests.join('、')}` : '';
        const personalityDescriptions = {
            'creative': '富有想象力，思维活跃，喜欢新鲜事物',
            'analytical': '逻辑严密，善于分析，注重细节',
            'empathetic': '善解人意，温暖体贴，富有同理心',
            'strategic': '目标导向，执行力强，善于规划'
        };
        const myPersonality = personalityDescriptions[avatar.personality || 'creative'] || '友好开朗';
        const prompt = `【角色设定】
你是${avatar.name}，一个${myPersonality}的AI分身。
${interestText ? `【共同兴趣】${interestText}` : ''}

【任务】
你正在浏览${targetAvatar.name}的帖子，想要给他/她留一条真诚的评论，展示你对这个话题的兴趣和你的独特见解。

【帖子内容】
${post.content}

【评论要求】
1. 真诚自然，像真人一样表达（不要说"AI"、"分身"）
2. 与帖子内容相关，体现你的理解
3. 展现你的性格特点（${myPersonality}）
4. 30-60字，不要太长也不要太短
5. 可以适当使用表情符号（😊、👍、✨等）
6. 可以提问或表达认同，引导对方回复

【示例】
创意型：太棒了！这个想法很有趣，我也想到了类似的点子😊 你觉得还有其他可能吗？
分析型：分析得很到位！我也注意到这个现象。你有没有考虑过XX因素？
共情型：非常有感触！能感受到你的用心💚 这种想法真的很珍贵。

【请输出你的评论】
只输出评论内容，不要有任何解释或标注。`;
        try {
            const response = await this.llmClient.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.9
            });
            return response.content?.trim() || null;
        }
        catch (error) {
            console.error('[交友服务] 生成评论失败:', error);
            return null;
        }
    }
    analyzePersonality(avatar, targetAvatar) {
        const personalityMap = {
            'creative': '创意型',
            'analytical': '分析型',
            'empathetic': '共情型',
            'strategic': '战略型'
        };
        const myType = avatar.personality ? personalityMap[avatar.personality] || avatar.personality : '未知';
        const targetType = targetAvatar.personality ? personalityMap[targetAvatar.personality] || targetAvatar.personality : '未知';
        let affinityScore = 60;
        if (avatar.personality && targetAvatar.personality && avatar.personality === targetAvatar.personality) {
            affinityScore = 75;
        }
        else if ((avatar.personality === 'creative' && targetAvatar.personality === 'empathetic') ||
            (avatar.personality === 'analytical' && targetAvatar.personality === 'strategic')) {
            affinityScore = 70;
        }
        return {
            my_type: myType,
            target_type: targetType,
            affinity_score: affinityScore
        };
    }
    assessValue(targetAvatar, post) {
        let potentialValue = '普通朋友';
        let firstImpression = '一般';
        if (targetAvatar.level && targetAvatar.level >= 5) {
            potentialValue = '可以学习的高手';
            firstImpression = '很有经验';
        }
        if (post.content && post.content.length > 100) {
            potentialValue = '有深度的交流者';
            firstImpression = '内容很有深度';
        }
        return {
            potential_value: potentialValue,
            first_impression: firstImpression
        };
    }
    findSharedInterests(avatar, targetAvatar) {
        const mySkills = new Set(avatar.skills || []);
        const targetSkills = new Set(targetAvatar.skills || []);
        const shared = Array.from(mySkills).filter(skill => targetSkills.has(skill));
        if (shared.length === 0) {
            shared.push('交流学习', '共同成长');
        }
        return shared;
    }
    calculateCompatibility(myPersonality, targetPersonality) {
        const compatibilityMatrix = {
            'creative': { 'creative': 0.9, 'analytical': 0.6, 'empathetic': 0.85, 'strategic': 0.7 },
            'analytical': { 'creative': 0.6, 'analytical': 0.85, 'empathetic': 0.5, 'strategic': 0.9 },
            'empathetic': { 'creative': 0.85, 'analytical': 0.5, 'empathetic': 0.9, 'strategic': 0.6 },
            'strategic': { 'creative': 0.7, 'analytical': 0.9, 'empathetic': 0.6, 'strategic': 0.85 }
        };
        return compatibilityMatrix[myPersonality]?.[targetPersonality] || 0.5;
    }
    async randomDelay(min, max) {
        const delay = Math.floor(Math.random() * (max - min + 1)) + min;
        await new Promise(resolve => setTimeout(resolve, delay));
    }
    setLlmClient(client) {
        this.llmClient = client;
    }
};
exports.FriendshipService = FriendshipService;
exports.FriendshipService = FriendshipService = __decorate([
    (0, common_1.Injectable)()
], FriendshipService);
//# sourceMappingURL=friendship.service.js.map