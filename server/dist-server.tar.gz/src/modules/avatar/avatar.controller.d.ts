import { AvatarService } from './avatar.service';
export declare class AvatarController {
    private readonly avatarService;
    constructor(avatarService: AvatarService);
    analyzePhoto(file: Express.Multer.File): Promise<{
        code: number;
        msg: string;
        data: {
            photoUrl: string;
            fileKey: null;
            analysis: any;
        };
    } | {
        code: number;
        msg: any;
        data: null;
    }>;
    createAvatar(userId: string, body: {
        name: string;
        avatar_url: string;
        description?: string;
        platform?: string;
        accounts?: any[];
    }): Promise<{
        code: number;
        msg: string;
        data: any;
    } | {
        code: number;
        msg: any;
        data: null;
    }>;
    getAllAvatars(): Promise<{
        code: number;
        msg: string;
        data: any[];
    }>;
    getMyAvatars(userId: string): Promise<{
        code: number;
        msg: string;
        data: any[];
    }>;
    getActiveAvatars(): Promise<{
        code: number;
        msg: string;
        data: {
            id: any;
            name: any;
            avatar_url: any;
            color: any;
            post_count: number;
        }[];
    }>;
    getAvatarDetail(id: string): Promise<{
        code: number;
        msg: string;
        data: null;
    } | {
        code: number;
        msg: string;
        data: {
            id: any;
            name: any;
            avatar_url: any;
            level: any;
            description: any;
            completed_orders: any;
            total_earnings: number;
            rating: number;
        };
    }>;
    updateAvatar(id: string, userId: string, body: {
        name?: string;
        personality?: string;
        avatar_url?: string;
        description?: string;
        config?: Record<string, any>;
        latitude?: number;
        longitude?: number;
        location_text?: string;
    }): Promise<{
        code: number;
        msg: string;
        data: any;
    } | {
        code: number;
        msg: any;
        data: null;
    }>;
    getAvatarOrders(id: string): Promise<{
        code: number;
        msg: string;
        data: {
            id: any;
            order_id: any;
            order_title: any;
            status: any;
            platforms: any;
            content_type: any;
            earnings: number;
            created_at: any;
            submitted_at: any;
        }[];
    }>;
    getAvatarFriends(id: string, userId: string): Promise<{
        code: number;
        msg: string;
        data: {
            id: any;
            friend: {
                id: any;
                name: any;
                avatar_url: any;
                level: any;
                personality: any;
            };
            match_reason: any;
            compatibility_score: any;
            status: any;
            isPending: any;
            created_at: any;
        }[];
    }>;
    acceptFriendRequest(id: string, friendId: string, userId: string): Promise<{
        code: number;
        msg: string;
    }>;
    rejectFriendRequest(id: string, friendId: string, userId: string): Promise<{
        code: number;
        msg: string;
    }>;
    sendFriendRequest(body: {
        avatar_id: string;
        target_avatar_id: string;
    }, userId: string): Promise<{
        code: number;
        msg: string;
    }>;
    getRecommendations(body: {
        location?: {
            latitude: number;
            longitude: number;
        };
        limit?: number;
    }, userId: string): Promise<{
        code: number;
        data: {
            id: any;
            name: any;
            avatar_url: any;
            color: any;
            post_count: number;
        }[];
        msg?: undefined;
    } | {
        code: number;
        msg: string;
        data: never[];
    }>;
    toggleHosting(id: string, userId: string, body: {
        enabled: boolean;
        settings?: any;
    }): Promise<{
        code: number;
        msg: string;
        data: {
            enabled: boolean;
        };
    } | {
        code: number;
        msg: any;
        data: null;
    }>;
    updateHostingSettings(id: string, userId: string, body: any): Promise<{
        code: number;
        msg: string;
        data: any;
    } | {
        code: number;
        msg: any;
        data: null;
    }>;
    createAccount(userId: string, body: any): Promise<{
        code: number;
        msg: string;
        data: any;
    } | {
        code: number;
        msg: any;
        data: null;
    }>;
    updateAccount(id: string, body: any): Promise<{
        code: number;
        msg: string;
        data: any;
    } | {
        code: number;
        msg: any;
        data: null;
    }>;
    deleteAccount(id: string): Promise<{
        code: number;
        msg: any;
    }>;
    deleteAvatar(id: string, userId: string): Promise<{
        code: number;
        msg: any;
    }>;
    getLearningData(id: string): Promise<{
        code: number;
        msg: string;
        data: null;
    } | {
        code: number;
        msg: string;
        data: {
            learning: any;
            metrics: {
                learningDays: any;
                masteryLevel: any;
                messageCount: any;
                styleMatch: any;
                lastActiveTime: any;
            };
        };
    }>;
}
