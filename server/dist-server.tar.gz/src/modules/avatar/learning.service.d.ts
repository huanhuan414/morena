export interface UserLearningData {
    messageCount: number;
    avgMessageLength: number;
    totalInteractionTime: number;
    userIdentity?: {
        occupation?: string;
        education?: string;
        personalityType?: string;
        lifeEvents?: string[];
    };
    toneProfile: {
        formal: number;
        casual: number;
        humorous: number;
        emotional: number;
    };
    personalityTraits: {
        openness: number;
        conscientiousness: number;
        extraversion: number;
        agreeableness: number;
        neuroticism: number;
    };
    logicPattern: {
        analytical: number;
        intuitive: number;
        structured: number;
        creative: number;
    };
    decisionStyle: {
        decisive: number;
        deliberative: number;
        riskTaking: number;
        cautious: number;
    };
    interests: string[];
    commonPhrases: string[];
    emojiUsage: string[];
    communicationStyle: {
        direct: number;
        polite: number;
        detailed: number;
        concise: number;
    };
    experiences: Array<{
        topic: string;
        context: string;
        timestamp: string;
    }>;
    learningHistory: Array<{
        type: string;
        insight: string;
        confidence: number;
        timestamp: string;
    }>;
    styleFingerprint: {
        sentenceLength: 'short' | 'medium' | 'long';
        punctuationStyle: 'minimal' | 'normal' | 'expressive';
        emojiFrequency: number;
        questionFrequency: number;
        exclamationFrequency: number;
        vocabularyLevel: 'simple' | 'moderate' | 'sophisticated';
    };
}
export declare class LearningService {
    analyzeAndUpdate(avatarId: string, userId: string, userMessage: string, aiResponse: string, conversationContext?: string[]): Promise<void>;
    private analyzeMessage;
    private analyzeStyleFingerprint;
    private assessVocabularyLevel;
    private mergeLearningData;
    private calculateProgressMetrics;
    private calculateConvergenceScore;
    private calculateStyleConsistency;
    private mergeValue;
    private mergeLists;
    private updateAverage;
    private extractEmojis;
    private addExperience;
    private getDefaultLearningData;
    buildPersonalizedPrompt(avatarId: string, avatar: any): Promise<string>;
    private buildBasicPrompt;
    private extractDominantTraits;
    private buildStyleGuide;
    private buildIdentityInfo;
    private buildLanguageHabits;
    getUserProfile(avatarId: string): Promise<{
        learning: UserLearningData | null;
        metrics: {
            masteryLevel: number;
            learningDays: number;
            styleMatch: number;
            level: number;
        } | null;
    }>;
}
