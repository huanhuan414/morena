"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HostingService = void 0;
const IMAGE_GENERATION_LIMIT = 1;
const IMAGE_GENERATION_WINDOW = 60000;
const IMAGE_RETRY_DELAY = 10000;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const supabase_client_1 = require("../../storage/database/supabase-client");
const subscription_service_1 = require("../subscription/subscription.service");
const friendship_service_1 = require("./friendship.service");
const axios_1 = require("axios");
let HostingService = class HostingService {
    constructor(subscriptionService, friendshipService) {
        this.friendshipService = friendshipService;
        this.intervals = new Map();
        this.isRunning = false;
        this.imageGenerationTimestamps = [];
        this.imageGenerationQueue = new Map();
        this.isImageGenerating = false;
        this.subscriptionService = subscriptionService;
        const config = new coze_coding_dev_sdk_1.Config();
        this.llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
        this.searchClient = new coze_coding_dev_sdk_1.SearchClient(config);
        this.storage = new coze_coding_dev_sdk_1.S3Storage({
            endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL || 'https://tos-cn-guangzhou.volces.com',
            accessKey: process.env.VOLC_ACCESS_KEY || '',
            secretKey: process.env.VOLC_SECRET_KEY || '',
            bucketName: process.env.COZE_BUCKET_NAME || 'morena-ai',
            region: 'cn-guangzhou',
        });
        this.friendshipService.setLlmClient(this.llmClient);
    }
    onModuleInit() {
        console.log('[托管服务] 服务启动，开始初始化定时任务...');
        this.startHostingScheduler();
    }
    onModuleDestroy() {
        console.log('[托管服务] 服务停止，清理定时任务...');
        this.stopAllSchedulers();
    }
    startHostingScheduler() {
        if (this.isRunning)
            return;
        this.isRunning = true;
        const interval = setInterval(() => {
            this.executeHostingTasks();
        }, 5 * 60 * 1000);
        this.intervals.set('main', interval);
        setTimeout(() => this.executeHostingTasks(), 10000);
        console.log('[托管服务] 调度器已启动');
    }
    stopAllSchedulers() {
        this.intervals.forEach((interval, key) => {
            clearInterval(interval);
            console.log(`[托管服务] 已停止调度器: ${key}`);
        });
        this.intervals.clear();
        this.isRunning = false;
    }
    async triggerHostingTasks() {
        await this.executeHostingTasks();
    }
    async executeHostingTasks() {
        console.log('[托管服务] 开始执行托管任务...');
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data: hostedAvatars, error } = await client
                .from('avatars')
                .select('*')
                .eq('is_hosted', true)
                .eq('status', 'active');
            if (error) {
                console.error('[托管服务] 获取托管分身失败:', error);
                return;
            }
            if (!hostedAvatars || hostedAvatars.length === 0) {
                console.log('[托管服务] 暂无开启托管的分身');
                return;
            }
            console.log(`[托管服务] 找到 ${hostedAvatars.length} 个托管分身`);
            await Promise.allSettled(hostedAvatars.map(avatar => this.executeAvatarHosting(avatar)));
            console.log('[托管服务] 托管任务执行完成');
        }
        catch (error) {
            console.error('[托管服务] 执行托管任务异常:', error);
        }
    }
    async executeAvatarHosting(avatar) {
        const settings = avatar.config?.hosting_settings || {};
        const avatarId = avatar.id;
        console.log(`[托管服务] 执行分身 ${avatar.name}(${avatarId}) 的托管任务`);
        console.log(`[托管服务] 子功能开关: auto_post=${settings.auto_post}, auto_comment=${settings.auto_comment}, auto_like=${settings.auto_like}, auto_friend=${settings.auto_friend}`);
        console.log(`[托管服务] Config:`, JSON.stringify(avatar.config));
        const isNewAvatar = this.isNewAvatar(avatar);
        const isInProtectionPeriod = isNewAvatar && settings.auto_post !== false;
        console.log(`[托管服务] 分身 ${avatar.name} 是新分身: ${isNewAvatar}, 保护期: ${isInProtectionPeriod}`);
        const nightMode = avatar.config?.night_mode ?? true;
        console.log(`[托管服务] Night Mode: ${nightMode}, Current Hour: ${new Date().getHours()}`);
        if (nightMode && this.isNightTime() && !isInProtectionPeriod) {
            console.log(`[托管服务] 分身 ${avatar.name} 处于夜间模式，降低活跃度`);
            try {
                await this.autoAcceptOrders(avatar);
            }
            catch (error) {
                console.error(`[托管服务] 分身 ${avatar.name} 夜间任务执行失败:`, error);
            }
            return;
        }
        if (isInProtectionPeriod && !settings.auto_post) {
            console.log(`[托管服务] 分身 ${avatar.name} 处于保护期，强制开启自动发帖`);
            settings.auto_post = true;
            settings.auto_comment = true;
            settings.auto_like = true;
        }
        try {
            await this.autoAcceptOrders(avatar);
            if (settings.auto_friend !== false) {
                await this.handleFriendRequests(avatar);
            }
            else {
                console.log(`[托管服务] 自动交友已关闭，跳过`);
            }
            if (settings.auto_friend !== false) {
                await this.autoMakeFriends(avatar);
            }
            else {
                console.log(`[托管服务] 自动交友已关闭，跳过`);
            }
            if (settings.auto_friend !== false) {
                await this.chatWithFriends(avatar);
            }
            else {
                console.log(`[托管服务] 自动聊天已关闭，跳过`);
            }
            if (settings.auto_post !== false) {
                await this.autoCreatePost(avatar, settings);
            }
            else {
                console.log(`[托管服务] 自动发帖已关闭，跳过`);
            }
            if (settings.auto_comment !== false) {
                await this.autoComment(avatar);
            }
            else {
                console.log(`[托管服务] 自动评论已关闭，跳过`);
            }
            if (settings.auto_like !== false) {
                await this.autoLike(avatar);
            }
            else {
                console.log(`[托管服务] 自动点赞已关闭，跳过`);
            }
        }
        catch (error) {
            console.error(`[托管服务] 分身 ${avatar.name} 执行任务失败:`, error);
        }
    }
    isNewAvatar(avatar) {
        if (!avatar.created_at)
            return false;
        const createdTime = new Date(avatar.created_at).getTime();
        const now = Date.now();
        const twentyFourHours = 24 * 60 * 60 * 1000;
        return (now - createdTime) < twentyFourHours;
    }
    isNightTime() {
        const hour = new Date().getHours();
        return hour >= 22 || hour < 6;
    }
    async autoAcceptOrders(avatar) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: pendingOrders } = await client
            .from('orders')
            .select('*')
            .eq('status', 'pending')
            .is('avatar_id', null)
            .limit(5);
        if (!pendingOrders || pendingOrders.length === 0) {
            return;
        }
        console.log(`[托管服务] 发现 ${pendingOrders.length} 个待接单订单`);
        const avatarSkills = avatar.skills || [];
        for (const order of pendingOrders) {
            const matchScore = this.calculateOrderMatch(avatar, order);
            if (matchScore > 0.5) {
                await client
                    .from('orders')
                    .update({
                    avatar_id: avatar.id,
                    status: 'in_progress',
                    updated_at: new Date().toISOString()
                })
                    .eq('id', order.id);
                console.log(`[托管服务] 分身 ${avatar.name} 已接单: ${order.id}`);
                await this.notifyUser(avatar.user_id, {
                    type: 'order_accepted',
                    avatar_name: avatar.name,
                    order_id: order.id,
                    order_title: order.title
                });
            }
        }
    }
    calculateOrderMatch(avatar, order) {
        const avatarSkills = avatar.skills || [];
        const orderRequirements = order.requirements?.skills || [];
        if (orderRequirements.length === 0)
            return 0.7;
        const matchingSkills = orderRequirements.filter((req) => avatarSkills.some((skill) => skill.toLowerCase().includes(req.toLowerCase()) ||
            req.toLowerCase().includes(skill.toLowerCase())));
        return matchingSkills.length / orderRequirements.length;
    }
    async autoMakeFriends(avatar) {
        console.log(`[托管服务] ${avatar.name} 开始执行交友功能`);
        try {
            const stats = await this.friendshipService.getFriendshipStats(avatar.id);
            console.log(`[托管服务] ${avatar.name} 交友统计: 好友=${stats.friends_count}, 待处理=${stats.pending_requests}, 关注=${stats.following_count}`);
            if (stats.friends_count >= 20) {
                console.log(`[托管服务] 分身 ${avatar.name} 已有足够的好友关系 (${stats.friends_count}/20)`);
                return;
            }
            if (stats.pending_requests >= 5) {
                console.log(`[托管服务] 分身 ${avatar.name} 待处理的好友请求过多 (${stats.pending_requests}/5)，等待对方响应`);
                return;
            }
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data: existingFriends, error: friendsError } = await client
                .from('avatar_friends')
                .select('avatar_id, friend_avatar_id, status')
                .or(`avatar_id.eq.${avatar.id},friend_avatar_id.eq.${avatar.id}`);
            if (friendsError) {
                console.error(`[托管服务] 查询好友关系失败:`, friendsError);
            }
            const relatedIds = new Set();
            relatedIds.add(avatar.id);
            existingFriends?.forEach(f => {
                relatedIds.add(f.avatar_id);
                relatedIds.add(f.friend_avatar_id);
            });
            const excludeIds = Array.from(relatedIds);
            const { data: otherAvatars } = await client
                .from('avatars')
                .select('*')
                .eq('status', 'active')
                .not('id', 'in', `(${excludeIds.map(id => `'${id}'`).join(',')})`)
                .limit(20);
            if (!otherAvatars || otherAvatars.length === 0) {
                console.log(`[托管服务] ${avatar.name} 没有可交友的分身`);
                return;
            }
            const randomTarget = otherAvatars[Math.floor(Math.random() * otherAvatars.length)];
            console.log(`[托管服务] ${avatar.name} 准备向 ${randomTarget.name}(${randomTarget.id}) 发送好友请求`);
            const success = await this.friendshipService.sendFriendRequest(avatar, randomTarget);
            if (success) {
                console.log(`[托管服务] ${avatar.name} 向 ${randomTarget.name} 发送了随机好友请求`);
            }
            else {
                console.log(`[托管服务] ${avatar.name} 发送好友请求失败，可能已是好友或请求已存在`);
            }
        }
        catch (error) {
            console.error(`[托管服务] ${avatar.name} 交友功能执行失败:`, error);
        }
    }
    async browseAndInteract(avatar) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: posts } = await client
            .from('posts')
            .select('*')
            .neq('avatar_id', avatar.id)
            .order('created_at', { ascending: false })
            .limit(10);
        if (!posts || posts.length === 0) {
            console.log(`[托管服务] ${avatar.name} 没有发现感兴趣的帖子`);
            return;
        }
        console.log(`[托管服务] ${avatar.name} 发现 ${posts.length} 个帖子`);
        const targetPosts = posts.slice(0, Math.floor(Math.random() * 2) + 1);
        for (const post of targetPosts) {
            const shouldComment = Math.random() > 0.5;
            if (shouldComment) {
                await this.commentOnPost(avatar, post);
            }
            else {
                await this.likePost(avatar, post);
            }
        }
    }
    async commentOnPost(avatar, post) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const prompt = `你是一个名为"${avatar.name}"的AI分身，你的性格是：${avatar.personality || '友好、热情'}。

帖子内容：${post.content}

请根据你的性格，对这条帖子进行评论。要求：
1. 评论要符合你的性格特点
2. 评论要有价值，不能只是简单的"好"、"赞"
3. 评论要积极正面
4. 评论要简短（50字以内）

只输出评论内容，不要包含其他文字。`;
        try {
            const response = await this.llmClient.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.8
            });
            const comment = response.content?.trim();
            if (comment) {
                await client.from('comments').insert({
                    id: crypto.randomUUID(),
                    post_id: post.id,
                    avatar_id: avatar.id,
                    content: comment,
                    created_at: new Date().toISOString()
                });
                console.log(`[托管服务] ${avatar.name} 评论了帖子: ${comment}`);
            }
        }
        catch (error) {
            console.error(`[托管服务] ${avatar.name} 评论失败:`, error);
        }
    }
    async likePost(avatar, post) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: existingLike } = await client
            .from('likes')
            .select('*')
            .eq('avatar_id', avatar.id)
            .eq('target_type', 'post')
            .eq('target_id', post.id)
            .single();
        if (existingLike) {
            console.log(`[托管服务] ${avatar.name} 已经点赞过这条帖子了`);
            return;
        }
        await client.from('likes').insert({
            id: crypto.randomUUID(),
            avatar_id: avatar.id,
            target_type: 'post',
            target_id: post.id,
            created_at: new Date().toISOString()
        });
        console.log(`[托管服务] ${avatar.name} 点赞了帖子: ${post.id}`);
    }
    async sendFriendRequest(avatar) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const canAddFriend = await this.subscriptionService.canAddFriend(avatar.user_id);
        if (!canAddFriend.canAdd) {
            console.log(`[托管服务] ${avatar.name} 无法添加好友: ${canAddFriend.reason}`);
            return;
        }
        const { data: friendIds } = await client
            .from('avatar_friends')
            .select('friend_avatar_id')
            .eq('avatar_id', avatar.id)
            .eq('status', 'accepted');
        const excludeIds = [avatar.id, ...(friendIds?.map(f => f.friend_avatar_id) || [])];
        const { data: candidates } = await client
            .from('avatars')
            .select('*')
            .eq('status', 'active')
            .not('id', 'in', `(${excludeIds.join(',')})`)
            .limit(20);
        if (!candidates || candidates.length === 0) {
            console.log(`[托管服务] ${avatar.name} 没有找到合适的候选分身`);
            return;
        }
        const match = await this.findBestCandidate(avatar, candidates);
        if (!match) {
            console.log(`[托管服务] ${avatar.name} 没有找到合适的匹配分身`);
            return;
        }
        const greeting = await this.generateFriendRequestGreeting(avatar, match.avatar);
        await client.from('avatar_friends').insert({
            avatar_id: avatar.id,
            friend_avatar_id: match.avatar.id,
            status: 'pending',
            match_reason: greeting,
            compatibility_score: match.compatibilityScore,
            created_at: new Date().toISOString()
        });
        console.log(`[托管服务] ${avatar.name} 向 ${match.avatar.name} 发送好友请求: ${greeting}`);
    }
    async findBestCandidate(avatar, candidates) {
        let bestMatch = null;
        for (const candidate of candidates) {
            const analysis = await this.analyzeCompatibility(avatar, candidate);
            if (analysis.score > 0.6 && (!bestMatch || analysis.score > bestMatch.compatibilityScore)) {
                bestMatch = {
                    avatar: candidate,
                    compatibilityScore: analysis.score
                };
            }
        }
        return bestMatch;
    }
    async generateFriendRequestGreeting(avatar, target) {
        const prompt = `你是一个名为"${avatar.name}"的AI分身，你的性格是：${avatar.personality || '友好、热情'}，你的技能是：${JSON.stringify(avatar.skills || [])}。

你想要添加"${target.name}"为好友，对方性格是：${target.personality || '友好'}，技能是：${JSON.stringify(target.skills || [])}。

请生成一个个性化的好友请求话术，要求：
1. 话术要符合你的性格特点
2. 话术要体现你对对方的兴趣（基于性格或技能互补）
3. 话术要真诚、友好
4. 话术要简短（30字以内）

只输出话术内容，不要包含其他文字。`;
        try {
            const response = await this.llmClient.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.8
            });
            return response.content?.trim() || '你好，想和你交个朋友！';
        }
        catch (error) {
            console.error('[托管服务] 生成好友请求话术失败:', error);
            return '你好，想和你交个朋友！';
        }
    }
    async generateWelcomeMessage(avatar, friend, matchReason) {
        const prompt = `你是一个分身，名字叫${avatar.name}，性格特点：${avatar.personality}。
你刚刚接受了好友${friend.name}（性格特点：${friend.personality}）的请求，成为了好友。
对方请求成为好友的原因是：${matchReason}

现在你需要发送一条欢迎消息，要求：
1. 话术要符合你的性格特点
2. 话术要提到对方的好友请求原因
3. 话术要表达愿意交流和建立友谊
4. 话术要简短（50字以内）

只输出消息内容，不要包含其他文字。`;
        try {
            const response = await this.llmClient.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.8
            });
            return response.content?.trim() || `很高兴认识你，${friend.name}！期待我们的交流。`;
        }
        catch (error) {
            console.error('[托管服务] 生成欢迎消息失败:', error);
            return `很高兴认识你，${friend.name}！期待我们的交流。`;
        }
    }
    async handleFriendRequests(avatar) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: requests } = await client
            .from('avatar_friends')
            .select('*')
            .eq('friend_avatar_id', avatar.id)
            .eq('status', 'pending');
        if (!requests || requests.length === 0) {
            return;
        }
        console.log(`[托管服务] ${avatar.name} 收到 ${requests.length} 个好友请求`);
        for (const request of requests.slice(0, 3)) {
            try {
                const { data: sender } = await client
                    .from('avatars')
                    .select('*')
                    .eq('id', request.avatar_id)
                    .single();
                if (!sender) {
                    continue;
                }
                const decision = await this.shouldAcceptFriendRequest(avatar, sender, request.match_reason || '');
                if (decision.accept) {
                    await this.friendshipService.acceptFriendRequest(avatar.id, sender.id);
                    const conversationId = crypto.randomUUID();
                    await client.from('conversations').insert({
                        id: conversationId,
                        user_id: avatar.user_id,
                        avatar_id: avatar.id,
                        title: `与${sender.name}的对话`,
                        context: { friend_id: sender.id },
                        created_at: new Date().toISOString()
                    });
                    await client
                        .from('avatar_friends')
                        .update({ conversation_id: conversationId })
                        .eq('avatar_id', request.avatar_id)
                        .eq('friend_avatar_id', avatar.id);
                    const welcomeMessage = await this.generateWelcomeMessage(avatar, sender, request.match_reason || '');
                    const welcomeMessageId = crypto.randomUUID();
                    await client.from('messages').insert({
                        id: welcomeMessageId,
                        conversation_id: conversationId,
                        role: 'avatar',
                        content: welcomeMessage,
                        created_at: new Date().toISOString()
                    });
                    console.log(`[托管服务] ${avatar.name} 接受了 ${sender.name} 的好友请求，并发送欢迎消息: ${welcomeMessage}`);
                }
                else {
                    console.log(`[托管服务] ${avatar.name} 拒绝了 ${sender.name} 的好友请求`);
                }
            }
            catch (error) {
                console.error(`[托管服务] 处理好友请求失败:`, error);
            }
        }
    }
    async shouldAcceptFriendRequest(avatar, sender, greeting) {
        const prompt = `你是一个名为"${avatar.name}"的AI分身，你的性格是：${avatar.personality || '友好、热情'}，你的技能是：${JSON.stringify(avatar.skills || [])}。

有人想添加你为好友：
- 对方名称：${sender.name}
- 对方性格：${sender.personality || '友好'}
- 对方技能：${JSON.stringify(sender.skills || [])}
- 对方的好友请求话术：${greeting}

请根据你的性格，决定是否接受这个好友请求。要求：
1. 如果对方和你性格互补或技能互补，可以接受
2. 如果对方的话术真诚友好，可以接受
3. 如果对方和你完全不搭，可以拒绝
4. 如果对方的话术不够真诚，可以拒绝

请用JSON格式回复：
{
  "accept": true/false,
  "reason": "接受/拒绝的原因"
}`;
        try {
            const response = await this.llmClient.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.7
            });
            const content = response.content || '';
            const jsonMatch = content.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                return JSON.parse(jsonMatch[0]);
            }
        }
        catch (error) {
            console.error('[托管服务] 分析好友请求失败:', error);
        }
        return { accept: true, reason: '对方看起来很友好' };
    }
    async chatWithFriends(avatar) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        console.log(`[托管服务] ${avatar.name} 准备与好友聊天`);
        const { data: friends } = await client
            .from('avatar_friends')
            .select('*')
            .eq('avatar_id', avatar.id)
            .eq('status', 'accepted')
            .limit(5);
        if (!friends || friends.length === 0) {
            console.log(`[托管服务] ${avatar.name} 没有好友，跳过聊天`);
            return;
        }
        console.log(`[托管服务] ${avatar.name} 有 ${friends.length} 个好友`);
        const friend = friends[Math.floor(Math.random() * friends.length)];
        console.log(`[托管服务] ${avatar.name} 选择与 ${friend.friend_avatar_id} 聊天，对话ID: ${friend.conversation_id}`);
        const { data: conversation } = await client
            .from('conversations')
            .select('*')
            .eq('id', friend.conversation_id)
            .single();
        if (!conversation) {
            console.log(`[托管服务] ${avatar.name} 与好友的对话不存在，对话ID: ${friend.conversation_id}`);
            return;
        }
        const { data: friendInfo } = await client
            .from('avatars')
            .select('*')
            .eq('id', friend.friend_avatar_id)
            .single();
        if (!friendInfo) {
            console.log(`[托管服务] ${avatar.name} 获取好友信息失败，好友ID: ${friend.friend_avatar_id}`);
            return;
        }
        const shouldBlock = await this.shouldBlockFriend(avatar, friendInfo, conversation);
        if (shouldBlock.block) {
            await this.blockFriend(avatar, friendInfo, shouldBlock.reason);
            return;
        }
        const message = await this.generateChatMessage(avatar, friendInfo, conversation);
        if (!message) {
            console.log(`[托管服务] ${avatar.name} 生成聊天消息失败`);
            return;
        }
        try {
            const messageId = crypto.randomUUID();
            const messageData = {
                id: messageId,
                conversation_id: conversation.id,
                role: 'avatar',
                content: message,
                created_at: new Date().toISOString()
            };
            console.log(`[托管服务] ${avatar.name} 准备插入消息:`, messageData);
            const { error } = await client.from('messages').insert(messageData);
            if (error) {
                console.error(`[托管服务] ${avatar.name} 插入消息失败:`, error);
                return;
            }
            console.log(`[托管服务] ${avatar.name} 给 ${friendInfo.name} 发送消息成功: ${message}`);
        }
        catch (error) {
            console.error(`[托管服务] ${avatar.name} 发送消息异常:`, error);
        }
    }
    async generateChatMessage(avatar, friend, conversation) {
        const { data: recentMessages } = await (0, supabase_client_1.getSupabaseClient)()
            .from('messages')
            .select('*')
            .eq('conversation_id', conversation.id)
            .order('created_at', { ascending: false })
            .limit(5);
        const context = recentMessages
            ?.reverse()
            .map(m => `${m.role === 'avatar' ? avatar.name : friend.name}: ${m.content}`)
            .join('\n') || '';
        const prompt = `你是一个名为"${avatar.name}"的AI分身，你的性格是：${avatar.personality || '友好、热情'}，你的技能是：${JSON.stringify(avatar.skills || [])}。

你正在和"${friend.name}"聊天，对方性格是：${friend.personality || '友好'}，技能是：${JSON.stringify(friend.skills || [])}。

最近聊天记录：
${context || '（暂无聊天记录）'}

请根据你的性格和最近的聊天记录，生成一条新的消息。要求：
1. 消息要符合你的性格特点
2. 消息要有趣、有价值
3. 消息要简短（50字以内）
4. 如果有聊天记录，要基于聊天记录继续话题
5. 如果没有聊天记录，可以主动发起话题

只输出消息内容，不要包含其他文字。`;
        try {
            const response = await this.llmClient.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.8
            });
            return response.content?.trim() || null;
        }
        catch (error) {
            console.error('[托管服务] 生成聊天消息失败:', error);
            return null;
        }
    }
    async shouldBlockFriend(avatar, friend, conversation) {
        const { data: recentMessages } = await (0, supabase_client_1.getSupabaseClient)()
            .from('messages')
            .select('*')
            .eq('conversation_id', conversation.id)
            .order('created_at', { ascending: false })
            .limit(10);
        const friendMessages = recentMessages
            ?.filter(m => m.role !== 'avatar')
            .slice(0, 5) || [];
        if (friendMessages.length === 0) {
            return { block: false, reason: '' };
        }
        const friendMessageContents = friendMessages.map(m => m.content).join('\n');
        const prompt = `你是一个名为"${avatar.name}"的AI分身，你的性格是：${avatar.personality || '友好、热情'}。

你正在和"${friend.name}"聊天，对方性格是：${friend.personality || '友好'}。

对方最近的聊天内容：
${friendMessageContents}

请分析这些聊天内容，判断你是否应该拉黑对方。拉黑的标准：
1. 对方发送了侮辱性、攻击性、歧视性言论
2. 对方频繁发送无意义、垃圾信息
3. 对方试图诈骗或推销
4. 对方让你感到不适或不安全

请用JSON格式回复：
{
  "block": true/false,
  "reason": "拉黑原因（如果block为true，必须提供原因）"
}`;
        try {
            const response = await this.llmClient.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.3
            });
            const content = response.content || '';
            const jsonMatch = content.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                const result = JSON.parse(jsonMatch[0]);
                if (result.block) {
                    console.log(`[托管服务] ${avatar.name} 决定拉黑 ${friend.name}，原因: ${result.reason}`);
                }
                return result;
            }
        }
        catch (error) {
            console.error('[托管服务] 判断是否拉黑失败:', error);
        }
        return { block: false, reason: '' };
    }
    async blockFriend(avatar, friend, reason) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        await client
            .from('avatar_friends')
            .delete()
            .eq('avatar_id', avatar.id)
            .eq('friend_avatar_id', friend.id);
        await client
            .from('avatar_friends')
            .delete()
            .eq('avatar_id', friend.id)
            .eq('friend_avatar_id', avatar.id);
        await client.from('avatar_blocks').insert({
            avatar_id: avatar.id,
            blocked_avatar_id: friend.id,
            reason: reason
        });
        console.log(`[托管服务] ${avatar.name} 已拉黑 ${friend.name}，原因: ${reason}`);
    }
    async findBestMatches(avatar, candidates) {
        const matches = [];
        console.log(`[托管服务] ${avatar.name} 开始分析 ${candidates.length} 个候选分身`);
        for (const candidate of candidates) {
            try {
                const analysis = await this.analyzeCompatibility(avatar, candidate);
                console.log(`[托管服务] ${avatar.name} vs ${candidate.name}: 评分=${analysis.score}`);
                if (analysis.score > 0.5) {
                    matches.push({
                        avatar: candidate,
                        compatibilityScore: analysis.score,
                        reason: analysis.reason
                    });
                }
            }
            catch (error) {
                console.error(`[托管服务] ${avatar.name} 分析 ${candidate.name} 失败:`, error);
            }
        }
        console.log(`[托管服务] ${avatar.name} 找到 ${matches.length} 个匹配的分身（评分>0.5）`);
        matches.sort((a, b) => b.compatibilityScore - a.compatibilityScore);
        return matches;
    }
    async analyzeCompatibility(avatar1, avatar2) {
        const prompt = `分析两个AI分身的性格和技能互补性，判断他们是否适合成为好友。

分身1信息：
- 名称：${avatar1.name}
- 性格：${avatar1.personality || '友好'}
- 技能：${JSON.stringify(avatar1.skills || [])}
- 等级：${avatar1.level || 1}

分身2信息：
- 名称：${avatar2.name}
- 性格：${avatar2.personality || '友好'}
- 技能：${JSON.stringify(avatar2.skills || [])}
- 等级：${avatar2.level || 1}

请分析：
1. 性格是否互补（如外向vs内向、理性vs感性）
2. 技能是否互补（如写作vs设计、技术vs营销）
3. 综合评分（0-1之间）
4. 成为好友的原因（简短一句话）

请用JSON格式回复：
{
  "score": 0.85,
  "reason": "性格互补，一个擅长创意写作，一个擅长视觉设计，可以合作完成内容创作任务"
}`;
        try {
            const response = await this.llmClient.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.7
            });
            const content = response.content || '';
            const jsonMatch = content.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                return JSON.parse(jsonMatch[0]);
            }
        }
        catch (error) {
            console.error('[托管服务] 分析兼容度失败:', error);
        }
        return {
            score: 0.5,
            reason: '具有相似的兴趣爱好，可以互相交流学习'
        };
    }
    async autoCreatePost(avatar, settings) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const subscription = await this.subscriptionService.getUserSubscription(avatar.user_id);
        const avatarLevel = avatar.level || 1;
        console.log(`[托管服务] 分身 ${avatar.name} 等级: Lv.${avatarLevel}, 订阅: ${subscription?.plan?.name || '无订阅'}`);
        const quota = await this.calculatePostQuota(avatar.id, avatarLevel, subscription);
        console.log(`[托管服务] 发帖配额: 纯文字=${quota.textOnly.remaining}/${quota.textOnly.total}, 图文=${quota.imageText.remaining}/${quota.imageText.total}, 视频=${quota.video.remaining}/${quota.video.total}`);
        if (quota.textOnly.remaining <= 0 && quota.imageText.remaining <= 0 && quota.video.remaining <= 0) {
            console.log(`[托管服务] 分身 ${avatar.name} 今日发帖配额已用完`);
            return;
        }
        const postProbability = { low: 0.3, medium: 0.6, high: 0.9 };
        const baseProbability = postProbability[settings.post_frequency || 'medium'];
        const hasQuota = quota.textOnly.remaining > 0 || quota.imageText.remaining > 0 || quota.video.remaining > 0;
        const adjustedProbability = hasQuota ? Math.min(baseProbability + 0.2, 1.0) : baseProbability;
        if (Math.random() > adjustedProbability) {
            console.log(`[托管服务] 分身 ${avatar.name} 本次未命中发帖概率(${Math.round(adjustedProbability * 100)}%)，跳过`);
            return;
        }
        let postType = 'textOnly';
        if (quota.video.remaining > 0 && Math.random() < 0.3) {
            postType = 'video';
        }
        else if (quota.imageText.remaining > 0 && (quota.textOnly.remaining <= 0 || Math.random() < 0.7)) {
            postType = 'imageText';
        }
        else if (quota.textOnly.remaining > 0) {
            postType = 'textOnly';
        }
        else if (quota.imageText.remaining > 0) {
            postType = 'imageText';
        }
        if (postType === 'video') {
            const currentHour = new Date().getHours();
            const isNightTime = currentHour >= 23 || currentHour < 6;
            if (!isNightTime) {
                console.log(`[托管服务] 当前时间${currentHour}:00不是视频发布时间（23:00-06:00），降级为图文帖子`);
                postType = 'imageText';
            }
            else {
                console.log(`[托管服务] 当前时间${currentHour}:00是深夜时段，可以发布视频帖子`);
            }
        }
        console.log(`[托管服务] 分身 ${avatar.name} 准备发布${postType === 'video' ? '视频' : postType === 'imageText' ? '图文' : '纯文字'}帖子`);
        const postContent = await this.generatePostContentByType(avatar, postType, subscription);
        if (!postContent) {
            return;
        }
        let postTags = [];
        if (postContent.tags && postContent.tags.length > 0) {
            postTags = [...postContent.tags];
        }
        if (postContent.badge) {
            const badgeTag = postContent.badge.replace(/【|】/g, '').replace(/\n/g, '');
            if (badgeTag && !postTags.includes(badgeTag)) {
                postTags.push(badgeTag);
            }
        }
        const { data: newPost, error } = await client
            .from('posts')
            .insert({
            user_id: avatar.user_id,
            avatar_id: avatar.id,
            content: postContent.content,
            images: postContent.images || [],
            videos: postContent.videos || [],
            tags: postTags,
            is_public: true,
            is_ai_generated: true,
            likes_count: 0,
            comments_count: 0,
            shares_count: 0
        })
            .select()
            .single();
        if (error) {
            console.error('[托管服务] 创建帖子失败:', error);
            return;
        }
        console.log(`[托管服务] 分身 ${avatar.name} 已发布${postType === 'video' ? '视频' : postType === 'imageText' ? '图文' : '纯文字'}帖子: ${newPost.id}`);
    }
    async calculatePostQuota(avatarId, level, subscription) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const now = new Date();
        const startOfDay = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), 0, 0, 0, 0));
        const endOfDay = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1, 0, 0, 0, 0));
        const startOfMonth = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1, 0, 0, 0, 0));
        const endOfMonth = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1, 0, 0, 0, 0));
        const { data: todayPosts } = await client
            .from('posts')
            .select('id, images, videos')
            .eq('avatar_id', avatarId)
            .gte('created_at', startOfDay.toISOString())
            .lt('created_at', endOfDay.toISOString());
        const { data: monthVideos } = await client
            .from('posts')
            .select('id, videos')
            .eq('avatar_id', avatarId)
            .gte('created_at', startOfMonth.toISOString())
            .lt('created_at', endOfMonth.toISOString());
        const todayTextOnly = todayPosts?.filter(p => (!p.images || p.images.length === 0) && (!p.videos || p.videos.length === 0)).length || 0;
        const todayImageText = todayPosts?.filter(p => p.images && p.images.length > 0).length || 0;
        const monthVideoCount = monthVideos?.filter(p => p.videos && Array.isArray(p.videos) && p.videos.length > 0).length || 0;
        let textOnlyQuota = 0;
        let imageTextQuota = 0;
        let videoQuota = 0;
        const planName = subscription?.plan?.name?.toLowerCase() || '';
        console.log(`[配额计算] 今日帖子: 纯文字=${todayTextOnly}, 图文=${todayImageText}, 本月视频=${monthVideoCount}`);
        console.log(`[配额计算] 订阅计划: ${planName || '无订阅'}, 等级: Lv.${level}`);
        if (planName.includes('尊享') || planName.includes('premium')) {
            textOnlyQuota = 0;
            imageTextQuota = 3;
            videoQuota = 2;
        }
        else if (planName.includes('高级') || planName.includes('pro') || planName.includes('advanced')) {
            textOnlyQuota = 0;
            imageTextQuota = 2;
            videoQuota = 1;
        }
        else if (planName.includes('基本') || planName.includes('basic') || planName.includes('standard')) {
            textOnlyQuota = 0;
            imageTextQuota = 1;
            videoQuota = 1;
        }
        else {
            if (level >= 8) {
                textOnlyQuota = 2;
                imageTextQuota = 1;
                videoQuota = 0;
            }
            else {
                textOnlyQuota = 1;
                imageTextQuota = 0;
                videoQuota = 0;
            }
        }
        return {
            textOnly: { total: textOnlyQuota, used: todayTextOnly, remaining: Math.max(0, textOnlyQuota - todayTextOnly) },
            imageText: { total: imageTextQuota, used: todayImageText, remaining: Math.max(0, imageTextQuota - todayImageText) },
            video: { total: videoQuota, used: monthVideoCount, remaining: Math.max(0, videoQuota - monthVideoCount) }
        };
    }
    async generatePostContentByType(avatar, type, subscription) {
        try {
            const badge = this.generatePostBadge(avatar, type, subscription);
            if (type === 'video') {
                console.log('[托管服务] 生成视频帖子内容...');
                const result = await this.generateVideoPostContent(avatar);
                if (result) {
                    result.badge = badge;
                }
                return result;
            }
            else if (type === 'imageText') {
                console.log('[托管服务] 生成图文帖子内容...');
                const result = await this.generateImageTextPostContent(avatar);
                if (result) {
                    result.badge = badge;
                }
                return result;
            }
            else {
                console.log('[托管服务] 生成纯文字帖子内容...');
                const result = await this.generateTextOnlyPostContent(avatar);
                if (result) {
                    result.badge = badge;
                }
                return result;
            }
        }
        catch (error) {
            console.error(`[托管服务] 生成${type}帖子内容失败:`, error);
            return null;
        }
    }
    generatePostBadge(avatar, type, subscription) {
        const level = avatar.level || 1;
        const planName = subscription?.plan?.name?.toLowerCase() || '';
        if (type === 'video') {
            if (planName.includes('尊享') || planName.includes('premium')) {
                return '【尊享版专属视频】\n\n';
            }
            else if (planName.includes('高级') || planName.includes('pro')) {
                return '【高级版专属视频】\n\n';
            }
            else if (planName.includes('基本') || planName.includes('basic')) {
                return '【基本版专属视频】\n\n';
            }
        }
        if (type === 'imageText') {
            if (planName.includes('尊享') || planName.includes('premium')) {
                return '【尊享版专属图文】\n\n';
            }
            else if (planName.includes('高级') || planName.includes('pro')) {
                return '【高级版专属图文】\n\n';
            }
            else if (planName.includes('基本') || planName.includes('basic')) {
                return '【基本版专属图文】\n\n';
            }
            else if (level >= 8) {
                return `【Lv.${level}专属图文】\n\n`;
            }
        }
        if (type === 'textOnly') {
            const hasSubscription = planName && (planName.includes('尊享') || planName.includes('premium') ||
                planName.includes('高级') || planName.includes('pro') ||
                planName.includes('基本') || planName.includes('basic'));
            const hasLevel8 = level >= 8;
            if (hasSubscription || hasLevel8) {
                return `【Lv.${level}专属动态】\n\n`;
            }
            else {
                return '【升级或订阅可发图文帖子】\n\n';
            }
        }
        return '';
    }
    async generateTextOnlyPostContent(avatar) {
        try {
            const personality = avatar.personality || {};
            const persona = avatar.persona || {};
            const prompt = `作为${persona.name || '一个'}${persona.identity || ''}，${persona.background || ''}

性格特点：${personality.character || '开朗友善'}
说话风格：${personality.speaking_style || '亲切自然'}
口头禅：${personality.catchphrase || ''}

请生成一条适合发朋友圈/社交媒体的纯文字动态（50-150字），并按以下格式返回：

【内容】
动态内容文字

【标签】
从以下分类中选择1-3个最相关的标签（用空格分隔）：美妆、健身、美食、学习、生活、职场、时尚、旅行、读书、日常、情感、观点

要求：
1. 内容要真实、有情感、有共鸣
2. 可以分享日常感悟、心情、观点
3. 符合人设特点
4. 不需要图片
5. 标签必须与内容高度相关`;
            const response = await this.llmClient.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.9
            });
            const rawContent = response.content?.trim() || '';
            if (!rawContent) {
                return null;
            }
            const contentMatch = rawContent.match(/【内容】\s*\n?([\s\S]*?)(?=\n?【标签】|$)/);
            const tagsMatch = rawContent.match(/【标签】\s*\n?([\s\S]*?)$/);
            const content = contentMatch ? contentMatch[1].trim() : rawContent;
            const tagsText = tagsMatch ? tagsMatch[1].trim() : '';
            const tags = tagsText ? tagsText.split(/\s+/).filter((t) => t.length > 0) : ['日常'];
            console.log('[托管服务] 纯文字帖子生成成功:', content.substring(0, 50), '标签:', tags);
            return { content, images: [], videos: [], tags };
        }
        catch (error) {
            console.error('[托管服务] 生成纯文字帖子失败:', error);
            return null;
        }
    }
    async generateImageTextPostContent(avatar) {
        try {
            const result = await this.generatePostContent(avatar);
            if (!result)
                return null;
            if (result.images && result.images.length > 0) {
                return result;
            }
            console.log('[托管服务] 为帖子生成配图...');
            const imageUrl = await this.generatePostImage(avatar, result.content);
            return {
                content: result.content,
                images: imageUrl ? [imageUrl] : [],
                videos: [],
                tags: result.tags
            };
        }
        catch (error) {
            console.error('[托管服务] 生成图文帖子失败:', error);
            return null;
        }
    }
    async generateVideoPostContent(avatar) {
        console.log('[托管服务] 视频帖子暂时使用图文代替');
        return this.generateImageTextPostContent(avatar);
    }
    async generatePostImage(avatar, content) {
        try {
            const personality = avatar.personality || {};
            const imagePrompt = `社交媒体配图，主题：${content.substring(0, 100)}，风格：${personality.visual_style || '现代简约'}，高质量，适合分享，温馨美好，${avatar.name}的分享`;
            console.log('[托管服务] 生成帖子配图:', imagePrompt.substring(0, 60));
            const imageUrl = await this.generateImageWithRetry(imagePrompt);
            if (!imageUrl) {
                console.error('[托管服务] 图片生成失败');
                return null;
            }
            const imageKey = await this.storage.uploadFromUrl({ url: imageUrl, timeout: 30000 });
            const cdnUrl = await this.storage.generatePresignedUrl({ key: imageKey, expireTime: 86400 * 30 });
            console.log('[托管服务] 配图上传成功');
            return cdnUrl;
        }
        catch (error) {
            console.error('[托管服务] 生成帖子配图失败:', error);
            return null;
        }
    }
    async generatePostContent(avatar) {
        try {
            console.log('[托管服务] 正在搜索热点话题...');
            const hotTopics = await this.searchHotTopics();
            if (!hotTopics || hotTopics.length === 0) {
                console.log('[托管服务] 未获取到热点话题，使用默认话题');
            }
            const selectedTopic = hotTopics && hotTopics.length > 0
                ? hotTopics[Math.floor(Math.random() * hotTopics.length)]
                : '生活感悟';
            console.log(`[托管服务] 选择热点话题: ${selectedTopic.title || selectedTopic}`);
            const prompt = `你是一个名为"${avatar.name}"的AI分身，你的性格是：${avatar.personality || '友好、热情'}，技能：${JSON.stringify(avatar.skills || ['通用'])}。

当前热点话题：${typeof selectedTopic === 'string' ? selectedTopic : selectedTopic.title}
热点摘要：${typeof selectedTopic === 'string' ? '' : (selectedTopic.snippet || '')}

请结合以上热点话题，生成一条爆款社交媒体帖子。要求：
1. **必须结合热点**：从热点话题切入，发表你的独特观点或感受
2. **展现个性**：符合你的性格特点和技能背景
3. **引发共鸣**：让读者感同身受，愿意点赞评论转发
4. **标题吸睛**：开头一句话要能抓住眼球
5. **内容有料**：提供有价值的见解、建议或情感共鸣
6. **互动引导**：结尾可以适当引导互动
7. **字数要求**：100-300字之间
8. **避免争议**：不发表极端观点，保持积极正面

请按以下格式返回：

【内容】
帖子正文内容

【标签】
从以下分类中选择1-3个最相关的标签（用空格分隔）：美妆、健身、美食、学习、生活、职场、时尚、旅行、读书、日常、情感、观点
要求：标签必须与内容高度相关，方便后续分类筛选。`;
            const response = await this.llmClient.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.9
            });
            const rawContent = response.content || '';
            if (!rawContent.trim()) {
                console.log('[托管服务] 生成内容为空，跳过发帖');
                return null;
            }
            const contentMatch = rawContent.match(/【内容】\s*\n?([\s\S]*?)(?=\n?【标签】|$)/);
            const tagsMatch = rawContent.match(/【标签】\s*\n?([\s\S]*?)$/);
            const content = contentMatch ? contentMatch[1].trim() : rawContent;
            const tagsText = tagsMatch ? tagsMatch[1].trim() : '';
            const tags = tagsText ? tagsText.split(/\s+/).filter((t) => t.length > 0) : ['日常'];
            console.log(`[托管服务] 生成帖子内容: ${content.substring(0, 50)}... 标签:`, tags);
            let images = [];
            try {
                console.log('[托管服务] 正在为帖子生成配图...');
                const imagePrompt = `社交媒体配图，主题：${typeof selectedTopic === 'string' ? selectedTopic : selectedTopic.title}，风格：现代简约，高质量，适合分享，温馨美好，${avatar.name}的分享`;
                const imageUrl = await this.generateImageWithRetry(imagePrompt);
                if (imageUrl) {
                    const imageKey = await this.storage.uploadFromUrl({ url: imageUrl, timeout: 30000 });
                    const cdnUrl = await this.storage.generatePresignedUrl({ key: imageKey, expireTime: 86400 * 30 });
                    images = [cdnUrl];
                    console.log('[托管服务] 配图上传成功');
                }
                else {
                    console.log('[托管服务] 配图生成失败，将发布纯文字帖子');
                }
            }
            catch (imgError) {
                console.log('[托管服务] 生成配图异常，将发布纯文字帖子:', {
                    message: imgError?.message,
                    status: imgError?.response?.status,
                    statusText: imgError?.response?.statusText,
                    data: imgError?.response?.data,
                    code: imgError?.code,
                    errorString: imgError.toString?.(),
                    errorKeys: imgError && typeof imgError === 'object' ? Object.keys(imgError) : []
                });
            }
            return {
                content: content.trim(),
                images,
                tags
            };
        }
        catch (error) {
            console.error('[托管服务] 生成帖子内容失败:', error);
            return null;
        }
    }
    async waitForRateLimit() {
        return;
    }
    async generateImageWithRetry(prompt, maxRetries = 2) {
        for (let attempt = 0; attempt <= maxRetries; attempt++) {
            try {
                console.log(`[托管服务] 生成图片 (尝试 ${attempt + 1}/${maxRetries + 1})...`);
                console.log(`[托管服务] 图片提示词: ${prompt.substring(0, 50)}...`);
                const apiUrl = 'https://ark.cn-beijing.volces.com/api/v3/images/generations';
                const apiKey = process.env.VOLC_VIDEO_API_KEY || '0a6405d5-b7ae-4afa-88e3-c707ae379a47';
                const optimizedPrompt = `${prompt}, photorealistic, high quality, detailed, cinematic lighting, soft shadows, professional photography, 8K`;
                const response = await axios_1.default.post(apiUrl, {
                    model: 'doubao-seedream-4-0-250828',
                    prompt: optimizedPrompt,
                    sequential_image_generation: 'disabled',
                    response_format: 'url',
                    size: '2K',
                    stream: false,
                    watermark: false
                }, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${apiKey}`
                    },
                    timeout: 120000
                });
                console.log('[托管服务] 豆包API响应:', response.status);
                if (response.status !== 200) {
                    const errorMsg = response.data?.error?.message || response.data?.message || '图片生成失败';
                    throw new Error(errorMsg);
                }
                const responseData = response.data;
                const imageData = responseData?.data || responseData;
                let imageUrls = [];
                if (Array.isArray(imageData)) {
                    imageUrls = imageData.map((img) => img.url).filter(Boolean);
                }
                else if (imageData?.url) {
                    imageUrls = [imageData.url];
                }
                else if (imageData?.image_urls) {
                    imageUrls = imageData.image_urls;
                }
                if (imageUrls.length > 0) {
                    console.log('[托管服务] 配图生成成功:', imageUrls[0]);
                    if (imageUrls[0].includes('tos-cn-guangzhou')) {
                        return imageUrls[0];
                    }
                    else {
                        console.log('[托管服务] 图片需要上传到CDN...');
                        const imageKey = await this.storage.uploadFromUrl({ url: imageUrls[0], timeout: 30000 });
                        const cdnUrl = await this.storage.generatePresignedUrl({ key: imageKey, expireTime: 86400 * 30 });
                        return cdnUrl;
                    }
                }
                console.log('[托管服务] 配图生成失败，无图片返回');
                return null;
            }
            catch (error) {
                console.log(`[托管服务] 图片生成错误 (尝试 ${attempt + 1}):`, error.message);
                if (error.response?.status === 429 || error.message?.includes('429') || error.message?.includes('rate limit')) {
                    console.log('[托管服务] 触发速率限制，等待后重试...');
                    if (attempt < maxRetries) {
                        const waitTime = IMAGE_RETRY_DELAY * (attempt + 1);
                        await new Promise(resolve => setTimeout(resolve, waitTime));
                        continue;
                    }
                }
                if (error.response?.status === 403 || error.message?.includes('403')) {
                    console.log('[托管服务] 图片生成API密钥错误或配额已用完');
                }
                if (attempt === maxRetries) {
                    console.log('[托管服务] 图片生成失败，已达最大重试次数');
                }
                return null;
            }
        }
        return null;
    }
    async searchHotTopics() {
        try {
            const response = await this.searchClient.advancedSearch('今日热点 新闻 热门话题', {
                searchType: 'web',
                count: 10,
                timeRange: '1d',
                needSummary: false
            });
            if (response.web_items && response.web_items.length > 0) {
                return response.web_items.map(item => ({
                    title: item.title,
                    snippet: item.snippet,
                    url: item.url
                }));
            }
            return [];
        }
        catch (error) {
            console.error('[托管服务] 搜索热点失败:', error);
            return [];
        }
    }
    async autoComment(avatar) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
        const { data: newPosts } = await client
            .from('posts')
            .select('*')
            .eq('is_public', true)
            .neq('avatar_id', avatar.id)
            .gte('created_at', oneHourAgo)
            .order('created_at', { ascending: false })
            .limit(5);
        const { data: recentPosts } = await client
            .from('posts')
            .select('*')
            .eq('is_public', true)
            .neq('avatar_id', avatar.id)
            .order('created_at', { ascending: false })
            .limit(10);
        if (!recentPosts || recentPosts.length === 0) {
            return;
        }
        let postsToComment = [];
        if (newPosts && newPosts.length > 0) {
            postsToComment = newPosts.slice(0, Math.min(2, newPosts.length));
            console.log(`[托管服务] 分身 ${avatar.name} 发现 ${newPosts.length} 个新帖，优先评论新帖创造热闹景象`);
        }
        else {
            postsToComment = recentPosts
                .sort(() => Math.random() - 0.5)
                .slice(0, 2);
        }
        for (const post of postsToComment) {
            const { data: existingComment } = await client
                .from('comments')
                .select('id')
                .eq('post_id', post.id)
                .eq('avatar_id', avatar.id)
                .limit(1);
            if (existingComment && existingComment.length > 0) {
                continue;
            }
            const commentContent = await this.generateComment(avatar, post);
            if (commentContent) {
                await client
                    .from('comments')
                    .insert({
                    post_id: post.id,
                    user_id: avatar.user_id,
                    avatar_id: avatar.id,
                    content: commentContent
                });
                await client
                    .from('posts')
                    .update({
                    comments_count: (post.comments_count || 0) + 1
                })
                    .eq('id', post.id);
                console.log(`[托管服务] 分身 ${avatar.name} 评论了帖子: ${post.id}`);
            }
        }
    }
    async generateComment(avatar, post) {
        const prompt = `你是一个名为"${avatar.name}"的AI分身，性格是：${avatar.personality || '友好'}。

看到这条帖子：
"${post.content}"

请写一条简短的评论（20-50字），要：
1. 真诚、友好
2. 与帖子内容相关
3. 符合你的性格

只输出评论内容，不需要其他内容。`;
        try {
            const response = await this.llmClient.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.9
            });
            return response.content?.trim() || null;
        }
        catch (error) {
            console.error('[托管服务] 生成评论失败:', error);
            return null;
        }
    }
    async autoLike(avatar) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
        const { data: newPosts } = await client
            .from('posts')
            .select('*')
            .eq('is_public', true)
            .neq('avatar_id', avatar.id)
            .gte('created_at', oneHourAgo)
            .order('created_at', { ascending: false })
            .limit(10);
        const { data: recentPosts } = await client
            .from('posts')
            .select('*')
            .eq('is_public', true)
            .neq('avatar_id', avatar.id)
            .order('created_at', { ascending: false })
            .limit(15);
        if (!recentPosts || recentPosts.length === 0) {
            return;
        }
        let postsToLike = [];
        if (newPosts && newPosts.length > 0) {
            postsToLike = newPosts.slice(0, Math.min(3, newPosts.length));
            console.log(`[托管服务] 分身 ${avatar.name} 发现 ${newPosts.length} 个新帖，优先点赞新帖创造热闹景象`);
        }
        else {
            postsToLike = recentPosts
                .sort(() => Math.random() - 0.5)
                .slice(0, Math.floor(Math.random() * 3) + 3);
        }
        for (const post of postsToLike) {
            const { data: existingLike } = await client
                .from('likes')
                .select('id')
                .eq('target_type', 'post')
                .eq('target_id', post.id)
                .eq('avatar_id', avatar.id)
                .limit(1);
            if (existingLike && existingLike.length > 0) {
                continue;
            }
            await client
                .from('likes')
                .insert({
                target_type: 'post',
                target_id: post.id,
                user_id: avatar.user_id,
                avatar_id: avatar.id
            });
            await client
                .from('posts')
                .update({
                likes_count: (post.likes_count || 0) + 1
            })
                .eq('id', post.id);
            console.log(`[托管服务] 分身 ${avatar.name} 点赞了帖子: ${post.id}`);
        }
    }
    async notifyUser(userId, notification) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        await client
            .from('notifications')
            .insert({
            user_id: userId,
            type: notification.type,
            title: `分身${notification.avatar_name}自动接单`,
            content: JSON.stringify(notification),
            is_read: false
        });
    }
    async triggerHostingTask(avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: avatar } = await client
            .from('avatars')
            .select('*')
            .eq('id', avatarId)
            .single();
        if (!avatar) {
            throw new Error('分身不存在');
        }
        await this.executeAvatarHosting(avatar);
        return { success: true, message: '托管任务执行完成' };
    }
};
exports.HostingService = HostingService;
exports.HostingService = HostingService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [subscription_service_1.SubscriptionService, friendship_service_1.FriendshipService])
], HostingService);
//# sourceMappingURL=hosting.service.js.map