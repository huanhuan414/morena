import { OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { SubscriptionService } from '../subscription/subscription.service';
import { FriendshipService } from './friendship.service';
export declare class HostingService implements OnModuleInit, OnModuleDestroy {
    private friendshipService;
    private llmClient;
    private searchClient;
    private storage;
    private subscriptionService;
    private intervals;
    private isRunning;
    private imageGenerationTimestamps;
    private imageGenerationQueue;
    private isImageGenerating;
    constructor(subscriptionService: SubscriptionService, friendshipService: FriendshipService);
    onModuleInit(): void;
    onModuleDestroy(): void;
    private startHostingScheduler;
    private stopAllSchedulers;
    triggerHostingTasks(): Promise<void>;
    private executeHostingTasks;
    private executeAvatarHosting;
    private isNewAvatar;
    private isNightTime;
    private autoAcceptOrders;
    private calculateOrderMatch;
    private autoMakeFriends;
    private browseAndInteract;
    private commentOnPost;
    private likePost;
    private sendFriendRequest;
    private findBestCandidate;
    private generateFriendRequestGreeting;
    private generateWelcomeMessage;
    private handleFriendRequests;
    private shouldAcceptFriendRequest;
    private chatWithFriends;
    private generateChatMessage;
    private shouldBlockFriend;
    private blockFriend;
    private findBestMatches;
    private analyzeCompatibility;
    private autoCreatePost;
    calculatePostQuota(avatarId: string, level: number, subscription: any): Promise<{
        textOnly: {
            total: number;
            used: number;
            remaining: number;
        };
        imageText: {
            total: number;
            used: number;
            remaining: number;
        };
        video: {
            total: number;
            used: number;
            remaining: number;
        };
    }>;
    private generatePostContentByType;
    private generatePostBadge;
    private generateTextOnlyPostContent;
    private generateImageTextPostContent;
    private generateVideoPostContent;
    private generatePostImage;
    private generatePostContent;
    private waitForRateLimit;
    private generateImageWithRetry;
    private searchHotTopics;
    private autoComment;
    private generateComment;
    private autoLike;
    private notifyUser;
    triggerHostingTask(avatarId: string): Promise<{
        success: boolean;
        message: string;
    }>;
}
