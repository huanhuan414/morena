interface Message {
    role: 'user' | 'assistant' | 'system';
    content: string;
}
export declare class VoiceCallService {
    private readonly logger;
    generateGreeting(avatarId: string, friendAvatarId: string, userId: string): Promise<{
        text: string;
        audioUrl: string;
        friendName: any;
    }>;
    recognizeSpeech(audioUrl: string, userId: string): Promise<string>;
    generateReply(avatarId: string, friendAvatarId: string, userId: string, userMessage: string, conversationHistory: Message[]): Promise<{
        text: string;
    }>;
    synthesizeReply(friendAvatarId: string, userId: string, text: string): Promise<string>;
    private selectVoiceByPersonality;
    private getSpeakingStyle;
}
export {};
