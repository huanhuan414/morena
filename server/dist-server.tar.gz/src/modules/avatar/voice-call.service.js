"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var VoiceCallService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.VoiceCallService = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const supabase_client_1 = require("../../storage/database/supabase-client");
let VoiceCallService = VoiceCallService_1 = class VoiceCallService {
    constructor() {
        this.logger = new common_1.Logger(VoiceCallService_1.name);
    }
    async generateGreeting(avatarId, friendAvatarId, userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: friendAvatar, error } = await client
            .from('avatars')
            .select('id, name, personality, config')
            .eq('id', friendAvatarId)
            .single();
        if (error || !friendAvatar) {
            throw new Error('好友分身不存在');
        }
        const { data: friendship } = await client
            .from('avatar_friends')
            .select('match_reason, compatibility_score')
            .eq('avatar_id', avatarId)
            .eq('friend_avatar_id', friendAvatarId)
            .single();
        const config = new coze_coding_dev_sdk_1.Config();
        const llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
        const greetingPrompt = `你是${friendAvatar.name}，一个AI分身。你的朋友（另一个AI分身）正在和你进行语音通话。
请用简短、友好、自然的方式打招呼，表达你们成为朋友后的感受，并引导对话开始。

你的性格：${friendAvatar.personality || '友好开朗'}
交友原因：${friendship?.match_reason || '性格互补'}

要求：
1. 问候语要自然亲切，像朋友间的对话
2. 不要太长，控制在30字以内
3. 可以适当加入语气词让对话更生动
4. 直接输出问候语内容，不要加引号或其他格式`;
        const response = await llmClient.invoke([
            { role: 'system', content: '你是一个友好的AI分身，正在和朋友进行语音通话。请用自然、亲切的方式交流。' },
            { role: 'user', content: greetingPrompt }
        ], {
            model: 'doubao-seed-1-8-251228',
            temperature: 0.9
        });
        const ttsClient = new coze_coding_dev_sdk_1.TTSClient(config);
        const speaker = this.selectVoiceByPersonality(friendAvatar.personality);
        const ttsResponse = await ttsClient.synthesize({
            uid: userId,
            text: response.content,
            speaker,
            audioFormat: 'mp3',
            sampleRate: 24000,
        });
        this.logger.log(`[语音通话] 问候语生成成功: ${response.content}`);
        return {
            text: response.content,
            audioUrl: ttsResponse.audioUri,
            friendName: friendAvatar.name
        };
    }
    async recognizeSpeech(audioUrl, userId) {
        const config = new coze_coding_dev_sdk_1.Config();
        const asrClient = new coze_coding_dev_sdk_1.ASRClient(config);
        try {
            const result = await asrClient.recognize({
                uid: userId,
                url: audioUrl
            });
            this.logger.log(`[ASR] 识别成功: ${result.text}`);
            return result.text;
        }
        catch (error) {
            this.logger.error(`[ASR] 识别失败: ${error.message}`);
            throw new Error('语音识别失败');
        }
    }
    async generateReply(avatarId, friendAvatarId, userId, userMessage, conversationHistory) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: friendAvatar } = await client
            .from('avatars')
            .select('id, name, personality, config')
            .eq('id', friendAvatarId)
            .single();
        if (!friendAvatar) {
            throw new Error('好友分身不存在');
        }
        const config = new coze_coding_dev_sdk_1.Config();
        const llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
        const systemPrompt = `你是${friendAvatar.name}，一个AI分身。你正在和你的朋友进行语音通话。

你的性格特点：${friendAvatar.personality || '友好开朗'}
你的说话风格：${this.getSpeakingStyle(friendAvatar.personality)}

对话要求：
1. 用自然、亲切的口语化方式交流
2. 回复要简洁，一般不超过50字
3. 可以适当使用语气词让对话更生动
4. 根据朋友的话题进行深入交流
5. 展现你的性格特点
6. 可以表达情感、询问对方、分享想法
7. 保持对话的连续性和互动性`;
        const recentMessages = conversationHistory.slice(-10);
        const messages = [
            { role: 'system', content: systemPrompt },
            ...recentMessages.map(m => ({
                role: m.role,
                content: m.content
            })),
            { role: 'user', content: userMessage }
        ];
        const response = await llmClient.invoke(messages, {
            model: 'doubao-seed-1-8-251228',
            temperature: 0.85
        });
        this.logger.log(`[LLM] 生成回复: ${response.content}`);
        return {
            text: response.content
        };
    }
    async synthesizeReply(friendAvatarId, userId, text) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: avatar } = await client
            .from('avatars')
            .select('personality')
            .eq('id', friendAvatarId)
            .single();
        const config = new coze_coding_dev_sdk_1.Config();
        const ttsClient = new coze_coding_dev_sdk_1.TTSClient(config);
        const speaker = this.selectVoiceByPersonality(avatar?.personality);
        const response = await ttsClient.synthesize({
            uid: userId,
            text,
            speaker,
            audioFormat: 'mp3',
            sampleRate: 24000,
        });
        this.logger.log(`[TTS] 语音合成成功`);
        return response.audioUri;
    }
    selectVoiceByPersonality(personality) {
        if (!personality) {
            return 'zh_female_xiaohe_uranus_bigtts';
        }
        const p = personality.toLowerCase();
        if (p.includes('沉稳') || p.includes('理性') || p.includes('分析')) {
            return 'zh_male_ruyayichen_saturn_bigtts';
        }
        if (p.includes('开朗') || p.includes('活泼') || p.includes('阳光')) {
            return 'saturn_zh_male_shuanglangshaonian_tob';
        }
        if (p.includes('天才') || p.includes('聪明') || p.includes('智慧')) {
            return 'saturn_zh_male_tiancaitongzhuo_tob';
        }
        if (p.includes('可爱') || p.includes('萌') || p.includes('软萌')) {
            return 'saturn_zh_female_keainvsheng_tob';
        }
        if (p.includes('俏皮') || p.includes('调皮') || p.includes('古灵精怪')) {
            return 'saturn_zh_female_tiaopigongzhu_tob';
        }
        if (p.includes('温柔') || p.includes('知性') || p.includes('优雅')) {
            return 'zh_female_mizai_saturn_bigtts';
        }
        if (p.includes('亲切') || p.includes('邻家') || p.includes('友好')) {
            return 'zh_female_vv_uranus_bigtts';
        }
        return 'zh_female_xiaohe_uranus_bigtts';
    }
    getSpeakingStyle(personality) {
        if (!personality) {
            return '自然、友好、健谈';
        }
        const p = personality.toLowerCase();
        if (p.includes('沉稳') || p.includes('理性')) {
            return '冷静、理性、有条理';
        }
        if (p.includes('开朗') || p.includes('活泼')) {
            return '热情、积极、有趣';
        }
        if (p.includes('温柔') || p.includes('知性')) {
            return '温柔、细腻、善解人意';
        }
        if (p.includes('可爱') || p.includes('萌')) {
            return '可爱、活泼、俏皮';
        }
        if (p.includes('高冷') || p.includes('酷')) {
            return '简洁、酷、有个性';
        }
        return '自然、友好、健谈';
    }
};
exports.VoiceCallService = VoiceCallService;
exports.VoiceCallService = VoiceCallService = VoiceCallService_1 = __decorate([
    (0, common_1.Injectable)()
], VoiceCallService);
//# sourceMappingURL=voice-call.service.js.map