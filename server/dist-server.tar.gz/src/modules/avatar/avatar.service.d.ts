import { ReverseGeocodingService } from '../../services/reverse-geocoding.service';
import { SubscriptionService } from '../subscription/subscription.service';
import { TikHubService } from '../tikhub/tikhub.service';
import { StorageService } from '../storage/storage.service';
import { FriendshipService } from './friendship.service';
export declare class AvatarService {
    private readonly reverseGeocodingService;
    private readonly subscriptionService;
    private readonly tikHubService;
    private readonly storageService;
    private readonly friendshipService;
    constructor(reverseGeocodingService: ReverseGeocodingService, subscriptionService: SubscriptionService, tikHubService: TikHubService, storageService: StorageService, friendshipService: FriendshipService);
    findAll(): Promise<any[]>;
    getAvatarsByUserId(userId: string): Promise<any[]>;
    findById(avatarId: string): Promise<any>;
    createAvatar(userId: string, avatarData: Record<string, any>): Promise<any>;
    private syncAvatarToUser;
    private triggerWelcomeMechanism;
    private randomDelay;
    sendFriendRequest(fromAvatarId: string, toAvatarId: string, userId: string): Promise<boolean>;
    private addUserSelectedSkills;
    private addDefaultSkills;
    private generateDescription;
    analyzePhoto(file: Express.Multer.File): Promise<{
        photoUrl: string;
        fileKey: null;
        analysis: any;
    }>;
    private deepAnalyzePhoto;
    private getDefaultAnalysis;
    private getDefaultAnalysisWithFace;
    getAvatarsByUser(userId: string): Promise<any[]>;
    getAvatarById(avatarId: string): Promise<any>;
    getAvatarAccounts(avatarId: string): Promise<{
        id: any;
        platform: any;
        account_name: any;
        followers: any;
        total_exposure: any;
        total_works: any;
        engagement_rate: any;
        account_url: any;
        last_updated_at: any;
    }[]>;
    updateAvatar(avatarId: string, userId: string, updates: Record<string, any>): Promise<any>;
    addExperience(avatarId: string, exp: number): Promise<any>;
    private calculateRewards;
    toggleHosting(avatarId: string, userId: string, enabled: boolean): Promise<any>;
    updateHostingSettings(avatarId: string, userId: string, settings: Record<string, any>): Promise<any>;
    getActivityStats(userId: string): Promise<{
        browseCount: number;
        likeCount: number;
        commentCount: number;
        postCount: number;
        minutesAgo: number;
    }>;
    getAllAvatars(userId: string): Promise<any[]>;
    getActiveAvatars(limit?: number): Promise<{
        id: any;
        name: any;
        avatar_url: any;
        color: any;
        post_count: number;
    }[]>;
    getAvatarOrders(avatarId: string, page?: number, pageSize?: number): Promise<{
        id: any;
        order_id: any;
        order_title: any;
        status: any;
        platforms: any;
        content_type: any;
        earnings: number;
        created_at: any;
        submitted_at: any;
    }[]>;
    getAvatarEarnings(avatarId: string): Promise<{
        totalEarnings: number;
        pendingEarnings: number;
        monthlyEarnings: number;
        totalOrders: number;
    }>;
    autoCreatePost(avatarId: string, userId: string, options?: {
        withImage?: boolean;
        withVideo?: boolean;
    }): Promise<any>;
    private generatePostContentWithMedia;
    private getDefaultPostContent;
    private generateImage;
    private generateVideo;
    private generatePostContent;
    autoLikePost(avatarId: string, userId: string, postId: string): Promise<{
        liked: boolean;
        message: string;
    }>;
    autoCommentPost(avatarId: string, userId: string, postId: string, postContent: string): Promise<any>;
    private generateCommentContent;
    getAvatarFriends(avatarId: string, userId: string): Promise<{
        id: any;
        friend: {
            id: any;
            name: any;
            avatar_url: any;
            level: any;
            personality: any;
        };
        match_reason: any;
        compatibility_score: any;
        status: any;
        isPending: any;
        created_at: any;
    }[]>;
    deleteAvatar(avatarId: string, userId: string): Promise<{
        success: boolean;
    }>;
    acceptFriendRequest(avatarId: string, friendAvatarId: string, userId: string): Promise<{
        success: boolean;
    }>;
    rejectFriendRequest(avatarId: string, friendAvatarId: string, userId: string): Promise<{
        success: boolean;
    }>;
    textToSpeech(avatarId: string, userId: string, text: string, headers?: any): Promise<string>;
    private selectVoiceByPersonality;
    startVoiceCall(avatarId: string, friendId: string, userId: string, headers?: any): Promise<{
        greeting: string;
        audioUrl: string;
        friendName: any;
        matchReason: any;
        compatibilityScore: any;
    }>;
    getChatHistory(avatarId: string, friendId: string, userId: string): Promise<{
        messages: {
            id: any;
            role: any;
            content: any;
            created_at: any;
        }[];
        match_reason: any;
        benefits: any;
    }>;
    getAccounts(avatarId: string): Promise<any[]>;
    createAccount(userId: string, accountData: Record<string, any>): Promise<any>;
    updateAccount(accountId: string, accountData: Record<string, any>): Promise<any>;
    deleteAccount(accountId: string): Promise<void>;
    refreshAccount(avatarId: string, accountId: string): Promise<any>;
    recognizeAccountFromImage(file: Express.Multer.File): Promise<any>;
    fetchAccountFromUrl(url: string): Promise<any>;
    private fetchDouyinUserInfo;
    private getRedirectUrl;
    private fetchUrlContent;
    blockAvatar(avatarId: string, blockedAvatarId: string, reason?: string): Promise<any>;
    unblockAvatar(avatarId: string, blockedAvatarId: string): Promise<{
        success: boolean;
    }>;
    getBlockedAvatars(avatarId: string): Promise<any[]>;
    isBlocked(avatarId: string, targetAvatarId: string): Promise<boolean>;
    getAvatarPosts(avatarId: string, page?: number, pageSize?: number): Promise<{
        posts: any[];
        total: number;
    }>;
    getAvatarStats(avatarId: string): Promise<{
        friendsCount: number;
        postsCount: number;
        likesReceived: number;
        commentsReceived: number;
    }>;
    getAvatarTodayStats(avatarId: string): Promise<{
        todayPostsCount: number;
        todayLikesCount: number;
        todayCommentsCount: number;
        todayOrdersCount: number;
    }>;
    isAvatarBlocked(avatarId: string, userId: string): Promise<boolean>;
}
