export declare class AdminModule {
}
