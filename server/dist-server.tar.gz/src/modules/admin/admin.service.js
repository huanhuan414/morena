"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
const DEFAULT_ADMIN = {
    username: 'admin',
    password: 'admin123',
    role: 'super'
};
let AdminService = class AdminService {
    constructor() {
        this.supabase = (0, supabase_client_1.getSupabaseClient)();
        this.admins = new Map();
        this.config = {
            siteName: 'AI分身平台',
            siteDescription: '创建你的专属AI分身',
            maintenanceMode: false,
            registerEnabled: true,
            maxAvatarsPerUser: 5,
            commissionRate: 10
        };
        this.admins.set('1', {
            id: '1',
            username: DEFAULT_ADMIN.username,
            password: DEFAULT_ADMIN.password,
            role: DEFAULT_ADMIN.role,
            created_at: new Date().toISOString()
        });
    }
    generateToken(admin) {
        const data = JSON.stringify({
            id: admin.id || '1',
            username: admin.username,
            role: admin.role,
            exp: Date.now() + 24 * 60 * 60 * 1000
        });
        return Buffer.from(data).toString('base64');
    }
    async verifyToken(token) {
        if (!token)
            return null;
        try {
            const data = JSON.parse(Buffer.from(token, 'base64').toString());
            if (data.exp < Date.now())
                return null;
            return data;
        }
        catch {
            return null;
        }
    }
    async login(username, password) {
        if (username === DEFAULT_ADMIN.username && password === DEFAULT_ADMIN.password) {
            const admin = {
                id: '1',
                username: DEFAULT_ADMIN.username,
                role: DEFAULT_ADMIN.role
            };
            return {
                success: true,
                message: '登录成功',
                data: { token: this.generateToken(admin), admin }
            };
        }
        for (const [id, admin] of this.admins) {
            if (admin.username === username && admin.password === password) {
                return {
                    success: true,
                    message: '登录成功',
                    data: { token: this.generateToken(admin), admin }
                };
            }
        }
        return { success: false, message: '账号或密码错误' };
    }
    async getDashboardStats() {
        try {
            const { count: totalUsers } = await this.supabase
                .from('users')
                .select('*', { count: 'exact', head: true });
            const { count: totalAvatars } = await this.supabase
                .from('avatars')
                .select('*', { count: 'exact', head: true });
            const { count: totalOrders } = await this.supabase
                .from('orders')
                .select('*', { count: 'exact', head: true });
            const { data: earnings } = await this.supabase
                .from('earnings')
                .select('amount')
                .eq('type', 'revenue');
            const totalRevenue = earnings?.reduce((sum, e) => sum + (e.amount || 0), 0) || 0;
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const { count: todayNewUsers } = await this.supabase
                .from('users')
                .select('*', { count: 'exact', head: true })
                .gte('created_at', today.toISOString());
            const { count: todayOrders } = await this.supabase
                .from('orders')
                .select('*', { count: 'exact', head: true })
                .gte('created_at', today.toISOString());
            const { count: pendingOrders } = await this.supabase
                .from('orders')
                .select('*', { count: 'exact', head: true })
                .eq('status', 'pending');
            const { count: pendingContent } = await this.supabase
                .from('posts')
                .select('*', { count: 'exact', head: true })
                .eq('status', 'pending');
            return {
                totalUsers: totalUsers || 0,
                totalAvatars: totalAvatars || 0,
                totalOrders: totalOrders || 0,
                totalRevenue: totalRevenue,
                todayNewUsers: todayNewUsers || 0,
                todayOrders: todayOrders || 0,
                pendingOrders: pendingOrders || 0,
                pendingContent: pendingContent || 0
            };
        }
        catch (error) {
            console.error('获取仪表盘数据失败:', error);
            return {
                totalUsers: 0, totalAvatars: 0, totalOrders: 0, totalRevenue: 0,
                todayNewUsers: 0, todayOrders: 0, pendingOrders: 0, pendingContent: 0
            };
        }
    }
    async getUsers(page, limit, keyword) {
        try {
            let query = this.supabase
                .from('users')
                .select('*', { count: 'exact' })
                .order('created_at', { ascending: false })
                .range((page - 1) * limit, page * limit - 1);
            if (keyword) {
                query = query.or(`phone.ilike.%${keyword}%,nickname.ilike.%${keyword}%`);
            }
            const { data, count, error } = await query;
            if (error)
                throw error;
            const userIds = data?.map(u => u.id) || [];
            const { data: avatarCounts } = await this.supabase
                .from('avatars')
                .select('user_id')
                .in('user_id', userIds);
            const { data: orderCounts } = await this.supabase
                .from('orders')
                .select('user_id')
                .in('user_id', userIds);
            const avatarCountMap = new Map();
            avatarCounts?.forEach(a => {
                avatarCountMap.set(a.user_id, (avatarCountMap.get(a.user_id) || 0) + 1);
            });
            const orderCountMap = new Map();
            orderCounts?.forEach(o => {
                orderCountMap.set(o.user_id, (orderCountMap.get(o.user_id) || 0) + 1);
            });
            const usersWithStats = data?.map(user => ({
                ...user,
                avatar_count: avatarCountMap.get(user.id) || 0,
                order_count: orderCountMap.get(user.id) || 0
            }));
            return { list: usersWithStats || [], total: count || 0, page, limit };
        }
        catch (error) {
            console.error('获取用户列表失败:', error);
            return { list: [], total: 0, page, limit };
        }
    }
    async getUserDetail(userId) {
        try {
            const { data: user, error } = await this.supabase
                .from('users')
                .select('*')
                .eq('id', userId)
                .single();
            if (error || !user)
                return null;
            const { count: avatarCount } = await this.supabase
                .from('avatars')
                .select('*', { count: 'exact', head: true })
                .eq('user_id', userId);
            const { count: orderCount } = await this.supabase
                .from('orders')
                .select('*', { count: 'exact', head: true })
                .eq('user_id', userId);
            const { count: postCount } = await this.supabase
                .from('posts')
                .select('*', { count: 'exact', head: true })
                .eq('user_id', userId);
            const { data: earnings } = await this.supabase
                .from('earnings')
                .select('amount')
                .eq('user_id', userId);
            const { data: transactions } = await this.supabase
                .from('transactions')
                .select('amount')
                .eq('user_id', userId)
                .eq('type', 'expense');
            const totalEarnings = earnings?.reduce((sum, e) => sum + (e.amount || 0), 0) || 0;
            const totalSpent = transactions?.reduce((sum, t) => sum + (t.amount || 0), 0) || 0;
            return {
                ...user,
                avatar_count: avatarCount || 0,
                order_count: orderCount || 0,
                post_count: postCount || 0,
                total_earnings: totalEarnings,
                total_spent: totalSpent
            };
        }
        catch (error) {
            console.error('获取用户详情失败:', error);
            return null;
        }
    }
    async getUserStats(userId) {
        try {
            const months = [];
            for (let i = 5; i >= 0; i--) {
                const date = new Date();
                date.setMonth(date.getMonth() - i);
                months.push({
                    month: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`,
                    start: new Date(date.getFullYear(), date.getMonth(), 1).toISOString(),
                    end: new Date(date.getFullYear(), date.getMonth() + 1, 0).toISOString()
                });
            }
            const monthlyOrders = [];
            const monthlySpending = [];
            for (const m of months) {
                const { count } = await this.supabase
                    .from('orders')
                    .select('*', { count: 'exact', head: true })
                    .eq('user_id', userId)
                    .gte('created_at', m.start)
                    .lte('created_at', m.end);
                const { data: spending } = await this.supabase
                    .from('transactions')
                    .select('amount')
                    .eq('user_id', userId)
                    .eq('type', 'expense')
                    .gte('created_at', m.start)
                    .lte('created_at', m.end);
                monthlyOrders.push({ month: m.month, count: count || 0 });
                monthlySpending.push({
                    month: m.month,
                    amount: spending?.reduce((sum, t) => sum + (t.amount || 0), 0) || 0
                });
            }
            return { monthlyOrders, monthlySpending };
        }
        catch (error) {
            console.error('获取用户统计失败:', error);
            return { monthlyOrders: [], monthlySpending: [] };
        }
    }
    async banUser(userId, action) {
        try {
            const { error } = await this.supabase
                .from('users')
                .update({ status: action === 'ban' ? 'banned' : 'active' })
                .eq('id', userId);
            if (error)
                throw error;
            return {
                success: true,
                message: action === 'ban' ? '用户已禁用' : '用户已解禁'
            };
        }
        catch (error) {
            console.error('操作用户失败:', error);
            return { success: false, message: '操作失败' };
        }
    }
    async getAvatars(page, limit, keyword, status) {
        try {
            let query = this.supabase
                .from('avatars')
                .select('*, users!inner(nickname)', { count: 'exact' })
                .order('created_at', { ascending: false })
                .range((page - 1) * limit, page * limit - 1);
            if (keyword) {
                query = query.or(`name.ilike.%${keyword}%,description.ilike.%${keyword}%`);
            }
            if (status && status !== 'all') {
                query = query.eq('status', status);
            }
            const { data, count, error } = await query;
            if (error)
                throw error;
            const avatarIds = data?.map(a => a.id) || [];
            const { data: orderStats } = await this.supabase
                .from('orders')
                .select('avatar_id')
                .in('avatar_id', avatarIds);
            const orderCountMap = new Map();
            orderStats?.forEach(o => {
                orderCountMap.set(o.avatar_id, (orderCountMap.get(o.avatar_id) || 0) + 1);
            });
            const avatarsWithStats = data?.map(avatar => ({
                ...avatar,
                user_nickname: avatar.users?.nickname,
                order_count: orderCountMap.get(avatar.id) || 0,
                rating: 4.5
            }));
            return { list: avatarsWithStats || [], total: count || 0, page, limit };
        }
        catch (error) {
            console.error('获取分身列表失败:', error);
            return { list: [], total: 0, page, limit };
        }
    }
    async updateAvatarStatus(avatarId, status) {
        try {
            const { error } = await this.supabase
                .from('avatars')
                .update({ status })
                .eq('id', avatarId);
            if (error)
                throw error;
            return { success: true, message: '状态更新成功' };
        }
        catch (error) {
            console.error('更新分身状态失败:', error);
            return { success: false, message: '操作失败' };
        }
    }
    async getOrders(page, limit, keyword, status) {
        try {
            let query = this.supabase
                .from('orders')
                .select('*, users!inner(nickname, phone), avatars!inner(name)', { count: 'exact' })
                .order('created_at', { ascending: false })
                .range((page - 1) * limit, page * limit - 1);
            if (status && status !== 'all') {
                query = query.eq('status', status);
            }
            const { data, count, error } = await query;
            if (error)
                throw error;
            const orders = data?.map(order => ({
                ...order,
                user_nickname: order.users?.nickname,
                user_phone: order.users?.phone,
                avatar_name: order.avatars?.name
            }));
            return { list: orders || [], total: count || 0, page, limit };
        }
        catch (error) {
            console.error('获取订单列表失败:', error);
            return { list: [], total: 0, page, limit };
        }
    }
    async updateOrderStatus(orderId, status) {
        try {
            const { error } = await this.supabase
                .from('orders')
                .update({ status })
                .eq('id', orderId);
            if (error)
                throw error;
            return { success: true, message: '状态更新成功' };
        }
        catch (error) {
            console.error('更新订单状态失败:', error);
            return { success: false, message: '操作失败' };
        }
    }
    async getSkills() {
        try {
            const { data, error } = await this.supabase
                .from('skills')
                .select('*')
                .order('created_at', { ascending: false });
            if (error)
                throw error;
            return { list: data || [], total: data?.length || 0 };
        }
        catch (error) {
            console.error('获取技能列表失败:', error);
            return { list: [], total: 0 };
        }
    }
    async createSkill(data) {
        try {
            const { data: skill, error } = await this.supabase
                .from('skills')
                .insert([{
                    ...data,
                    order_count: 0,
                    rating: 5.0,
                    status: 'active',
                    created_at: new Date().toISOString()
                }])
                .select()
                .single();
            if (error)
                throw error;
            return { success: true, message: '创建成功', data: skill };
        }
        catch (error) {
            console.error('创建技能失败:', error);
            return { success: false, message: '创建失败' };
        }
    }
    async updateSkill(id, data) {
        try {
            const { error } = await this.supabase
                .from('skills')
                .update(data)
                .eq('id', id);
            if (error)
                throw error;
            return { success: true, message: '更新成功' };
        }
        catch (error) {
            console.error('更新技能失败:', error);
            return { success: false, message: '更新失败' };
        }
    }
    async deleteSkill(id) {
        try {
            const { error } = await this.supabase
                .from('skills')
                .delete()
                .eq('id', id);
            if (error)
                throw error;
            return { success: true, message: '删除成功' };
        }
        catch (error) {
            console.error('删除技能失败:', error);
            return { success: false, message: '删除失败' };
        }
    }
    async updateSkillStatus(id, status) {
        try {
            const { error } = await this.supabase
                .from('skills')
                .update({ status })
                .eq('id', id);
            if (error)
                throw error;
            return { success: true, message: '状态更新成功' };
        }
        catch (error) {
            console.error('更新技能状态失败:', error);
            return { success: false, message: '更新失败' };
        }
    }
    async getPosts(status, search) {
        try {
            let query = this.supabase
                .from('posts')
                .select('*, users!inner(nickname, avatar)')
                .order('created_at', { ascending: false });
            if (status && status !== 'all') {
                query = query.eq('status', status);
            }
            const { data, error } = await query;
            if (error)
                throw error;
            let list = data || [];
            if (search) {
                list = list.filter((p) => p.content?.includes(search));
            }
            return {
                list: list.map((p) => ({
                    ...p,
                    nickname: p.users?.nickname,
                    avatar: p.users?.avatar
                })),
                total: list.length
            };
        }
        catch (error) {
            console.error('获取帖子列表失败:', error);
            return { list: [], total: 0 };
        }
    }
    async reviewPost(id, status) {
        try {
            const { error } = await this.supabase
                .from('posts')
                .update({ status })
                .eq('id', id);
            if (error)
                throw error;
            return { success: true, message: '审核成功' };
        }
        catch (error) {
            console.error('审核帖子失败:', error);
            return { success: false, message: '审核失败' };
        }
    }
    async deletePost(id) {
        try {
            const { error } = await this.supabase
                .from('posts')
                .delete()
                .eq('id', id);
            if (error)
                throw error;
            return { success: true, message: '删除成功' };
        }
        catch (error) {
            console.error('删除帖子失败:', error);
            return { success: false, message: '删除失败' };
        }
    }
    async getFinanceStats() {
        try {
            const { data: rechargeData } = await this.supabase
                .from('transactions')
                .select('amount')
                .eq('type', 'recharge')
                .eq('status', 'completed');
            const totalRecharge = rechargeData?.reduce((sum, t) => sum + (t.amount || 0), 0) || 0;
            const { data: withdrawData } = await this.supabase
                .from('transactions')
                .select('amount')
                .eq('type', 'withdraw')
                .eq('status', 'completed');
            const totalWithdraw = withdrawData?.reduce((sum, t) => sum + (t.amount || 0), 0) || 0;
            const { data: commissionData } = await this.supabase
                .from('earnings')
                .select('amount')
                .eq('type', 'commission');
            const totalCommission = commissionData?.reduce((sum, e) => sum + (e.amount || 0), 0) || 0;
            const { data: pendingData } = await this.supabase
                .from('transactions')
                .select('amount')
                .eq('type', 'withdraw')
                .eq('status', 'pending');
            const pendingWithdraw = pendingData?.reduce((sum, t) => sum + (t.amount || 0), 0) || 0;
            return {
                totalRecharge,
                totalWithdraw,
                totalCommission,
                balance: totalRecharge - totalWithdraw,
                pendingWithdraw
            };
        }
        catch (error) {
            console.error('获取财务统计失败:', error);
            return {
                totalRecharge: 0,
                totalWithdraw: 0,
                totalCommission: 0,
                balance: 0,
                pendingWithdraw: 0
            };
        }
    }
    async getTransactions(type) {
        try {
            let query = this.supabase
                .from('transactions')
                .select('*, users!inner(nickname)')
                .order('created_at', { ascending: false });
            if (type && type !== 'all') {
                query = query.eq('type', type);
            }
            const { data, error } = await query;
            if (error)
                throw error;
            return {
                list: data?.map((t) => ({
                    ...t,
                    nickname: t.users?.nickname
                })) || [],
                total: data?.length || 0
            };
        }
        catch (error) {
            console.error('获取交易记录失败:', error);
            return { list: [], total: 0 };
        }
    }
    async approveWithdraw(id) {
        try {
            const { error } = await this.supabase
                .from('transactions')
                .update({ status: 'completed' })
                .eq('id', id);
            if (error)
                throw error;
            return { success: true, message: '已通过' };
        }
        catch (error) {
            console.error('审核提现失败:', error);
            return { success: false, message: '审核失败' };
        }
    }
    async rejectWithdraw(id, reason) {
        try {
            const { error } = await this.supabase
                .from('transactions')
                .update({ status: 'rejected', reject_reason: reason })
                .eq('id', id);
            if (error)
                throw error;
            return { success: true, message: '已驳回' };
        }
        catch (error) {
            console.error('驳回提现失败:', error);
            return { success: false, message: '驳回失败' };
        }
    }
    async getReferralStats() {
        try {
            const { count: totalReferrers } = await this.supabase
                .from('referrals')
                .select('*', { count: 'exact', head: true });
            const { data: referredData } = await this.supabase
                .from('users')
                .select('referred_by')
                .not('referred_by', 'is', null);
            const totalReferred = referredData?.length || 0;
            const { data: commissionData } = await this.supabase
                .from('earnings')
                .select('amount')
                .eq('type', 'commission');
            const totalCommission = commissionData?.reduce((sum, e) => sum + (e.amount || 0), 0) || 0;
            return {
                totalReferrers: totalReferrers || 0,
                totalReferred,
                totalCommission,
                commissionRate: this.config.commissionRate
            };
        }
        catch (error) {
            console.error('获取推广统计失败:', error);
            return {
                totalReferrers: 0,
                totalReferred: 0,
                totalCommission: 0,
                commissionRate: this.config.commissionRate
            };
        }
    }
    async getReferrers() {
        try {
            const { data, error } = await this.supabase
                .from('referrals')
                .select('*, users!inner(nickname, avatar)')
                .order('created_at', { ascending: false });
            if (error)
                throw error;
            return data?.map((r) => ({
                ...r,
                nickname: r.users?.nickname,
                avatar: r.users?.avatar
            })) || [];
        }
        catch (error) {
            console.error('获取推广员列表失败:', error);
            return [];
        }
    }
    async updateCommissionRate(rate) {
        try {
            this.config.commissionRate = rate;
            const { error } = await this.supabase
                .from('settings')
                .upsert({ key: 'commission_rate', value: rate.toString() });
            if (error)
                throw error;
            return { success: true, message: '设置已更新' };
        }
        catch (error) {
            console.error('更新分佣比例失败:', error);
            return { success: false, message: '更新失败' };
        }
    }
    async getAdmins() {
        return Array.from(this.admins.values()).map(a => ({
            id: a.id,
            username: a.username,
            role: a.role,
            last_login: a.last_login,
            created_at: a.created_at
        }));
    }
    async addAdmin(username, password) {
        const id = Date.now().toString();
        this.admins.set(id, {
            id,
            username,
            password,
            role: 'admin',
            created_at: new Date().toISOString()
        });
        return { success: true, message: '添加成功' };
    }
    async deleteAdmin(id) {
        if (id === '1')
            return { success: false, message: '不能删除超级管理员' };
        this.admins.delete(id);
        return { success: true, message: '删除成功' };
    }
    async changePassword(adminId, oldPassword, newPassword) {
        const admin = this.admins.get(adminId);
        if (!admin)
            return { success: false, message: '管理员不存在' };
        if (admin.password !== oldPassword)
            return { success: false, message: '原密码错误' };
        admin.password = newPassword;
        return { success: true, message: '密码修改成功' };
    }
    async getConfig() {
        return this.config;
    }
    async updateConfig(config) {
        this.config = { ...this.config, ...config };
        return { success: true, message: '配置已更新' };
    }
};
exports.AdminService = AdminService;
exports.AdminService = AdminService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], AdminService);
//# sourceMappingURL=admin.service.js.map