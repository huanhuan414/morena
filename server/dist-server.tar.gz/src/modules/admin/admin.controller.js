"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminController = void 0;
const common_1 = require("@nestjs/common");
const admin_service_1 = require("./admin.service");
let AdminController = class AdminController {
    constructor(adminService) {
        this.adminService = adminService;
    }
    async login(username, password) {
        const result = await this.adminService.login(username, password);
        return {
            code: result.success ? 200 : 401,
            data: result.data,
            message: result.message
        };
    }
    async getDashboardStats(token) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const stats = await this.adminService.getDashboardStats();
        return {
            code: 200,
            data: stats,
            message: 'success'
        };
    }
    async getUsers(token, page = 1, limit = 20, keyword) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getUsers(page, limit, keyword);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async getUserDetail(token, userId) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const user = await this.adminService.getUserDetail(userId);
        return {
            code: user ? 200 : 404,
            data: user,
            message: user ? 'success' : '用户不存在'
        };
    }
    async getUserStats(token, userId) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const stats = await this.adminService.getUserStats(userId);
        return {
            code: 200,
            data: stats,
            message: 'success'
        };
    }
    async banUser(token, userId, action) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.banUser(userId, action);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getAvatars(token, page = 1, limit = 20, keyword, status) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getAvatars(page, limit, keyword, status);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async toggleAvatarStatus(token, avatarId, status) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.updateAvatarStatus(avatarId, status);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getOrders(token, page = 1, limit = 20, keyword, status) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getOrders(page, limit, keyword, status);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async updateOrderStatus(token, orderId, status) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.updateOrderStatus(orderId, status);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getSkills(token) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getSkills();
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async createSkill(token, data) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.createSkill(data);
        return {
            code: result.success ? 200 : 400,
            data: result.data,
            message: result.message
        };
    }
    async updateSkill(token, id, data) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.updateSkill(id, data);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async deleteSkill(token, id) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.deleteSkill(id);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async toggleSkillStatus(token, id, status) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.updateSkillStatus(id, status);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getPosts(token, status, search) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getPosts(status, search);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async reviewPost(token, id, status) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.reviewPost(id, status);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async deletePost(token, id) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.deletePost(id);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getFinanceStats(token) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const stats = await this.adminService.getFinanceStats();
        return {
            code: 200,
            data: stats,
            message: 'success'
        };
    }
    async getTransactions(token, type) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getTransactions(type);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async approveWithdraw(token, id) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.approveWithdraw(id);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async rejectWithdraw(token, id, reason) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.rejectWithdraw(id, reason);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getReferralStats(token) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const stats = await this.adminService.getReferralStats();
        return {
            code: 200,
            data: stats,
            message: 'success'
        };
    }
    async getReferrers(token) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getReferrers();
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async updateReferralSettings(token, rate) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.updateCommissionRate(rate);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getAdmins(token) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getAdmins();
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async addAdmin(token, username, password) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.addAdmin(username, password);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async deleteAdmin(token, id) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.deleteAdmin(id);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async changePassword(token, oldPassword, newPassword) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.changePassword(admin.id, oldPassword, newPassword);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getConfig(token) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const config = await this.adminService.getConfig();
        return {
            code: 200,
            data: config,
            message: 'success'
        };
    }
    async updateConfig(token, config) {
        const admin = await this.adminService.verifyToken(token);
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.updateConfig(config);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
};
exports.AdminController = AdminController;
__decorate([
    (0, common_1.Post)('login'),
    __param(0, (0, common_1.Body)('username')),
    __param(1, (0, common_1.Body)('password')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "login", null);
__decorate([
    (0, common_1.Get)('dashboard/stats'),
    __param(0, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getDashboardStats", null);
__decorate([
    (0, common_1.Get)('users'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('limit')),
    __param(3, (0, common_1.Query)('keyword')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, Number, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getUsers", null);
__decorate([
    (0, common_1.Get)('users/:id'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getUserDetail", null);
__decorate([
    (0, common_1.Get)('users/:id/stats'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getUserStats", null);
__decorate([
    (0, common_1.Post)('users/ban'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Body)('user_id')),
    __param(2, (0, common_1.Body)('action')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "banUser", null);
__decorate([
    (0, common_1.Get)('avatars'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('limit')),
    __param(3, (0, common_1.Query)('keyword')),
    __param(4, (0, common_1.Query)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, Number, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getAvatars", null);
__decorate([
    (0, common_1.Post)('avatars/toggle-status'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Body)('avatar_id')),
    __param(2, (0, common_1.Body)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "toggleAvatarStatus", null);
__decorate([
    (0, common_1.Get)('orders'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('limit')),
    __param(3, (0, common_1.Query)('keyword')),
    __param(4, (0, common_1.Query)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, Number, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getOrders", null);
__decorate([
    (0, common_1.Post)('orders/update-status'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Body)('order_id')),
    __param(2, (0, common_1.Body)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "updateOrderStatus", null);
__decorate([
    (0, common_1.Get)('skills'),
    __param(0, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getSkills", null);
__decorate([
    (0, common_1.Post)('skills'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "createSkill", null);
__decorate([
    (0, common_1.Put)('skills/:id'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "updateSkill", null);
__decorate([
    (0, common_1.Delete)('skills/:id'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "deleteSkill", null);
__decorate([
    (0, common_1.Put)('skills/:id/status'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "toggleSkillStatus", null);
__decorate([
    (0, common_1.Get)('posts'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Query)('status')),
    __param(2, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getPosts", null);
__decorate([
    (0, common_1.Put)('posts/:id/review'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "reviewPost", null);
__decorate([
    (0, common_1.Delete)('posts/:id'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "deletePost", null);
__decorate([
    (0, common_1.Get)('finance/stats'),
    __param(0, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getFinanceStats", null);
__decorate([
    (0, common_1.Get)('finance/transactions'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Query)('type')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getTransactions", null);
__decorate([
    (0, common_1.Post)('finance/withdraw/:id/approve'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "approveWithdraw", null);
__decorate([
    (0, common_1.Post)('finance/withdraw/:id/reject'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)('reason')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "rejectWithdraw", null);
__decorate([
    (0, common_1.Get)('referral/stats'),
    __param(0, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getReferralStats", null);
__decorate([
    (0, common_1.Get)('referral/list'),
    __param(0, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getReferrers", null);
__decorate([
    (0, common_1.Put)('referral/settings'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Body)('commissionRate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "updateReferralSettings", null);
__decorate([
    (0, common_1.Get)('settings/admins'),
    __param(0, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getAdmins", null);
__decorate([
    (0, common_1.Post)('settings/admins'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Body)('username')),
    __param(2, (0, common_1.Body)('password')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "addAdmin", null);
__decorate([
    (0, common_1.Delete)('settings/admins/:id'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "deleteAdmin", null);
__decorate([
    (0, common_1.Put)('settings/password'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Body)('oldPassword')),
    __param(2, (0, common_1.Body)('newPassword')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "changePassword", null);
__decorate([
    (0, common_1.Get)('settings/config'),
    __param(0, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getConfig", null);
__decorate([
    (0, common_1.Put)('settings/config'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "updateConfig", null);
exports.AdminController = AdminController = __decorate([
    (0, common_1.Controller)('admin'),
    __metadata("design:paramtypes", [admin_service_1.AdminService])
], AdminController);
//# sourceMappingURL=admin.controller.js.map