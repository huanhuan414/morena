interface SystemConfig {
    siteName: string;
    siteDescription: string;
    maintenanceMode: boolean;
    registerEnabled: boolean;
    maxAvatarsPerUser: number;
    commissionRate: number;
}
export declare class AdminService {
    private supabase;
    private admins;
    private config;
    constructor();
    private generateToken;
    verifyToken(token: string): Promise<any>;
    login(username: string, password: string): Promise<{
        success: boolean;
        message: string;
        data?: any;
    }>;
    getDashboardStats(): Promise<any>;
    getUsers(page: number, limit: number, keyword?: string): Promise<any>;
    getUserDetail(userId: string): Promise<any>;
    getUserStats(userId: string): Promise<any>;
    banUser(userId: string, action: 'ban' | 'unban'): Promise<{
        success: boolean;
        message: string;
    }>;
    getAvatars(page: number, limit: number, keyword?: string, status?: string): Promise<any>;
    updateAvatarStatus(avatarId: string, status: string): Promise<{
        success: boolean;
        message: string;
    }>;
    getOrders(page: number, limit: number, keyword?: string, status?: string): Promise<any>;
    updateOrderStatus(orderId: string, status: string): Promise<{
        success: boolean;
        message: string;
    }>;
    getSkills(): Promise<any>;
    createSkill(data: any): Promise<{
        success: boolean;
        message: string;
        data?: any;
    }>;
    updateSkill(id: string, data: any): Promise<{
        success: boolean;
        message: string;
    }>;
    deleteSkill(id: string): Promise<{
        success: boolean;
        message: string;
    }>;
    updateSkillStatus(id: string, status: string): Promise<{
        success: boolean;
        message: string;
    }>;
    getPosts(status?: string, search?: string): Promise<any>;
    reviewPost(id: string, status: string): Promise<{
        success: boolean;
        message: string;
    }>;
    deletePost(id: string): Promise<{
        success: boolean;
        message: string;
    }>;
    getFinanceStats(): Promise<any>;
    getTransactions(type?: string): Promise<any>;
    approveWithdraw(id: string): Promise<{
        success: boolean;
        message: string;
    }>;
    rejectWithdraw(id: string, reason: string): Promise<{
        success: boolean;
        message: string;
    }>;
    getReferralStats(): Promise<any>;
    getReferrers(): Promise<any[]>;
    updateCommissionRate(rate: number): Promise<{
        success: boolean;
        message: string;
    }>;
    getAdmins(): Promise<any[]>;
    addAdmin(username: string, password: string): Promise<{
        success: boolean;
        message: string;
    }>;
    deleteAdmin(id: string): Promise<{
        success: boolean;
        message: string;
    }>;
    changePassword(adminId: string, oldPassword: string, newPassword: string): Promise<{
        success: boolean;
        message: string;
    }>;
    getConfig(): Promise<SystemConfig>;
    updateConfig(config: Partial<SystemConfig>): Promise<{
        success: boolean;
        message: string;
    }>;
}
export {};
