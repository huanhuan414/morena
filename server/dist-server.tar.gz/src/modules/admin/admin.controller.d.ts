import { AdminService } from './admin.service';
export declare class AdminController {
    private readonly adminService;
    constructor(adminService: AdminService);
    login(username: string, password: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getDashboardStats(token: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getUsers(token: string, page?: number, limit?: number, keyword?: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getUserDetail(token: string, userId: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getUserStats(token: string, userId: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    banUser(token: string, userId: string, action: 'ban' | 'unban'): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    getAvatars(token: string, page?: number, limit?: number, keyword?: string, status?: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    toggleAvatarStatus(token: string, avatarId: string, status: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    getOrders(token: string, page?: number, limit?: number, keyword?: string, status?: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    updateOrderStatus(token: string, orderId: string, status: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    getSkills(token: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    createSkill(token: string, data: any): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    updateSkill(token: string, id: string, data: any): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    deleteSkill(token: string, id: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    toggleSkillStatus(token: string, id: string, status: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    getPosts(token: string, status?: string, search?: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    reviewPost(token: string, id: string, status: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    deletePost(token: string, id: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    getFinanceStats(token: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getTransactions(token: string, type?: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    approveWithdraw(token: string, id: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    rejectWithdraw(token: string, id: string, reason: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    getReferralStats(token: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getReferrers(token: string): Promise<{
        code: number;
        data: null;
        message: string;
    } | {
        code: number;
        data: any[];
        message: string;
    }>;
    updateReferralSettings(token: string, rate: number): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    getAdmins(token: string): Promise<{
        code: number;
        data: null;
        message: string;
    } | {
        code: number;
        data: any[];
        message: string;
    }>;
    addAdmin(token: string, username: string, password: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    deleteAdmin(token: string, id: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    changePassword(token: string, oldPassword: string, newPassword: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    getConfig(token: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    updateConfig(token: string, config: any): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
}
