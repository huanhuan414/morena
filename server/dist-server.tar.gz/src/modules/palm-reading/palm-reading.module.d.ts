export declare class PalmReadingModule {
}
