import { PalmReadingService } from './palm-reading.service';
export declare class PalmReadingController {
    private readonly palmReadingService;
    constructor(palmReadingService: PalmReadingService);
    create(userId: string, body: {
        imageUrl: string;
        avatarId?: string;
    }): Promise<{
        code: number;
        message: string;
        data: import("./palm-reading.service").PalmReadingRecord;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
    getProgress(id: string): Promise<{
        code: number;
        message: string;
        data: import("./palm-reading.service").PalmReadingRecord;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
    getHistory(userId: string, avatarId?: string, page?: string, limit?: string): Promise<{
        code: number;
        message: string;
        data: {
            records: import("./palm-reading.service").PalmReadingRecord[];
            total: number;
        };
    } | {
        code: number;
        message: any;
        data: null;
    }>;
    deleteRecord(userId: string, id: string): Promise<{
        code: number;
        message: any;
        data: null;
    }>;
    clearHistory(userId: string, avatarId?: string): Promise<{
        code: number;
        message: any;
        data: null;
    }>;
}
