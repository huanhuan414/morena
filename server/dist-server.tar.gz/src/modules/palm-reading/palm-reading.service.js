"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PalmReadingService = void 0;
const common_1 = require("@nestjs/common");
const storage_service_1 = require("../storage/storage.service");
const supabase_client_1 = require("../../storage/database/supabase-client");
const https = require("https");
const FormData = require("form-data");
const sharp = require("sharp");
let PalmReadingService = class PalmReadingService {
    constructor(storageService) {
        this.storageService = storageService;
        this.imageApiUrl = 'https://api.aaigc.top/v1/images/edits';
        this.imageApiKey = 'sk-z1CFQbVdKI6x7ciJLwQkp1vPJPp8P9lQWW0jJGQWUdkSuQsK';
    }
    get supabase() {
        return (0, supabase_client_1.getSupabaseClient)();
    }
    async createTask(imageUrl, avatarId, userId) {
        const { data, error } = await this.supabase
            .from('palm_reading_records')
            .insert({
            avatar_id: avatarId || null,
            palm_image_url: imageUrl,
            status: 'pending',
            progress: '任务已创建',
            user_id: userId || null,
        })
            .select()
            .single();
        if (error || !data) {
            throw new Error(`创建记录失败: ${error?.message || '未知错误'}`);
        }
        const record = data;
        this.executeTask(record.id, imageUrl).catch((err) => {
            console.error('[PalmReadingService] 异步任务执行失败:', err.message);
        });
        return record;
    }
    async executeTask(taskId, imageUrl) {
        try {
            await this.updateTask(taskId, { status: 'processing', progress: '正在下载手掌图片...' });
            const imageBuffer = await this.downloadAndCompressImage(imageUrl);
            await this.updateTask(taskId, { progress: '图片已就绪，正在生成掌相阅读指南...' });
            const prompt = `Create a comprehensive Chinese palm reading guide poster based on my palm photo.

LAYOUT (vertical poster, white/light background, minimalist high-end style, fine lines, rounded cards):

TOP SECTION:
- Title "掌相阅读指南" centered, subtitle "了解天赋·把握机遇·成就更好的自己"
- My ORIGINAL palm photo displayed as-is (do NOT redraw or modify my hand)
- Next to the photo, annotate the main palm lines with labels: 生命线(Life line), 感情线(Heart line), 智慧线(Head line), 命运线(Fate line), 太阳线(Sun line)

IMPORTANT - PALM LINE DIAGRAM SECTION (must include):
- Create a clean black-and-white outline drawing of MY palm (based on my actual palm shape and line positions)
- Draw the main palm lines as distinct colored strokes on the outline: 生命线 in RED, 感情线 in BLUE, 智慧线 in GREEN, 命运线 in ORANGE, 太阳线 in PURPLE
- Label each line with its Chinese name and a brief 1-line description
- This diagram should look like an artistic minimalist illustration, NOT a photo

MIDDLE SECTION:
- Left card: 掌型与手指分析 (hand shape features, thumb/index/middle/ring/little finger meanings)
- Right card: 主要掌纹解读 (detailed meaning of each palm line with small icons)

BOTTOM SECTION:
- Left: 整体掌相总结 (3 core personality traits and talents)
- Center: 人生建议 (4 concise life advice points)
- Right: 发展方向与运势评分 (career/wealth/love/health/benefactor fortune scores as progress bars or numbers)
- Bottom line: "命运在你手中，选择与努力让未来更美好"

STYLE: All text in Chinese. Fine lines, rounded cards, minimalist black-white palette with accent colors. Professional and elegant like a premium design piece.`;
            const formData = new FormData();
            formData.append('model', 'gpt-image-2-all');
            formData.append('prompt', prompt);
            formData.append('image', imageBuffer, {
                filename: 'palm.jpg',
                contentType: 'image/jpeg',
            });
            formData.append('n', '1');
            formData.append('size', '1024x1024');
            await this.updateTask(taskId, { progress: 'AI 正在绘制掌相指南（约1-5分钟）...' });
            const response = await this.sendImageEditRequest(formData);
            if (response.data && response.data.length > 0) {
                const imageData = response.data[0];
                let tosUrl;
                if (imageData.b64_json) {
                    await this.updateTask(taskId, { progress: '正在保存生成的图片...' });
                    const timestamp = Date.now();
                    const filename = `palm-reading-${timestamp}.png`;
                    tosUrl = await this.storageService.uploadBase64Image(`data:image/png;base64,${imageData.b64_json}`, filename);
                }
                else if (imageData.url) {
                    await this.updateTask(taskId, { progress: '正在保存生成的图片...' });
                    const timestamp = Date.now();
                    const filename = `palm-reading-${timestamp}.png`;
                    const base64 = await this.downloadImageAsBase64(imageData.url);
                    tosUrl = await this.storageService.uploadBase64Image(`data:image/png;base64,${base64}`, filename);
                }
                else {
                    throw new Error('生成失败，无图片数据返回');
                }
                await this.updateTask(taskId, {
                    status: 'completed',
                    progress: '生成完成',
                    generated_image_url: tosUrl,
                });
                console.log('[PalmReadingService] 任务完成:', taskId, '图片:', tosUrl);
            }
            else {
                throw new Error('生成失败，响应格式错误');
            }
        }
        catch (error) {
            console.error('[PalmReadingService] 任务执行失败:', taskId, error.message);
            await this.updateTask(taskId, {
                status: 'failed',
                progress: '生成失败',
                error_message: error.message || '未知错误',
            });
        }
    }
    async updateTask(taskId, updates) {
        const { error } = await this.supabase
            .from('palm_reading_records')
            .update({ ...updates, updated_at: new Date().toISOString() })
            .eq('id', taskId);
        if (error) {
            console.error('[PalmReadingService] 更新任务失败:', error.message);
        }
    }
    async getProgress(taskId) {
        const { data, error } = await this.supabase
            .from('palm_reading_records')
            .select('*')
            .eq('id', taskId)
            .single();
        if (error || !data) {
            throw new Error(`查询任务失败: ${error?.message || '任务不存在'}`);
        }
        return data;
    }
    async getHistory(userId, avatarId, page = 1, limit = 10) {
        const offset = (page - 1) * limit;
        let countQuery = this.supabase.from('palm_reading_records').select('*', { count: 'exact', head: true });
        if (userId) {
            countQuery = countQuery.eq('user_id', userId);
        }
        else if (avatarId) {
            countQuery = countQuery.eq('avatar_id', avatarId);
        }
        const { count } = await countQuery;
        let dataQuery = this.supabase
            .from('palm_reading_records')
            .select('*')
            .order('created_at', { ascending: false })
            .range(offset, offset + limit - 1);
        if (userId) {
            dataQuery = dataQuery.eq('user_id', userId);
        }
        else if (avatarId) {
            dataQuery = dataQuery.eq('avatar_id', avatarId);
        }
        const { data, error } = await dataQuery;
        if (error) {
            throw new Error(`查询历史失败: ${error.message}`);
        }
        return { records: (data || []), total: count || 0 };
    }
    async deleteRecord(id, userId) {
        if (userId) {
            const { data } = await this.supabase
                .from('palm_reading_records')
                .select('user_id')
                .eq('id', id)
                .single();
            if (data && data.user_id && data.user_id !== userId) {
                throw new Error('无权删除此记录');
            }
        }
        const { error } = await this.supabase.from('palm_reading_records').delete().eq('id', id);
        if (error) {
            throw new Error(`删除记录失败: ${error.message}`);
        }
    }
    async clearHistory(userId, avatarId) {
        let query = this.supabase.from('palm_reading_records').delete();
        if (userId) {
            query = query.eq('user_id', userId);
        }
        else if (avatarId) {
            query = query.eq('avatar_id', avatarId);
        }
        const { error } = await query;
        if (error) {
            throw new Error(`清空历史失败: ${error.message}`);
        }
    }
    async downloadAndCompressImage(imageUrl) {
        console.log('[PalmReadingService] 下载并压缩图片...', imageUrl);
        return new Promise((resolve, reject) => {
            https.get(imageUrl, (res) => {
                if (res.statusCode !== 200) {
                    reject(new Error(`下载图片失败: HTTP ${res.statusCode}`));
                    return;
                }
                const chunks = [];
                res.on('data', (chunk) => chunks.push(chunk));
                res.on('end', async () => {
                    try {
                        const originalBuffer = Buffer.concat(chunks);
                        console.log('[PalmReadingService] 原始图片大小:', originalBuffer.length, 'bytes');
                        let compressedBuffer;
                        try {
                            compressedBuffer = await sharp(originalBuffer)
                                .resize(1024, 1024, { fit: 'inside', withoutEnlargement: true })
                                .jpeg({ quality: 85 })
                                .toBuffer();
                            console.log('[PalmReadingService] 压缩后大小:', compressedBuffer.length, 'bytes');
                        }
                        catch (e) {
                            console.log('[PalmReadingService] sharp压缩失败，使用原图:', e.message);
                            compressedBuffer = originalBuffer;
                        }
                        resolve(compressedBuffer);
                    }
                    catch (e) {
                        reject(e);
                    }
                });
                res.on('error', reject);
            }).on('error', reject);
        });
    }
    async sendImageEditRequest(formData) {
        return new Promise((resolve, reject) => {
            const formHeaders = formData.getHeaders();
            const options = {
                hostname: 'api.aaigc.top',
                path: '/v1/images/edits',
                method: 'POST',
                headers: {
                    ...formHeaders,
                    Authorization: `Bearer ${this.imageApiKey}`,
                },
                timeout: 600000,
            };
            console.log('[PalmReadingService] 发送请求到 /v1/images/edits ...');
            const req = https.request(options, (res) => {
                const chunks = [];
                res.on('data', (chunk) => chunks.push(chunk));
                res.on('end', () => {
                    try {
                        const body = Buffer.concat(chunks).toString('utf8');
                        console.log('[PalmReadingService] API响应状态:', res.statusCode);
                        if (res.statusCode !== 200) {
                            console.error('[PalmReadingService] API错误响应:', body.substring(0, 500));
                            reject(new Error(`API返回错误: HTTP ${res.statusCode} - ${body.substring(0, 200)}`));
                            return;
                        }
                        const data = JSON.parse(body);
                        resolve(data);
                    }
                    catch (e) {
                        reject(new Error(`解析API响应失败: ${e.message}`));
                    }
                });
                res.on('error', reject);
            });
            req.on('timeout', () => {
                console.error('[PalmReadingService] 请求超时(10分钟)');
                req.destroy();
                reject(new Error('图片编辑请求超时，请稍后重试'));
            });
            req.on('error', (e) => {
                console.error('[PalmReadingService] 请求错误:', e.message);
                reject(new Error(`网络请求失败: ${e.message}`));
            });
            formData.pipe(req);
        });
    }
    downloadImageAsBase64(url) {
        return new Promise((resolve, reject) => {
            https.get(url, (res) => {
                if (res.statusCode !== 200) {
                    reject(new Error(`下载图片失败: HTTP ${res.statusCode}`));
                    return;
                }
                const chunks = [];
                res.on('data', (chunk) => chunks.push(chunk));
                res.on('end', () => {
                    const buffer = Buffer.concat(chunks);
                    resolve(buffer.toString('base64'));
                });
                res.on('error', reject);
            }).on('error', reject);
        });
    }
};
exports.PalmReadingService = PalmReadingService;
exports.PalmReadingService = PalmReadingService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [storage_service_1.StorageService])
], PalmReadingService);
//# sourceMappingURL=palm-reading.service.js.map