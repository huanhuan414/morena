import { StorageService } from '../storage/storage.service';
export interface PalmReadingRecord {
    id: string;
    avatar_id: string | null;
    palm_image_url: string;
    generated_image_url: string | null;
    status: 'pending' | 'processing' | 'completed' | 'failed';
    progress: string;
    error_message: string | null;
    created_at: string;
    updated_at: string;
}
export declare class PalmReadingService {
    private storageService;
    private readonly imageApiUrl;
    private readonly imageApiKey;
    constructor(storageService: StorageService);
    private get supabase();
    createTask(imageUrl: string, avatarId?: string, userId?: string): Promise<PalmReadingRecord>;
    private executeTask;
    private updateTask;
    getProgress(taskId: string): Promise<PalmReadingRecord>;
    getHistory(userId?: string, avatarId?: string, page?: number, limit?: number): Promise<{
        records: PalmReadingRecord[];
        total: number;
    }>;
    deleteRecord(id: string, userId?: string): Promise<void>;
    clearHistory(userId?: string, avatarId?: string): Promise<void>;
    private downloadAndCompressImage;
    private sendImageEditRequest;
    private downloadImageAsBase64;
}
