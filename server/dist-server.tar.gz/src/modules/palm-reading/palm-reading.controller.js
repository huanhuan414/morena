"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PalmReadingController = void 0;
const common_1 = require("@nestjs/common");
const palm_reading_service_1 = require("./palm-reading.service");
let PalmReadingController = class PalmReadingController {
    constructor(palmReadingService) {
        this.palmReadingService = palmReadingService;
    }
    async create(userId, body) {
        const { imageUrl, avatarId } = body;
        if (!imageUrl) {
            return { code: 400, message: '请提供图片URL', data: null };
        }
        try {
            const record = await this.palmReadingService.createTask(imageUrl, avatarId, userId);
            return { code: 200, message: '任务创建成功', data: record };
        }
        catch (error) {
            return { code: 500, message: error.message || '创建任务失败', data: null };
        }
    }
    async getProgress(id) {
        try {
            const record = await this.palmReadingService.getProgress(id);
            return { code: 200, message: '查询成功', data: record };
        }
        catch (error) {
            return { code: 500, message: error.message || '查询失败', data: null };
        }
    }
    async getHistory(userId, avatarId, page, limit) {
        try {
            const pageNum = page ? parseInt(page, 10) : 1;
            const limitNum = limit ? parseInt(limit, 10) : 10;
            const result = await this.palmReadingService.getHistory(userId, avatarId, pageNum, limitNum);
            return { code: 200, message: '查询成功', data: result };
        }
        catch (error) {
            return { code: 500, message: error.message || '查询失败', data: null };
        }
    }
    async deleteRecord(userId, id) {
        try {
            await this.palmReadingService.deleteRecord(id, userId);
            return { code: 200, message: '删除成功', data: null };
        }
        catch (error) {
            return { code: 500, message: error.message || '删除失败', data: null };
        }
    }
    async clearHistory(userId, avatarId) {
        try {
            await this.palmReadingService.clearHistory(userId, avatarId);
            return { code: 200, message: '清空成功', data: null };
        }
        catch (error) {
            return { code: 500, message: error.message || '清空失败', data: null };
        }
    }
};
exports.PalmReadingController = PalmReadingController;
__decorate([
    (0, common_1.Post)('create'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], PalmReadingController.prototype, "create", null);
__decorate([
    (0, common_1.Get)('progress/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PalmReadingController.prototype, "getProgress", null);
__decorate([
    (0, common_1.Get)('history'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('avatarId')),
    __param(2, (0, common_1.Query)('page')),
    __param(3, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], PalmReadingController.prototype, "getHistory", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], PalmReadingController.prototype, "deleteRecord", null);
__decorate([
    (0, common_1.Delete)(),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], PalmReadingController.prototype, "clearHistory", null);
exports.PalmReadingController = PalmReadingController = __decorate([
    (0, common_1.Controller)('palm-reading'),
    __metadata("design:paramtypes", [palm_reading_service_1.PalmReadingService])
], PalmReadingController);
//# sourceMappingURL=palm-reading.controller.js.map