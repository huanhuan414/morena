import { SmsService, SendSmsParams } from './sms.service';
export declare class SmsController {
    private readonly smsService;
    constructor(smsService: SmsService);
    sendSms(params: SendSmsParams): Promise<{
        code: number;
        msg: string;
        data: {
            success: boolean;
        };
    }>;
    notifyDispatch(body: {
        phone: string;
        avatarName: string;
        orderId: string;
    }): Promise<{
        code: number;
        msg: string;
        data: {
            success: boolean;
        };
    }>;
    notifyCompletion(body: {
        phone: string;
        orderId: string;
    }): Promise<{
        code: number;
        msg: string;
        data: {
            success: boolean;
        };
    }>;
    getTemplates(): Promise<{
        code: number;
        msg: string;
        data: import("./sms.service").SmsTemplate[];
    }>;
}
