export interface SendSmsParams {
    phone: string;
    templateCode: string;
    params: Record<string, string>;
}
export interface SmsTemplate {
    code: string;
    name: string;
    content: string;
}
export declare class SmsService {
    private accessKeyId;
    private accessKeySecret;
    private signName;
    sendSms(phone: string, templateCode: string, params: Record<string, string>): Promise<boolean>;
    private percentEncode;
    sendVerificationCode(phone: string, code: string): Promise<boolean>;
    generateCode(): string;
    sendOrderDispatchNotification(phone: string, avatarName: string, orderId: string): Promise<boolean>;
    sendOrderCompletionNotification(phone: string, orderId: string): Promise<boolean>;
    sendContentGeneratedNotification(phone: string, avatarName: string, orderId: string): Promise<boolean>;
    getTemplates(): SmsTemplate[];
}
