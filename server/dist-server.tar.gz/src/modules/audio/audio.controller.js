"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AudioController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const audio_service_1 = require("./audio.service");
let AudioController = class AudioController {
    constructor(audioService) {
        this.audioService = audioService;
    }
    async recognizeSpeech(file) {
        console.log('[AudioController] 收到语音识别请求');
        console.log('[AudioController] 文件信息:', {
            fieldname: file?.fieldname,
            originalname: file?.originalname,
            size: file?.size,
            mimetype: file?.mimetype,
            hasPath: !!file?.path,
            hasBuffer: !!file?.buffer,
        });
        if (!file) {
            throw new common_1.BadRequestException('未上传音频文件');
        }
        try {
            const result = await this.audioService.recognizeSpeech(file);
            console.log('[AudioController] 识别结果:', result);
            return {
                code: 200,
                msg: '识别成功',
                data: result,
            };
        }
        catch (error) {
            console.error('[AudioController] 识别失败:', error);
            throw new common_1.BadRequestException('语音识别失败: ' + error.message);
        }
    }
};
exports.AudioController = AudioController;
__decorate([
    (0, common_1.Post)('asr'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('audio')),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AudioController.prototype, "recognizeSpeech", null);
exports.AudioController = AudioController = __decorate([
    (0, common_1.Controller)('audio'),
    __metadata("design:paramtypes", [audio_service_1.AudioService])
], AudioController);
//# sourceMappingURL=audio.controller.js.map