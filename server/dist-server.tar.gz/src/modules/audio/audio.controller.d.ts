import { AudioService } from './audio.service';
export declare class AudioController {
    private readonly audioService;
    constructor(audioService: AudioService);
    recognizeSpeech(file: Express.Multer.File): Promise<{
        code: number;
        msg: string;
        data: {
            text: string;
            duration?: number;
        };
    }>;
}
