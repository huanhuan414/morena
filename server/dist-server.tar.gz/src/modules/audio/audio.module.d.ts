export declare class AudioModule {
}
