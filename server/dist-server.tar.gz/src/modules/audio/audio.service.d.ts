export declare class AudioService {
    private asrClient;
    private config;
    constructor();
    recognizeSpeech(file: Express.Multer.File): Promise<{
        text: string;
        duration?: number;
    }>;
    recognizeFromUrl(url: string): Promise<{
        text: string;
        duration?: number;
    }>;
}
