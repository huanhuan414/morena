export declare class SkillTrainingModule {
}
