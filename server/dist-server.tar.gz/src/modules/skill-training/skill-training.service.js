"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SkillTrainingService = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
let SkillTrainingService = class SkillTrainingService {
    constructor() {
        const config = new coze_coding_dev_sdk_1.Config();
        this.llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
    }
    async generateSkill(experience, tips) {
        const systemPrompt = `你是一个专业的技能生成助手。根据用户提供的经验和技巧，生成一个独特的技能。

要求：
1. 技能名称：简洁有力，2-6个字，能体现技能特点
2. 技能描述：详细描述这个技能的功能和使用场景，50-100字
3. 技能分类：选择合适的分类，如"创作"、"分析"、"运营"、"营销"、"技术"等

请以JSON格式返回，格式如下：
{
  "name": "技能名称",
  "description": "技能描述",
  "category": "技能分类"
}`;
        const userPrompt = `我的经验：${experience}${tips ? `\n\n我的技巧心得：${tips}` : ''}

请根据以上内容生成一个独特的技能。`;
        const messages = [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt }
        ];
        try {
            const response = await this.llmClient.invoke(messages, {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.8,
                thinking: 'enabled'
            });
            const content = response.content;
            const jsonMatch = content.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                const parsed = JSON.parse(jsonMatch[0]);
                return {
                    name: parsed.name || '自定义技能',
                    description: parsed.description || '基于个人经验生成的独特技能',
                    category: parsed.category || '其他'
                };
            }
            return {
                name: '自定义技能',
                description: `基于${experience.slice(0, 20)}...等经验生成的独特技能`,
                category: '其他'
            };
        }
        catch (error) {
            console.error('生成技能失败:', error);
            return {
                name: '自定义技能',
                description: `基于个人经验生成的独特技能：${experience.slice(0, 30)}...`,
                category: '其他'
            };
        }
    }
    async saveSkill(skill) {
        return {
            id: `skill_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
        };
    }
};
exports.SkillTrainingService = SkillTrainingService;
exports.SkillTrainingService = SkillTrainingService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], SkillTrainingService);
//# sourceMappingURL=skill-training.service.js.map