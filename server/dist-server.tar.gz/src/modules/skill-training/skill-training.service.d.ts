export interface GeneratedSkill {
    name: string;
    description: string;
    category: string;
}
interface SaveSkillDto {
    name: string;
    description: string;
    category: string;
}
export declare class SkillTrainingService {
    private llmClient;
    constructor();
    generateSkill(experience: string, tips?: string): Promise<GeneratedSkill>;
    saveSkill(skill: SaveSkillDto): Promise<{
        id: string;
    }>;
}
export {};
