import { SkillTrainingService, GeneratedSkill } from './skill-training.service';
interface GenerateSkillDto {
    experience: string;
    tips?: string;
}
interface SaveSkillDto {
    name: string;
    description: string;
    category: string;
}
export declare class SkillTrainingController {
    private readonly skillTrainingService;
    constructor(skillTrainingService: SkillTrainingService);
    generateSkill(dto: GenerateSkillDto): Promise<{
        code: number;
        msg: string;
        data: GeneratedSkill;
    }>;
    saveSkill(dto: SaveSkillDto): Promise<{
        code: number;
        msg: string;
        data: {
            id: string;
        };
    }>;
}
export {};
