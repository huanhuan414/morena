"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderDispatchModule = void 0;
const common_1 = require("@nestjs/common");
const order_dispatch_controller_1 = require("./order-dispatch.controller");
const order_dispatch_service_1 = require("./order-dispatch.service");
const notification_module_1 = require("../notification/notification.module");
const subscription_module_1 = require("../subscription/subscription.module");
const sms_module_1 = require("../sms/sms.module");
const content_generation_module_1 = require("../content-generation/content-generation.module");
const order_processing_module_1 = require("../order-processing/order-processing.module");
let OrderDispatchModule = class OrderDispatchModule {
};
exports.OrderDispatchModule = OrderDispatchModule;
exports.OrderDispatchModule = OrderDispatchModule = __decorate([
    (0, common_1.Module)({
        imports: [
            (0, common_1.forwardRef)(() => notification_module_1.NotificationModule),
            (0, common_1.forwardRef)(() => subscription_module_1.SubscriptionModule),
            sms_module_1.SmsModule,
            content_generation_module_1.ContentGenerationModule,
            order_processing_module_1.OrderProcessingModule
        ],
        controllers: [order_dispatch_controller_1.OrderDispatchController],
        providers: [order_dispatch_service_1.OrderDispatchService],
        exports: [order_dispatch_service_1.OrderDispatchService]
    })
], OrderDispatchModule);
//# sourceMappingURL=order-dispatch.module.js.map