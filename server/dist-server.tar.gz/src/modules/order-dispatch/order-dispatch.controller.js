"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderDispatchController = void 0;
const common_1 = require("@nestjs/common");
const order_dispatch_service_1 = require("./order-dispatch.service");
let OrderDispatchController = class OrderDispatchController {
    constructor(dispatchService) {
        this.dispatchService = dispatchService;
    }
    async dispatchOrder(orderId) {
        const result = await this.dispatchService.dispatchOrder(orderId);
        return {
            code: 200,
            data: result,
            message: result ? '订单分配成功' : '暂无符合条件的分身'
        };
    }
    async getProgress(orderId) {
        const progress = await this.dispatchService.getExecutionProgress(orderId);
        return {
            code: 200,
            data: progress,
            message: '获取成功'
        };
    }
    async getDispatchStatus(orderId) {
        const status = await this.dispatchService.getDispatchStatus(orderId);
        return {
            code: 200,
            data: status,
            message: '获取成功'
        };
    }
    async getRecommendedAvatars(orderId, limit) {
        const avatars = await this.dispatchService.getRecommendedAvatars(orderId, limit ? parseInt(limit) : 0);
        return {
            code: 200,
            data: avatars,
            message: '获取成功'
        };
    }
    async getRequest(requestId) {
        const result = await this.dispatchService.getRequestById(requestId);
        return {
            code: 200,
            data: result,
            message: '获取成功'
        };
    }
    async dispatchToAvatar(orderId, avatarId) {
        const result = await this.dispatchService.dispatchToAvatar(orderId, avatarId);
        return {
            code: 200,
            data: result,
            message: '分配成功，已发送通知'
        };
    }
    async getPendingRequests(userId) {
        const requests = await this.dispatchService.getUserPendingRequests(userId);
        return {
            code: 200,
            data: requests,
            message: '获取成功'
        };
    }
    async confirmDispatch(requestId, userId, avatarId) {
        const result = await this.dispatchService.confirmDispatch(requestId, avatarId);
        return {
            code: 200,
            data: result,
            message: '确认成功'
        };
    }
    async rejectDispatch(requestId, userId, avatarId) {
        const result = await this.dispatchService.rejectDispatch(requestId, avatarId);
        return {
            code: 200,
            data: result,
            message: '已拒绝'
        };
    }
    async cancelDispatch(orderId, userId) {
        const result = await this.dispatchService.cancelDispatch(orderId, userId);
        return {
            code: 200,
            data: result,
            message: '已取消分配'
        };
    }
    async getAvatarAcceptedOrders(avatarId) {
        const orders = await this.dispatchService.getAvatarAcceptedOrders(avatarId);
        return {
            code: 200,
            data: orders,
            message: '获取成功'
        };
    }
    async getAvatarNotifications(avatarId) {
        const notifications = await this.dispatchService.getAvatarNotifications(avatarId);
        return {
            code: 200,
            data: notifications,
            message: '获取成功'
        };
    }
    async updateExecutionStep(executionId, status, result) {
        const execution = await this.dispatchService.updateExecutionStep(executionId, status, result);
        return {
            code: 200,
            data: execution,
            message: '更新成功'
        };
    }
    async updateRequestStatus(requestId, status) {
        await this.dispatchService.updateRequestStatus(requestId, status);
        return {
            code: 200,
            message: '状态更新成功'
        };
    }
};
exports.OrderDispatchController = OrderDispatchController;
__decorate([
    (0, common_1.Post)(':id/dispatch'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "dispatchOrder", null);
__decorate([
    (0, common_1.Get)(':id/progress'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "getProgress", null);
__decorate([
    (0, common_1.Get)(':id/status'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "getDispatchStatus", null);
__decorate([
    (0, common_1.Get)('recommend/:orderId'),
    __param(0, (0, common_1.Param)('orderId')),
    __param(1, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "getRecommendedAvatars", null);
__decorate([
    (0, common_1.Get)('request/:requestId'),
    __param(0, (0, common_1.Param)('requestId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "getRequest", null);
__decorate([
    (0, common_1.Post)(':orderId/dispatch-avatar'),
    __param(0, (0, common_1.Param)('orderId')),
    __param(1, (0, common_1.Body)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "dispatchToAvatar", null);
__decorate([
    (0, common_1.Get)('pending-requests'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "getPendingRequests", null);
__decorate([
    (0, common_1.Put)('request/:requestId/confirm'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __param(2, (0, common_1.Body)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "confirmDispatch", null);
__decorate([
    (0, common_1.Put)('request/:requestId/reject'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __param(2, (0, common_1.Body)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "rejectDispatch", null);
__decorate([
    (0, common_1.Put)(':id/cancel'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "cancelDispatch", null);
__decorate([
    (0, common_1.Get)('avatar/:avatarId/accepted-orders'),
    __param(0, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "getAvatarAcceptedOrders", null);
__decorate([
    (0, common_1.Get)('avatar/:avatarId/notifications'),
    __param(0, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "getAvatarNotifications", null);
__decorate([
    (0, common_1.Put)('execution/:executionId/status'),
    __param(0, (0, common_1.Param)('executionId')),
    __param(1, (0, common_1.Body)('status')),
    __param(2, (0, common_1.Body)('result')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "updateExecutionStep", null);
__decorate([
    (0, common_1.Put)('request/:requestId/status'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, common_1.Body)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderDispatchController.prototype, "updateRequestStatus", null);
exports.OrderDispatchController = OrderDispatchController = __decorate([
    (0, common_1.Controller)('order-dispatch'),
    __metadata("design:paramtypes", [order_dispatch_service_1.OrderDispatchService])
], OrderDispatchController);
//# sourceMappingURL=order-dispatch.controller.js.map