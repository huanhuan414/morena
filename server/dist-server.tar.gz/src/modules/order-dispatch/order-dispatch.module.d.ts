export declare class OrderDispatchModule {
}
