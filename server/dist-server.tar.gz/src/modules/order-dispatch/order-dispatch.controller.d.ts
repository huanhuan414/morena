import { OrderDispatchService } from './order-dispatch.service';
export declare class OrderDispatchController {
    private readonly dispatchService;
    constructor(dispatchService: OrderDispatchService);
    dispatchOrder(orderId: string): Promise<{
        code: number;
        data: import("./order-dispatch.service").DispatchResult | null;
        message: string;
    }>;
    getProgress(orderId: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
    getDispatchStatus(orderId: string): Promise<{
        code: number;
        data: {
            order: any;
            pendingRequest: any;
            acceptedAvatar: any;
            executions: any[];
            currentStep: any;
        };
        message: string;
    }>;
    getRecommendedAvatars(orderId: string, limit?: string): Promise<{
        code: number;
        data: {
            id: string;
            name: string;
            avatar_url: string;
            level: number;
            score: number;
            isReal: boolean;
            matchReasons: string[];
            isHosted: boolean;
            completionRate: number;
            completedOrders: number;
            avgRating: number;
            totalEarnings: number;
            estimatedEffect: {
                reach: string;
                engagement: string;
                quality: string;
                time: string;
            } | undefined;
            skillMatchScore: number;
            platformMatchScore: number;
            semanticSimilarity: number | undefined;
            personalityFit: number | undefined;
            experienceMatch: number | undefined;
            avatarProfile: {
                expertise: string[];
                speakingStyle: string[];
                platforms: string[];
            } | undefined;
            orderAnalysis: {
                coreRequirement: string;
                category: string;
                requiredSkills: string[];
                complexityLevel: number;
            };
        }[];
        message: string;
    }>;
    getRequest(requestId: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    dispatchToAvatar(orderId: string, avatarId: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getPendingRequests(userId: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
    confirmDispatch(requestId: string, userId: string, avatarId: string): Promise<{
        code: number;
        data: boolean;
        message: string;
    }>;
    rejectDispatch(requestId: string, userId: string, avatarId: string): Promise<{
        code: number;
        data: boolean;
        message: string;
    }>;
    cancelDispatch(orderId: string, userId: string): Promise<{
        code: number;
        data: boolean;
        message: string;
    }>;
    getAvatarAcceptedOrders(avatarId: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
    getAvatarNotifications(avatarId: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
    updateExecutionStep(executionId: string, status: string, result?: any): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    updateRequestStatus(requestId: string, status: string): Promise<{
        code: number;
        message: string;
    }>;
}
