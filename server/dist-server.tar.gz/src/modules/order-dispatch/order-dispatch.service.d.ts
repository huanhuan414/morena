import { NotificationService } from '../notification/notification.service';
import { SubscriptionService } from '../subscription/subscription.service';
import { SmsService } from '../sms/sms.service';
import { ContentGenerationService } from '../content-generation/content-generation.service';
import { OrderProcessingService } from '../order-processing/order-processing.service';
export interface OrderAnalysis {
    coreRequirement: string;
    targetAudience: string[];
    requiredSkills: string[];
    preferredPlatforms: string[];
    toneStyle: string[];
    contentType: string[];
    urgencyLevel: 'high' | 'medium' | 'low';
    complexityLevel: number;
    estimatedBudget: string;
    keywords: string[];
    semanticTags: string[];
    category: string;
    specialRequirements: string[];
    expectedResults: {
        reachTarget?: number;
        engagementTarget?: number;
        qualityTarget?: string;
        customTargets?: string[];
    };
}
export interface AvatarProfile {
    id: string;
    name: string;
    avatar_url: string;
    user_id: string;
    personality: string;
    skills: string[];
    speakingStyle: string[];
    expertise: string[];
    targetAudience: string[];
    level: number;
    completionRate: number;
    completedOrders: number;
    totalOrders: number;
    avgRating: number;
    totalEarnings: number;
    is_hosted: boolean;
    platforms: string[];
    lastActiveAt: string;
    hostedTasksCount: number;
}
export interface AvatarScore {
    id: string;
    name: string;
    avatar_url: string;
    score: number;
    completionRate: number;
    level: number;
    totalOrders: number;
    completedOrders: number;
    skillMatchScore: number;
    platformMatchScore: number;
    reason: string[];
    is_hosted: boolean;
    avatarProfile?: AvatarProfile;
    orderAnalysis?: OrderAnalysis;
    semanticSimilarity?: number;
    personalityFit?: number;
    experienceMatch?: number;
    estimatedEffect?: {
        reach: string;
        engagement: string;
        quality: string;
        time: string;
    };
}
export interface DispatchResult {
    orderId: string;
    avatarId: string;
    avatarName: string;
    score: number;
    reason: string[];
}
export declare class OrderDispatchService {
    private readonly notificationService;
    private readonly subscriptionService;
    private readonly smsService;
    private readonly contentGenerationService;
    private readonly orderProcessingService;
    private llmClient;
    constructor(notificationService: NotificationService, subscriptionService: SubscriptionService, smsService: SmsService, contentGenerationService: ContentGenerationService, orderProcessingService: OrderProcessingService);
    private normalizePlatformName;
    analyzeOrderRequirements(order: any): Promise<OrderAnalysis>;
    private basicOrderAnalysis;
    private parseExpectedResults;
    private extractKeywords;
    private detectContentType;
    private generateSemanticTags;
    private detectCategory;
    analyzeAvatarProfile(avatar: any): Promise<AvatarProfile>;
    private inferSpeakingStyle;
    private inferExpertise;
    private calculateDistance;
    private toRadians;
    private calculateLocationWeight;
    private safeToString;
    private calculateSemanticSimilarity;
    evaluateAvatarOrderFit(avatar: any, order: any, orderAnalysis: OrderAnalysis, platformConfigMap: Map<string, any[]>): Promise<AvatarScore & {
        user_id: string;
    }>;
    private generateMatchReasons;
    private calculateEstimatedEffect;
    private getAvatarPerformanceData;
    private calculateTraditionalCount;
    private calculateRecommendedAvatarCount;
    dispatchOrder(orderId: string): Promise<DispatchResult | null>;
    private assignOrderToAvatar;
    private sendDispatchRequest;
    dispatchToAvatar(orderId: string, avatarId: string): Promise<any>;
    getUserPendingRequests(userId: string): Promise<any[]>;
    getRequestById(requestId: string): Promise<any>;
    getAvatarAcceptedOrders(avatarId: string): Promise<any[]>;
    getAvatarNotifications(avatarId: string): Promise<any[]>;
    confirmDispatch(requestId: string, avatarId: string): Promise<boolean>;
    rejectDispatch(requestId: string, avatarId: string): Promise<boolean>;
    private createExecutionSteps;
    getExecutionProgress(orderId: string): Promise<any[]>;
    updateExecutionStep(executionId: string, status: string, result?: any): Promise<any>;
    private moveToNextStep;
    getDispatchStatus(orderId: string): Promise<{
        order: any;
        pendingRequest: any;
        acceptedAvatar: any;
        executions: any[];
        currentStep: any;
    }>;
    getRecommendedAvatars(orderId: string, limit?: number): Promise<{
        id: string;
        name: string;
        avatar_url: string;
        level: number;
        score: number;
        isReal: boolean;
        matchReasons: string[];
        isHosted: boolean;
        completionRate: number;
        completedOrders: number;
        avgRating: number;
        totalEarnings: number;
        estimatedEffect: {
            reach: string;
            engagement: string;
            quality: string;
            time: string;
        } | undefined;
        skillMatchScore: number;
        platformMatchScore: number;
        semanticSimilarity: number | undefined;
        personalityFit: number | undefined;
        experienceMatch: number | undefined;
        avatarProfile: {
            expertise: string[];
            speakingStyle: string[];
            platforms: string[];
        } | undefined;
        orderAnalysis: {
            coreRequirement: string;
            category: string;
            requiredSkills: string[];
            complexityLevel: number;
        };
    }[]>;
    cancelDispatch(orderId: string, userId: string): Promise<boolean>;
    autoGenerateContent(orderId: string, avatarId: string, requestId: string): Promise<{
        success: boolean;
        executionId: any;
        content: {
            platform_count: number;
            contents: import("../content-generation/types").GeneratedContent[];
        };
    }>;
    updateRequestStatus(requestId: string, status: string): Promise<void>;
    private syncOrderStatusAfterFeedback;
}
