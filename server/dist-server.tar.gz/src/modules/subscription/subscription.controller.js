"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionController = void 0;
const common_1 = require("@nestjs/common");
const subscription_service_1 = require("./subscription.service");
const supabase_client_1 = require("../../storage/database/supabase-client");
const wechat_pay_service_1 = require("../payment/wechat-pay.service");
let SubscriptionController = class SubscriptionController {
    constructor(subscriptionService, wechatPayService) {
        this.subscriptionService = subscriptionService;
        this.wechatPayService = wechatPayService;
    }
    async getSubscriptionPlans() {
        try {
            const plans = await this.subscriptionService.getSubscriptionPlans();
            return {
                code: 200,
                data: plans,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                message: error.message || '获取失败',
                data: null
            };
        }
    }
    async getUserSubscription(userId) {
        try {
            const subscription = await this.subscriptionService.getUserSubscription(userId);
            return {
                code: 200,
                data: subscription,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                message: error.message || '获取失败',
                data: null
            };
        }
    }
    async getAvatarSubscription(avatarId) {
        try {
            const subscription = await this.subscriptionService.getAvatarSubscription(avatarId);
            return {
                code: 200,
                data: subscription,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                message: error.message || '获取失败',
                data: null
            };
        }
    }
    async checkCanCreateAvatar(userId) {
        try {
            const result = await this.subscriptionService.canCreateAvatar(userId);
            return {
                code: 200,
                data: result,
                message: result.canCreate ? '可以创建' : '无法创建'
            };
        }
        catch (error) {
            return {
                code: 500,
                message: error.message || '检查失败',
                data: null
            };
        }
    }
    async checkCanReceiveOrders(avatarId) {
        try {
            const canReceive = await this.subscriptionService.canAvatarReceiveOrders(avatarId);
            return {
                code: 200,
                data: { canReceive },
                message: canReceive ? '可以接单' : '无法接单'
            };
        }
        catch (error) {
            return {
                code: 500,
                message: error.message || '检查失败',
                data: null
            };
        }
    }
    async createSubscriptionOrder(userId, body) {
        try {
            const { planId, paymentMethod, openid } = body;
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data: plan, error: planError } = await client
                .from('subscription_plans')
                .select('*')
                .eq('id', planId)
                .single();
            if (planError || !plan) {
                return {
                    code: 400,
                    message: '订阅计划不存在',
                    data: null
                };
            }
            if (plan.price === 0) {
                const startDate = new Date();
                const endDate = new Date(startDate);
                endDate.setDate(endDate.getDate() + plan.duration_days);
                const { data: subscription, error: subError } = await client
                    .from('user_subscriptions')
                    .insert({
                    user_id: userId,
                    plan_id: planId,
                    start_date: startDate.toISOString(),
                    end_date: endDate.toISOString(),
                    status: 'active',
                    payment_id: `FREE_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                    payment_method: 'free',
                    auto_renew: false
                })
                    .select()
                    .single();
                if (subError) {
                    throw new Error(`创建订阅失败: ${subError.message}`);
                }
                const { data: avatars } = await client
                    .from('avatars')
                    .select('id')
                    .eq('user_id', userId);
                if (avatars) {
                    for (const avatar of avatars) {
                        await this.subscriptionService.updateAvatarSubscription(avatar.id, userId);
                    }
                }
                return {
                    code: 200,
                    data: {
                        subscriptionId: subscription.id,
                        plan: plan.name,
                        price: plan.price,
                        startDate: subscription.start_date,
                        endDate: subscription.end_date
                    },
                    message: '订阅成功'
                };
            }
            if (paymentMethod === 'wechat') {
                if (!openid) {
                    return {
                        code: 400,
                        message: '缺少用户openid',
                        data: null
                    };
                }
                if (!this.wechatPayService.isServiceAvailable()) {
                    console.warn('[SubscriptionController] 微信支付服务未配置，使用模拟支付模式');
                    return this.createMockOrder(userId, planId, plan, openid, client);
                }
                const outTradeNo = `SUB_${userId}_${Date.now()}`;
                const totalAmount = Math.round(plan.price * 100);
                const orderResult = await this.wechatPayService.createOrder(`订阅-${plan.name}`, outTradeNo, totalAmount, openid);
                console.log('[SubscriptionController] 微信支付订单创建成功:', orderResult);
                if (orderResult.prepay_id) {
                    const payParams = this.generateMiniProgramPayParams(orderResult.prepay_id);
                    const { data: order, error: orderError } = await client
                        .from('payment_orders')
                        .insert({
                        user_id: userId,
                        plan_id: planId,
                        out_trade_no: outTradeNo,
                        transaction_id: orderResult.prepay_id,
                        total_amount: totalAmount,
                        status: 'pending',
                        payment_method: 'wechat',
                        payment_params: payParams
                    })
                        .select()
                        .single();
                    if (orderError) {
                        console.error('[SubscriptionController] 创建支付订单记录失败:', orderError);
                        throw new Error('创建支付订单记录失败');
                    }
                    return {
                        code: 200,
                        data: {
                            orderId: order.id,
                            outTradeNo,
                            prepayId: orderResult.prepay_id,
                            ...payParams
                        },
                        message: '订单创建成功'
                    };
                }
                else {
                    throw new Error('微信支付订单创建失败');
                }
            }
            return {
                code: 400,
                message: '暂不支持该支付方式',
                data: null
            };
        }
        catch (error) {
            console.error('[SubscriptionController] 创建订阅订单失败:', error);
            return {
                code: 500,
                message: error.message || '创建订阅失败',
                data: null
            };
        }
    }
    async createMockOrder(userId, planId, plan, openid, client) {
        console.log('[SubscriptionController] 创建模拟支付订单');
        const outTradeNo = `MOCK_SUB_${userId}_${Date.now()}`;
        const payParams = {
            appId: process.env.WECHAT_APPID || '',
            timeStamp: Math.floor(Date.now() / 1000).toString(),
            nonceStr: Math.random().toString(36).substr(2, 32),
            package: 'prepay_id=mock_prepay_id',
            signType: 'RSA',
            paySign: 'mock_pay_sign_for_testing'
        };
        const startDate = new Date();
        const endDate = new Date(startDate);
        endDate.setDate(endDate.getDate() + plan.duration_days);
        const { data: subscription, error: subError } = await client
            .from('user_subscriptions')
            .insert({
            user_id: userId,
            plan_id: planId,
            start_date: startDate.toISOString(),
            end_date: endDate.toISOString(),
            status: 'active',
            payment_id: outTradeNo,
            payment_method: 'mock',
            auto_renew: false
        })
            .select()
            .single();
        if (subError) {
            console.error('[SubscriptionController] 创建订阅失败:', subError);
            throw new Error('创建订阅失败');
        }
        const { data: avatars } = await client
            .from('avatars')
            .select('id')
            .eq('user_id', userId);
        if (avatars) {
            for (const avatar of avatars) {
                await this.subscriptionService.updateAvatarSubscription(avatar.id, userId);
            }
        }
        return {
            code: 200,
            data: {
                orderId: 'mock-order-id',
                outTradeNo,
                prepayId: 'mock_prepay_id',
                ...payParams,
                isMock: true
            },
            message: '订阅成功（模拟支付）'
        };
    }
    generateMiniProgramPayParams(prepayId) {
        const appId = process.env.WECHAT_PAY_APPID || '';
        const timeStamp = Math.floor(Date.now() / 1000).toString();
        const nonceStr = Math.random().toString(36).substr(2, 32);
        const packageStr = `prepay_id=${prepayId}`;
        return {
            appId,
            timeStamp,
            nonceStr,
            package: packageStr,
            signType: 'RSA',
            paySign: 'TODO_USE_WECHAT_PAY_SDK_TO_SIGN'
        };
    }
    async checkCanAddFriend(userId) {
        try {
            const result = await this.subscriptionService.canAddFriend(userId);
            return {
                code: 200,
                data: result,
                message: result.canAdd ? '可以添加好友' : '无法添加好友'
            };
        }
        catch (error) {
            return {
                code: 500,
                message: error.message || '检查失败',
                data: null
            };
        }
    }
    async getFriendLimit(userId) {
        try {
            const result = await this.subscriptionService.getFriendLimit(userId);
            return {
                code: 200,
                data: result,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                message: error.message || '获取失败',
                data: null
            };
        }
    }
};
exports.SubscriptionController = SubscriptionController;
__decorate([
    (0, common_1.Get)('plans'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SubscriptionController.prototype, "getSubscriptionPlans", null);
__decorate([
    (0, common_1.Get)('user'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SubscriptionController.prototype, "getUserSubscription", null);
__decorate([
    (0, common_1.Get)('avatar/:avatarId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SubscriptionController.prototype, "getAvatarSubscription", null);
__decorate([
    (0, common_1.Get)('check/create-avatar'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SubscriptionController.prototype, "checkCanCreateAvatar", null);
__decorate([
    (0, common_1.Get)('check/receive-orders/:avatarId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SubscriptionController.prototype, "checkCanReceiveOrders", null);
__decorate([
    (0, common_1.Post)('order'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SubscriptionController.prototype, "createSubscriptionOrder", null);
__decorate([
    (0, common_1.Get)('check/add-friend'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SubscriptionController.prototype, "checkCanAddFriend", null);
__decorate([
    (0, common_1.Get)('friend-limit'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SubscriptionController.prototype, "getFriendLimit", null);
exports.SubscriptionController = SubscriptionController = __decorate([
    (0, common_1.Controller)('subscription'),
    __metadata("design:paramtypes", [subscription_service_1.SubscriptionService,
        wechat_pay_service_1.WechatPayService])
], SubscriptionController);
//# sourceMappingURL=subscription.controller.js.map