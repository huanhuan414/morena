import { SubscriptionService } from './subscription.service';
import { WechatPayService } from '../payment/wechat-pay.service';
export declare class SubscriptionController {
    private readonly subscriptionService;
    private readonly wechatPayService;
    constructor(subscriptionService: SubscriptionService, wechatPayService: WechatPayService);
    getSubscriptionPlans(): Promise<{
        code: number;
        data: import("./subscription.entity").SubscriptionPlan[];
        message: string;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
    getUserSubscription(userId: string): Promise<{
        code: number;
        data: import("./subscription.entity").UserSubscription | null;
        message: string;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
    getAvatarSubscription(avatarId: string): Promise<{
        code: number;
        data: import("./subscription.entity").AvatarSubscription | null;
        message: string;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
    checkCanCreateAvatar(userId: string): Promise<{
        code: number;
        data: {
            canCreate: boolean;
            reason?: string;
        };
        message: string;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
    checkCanReceiveOrders(avatarId: string): Promise<{
        code: number;
        data: {
            canReceive: boolean;
        };
        message: string;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
    createSubscriptionOrder(userId: string, body: {
        planId: string;
        paymentMethod?: string;
        openid?: string;
    }): Promise<{
        code: number;
        data: any;
        message: string;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
    private createMockOrder;
    private generateMiniProgramPayParams;
    checkCanAddFriend(userId: string): Promise<{
        code: number;
        data: {
            canAdd: boolean;
            reason?: string;
        };
        message: string;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
    getFriendLimit(userId: string): Promise<{
        code: number;
        data: {
            limit: number;
            current: number;
            canAddMore: boolean;
        };
        message: string;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
}
