"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
let SubscriptionService = class SubscriptionService {
    async getSubscriptionPlans() {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data, error } = await client
            .from('subscription_plans')
            .select('*')
            .eq('is_active', true)
            .order('display_order', { ascending: true });
        if (error) {
            throw new Error(`获取订阅计划失败: ${error.message}`);
        }
        return (data || []).map(plan => ({
            id: plan.id,
            name: plan.name,
            description: plan.description,
            price: parseFloat(plan.price),
            duration_days: plan.duration_days,
            max_avatars: plan.max_avatars,
            can_receive_orders: plan.can_receive_orders,
            order_priority: plan.order_priority,
            features: plan.features || {},
            display_order: plan.display_order,
            is_active: plan.is_active,
            created_at: plan.created_at,
            updated_at: plan.updated_at
        }));
    }
    async getUserSubscription(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data, error } = await client
            .from('user_subscriptions')
            .select(`
        *,
        plan:subscription_plans(*)
      `)
            .eq('user_id', userId)
            .eq('status', 'active')
            .order('end_date', { ascending: false })
            .limit(1)
            .single();
        if (error || !data) {
            return null;
        }
        return {
            id: data.id,
            user_id: data.user_id,
            plan_id: data.plan_id,
            start_date: data.start_date,
            end_date: data.end_date,
            status: data.status,
            payment_id: data.payment_id,
            payment_method: data.payment_method,
            auto_renew: data.auto_renew,
            created_at: data.created_at,
            updated_at: data.updated_at,
            plan: data.plan ? {
                id: data.plan.id,
                name: data.plan.name,
                description: data.plan.description,
                price: parseFloat(data.plan.price),
                duration_days: data.plan.duration_days,
                max_avatars: data.plan.max_avatars,
                can_receive_orders: data.plan.can_receive_orders,
                order_priority: data.plan.order_priority,
                features: data.plan.features || {},
                display_order: data.plan.display_order,
                is_active: data.plan.is_active,
                created_at: data.plan.created_at,
                updated_at: data.plan.updated_at
            } : undefined
        };
    }
    async getAvatarSubscription(avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data, error } = await client
            .from('avatar_subscriptions')
            .select('*')
            .eq('avatar_id', avatarId)
            .eq('is_active', true)
            .single();
        if (error || !data) {
            return null;
        }
        return {
            id: data.id,
            user_id: data.user_id,
            avatar_id: data.avatar_id,
            subscription_id: data.subscription_id,
            subscription_level: data.subscription_level,
            can_receive_orders: data.can_receive_orders,
            order_priority: data.order_priority,
            is_active: data.is_active,
            created_at: data.created_at,
            updated_at: data.updated_at
        };
    }
    async canCreateAvatar(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const subscription = await this.getUserSubscription(userId);
        const { count: avatarCount } = await client
            .from('avatars')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId)
            .eq('status', 'active');
        if (!subscription) {
            if ((avatarCount || 0) >= 1) {
                return {
                    canCreate: false,
                    reason: '免费用户只能创建1个分身，请升级订阅以创建更多分身'
                };
            }
            return { canCreate: true };
        }
        const now = new Date();
        const endDate = new Date(subscription.end_date);
        if (endDate < now) {
            return {
                canCreate: false,
                reason: '订阅已过期，请续费以创建更多分身'
            };
        }
        const maxAvatars = subscription.plan?.max_avatars || 1;
        if (maxAvatars !== -1 && (avatarCount || 0) >= maxAvatars) {
            return {
                canCreate: false,
                reason: `当前订阅计划最多支持${maxAvatars}个分身，请升级订阅以创建更多分身`
            };
        }
        return { canCreate: true };
    }
    async updateAvatarSubscription(avatarId, userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const subscription = await this.getUserSubscription(userId);
        let subscriptionLevel = 'free';
        let canReceiveOrders = false;
        let orderPriority = 0;
        if (subscription) {
            const now = new Date();
            const endDate = new Date(subscription.end_date);
            if (endDate >= now && subscription.plan) {
                if (subscription.plan.name.includes('尊享') || subscription.plan.name.includes('VIP')) {
                    subscriptionLevel = 'vip';
                }
                else if (subscription.plan.name.includes('高级') || subscription.plan.name.includes('Premium')) {
                    subscriptionLevel = 'premium';
                }
                else if (subscription.plan.name.includes('基础') || subscription.plan.name.includes('Basic')) {
                    subscriptionLevel = 'basic';
                }
                canReceiveOrders = subscription.plan.can_receive_orders;
                orderPriority = subscription.plan.order_priority;
            }
        }
        const { data: existing } = await client
            .from('avatar_subscriptions')
            .select('*')
            .eq('avatar_id', avatarId)
            .single();
        if (existing) {
            await client
                .from('avatar_subscriptions')
                .update({
                subscription_id: subscription?.id,
                subscription_level: subscriptionLevel,
                can_receive_orders: canReceiveOrders,
                order_priority: orderPriority,
                updated_at: new Date().toISOString()
            })
                .eq('id', existing.id);
        }
        else {
            await client
                .from('avatar_subscriptions')
                .insert({
                user_id: userId,
                avatar_id: avatarId,
                subscription_id: subscription?.id,
                subscription_level: subscriptionLevel,
                can_receive_orders: canReceiveOrders,
                order_priority: orderPriority,
                is_active: true,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            });
        }
    }
    async canAvatarReceiveOrders(avatarId) {
        const subscription = await this.getAvatarSubscription(avatarId);
        if (!subscription) {
            return false;
        }
        return subscription.can_receive_orders;
    }
    async getAvatarOrderPriority(avatarId) {
        const subscription = await this.getAvatarSubscription(avatarId);
        if (!subscription) {
            return 0;
        }
        return subscription.order_priority;
    }
    async initAvatarSubscription(avatarId, userId) {
        await this.updateAvatarSubscription(avatarId, userId);
    }
    async canAddFriend(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const subscription = await this.getUserSubscription(userId);
        const { count: friendCount } = await client
            .from('avatar_friends')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId)
            .in('status', ['accepted', 'pending']);
        if (!subscription) {
            if ((friendCount || 0) >= 10) {
                return {
                    canAdd: false,
                    reason: '免费用户最多添加10个好友，请升级订阅以添加更多好友'
                };
            }
            return { canAdd: true };
        }
        const now = new Date();
        const endDate = new Date(subscription.end_date);
        if (endDate < now) {
            return {
                canAdd: false,
                reason: '订阅已过期，请续费以添加更多好友'
            };
        }
        const maxFriends = subscription.plan?.features?.max_friends || 10;
        if (maxFriends === -1) {
            return { canAdd: true };
        }
        if ((friendCount || 0) >= maxFriends) {
            return {
                canAdd: false,
                reason: `当前订阅计划最多添加${maxFriends}个好友，请升级订阅以添加更多好友`
            };
        }
        return { canAdd: true };
    }
    async getFriendLimit(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const subscription = await this.getUserSubscription(userId);
        const { count: friendCount } = await client
            .from('avatar_friends')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId)
            .in('status', ['accepted', 'pending']);
        const maxFriends = subscription?.plan?.features?.max_friends || 10;
        return {
            limit: maxFriends,
            current: friendCount || 0,
            canAddMore: maxFriends === -1 || (friendCount || 0) < maxFriends
        };
    }
};
exports.SubscriptionService = SubscriptionService;
exports.SubscriptionService = SubscriptionService = __decorate([
    (0, common_1.Injectable)()
], SubscriptionService);
//# sourceMappingURL=subscription.service.js.map