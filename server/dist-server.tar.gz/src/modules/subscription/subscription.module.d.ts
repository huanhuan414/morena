export declare class SubscriptionModule {
}
