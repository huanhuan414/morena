import { SubscriptionPlan, UserSubscription, AvatarSubscription } from './subscription.entity';
export declare class SubscriptionService {
    getSubscriptionPlans(): Promise<SubscriptionPlan[]>;
    getUserSubscription(userId: string): Promise<UserSubscription | null>;
    getAvatarSubscription(avatarId: string): Promise<AvatarSubscription | null>;
    canCreateAvatar(userId: string): Promise<{
        canCreate: boolean;
        reason?: string;
    }>;
    updateAvatarSubscription(avatarId: string, userId: string): Promise<void>;
    canAvatarReceiveOrders(avatarId: string): Promise<boolean>;
    getAvatarOrderPriority(avatarId: string): Promise<number>;
    initAvatarSubscription(avatarId: string, userId: string): Promise<void>;
    canAddFriend(userId: string): Promise<{
        canAdd: boolean;
        reason?: string;
    }>;
    getFriendLimit(userId: string): Promise<{
        limit: number;
        current: number;
        canAddMore: boolean;
    }>;
}
