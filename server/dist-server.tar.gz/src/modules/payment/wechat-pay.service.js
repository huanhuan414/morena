"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WechatPayService = void 0;
const common_1 = require("@nestjs/common");
const WxPay = require('wechatpay-node-v3');
const fs_1 = require("fs");
let WechatPayService = class WechatPayService {
    constructor() {
        this.pay = null;
        this.isAvailable = false;
        this.mchid = process.env.WECHAT_PAY_MCHID || '1290305501';
        this.appid = process.env.WECHAT_PAY_APPID || '';
        const privateKeyPath = process.env.WECHAT_PAY_PRIVATE_KEY_PATH;
        const publicKeyPath = process.env.WECHAT_PAY_PUBLIC_KEY_PATH;
        const privateKeyContent = process.env.WECHAT_PAY_PRIVATE_KEY;
        const publicKeyContent = process.env.WECHAT_PAY_PUBLIC_KEY;
        console.log('[WechatPayService] 开始初始化微信支付服务', {
            hasPrivateKeyPath: !!privateKeyPath,
            hasPublicKeyPath: !!publicKeyPath,
            hasPrivateKeyContent: !!privateKeyContent,
            hasPublicKeyContent: !!publicKeyContent
        });
        if (!privateKeyPath && !privateKeyContent) {
            console.warn('[WechatPayService] 未配置商户私钥（文件路径或证书内容），支付功能将不可用');
            console.warn('[WechatPayService] 请在 .env 文件中配置 WECHAT_PAY_PRIVATE_KEY_PATH 或 WECHAT_PAY_PRIVATE_KEY');
            this.pay = null;
            this.isAvailable = false;
            return;
        }
        try {
            const privateKey = privateKeyContent || this.getPrivateKeyFromFile(privateKeyPath);
            const publicKey = publicKeyContent || this.getPublicKeyFromFile(publicKeyPath);
            console.log('[WechatPayService] 成功获取证书', {
                hasPrivateKey: !!privateKey,
                hasPublicKey: !!publicKey
            });
            this.pay = new WxPay({
                appid: this.appid,
                mchid: this.mchid,
                publicKey: publicKey ? Buffer.from(publicKey) : undefined,
                privateKey: Buffer.from(privateKey),
                serial_no: process.env.WECHAT_PAY_SERIAL_NO || '',
                key: process.env.WECHAT_PAY_APIV3_KEY || ''
            });
            this.isAvailable = true;
            console.log('[WechatPayService] 微信支付服务初始化完成', {
                mchid: this.mchid,
                appid: this.appid,
                isAvailable: true
            });
        }
        catch (error) {
            console.error('[WechatPayService] 微信支付服务初始化失败:', error.message);
            console.error('[WechatPayService] 错误详情:', error);
            this.pay = null;
            this.isAvailable = false;
        }
    }
    isServiceAvailable() {
        return this.isAvailable && this.pay !== null;
    }
    getConfigStatus() {
        const missingConfigs = [];
        if (!process.env.WECHAT_PAY_PRIVATE_KEY && !process.env.WECHAT_PAY_PRIVATE_KEY_PATH) {
            missingConfigs.push('商户私钥（WECHAT_PAY_PRIVATE_KEY）');
        }
        if (!process.env.WECHAT_PAY_APIV3_KEY) {
            missingConfigs.push('APIv3密钥（WECHAT_PAY_APIV3_KEY）');
        }
        if (!process.env.WECHAT_PAY_MCHID) {
            missingConfigs.push('商户号（WECHAT_PAY_MCHID）');
        }
        if (!process.env.WECHAT_PAY_APPID) {
            missingConfigs.push('小程序AppID（WECHAT_PAY_APPID）');
        }
        return {
            isAvailable: this.isServiceAvailable(),
            mchid: this.mchid,
            appid: this.appid,
            missingConfigs,
            instructions: missingConfigs.length > 0
                ? `请在 .env 文件中配置以下项：${missingConfigs.join('、')}。详细说明请查看 docs/WECHAT_PAY_CONFIG.md`
                : '配置完整，服务正常运行'
        };
    }
    getPrivateKeyFromFile(filePath) {
        if (!filePath) {
            console.warn('[WechatPayService] 未配置商户私钥文件路径');
            return '';
        }
        try {
            return (0, fs_1.readFileSync)(filePath, 'utf-8');
        }
        catch (error) {
            console.error('[WechatPayService] 读取商户私钥失败:', error);
            throw new Error(`读取商户私钥失败: ${filePath}`);
        }
    }
    getPublicKeyFromFile(filePath) {
        if (!filePath) {
            console.warn('[WechatPayService] 未配置平台公钥文件路径');
            return '';
        }
        try {
            return (0, fs_1.readFileSync)(filePath, 'utf-8');
        }
        catch (error) {
            console.warn('[WechatPayService] 读取平台公钥失败，签名验证可能受影响:', error);
            return '';
        }
    }
    async createOrder(description, outTradeNo, totalAmount, openid, notifyUrl) {
        if (!this.pay) {
            throw new Error('微信支付服务未初始化，请检查配置');
        }
        try {
            const params = {
                appid: this.appid,
                mchid: this.mchid,
                description,
                out_trade_no: outTradeNo,
                notify_url: notifyUrl || process.env.WECHAT_PAY_NOTIFY_URL || '',
                amount: {
                    total: totalAmount,
                    currency: 'CNY'
                },
                payer: {
                    openid
                }
            };
            console.log('[WechatPayService] 创建小程序订单参数:', params);
            const result = await this.pay.transactions_jsapi(params);
            console.log('[WechatPayService] 创建小程序订单响应:', result);
            return result;
        }
        catch (error) {
            console.error('[WechatPayService] 创建小程序订单失败:', error);
            throw new Error(error.message || '创建订单失败');
        }
    }
    async createH5Order(description, outTradeNo, totalAmount, notifyUrl) {
        if (!this.pay) {
            throw new Error('微信支付服务未初始化，请检查配置');
        }
        try {
            const params = {
                appid: this.appid,
                mchid: this.mchid,
                description,
                out_trade_no: outTradeNo,
                notify_url: notifyUrl || process.env.WECHAT_PAY_NOTIFY_URL || '',
                amount: {
                    total: totalAmount,
                    currency: 'CNY'
                },
                scene_info: {
                    payer_client_ip: '127.0.0.1',
                    h5_info: {
                        type: 'Wap',
                        app_name: '分身营销助手',
                        app_url: process.env.FRONTEND_URL || 'https://yourdomain.com'
                    }
                }
            };
            console.log('[WechatPayService] 创建H5订单参数:', params);
            const result = await this.pay.transactions_h5(params);
            console.log('[WechatPayService] 创建H5订单响应:', result);
            return result;
        }
        catch (error) {
            console.error('[WechatPayService] 创建H5订单失败:', error);
            throw new Error(error.message || '创建H5订单失败');
        }
    }
    async queryOrder(outTradeNo) {
        if (!this.pay) {
            throw new Error('微信支付服务未初始化，请检查配置');
        }
        try {
            console.log('[WechatPayService] 查询订单:', outTradeNo);
            const result = await this.pay.query({ out_trade_no: outTradeNo });
            console.log('[WechatPayService] 查询订单结果:', result);
            return result;
        }
        catch (error) {
            console.error('[WechatPayService] 查询订单失败:', error);
            throw new Error(error.message || '查询订单失败');
        }
    }
    async closeOrder(outTradeNo) {
        if (!this.pay) {
            throw new Error('微信支付服务未初始化，请检查配置');
        }
        try {
            console.log('[WechatPayService] 关闭订单:', outTradeNo);
            const result = await this.pay.close({ out_trade_no: outTradeNo });
            console.log('[WechatPayService] 关闭订单结果:', result);
            return result;
        }
        catch (error) {
            console.error('[WechatPayService] 关闭订单失败:', error);
            throw new Error(error.message || '关闭订单失败');
        }
    }
    async verifyNotify(signature, timestamp, nonce, body) {
        if (!this.pay) {
            console.warn('[WechatPayService] 支付服务未初始化，无法验证签名');
            return false;
        }
        try {
            const isValid = await this.pay.verifySign({
                timestamp,
                nonce,
                body,
                serial: process.env.WECHAT_PAY_SERIAL_NO || '',
                signature,
                apiSecret: process.env.WECHAT_PAY_APIV3_KEY
            });
            console.log('[WechatPayService] 验证签名结果:', isValid);
            return isValid;
        }
        catch (error) {
            console.error('[WechatPayService] 验证签名失败:', error);
            return false;
        }
    }
    async decryptNotify(associatedData, nonce, ciphertext) {
        if (!this.pay) {
            throw new Error('微信支付服务未初始化，请检查配置');
        }
        try {
            const result = this.pay.decipher_gcm(associatedData, nonce, ciphertext);
            console.log('[WechatPayService] 解密通知结果:', result);
            return typeof result === 'string' ? JSON.parse(result) : result;
        }
        catch (error) {
            console.error('[WechatPayService] 解密通知失败:', error);
            throw new Error(error.message || '解密通知失败');
        }
    }
    async refund(outTradeNo, outRefundNo, totalAmount, refundAmount) {
        if (!this.pay) {
            throw new Error('微信支付服务未初始化，请检查配置');
        }
        try {
            const params = {
                out_trade_no: outTradeNo,
                out_refund_no: outRefundNo,
                notify_url: process.env.WECHAT_PAY_REFUND_NOTIFY_URL || '',
                amount: {
                    refund: refundAmount,
                    total: totalAmount,
                    currency: 'CNY'
                }
            };
            console.log('[WechatPayService] 申请退款参数:', params);
            const result = await this.pay.refunds(params);
            console.log('[WechatPayService] 申请退款结果:', result);
            return result;
        }
        catch (error) {
            console.error('[WechatPayService] 申请退款失败:', error);
            throw new Error(error.message || '申请退款失败');
        }
    }
};
exports.WechatPayService = WechatPayService;
exports.WechatPayService = WechatPayService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], WechatPayService);
//# sourceMappingURL=wechat-pay.service.js.map