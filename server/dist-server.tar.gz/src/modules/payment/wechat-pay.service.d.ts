export declare class WechatPayService {
    private pay;
    private mchid;
    private appid;
    private isAvailable;
    constructor();
    isServiceAvailable(): boolean;
    getConfigStatus(): {
        isAvailable: boolean;
        mchid: string;
        appid: string;
        missingConfigs: string[];
        instructions: string;
    };
    private getPrivateKeyFromFile;
    private getPublicKeyFromFile;
    createOrder(description: string, outTradeNo: string, totalAmount: number, openid: string, notifyUrl?: string): Promise<any>;
    createH5Order(description: string, outTradeNo: string, totalAmount: number, notifyUrl?: string): Promise<any>;
    queryOrder(outTradeNo: string): Promise<any>;
    closeOrder(outTradeNo: string): Promise<any>;
    verifyNotify(signature: string, timestamp: string, nonce: string, body: any): Promise<boolean>;
    decryptNotify(associatedData: string, nonce: string, ciphertext: string): Promise<any>;
    refund(outTradeNo: string, outRefundNo: string, totalAmount: number, refundAmount: number): Promise<any>;
}
