export declare class PaymentModule {
}
