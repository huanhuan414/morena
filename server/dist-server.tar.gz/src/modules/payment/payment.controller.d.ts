import { WechatPayService } from './wechat-pay.service';
interface CreatePaymentRequest {
    planId: string;
    paymentMethod: 'wechat';
    openid?: string;
}
interface CreateOrderPaymentRequest {
    orderId: string;
    amount: number;
    description: string;
    openid: string;
    platform?: 'miniprogram' | 'h5';
}
export declare class PaymentController {
    private readonly wechatPayService;
    constructor(wechatPayService: WechatPayService);
    createPayment(userId: string, body: CreatePaymentRequest): Promise<{
        code: number;
        data: any;
        message: string;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
    createOrderPayment(userId: string, body: CreateOrderPaymentRequest): Promise<{
        code: number;
        message: string;
        data: any;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
    private generateMiniProgramPayParams;
    paymentNotify(req: any): Promise<{
        code: string;
        message: any;
    }>;
    private updatePaymentOrder;
    private activateUserSubscription;
    queryOrder(req: any): Promise<{
        code: number;
        data: any;
        message: string;
    } | {
        code: number;
        message: any;
        data: null;
    }>;
}
export {};
