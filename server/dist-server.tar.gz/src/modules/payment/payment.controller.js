"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentController = void 0;
const common_1 = require("@nestjs/common");
const wechat_pay_service_1 = require("./wechat-pay.service");
const supabase_client_1 = require("../../storage/database/supabase-client");
let PaymentController = class PaymentController {
    constructor(wechatPayService) {
        this.wechatPayService = wechatPayService;
    }
    async createPayment(userId, body) {
        try {
            const { planId, paymentMethod, openid } = body;
            if (paymentMethod !== 'wechat') {
                return {
                    code: 400,
                    message: '暂不支持该支付方式',
                    data: null
                };
            }
            if (!openid) {
                return {
                    code: 400,
                    message: '缺少用户openid',
                    data: null
                };
            }
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data: plan, error: planError } = await client
                .from('subscription_plans')
                .select('*')
                .eq('id', planId)
                .single();
            if (planError || !plan) {
                return {
                    code: 400,
                    message: '订阅计划不存在',
                    data: null
                };
            }
            if (plan.price <= 0) {
                return {
                    code: 400,
                    message: '免费版无需支付',
                    data: null
                };
            }
            if (!this.wechatPayService.isServiceAvailable()) {
                const configStatus = this.wechatPayService.getConfigStatus();
                console.error('[PaymentController] 微信支付服务未初始化，配置状态:', configStatus);
                return {
                    code: 400,
                    message: '微信支付服务未初始化',
                    data: {
                        isAvailable: configStatus.isAvailable,
                        missingConfigs: configStatus.missingConfigs,
                        instructions: configStatus.instructions,
                        currentConfig: {
                            hasAppid: !!process.env.WECHAT_PAY_APPID,
                            hasMchid: !!process.env.WECHAT_PAY_MCHID,
                            hasPrivateKey: !!(process.env.WECHAT_PAY_PRIVATE_KEY || process.env.WECHAT_PAY_PRIVATE_KEY_PATH),
                            hasKey: !!process.env.WECHAT_PAY_APIV3_KEY
                        }
                    }
                };
            }
            const outTradeNo = `SUB_${userId}_${Date.now()}`;
            const totalAmount = Math.round(plan.price * 100);
            const orderResult = await this.wechatPayService.createOrder(`订阅-${plan.name}`, outTradeNo, totalAmount, openid);
            console.log('[PaymentController] 微信支付订单创建成功:', orderResult);
            if (orderResult.prepay_id) {
                const payParams = this.generateMiniProgramPayParams(orderResult.prepay_id);
                const { data: order, error: orderError } = await client
                    .from('payment_orders')
                    .insert({
                    user_id: userId,
                    plan_id: planId,
                    out_trade_no: outTradeNo,
                    transaction_id: orderResult.prepay_id,
                    total_amount: totalAmount,
                    status: 'pending',
                    payment_method: 'wechat',
                    payment_params: payParams
                })
                    .select()
                    .single();
                if (orderError) {
                    console.error('[PaymentController] 创建支付订单记录失败:', orderError);
                    throw new Error('创建支付订单记录失败');
                }
                return {
                    code: 200,
                    data: {
                        orderId: order.id,
                        outTradeNo,
                        prepayId: orderResult.prepay_id,
                        ...payParams
                    },
                    message: '订单创建成功'
                };
            }
            else {
                throw new Error('微信支付订单创建失败');
            }
        }
        catch (error) {
            console.error('[PaymentController] 创建支付订单失败:', error);
            return {
                code: 500,
                message: error.message || '创建支付订单失败',
                data: null
            };
        }
    }
    async createOrderPayment(userId, body) {
        try {
            const { orderId, amount, description, openid, platform = 'miniprogram' } = body;
            console.log('[PaymentController] 开始创建订单支付:', {
                userId,
                orderId,
                amount,
                description,
                openid,
                platform
            });
            if (!openid) {
                console.error('[PaymentController] 缺少用户openid');
                return {
                    code: 400,
                    message: '缺少用户openid',
                    data: null
                };
            }
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data: order, error: orderError } = await client
                .from('orders')
                .select('*')
                .eq('id', orderId)
                .eq('user_id', userId)
                .single();
            if (orderError || !order) {
                console.error('[PaymentController] 订单不存在:', { orderId, userId, error: orderError });
                return {
                    code: 400,
                    message: '订单不存在',
                    data: null
                };
            }
            console.log('[PaymentController] 订单查询成功，当前状态:', order.status, '预算:', order.budget);
            if (order.status !== 'pending_payment' && order.status !== 'paying') {
                console.error('[PaymentController] 订单状态不正确，当前状态:', order.status, '期望状态: pending_payment 或 paying');
                return {
                    code: 400,
                    message: `订单状态不正确，当前状态：${order.status}，期望状态：待支付或支付中`,
                    data: {
                        currentStatus: order.status,
                        expectedStatus: ['pending_payment', 'paying']
                    }
                };
            }
            const { data: existingPayment } = await client
                .from('order_payments')
                .select('*')
                .eq('order_id', orderId)
                .in('status', ['pending', 'paying'])
                .maybeSingle();
            if (existingPayment) {
                console.log('[PaymentController] 订单已在支付中，返回已有支付记录:', existingPayment.id);
                return {
                    code: 400,
                    message: '订单已在支付中，请勿重复操作',
                    data: {
                        paymentId: existingPayment.id,
                        ...existingPayment.payment_params
                    }
                };
            }
            console.log('[PaymentController] 尝试更新订单状态: pending_payment -> paying');
            const { error: updateError } = await client
                .from('orders')
                .update({ status: 'paying' })
                .eq('id', orderId)
                .eq('status', 'pending_payment');
            if (updateError) {
                console.error('[PaymentController] 订单状态更新失败:', updateError);
                const { data: currentOrder } = await client
                    .from('orders')
                    .select('status')
                    .eq('id', orderId)
                    .single();
                return {
                    code: 400,
                    message: `订单状态已变更，请刷新后重试。当前状态：${currentOrder?.status || 'unknown'}`,
                    data: null
                };
            }
            console.log('[PaymentController] 订单状态更新成功: paying');
            if (!this.wechatPayService.isServiceAvailable()) {
                const configStatus = this.wechatPayService.getConfigStatus();
                console.error('[PaymentController] 微信支付服务未初始化，配置状态:', configStatus);
                return {
                    code: 400,
                    message: '微信支付服务未初始化',
                    data: {
                        isAvailable: configStatus.isAvailable,
                        missingConfigs: configStatus.missingConfigs,
                        instructions: configStatus.instructions,
                        currentConfig: {
                            hasAppid: !!process.env.WECHAT_PAY_APPID,
                            hasMchid: !!process.env.WECHAT_PAY_MCHID,
                            hasPrivateKey: !!(process.env.WECHAT_PAY_PRIVATE_KEY || process.env.WECHAT_PAY_PRIVATE_KEY_PATH),
                            hasKey: !!process.env.WECHAT_PAY_APIV3_KEY
                        }
                    }
                };
            }
            const outTradeNo = `ORDER_${userId}_${orderId}_${Date.now()}`;
            const totalAmount = Math.round(amount * 100);
            console.log('[PaymentController] 创建微信支付订单:', {
                platform,
                orderId,
                outTradeNo,
                totalAmount,
                openid,
                description
            });
            let wechatOrderResult;
            let payParams;
            try {
                if (platform === 'h5') {
                    console.log('[PaymentController] 调用微信H5支付接口');
                    wechatOrderResult = await this.wechatPayService.createH5Order(description, outTradeNo, totalAmount);
                    console.log('[PaymentController] H5支付订单创建成功:', wechatOrderResult);
                    if (wechatOrderResult.h5_url) {
                        payParams = {
                            mweb_url: wechatOrderResult.h5_url
                        };
                    }
                    else {
                        throw new Error('微信H5支付订单创建失败：h5_url为空');
                    }
                }
                else {
                    console.log('[PaymentController] 调用微信小程序支付接口');
                    wechatOrderResult = await this.wechatPayService.createOrder(description, outTradeNo, totalAmount, openid);
                    console.log('[PaymentController] 小程序支付订单创建成功:', wechatOrderResult);
                    if (wechatOrderResult.prepay_id) {
                        payParams = this.generateMiniProgramPayParams(wechatOrderResult.prepay_id);
                    }
                    else {
                        throw new Error('微信支付订单创建失败：prepay_id为空');
                    }
                }
                console.log('[PaymentController] 创建支付记录');
                const { data: payment, error: paymentError } = await client
                    .from('order_payments')
                    .insert({
                    user_id: userId,
                    order_id: orderId,
                    out_trade_no: outTradeNo,
                    transaction_id: wechatOrderResult.prepay_id || wechatOrderResult.h5_url,
                    total_amount: totalAmount,
                    status: 'paying',
                    payment_method: 'wechat',
                    payment_params: payParams,
                    platform
                })
                    .select()
                    .single();
                if (paymentError) {
                    console.error('[PaymentController] 创建支付记录失败:', paymentError);
                    console.log('[PaymentController] 回滚订单状态: paying -> pending_payment');
                    await client
                        .from('orders')
                        .update({ status: 'pending_payment' })
                        .eq('id', orderId);
                    throw new Error(`创建支付记录失败: ${paymentError.message}`);
                }
                console.log('[PaymentController] 支付记录创建成功，支付ID:', payment.id);
                return {
                    code: 200,
                    data: {
                        paymentId: payment.id,
                        orderId,
                        outTradeNo,
                        platform,
                        ...payParams
                    },
                    message: '支付订单创建成功'
                };
            }
            catch (error) {
                console.error('[PaymentController] 创建微信支付订单失败，回滚订单状态:', error);
                await client
                    .from('orders')
                    .update({ status: 'pending_payment' })
                    .eq('id', orderId)
                    .eq('status', 'paying');
                throw error;
            }
        }
        catch (error) {
            console.error('[PaymentController] 创建订单支付失败:', error);
            return {
                code: 500,
                message: error.message || '创建订单支付失败',
                data: null
            };
        }
    }
    generateMiniProgramPayParams(prepayId) {
        const appId = process.env.WECHAT_PAY_APPID || '';
        const timeStamp = Math.floor(Date.now() / 1000).toString();
        const nonceStr = Math.random().toString(36).substr(2, 32);
        const packageStr = `prepay_id=${prepayId}`;
        const signStr = `${appId}\n${timeStamp}\n${nonceStr}\n${packageStr}\n`;
        return {
            appId,
            timeStamp,
            nonceStr,
            package: packageStr,
            signType: 'RSA',
            paySign: 'TODO_USE_WECHAT_PAY_SDK_TO_SIGN'
        };
    }
    async paymentNotify(req) {
        try {
            console.log('[PaymentController] 收到支付通知:', req.body);
            const { signature, timestamp, nonce } = req.headers;
            const body = JSON.stringify(req.body);
            const isValid = await this.wechatPayService.verifyNotify(signature, timestamp, nonce, body);
            if (!isValid) {
                console.error('[PaymentController] 支付通知签名验证失败');
                return {
                    code: 'FAIL',
                    message: '签名验证失败'
                };
            }
            const { resource } = req.body;
            const decryptedData = await this.wechatPayService.decryptNotify(resource.associated_data, resource.nonce, resource.ciphertext);
            console.log('[PaymentController] 解密后的支付数据:', decryptedData);
            await this.updatePaymentOrder(decryptedData.out_trade_no, decryptedData.transaction_id, 'success');
            return {
                code: 'SUCCESS',
                message: '处理成功'
            };
        }
        catch (error) {
            console.error('[PaymentController] 处理支付通知失败:', error);
            return {
                code: 'FAIL',
                message: error.message || '处理失败'
            };
        }
    }
    async updatePaymentOrder(outTradeNo, transactionId, status) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: order, error: orderError } = await client
            .from('payment_orders')
            .select('*')
            .eq('out_trade_no', outTradeNo)
            .single();
        if (orderError || !order) {
            console.error('[PaymentController] 支付订单不存在:', outTradeNo);
            throw new Error('支付订单不存在');
        }
        await client
            .from('payment_orders')
            .update({
            status,
            transaction_id: transactionId,
            paid_at: new Date().toISOString()
        })
            .eq('id', order.id);
        if (status === 'success') {
            await this.activateUserSubscription(order.user_id, order.plan_id);
        }
    }
    async activateUserSubscription(userId, planId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: plan, error: planError } = await client
            .from('subscription_plans')
            .select('*')
            .eq('id', planId)
            .single();
        if (planError || !plan) {
            console.error('[PaymentController] 订阅计划不存在:', planId);
            throw new Error('订阅计划不存在');
        }
        const startDate = new Date();
        const endDate = new Date(startDate);
        endDate.setDate(endDate.getDate() + plan.duration_days);
        await client
            .from('user_subscriptions')
            .upsert({
            user_id: userId,
            plan_id: planId,
            start_date: startDate.toISOString(),
            end_date: endDate.toISOString(),
            status: 'active',
            auto_renew: false
        }, {
            onConflict: 'user_id'
        });
        console.log('[PaymentController] 用户订阅激活成功:', { userId, planId, endDate });
    }
    async queryOrder(req) {
        try {
            const { outTradeNo } = req.params;
            const wechatOrder = await this.wechatPayService.queryOrder(outTradeNo);
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data: localOrder } = await client
                .from('payment_orders')
                .select('*')
                .eq('out_trade_no', outTradeNo)
                .single();
            return {
                code: 200,
                data: {
                    ...localOrder,
                    wechatStatus: wechatOrder.trade_state,
                    wechatOrder
                },
                message: '查询成功'
            };
        }
        catch (error) {
            console.error('[PaymentController] 查询订单失败:', error);
            return {
                code: 500,
                message: error.message || '查询订单失败',
                data: null
            };
        }
    }
};
exports.PaymentController = PaymentController;
__decorate([
    (0, common_1.Post)('wechat/create'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "createPayment", null);
__decorate([
    (0, common_1.Post)('wechat/create-order-payment'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "createOrderPayment", null);
__decorate([
    (0, common_1.Post)('wechat/notify'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "paymentNotify", null);
__decorate([
    (0, common_1.Get)('order/:outTradeNo'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "queryOrder", null);
exports.PaymentController = PaymentController = __decorate([
    (0, common_1.Controller)('payment'),
    __metadata("design:paramtypes", [wechat_pay_service_1.WechatPayService])
], PaymentController);
//# sourceMappingURL=payment.controller.js.map