import { StorageService } from '../storage/storage.service';
export declare class MediaService {
    private readonly storageService;
    constructor(storageService: StorageService);
    generateSignedUrl(key: string, expireTime?: number): Promise<string>;
}
