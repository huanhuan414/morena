import { SocialService } from './social.service';
export declare class SocialController {
    private readonly socialService;
    constructor(socialService: SocialService);
    getFollowersAndFollowing(userId: string): Promise<{
        code: number;
        data: {
            followers: {
                id: any;
                nickname: any;
                avatar: any;
                isAi: boolean;
                followedAt: any;
            }[];
            following: {
                id: any;
                nickname: any;
                avatar: any;
                isAi: boolean;
                followedAt: any;
            }[];
        };
        message: string;
    }>;
    createPost(userId: string, postData: Record<string, any>): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getAvatarRelatedPosts(userId: string, page?: string, pageSize?: string): Promise<{
        code: number;
        data: {
            posts: any[];
            total: number;
            page: number;
            pageSize: number;
            stats: {
                postCount: number;
                likeCount: number;
                commentCount: number;
            };
        };
        message: string;
    }>;
    getAvatarTodayStats(userId: string): Promise<{
        code: number;
        data: {
            postCount: number;
            likeCount: number;
            commentCount: number;
            orderCount: number;
            totalEarnings: number;
        };
        message: string;
    }>;
    getAvatarTotalStats(userId: string): Promise<{
        code: number;
        data: {
            postCount: number;
            likeCount: number;
            commentCount: number;
            orderCount: number;
            totalEarnings: number;
        };
        message: string;
    }>;
    getPosts(userId: string, page?: string, pageSize?: string): Promise<{
        code: number;
        data: {
            posts: any[];
            total: number;
            page: number;
            pageSize: number;
        };
        message: string;
    }>;
    getPost(postId: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getPostsByAvatar(avatarId: string, limit?: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
    deletePost(postId: string, userId: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    likePost(postId: string, userId: string, avatarId?: string): Promise<{
        code: number;
        data: {
            liked: boolean;
            avatar_id?: undefined;
        } | {
            liked: boolean;
            avatar_id: string | undefined;
        };
        message: string;
    }>;
    createComment(postId: string, userId: string, content: string, parentId?: string, avatarId?: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getComments(postId: string, page?: string, pageSize?: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
    getLikes(postId: string, page?: string, pageSize?: string): Promise<{
        code: number;
        data: {
            id: any;
            user_id: any;
            avatar_id: any;
            name: any;
            avatar: any;
            is_ai: boolean;
        }[];
        message: string;
    }>;
    followUser(targetUserId: string, userId: string): Promise<{
        code: number;
        data: {
            following: boolean;
        };
        message: string;
    }>;
    getUserPosts(userId: string, page?: string, pageSize?: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
    sharePost(postId: string, userId: string): Promise<{
        code: number;
        data: {
            shared: boolean;
            shares_count: any;
        };
        message: string;
    }>;
    getAllPosts(page?: string, pageSize?: string, sort?: string, filter?: string): Promise<{
        code: number;
        data: {
            posts: any[];
            total: number;
        };
        message: string;
    }>;
    getRelatedPosts(userId: string, page?: string, pageSize?: string): Promise<{
        code: number;
        data: {
            posts: any[];
            total: number;
        };
        message: string;
    }>;
}
