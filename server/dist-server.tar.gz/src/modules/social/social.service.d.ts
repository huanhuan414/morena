export declare class SocialService {
    syncPostCounts(): Promise<{
        synced: number;
    }>;
    getAvatarTodayStats(userId: string): Promise<{
        postCount: number;
        likeCount: number;
        commentCount: number;
        orderCount: number;
        totalEarnings: number;
    }>;
    getAvatarTotalStats(userId: string): Promise<{
        postCount: number;
        likeCount: number;
        commentCount: number;
        orderCount: number;
        totalEarnings: number;
    }>;
    createPost(userId: string, postData: Record<string, any>): Promise<any>;
    private checkAndTriggerFirstPostWelcome;
    private triggerFirstPostWelcome;
    private randomDelay;
    getAvatarRelatedPosts(userId: string, page?: number, pageSize?: number): Promise<{
        posts: any[];
        total: number;
        page: number;
        pageSize: number;
        stats: {
            postCount: number;
            likeCount: number;
            commentCount: number;
        };
    }>;
    private countAvatarPosts;
    getPosts(page?: number, pageSize?: number, userId?: string): Promise<{
        posts: any[];
        total: number;
        page: number;
        pageSize: number;
    }>;
    getPostById(postId: string): Promise<any>;
    deletePost(postId: string, userId: string): Promise<{
        success: boolean;
    }>;
    getPostsByAvatar(avatarId: string, limit?: number): Promise<any[]>;
    likePost(userId: string, postId: string, avatarId?: string): Promise<{
        liked: boolean;
        avatar_id?: undefined;
    } | {
        liked: boolean;
        avatar_id: string | undefined;
    }>;
    createComment(userId: string, postId: string, content: string, parentId?: string, avatarId?: string): Promise<any>;
    getComments(postId: string, page?: number, pageSize?: number): Promise<any[]>;
    getLikes(postId: string, page?: number, pageSize?: number): Promise<{
        id: any;
        user_id: any;
        avatar_id: any;
        name: any;
        avatar: any;
        is_ai: boolean;
    }[]>;
    getFollowersAndFollowing(userId: string): Promise<{
        followers: {
            id: any;
            nickname: any;
            avatar: any;
            isAi: boolean;
            followedAt: any;
        }[];
        following: {
            id: any;
            nickname: any;
            avatar: any;
            isAi: boolean;
            followedAt: any;
        }[];
    }>;
    followUser(userId: string, targetUserId: string): Promise<{
        following: boolean;
    }>;
    getUserPosts(userId: string, page?: number, pageSize?: number): Promise<any[]>;
    sharePost(userId: string, postId: string): Promise<{
        shared: boolean;
        shares_count: any;
    }>;
    getAllPosts(page?: number, pageSize?: number, sort?: string, filter?: string): Promise<{
        posts: any[];
        total: number;
    }>;
    getRelatedPosts(userId: string, page?: number, pageSize?: number): Promise<{
        posts: any[];
        total: number;
    }>;
}
