"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
let SocialService = class SocialService {
    async syncPostCounts() {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: posts } = await client.from('posts').select('id');
        if (posts && posts.length > 0) {
            for (const post of posts) {
                const { count: likeCount } = await client
                    .from('likes')
                    .select('id', { count: 'exact', head: true })
                    .eq('target_type', 'post')
                    .eq('target_id', post.id);
                const { count: commentCount } = await client
                    .from('comments')
                    .select('id', { count: 'exact', head: true })
                    .eq('post_id', post.id);
                await client
                    .from('posts')
                    .update({
                    likes_count: likeCount || 0,
                    comments_count: commentCount || 0
                })
                    .eq('id', post.id);
            }
        }
        console.log('[社交服务] 帖子计数同步完成');
        return { synced: posts?.length || 0 };
    }
    async getAvatarTodayStats(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayStart = today.toISOString();
        const { data: avatars } = await client
            .from('avatars')
            .select('id')
            .eq('user_id', userId);
        const avatarIds = avatars?.map(a => a.id) || [];
        let postCount = 0;
        if (avatarIds.length > 0) {
            const { count } = await client
                .from('posts')
                .select('id', { count: 'exact', head: true })
                .in('avatar_id', avatarIds)
                .gte('created_at', todayStart);
            postCount = count || 0;
        }
        let likeCount = 0;
        if (avatarIds.length > 0) {
            const { count } = await client
                .from('likes')
                .select('id', { count: 'exact', head: true })
                .in('avatar_id', avatarIds)
                .eq('target_type', 'post')
                .gte('created_at', todayStart);
            likeCount = count || 0;
        }
        let commentCount = 0;
        if (avatarIds.length > 0) {
            const { count } = await client
                .from('comments')
                .select('id', { count: 'exact', head: true })
                .in('avatar_id', avatarIds)
                .gte('created_at', todayStart);
            commentCount = count || 0;
        }
        let orderCount = 0;
        const { count: completedOrders } = await client
            .from('orders')
            .select('id', { count: 'exact', head: true })
            .in('avatar_id', avatarIds)
            .eq('status', 'completed')
            .gte('completed_at', todayStart);
        orderCount = completedOrders || 0;
        let totalEarnings = 0;
        const { data: earnings } = await client
            .from('earnings')
            .select('amount')
            .eq('user_id', userId)
            .eq('status', 'completed')
            .gte('created_at', todayStart);
        if (earnings && earnings.length > 0) {
            totalEarnings = earnings.reduce((sum, e) => sum + Number(e.amount || 0), 0);
        }
        return {
            postCount,
            likeCount,
            commentCount,
            orderCount,
            totalEarnings
        };
    }
    async getAvatarTotalStats(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: avatars } = await client
            .from('avatars')
            .select('id')
            .eq('user_id', userId);
        const avatarIds = avatars?.map(a => a.id) || [];
        let postCount = 0;
        if (avatarIds.length > 0) {
            const { count } = await client
                .from('posts')
                .select('id', { count: 'exact', head: true })
                .in('avatar_id', avatarIds);
            postCount = count || 0;
        }
        let likeCount = 0;
        if (avatarIds.length > 0) {
            const { count } = await client
                .from('likes')
                .select('id', { count: 'exact', head: true })
                .in('avatar_id', avatarIds)
                .eq('target_type', 'post');
            likeCount = count || 0;
        }
        let commentCount = 0;
        if (avatarIds.length > 0) {
            const { count } = await client
                .from('comments')
                .select('id', { count: 'exact', head: true })
                .in('avatar_id', avatarIds);
            commentCount = count || 0;
        }
        let orderCount = 0;
        const { count: completedOrders } = await client
            .from('orders')
            .select('id', { count: 'exact', head: true })
            .in('avatar_id', avatarIds)
            .eq('status', 'completed');
        orderCount = completedOrders || 0;
        let totalEarnings = 0;
        const { data: earnings } = await client
            .from('earnings')
            .select('amount')
            .eq('user_id', userId)
            .eq('status', 'completed');
        if (earnings && earnings.length > 0) {
            totalEarnings = earnings.reduce((sum, e) => sum + Number(e.amount || 0), 0);
        }
        return {
            postCount,
            likeCount,
            commentCount,
            orderCount,
            totalEarnings
        };
    }
    async createPost(userId, postData) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data, error } = await client
            .from('posts')
            .insert({
            user_id: userId,
            avatar_id: postData.avatar_id,
            content: postData.content,
            images: postData.images || [],
            videos: postData.videos || [],
            tags: postData.tags || [],
            is_public: postData.is_public ?? true
        })
            .select()
            .single();
        if (error) {
            throw new Error(`发布动态失败: ${error.message}`);
        }
        this.checkAndTriggerFirstPostWelcome(data, postData.avatar_id).catch(error => {
            console.error('[SocialService] 首次发帖欢迎机制执行失败:', error);
        });
        return data;
    }
    async checkAndTriggerFirstPostWelcome(post, avatarId) {
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { count, error } = await client
                .from('posts')
                .select('*', { count: 'exact', head: true })
                .eq('avatar_id', avatarId);
            if (error) {
                console.error('[首次发帖欢迎] 查询帖子数量失败:', error);
                return;
            }
            if (count === 1) {
                console.log(`[首次发帖欢迎] 分身 ${avatarId} 发布了第一个帖子，触发欢迎机制`);
                await this.triggerFirstPostWelcome(post, avatarId);
            }
        }
        catch (error) {
            console.error('[首次发帖欢迎] 检查失败:', error);
        }
    }
    async triggerFirstPostWelcome(post, avatarId) {
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data: posterAvatar, error: posterError } = await client
                .from('avatars')
                .select('*')
                .eq('id', avatarId)
                .single();
            if (posterError || !posterAvatar) {
                console.error('[首次发帖欢迎] 获取发帖分身信息失败');
                return;
            }
            const { data: otherAvatars, error } = await client
                .from('avatars')
                .select('*')
                .eq('status', 'active')
                .neq('id', avatarId)
                .limit(30);
            if (error || !otherAvatars || otherAvatars.length === 0) {
                console.log('[首次发帖欢迎] 没有其他分身可以参与欢迎');
                return;
            }
            const participantCount = Math.min(otherAvatars.length, Math.floor(Math.random() * 71) + 80);
            const participants = otherAvatars
                .sort(() => Math.random() - 0.5)
                .slice(0, participantCount);
            console.log(`[首次发帖欢迎] 选择 ${participants.length} 个分身来点赞评论（目标80-150个）`);
            for (const participant of participants) {
                try {
                    await this.randomDelay(500, 3000);
                    if (Math.random() < 0.8) {
                        await client
                            .from('likes')
                            .insert({
                            avatar_id: participant.id,
                            target_id: post.id,
                            target_type: 'post'
                        });
                        console.log(`[首次发帖欢迎] ${participant.name} 点赞了帖子`);
                    }
                    if (Math.random() < 0.6) {
                        const comments = [
                            '欢迎来到社区！',
                            '第一条动态，加油！',
                            '期待看到更多精彩内容！',
                            '新朋友你好呀！',
                            '支持一下！',
                            '太棒了，欢迎加入！',
                            '很有意思的内容！',
                            '新朋友，多多交流！',
                            '关注了，期待后续！',
                            '欢迎来到我们的大家庭！'
                        ];
                        const randomComment = comments[Math.floor(Math.random() * comments.length)];
                        await client
                            .from('comments')
                            .insert({
                            avatar_id: participant.id,
                            post_id: post.id,
                            content: randomComment
                        });
                        console.log(`[首次发帖欢迎] ${participant.name} 评论了帖子: ${randomComment}`);
                    }
                }
                catch (error) {
                    console.error(`[首次发帖欢迎] ${participant.name} 参与失败:`, error);
                }
            }
            console.log(`[首次发帖欢迎] 分身 ${posterAvatar.name} 的首次发帖欢迎完成`);
        }
        catch (error) {
            console.error('[首次发帖欢迎] 执行失败:', error);
        }
    }
    randomDelay(min, max) {
        const delay = Math.floor(Math.random() * (max - min + 1)) + min;
        return new Promise(resolve => setTimeout(resolve, delay));
    }
    async getAvatarRelatedPosts(userId, page = 1, pageSize = 20) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const offset = (page - 1) * pageSize;
        const { data: avatars, error: avatarError } = await client
            .from('avatars')
            .select('id')
            .eq('user_id', userId);
        if (avatarError) {
            throw new Error(`获取分身列表失败: ${avatarError.message}`);
        }
        const avatarIds = avatars?.map(a => a.id) || [];
        if (avatarIds.length === 0) {
            return {
                posts: [],
                total: 0,
                page,
                pageSize,
                stats: { postCount: 0, likeCount: 0, commentCount: 0 }
            };
        }
        const { data: likes } = await client
            .from('likes')
            .select('target_id')
            .in('avatar_id', avatarIds)
            .eq('target_type', 'post');
        const likedPostIds = likes?.map(l => l.target_id) || [];
        const { data: comments } = await client
            .from('comments')
            .select('post_id')
            .in('avatar_id', avatarIds);
        const commentedPostIds = comments?.map(c => c.post_id) || [];
        const allRelatedPostIds = [...new Set([
                ...likedPostIds,
                ...commentedPostIds
            ])];
        const limitedAvatarIds = avatarIds.slice(0, 50);
        const limitedLikedPostIds = likedPostIds.slice(0, 100);
        const limitedCommentedPostIds = commentedPostIds.slice(0, 100);
        let ownedPosts = [];
        if (limitedAvatarIds.length > 0) {
            const { data, error } = await client
                .from('posts')
                .select('*')
                .eq('is_public', true)
                .in('avatar_id', limitedAvatarIds)
                .order('created_at', { ascending: false })
                .limit(100);
            if (error) {
                throw new Error(`获取分身发布帖子失败: ${error.message}`);
            }
            ownedPosts = data || [];
        }
        let likedPosts = [];
        if (limitedLikedPostIds.length > 0) {
            const batchSize = 20;
            const batches = [];
            for (let i = 0; i < limitedLikedPostIds.length; i += batchSize) {
                batches.push(limitedLikedPostIds.slice(i, i + batchSize));
            }
            for (const batch of batches) {
                const { data, error } = await client
                    .from('posts')
                    .select('*')
                    .eq('is_public', true)
                    .in('id', batch)
                    .order('created_at', { ascending: false });
                if (error) {
                    console.error('获取点赞帖子批次失败:', error);
                    continue;
                }
                likedPosts.push(...(data || []));
            }
        }
        let commentedPosts = [];
        if (limitedCommentedPostIds.length > 0) {
            const batchSize = 20;
            const batches = [];
            for (let i = 0; i < limitedCommentedPostIds.length; i += batchSize) {
                batches.push(limitedCommentedPostIds.slice(i, i + batchSize));
            }
            for (const batch of batches) {
                const { data, error } = await client
                    .from('posts')
                    .select('*')
                    .eq('is_public', true)
                    .in('id', batch)
                    .order('created_at', { ascending: false });
                if (error) {
                    console.error('获取评论帖子批次失败:', error);
                    continue;
                }
                commentedPosts.push(...(data || []));
            }
        }
        const allPosts = [...ownedPosts, ...likedPosts, ...commentedPosts];
        const uniquePosts = Array.from(new Map(allPosts.map(p => [p.id, p])).values());
        uniquePosts.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        const total = uniquePosts.length;
        const paginatedPosts = uniquePosts.slice(offset, offset + pageSize);
        const postsWithLikers = await Promise.all((paginatedPosts || []).map(async (post) => {
            const { data: likes } = await client
                .from('likes')
                .select('id, user_id, avatar_id')
                .eq('target_type', 'post')
                .eq('target_id', post.id)
                .limit(5);
            const likers = await Promise.all((likes || []).map(async (like) => {
                let name = '匿名';
                let avatar = '';
                if (like.avatar_id) {
                    const { data: avatarData } = await client
                        .from('avatars')
                        .select('name, avatar_url')
                        .eq('id', like.avatar_id)
                        .single();
                    if (avatarData) {
                        name = avatarData.name;
                        avatar = avatarData.avatar_url;
                    }
                }
                else if (like.user_id) {
                    const { data: userData } = await client
                        .from('users')
                        .select('nickname, avatar')
                        .eq('id', like.user_id)
                        .single();
                    if (userData) {
                        name = userData.nickname;
                        avatar = userData.avatar;
                    }
                }
                return {
                    id: like.id,
                    user_id: like.user_id,
                    avatar_id: like.avatar_id,
                    name,
                    avatar,
                    is_ai: !!like.avatar_id
                };
            }));
            let isLiked = false;
            if (avatarIds.length > 0) {
                const { data: userLike } = await client
                    .from('likes')
                    .select('id')
                    .eq('target_type', 'post')
                    .eq('target_id', post.id)
                    .in('avatar_id', avatarIds)
                    .maybeSingle();
                if (userLike)
                    isLiked = true;
            }
            if (!isLiked) {
                const { data: userLike } = await client
                    .from('likes')
                    .select('id')
                    .eq('target_type', 'post')
                    .eq('target_id', post.id)
                    .eq('user_id', userId)
                    .is('avatar_id', null)
                    .maybeSingle();
                if (userLike)
                    isLiked = true;
            }
            let authorName = '匿名';
            let authorAvatar = '';
            if (post.avatar_id) {
                const { data: avatarData } = await client
                    .from('avatars')
                    .select('name, avatar_url')
                    .eq('id', post.avatar_id)
                    .single();
                if (avatarData) {
                    authorName = avatarData.name;
                    authorAvatar = avatarData.avatar_url;
                }
            }
            else if (post.user_id) {
                const { data: userData } = await client
                    .from('users')
                    .select('nickname, avatar')
                    .eq('id', post.user_id)
                    .single();
                if (userData) {
                    authorName = userData.nickname;
                    authorAvatar = userData.avatar;
                }
            }
            return {
                ...post,
                author_name: authorName,
                author_avatar: authorAvatar,
                likers,
                is_liked: isLiked
            };
        }));
        const stats = {
            postCount: avatarIds.length > 0 ? await this.countAvatarPosts(avatarIds) : 0,
            likeCount: likedPostIds.length,
            commentCount: comments?.length || 0
        };
        return {
            posts: postsWithLikers || [],
            total: total || 0,
            page,
            pageSize,
            stats
        };
    }
    async countAvatarPosts(avatarIds) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { count } = await client
            .from('posts')
            .select('id', { count: 'exact', head: true })
            .in('avatar_id', avatarIds);
        return count || 0;
    }
    async getPosts(page = 1, pageSize = 20, userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const offset = (page - 1) * pageSize;
        const { data, error, count } = await client
            .from('posts')
            .select('*', { count: 'exact' })
            .eq('is_public', true)
            .order('created_at', { ascending: false })
            .range(offset, offset + pageSize - 1);
        if (error) {
            throw new Error(`获取动态列表失败: ${error.message}`);
        }
        const postsWithAuthors = await Promise.all((data || []).map(async (post) => {
            let authorName = '匿名';
            let authorAvatar = '';
            if (post.avatar_id) {
                const { data: avatarData } = await client
                    .from('avatars')
                    .select('name, avatar_url')
                    .eq('id', post.avatar_id)
                    .single();
                if (avatarData) {
                    authorName = avatarData.name;
                    authorAvatar = avatarData.avatar_url;
                }
            }
            else if (post.user_id) {
                const { data: userData } = await client
                    .from('users')
                    .select('nickname, avatar')
                    .eq('id', post.user_id)
                    .single();
                if (userData) {
                    authorName = userData.nickname;
                    authorAvatar = userData.avatar;
                }
            }
            return {
                ...post,
                author_name: authorName,
                author_avatar: authorAvatar
            };
        }));
        let postsWithLikeStatus = postsWithAuthors;
        if (userId) {
            const { data: userAvatars } = await client
                .from('avatars')
                .select('id')
                .eq('user_id', userId);
            const avatarIds = userAvatars?.map(a => a.id) || [];
            const postIds = postsWithAuthors.map(p => p.id);
            if (postIds.length > 0) {
                let likesQuery = client
                    .from('likes')
                    .select('target_id')
                    .eq('target_type', 'post')
                    .in('target_id', postIds);
                if (avatarIds.length > 0) {
                    likesQuery = likesQuery.or(`user_id.eq.${userId},avatar_id.in.(${avatarIds.join(',')})`);
                }
                else {
                    likesQuery = likesQuery.eq('user_id', userId);
                }
                const { data: likes } = await likesQuery;
                const likedPostIds = new Set(likes?.map(l => l.target_id) || []);
                postsWithLikeStatus = postsWithAuthors.map(post => ({
                    ...post,
                    is_liked: likedPostIds.has(post.id)
                }));
            }
        }
        return {
            posts: postsWithLikeStatus,
            total: count || 0,
            page,
            pageSize
        };
    }
    async getPostById(postId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data, error } = await client
            .from('posts')
            .select('*')
            .eq('id', postId)
            .single();
        if (error) {
            throw new Error(`获取动态详情失败: ${error.message}`);
        }
        let authorName = '匿名';
        let authorAvatar = '';
        if (data.avatar_id) {
            const { data: avatarData } = await client
                .from('avatars')
                .select('name, avatar_url')
                .eq('id', data.avatar_id)
                .single();
            if (avatarData) {
                authorName = avatarData.name;
                authorAvatar = avatarData.avatar_url;
            }
        }
        else if (data.user_id) {
            const { data: userData } = await client
                .from('users')
                .select('nickname, avatar')
                .eq('id', data.user_id)
                .single();
            if (userData) {
                authorName = userData.nickname;
                authorAvatar = userData.avatar;
            }
        }
        return {
            ...data,
            author_name: authorName,
            author_avatar: authorAvatar
        };
    }
    async deletePost(postId, userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { error } = await client
            .from('posts')
            .delete()
            .eq('id', postId)
            .eq('user_id', userId);
        if (error) {
            throw new Error(`删除动态失败: ${error.message}`);
        }
        return { success: true };
    }
    async getPostsByAvatar(avatarId, limit = 10) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: posts, error } = await client
            .from('posts')
            .select('*')
            .eq('avatar_id', avatarId)
            .order('created_at', { ascending: false })
            .limit(limit);
        if (error) {
            throw new Error(`获取帖子列表失败: ${error.message}`);
        }
        if (!posts || posts.length === 0) {
            return [];
        }
        const postIds = posts.map(p => p.id);
        const { data: comments } = await client
            .from('comments')
            .select('id, content, post_id, avatar_id, created_at')
            .in('post_id', postIds)
            .order('created_at', { ascending: false })
            .limit(20);
        const commentAvatarIds = comments?.map(c => c.avatar_id).filter(Boolean) || [];
        let commentAvatars = {};
        if (commentAvatarIds.length > 0) {
            const { data: avatars } = await client
                .from('avatars')
                .select('id, name, avatar_url')
                .in('id', [...new Set(commentAvatarIds)]);
            avatars?.forEach(a => {
                commentAvatars[a.id] = a;
            });
        }
        const commentsByPostId = {};
        comments?.forEach(comment => {
            if (!commentsByPostId[comment.post_id]) {
                commentsByPostId[comment.post_id] = [];
            }
            if (commentsByPostId[comment.post_id].length < 2) {
                commentsByPostId[comment.post_id].push({
                    id: comment.id,
                    content: comment.content,
                    avatar_name: comment.avatar_id ? commentAvatars[comment.avatar_id]?.name : '匿名',
                    avatar_url: comment.avatar_id ? commentAvatars[comment.avatar_id]?.avatar_url : ''
                });
            }
        });
        return posts.map(post => ({
            ...post,
            recent_comments: commentsByPostId[post.id] || []
        }));
    }
    async likePost(userId, postId, avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: userAvatars } = await client
            .from('avatars')
            .select('id')
            .eq('user_id', userId);
        const avatarIds = userAvatars?.map(a => a.id) || [];
        let existingLikes = [];
        if (avatarIds.length > 0) {
            const { data } = await client
                .from('likes')
                .select('id')
                .eq('target_type', 'post')
                .eq('target_id', postId)
                .in('avatar_id', avatarIds);
            existingLikes = data || [];
        }
        const { data: userOwnLikes } = await client
            .from('likes')
            .select('id')
            .eq('target_type', 'post')
            .eq('target_id', postId)
            .eq('user_id', userId)
            .is('avatar_id', null);
        if (userOwnLikes && userOwnLikes.length > 0) {
            existingLikes = [...existingLikes, ...userOwnLikes];
        }
        if (existingLikes.length > 0) {
            for (const like of existingLikes) {
                await client.from('likes').delete().eq('id', like.id);
            }
            const { data: post } = await client
                .from('posts')
                .select('likes_count')
                .eq('id', postId)
                .single();
            const newCount = Math.max(0, (post?.likes_count || existingLikes.length) - existingLikes.length);
            await client
                .from('posts')
                .update({ likes_count: newCount })
                .eq('id', postId);
            return { liked: false };
        }
        else {
            let finalAvatarId = avatarId;
            if (!finalAvatarId && avatarIds.length > 0) {
                finalAvatarId = avatarIds[0];
            }
            await client.from('likes').insert({
                user_id: userId,
                avatar_id: finalAvatarId || null,
                target_type: 'post',
                target_id: postId
            });
            const { data: post } = await client
                .from('posts')
                .select('likes_count')
                .eq('id', postId)
                .single();
            await client
                .from('posts')
                .update({ likes_count: (post?.likes_count || 0) + 1 })
                .eq('id', postId);
            return { liked: true, avatar_id: finalAvatarId };
        }
    }
    async createComment(userId, postId, content, parentId, avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        let finalAvatarId = avatarId;
        if (!finalAvatarId) {
            const { data: userAvatars } = await client
                .from('avatars')
                .select('id')
                .eq('user_id', userId)
                .limit(1);
            if (userAvatars && userAvatars.length > 0) {
                finalAvatarId = userAvatars[0].id;
            }
        }
        const { data, error } = await client
            .from('comments')
            .insert({
            post_id: postId,
            user_id: userId,
            avatar_id: finalAvatarId || null,
            content,
            parent_id: parentId
        })
            .select('*, users(nickname, avatar), avatars(name, avatar_url)')
            .single();
        if (error) {
            throw new Error(`发布评论失败: ${error.message}`);
        }
        const { data: post } = await client
            .from('posts')
            .select('comments_count')
            .eq('id', postId)
            .single();
        await client
            .from('posts')
            .update({ comments_count: (post?.comments_count || 0) + 1 })
            .eq('id', postId);
        return data;
    }
    async getComments(postId, page = 1, pageSize = 20) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const offset = (page - 1) * pageSize;
        const { data, error } = await client
            .from('comments')
            .select('*')
            .eq('post_id', postId)
            .is('parent_id', null)
            .order('created_at', { ascending: false })
            .range(offset, offset + pageSize - 1);
        if (error) {
            throw new Error(`获取评论失败: ${error.message}`);
        }
        const commentsWithAuthors = await Promise.all((data || []).map(async (comment) => {
            let authorName = '匿名';
            let authorAvatar = '';
            if (comment.avatar_id) {
                const { data: avatar } = await client
                    .from('avatars')
                    .select('name, avatar_url')
                    .eq('id', comment.avatar_id)
                    .single();
                if (avatar) {
                    authorName = avatar.name;
                    authorAvatar = avatar.avatar_url;
                }
            }
            else if (comment.user_id) {
                const { data: user } = await client
                    .from('users')
                    .select('nickname, avatar')
                    .eq('id', comment.user_id)
                    .single();
                if (user) {
                    authorName = user.nickname;
                    authorAvatar = user.avatar;
                }
            }
            return {
                ...comment,
                author_name: authorName,
                author_avatar: authorAvatar
            };
        }));
        return commentsWithAuthors;
    }
    async getLikes(postId, page = 1, pageSize = 20) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const offset = (page - 1) * pageSize;
        const { data: likes, error } = await client
            .from('likes')
            .select('id, user_id, avatar_id')
            .eq('target_type', 'post')
            .eq('target_id', postId)
            .order('created_at', { ascending: false })
            .range(offset, offset + pageSize - 1);
        if (error) {
            throw new Error(`获取点赞列表失败: ${error.message}`);
        }
        if (!likes || likes.length === 0) {
            return [];
        }
        const userIds = likes.filter(l => l.user_id).map(l => l.user_id);
        const avatarIds = likes.filter(l => l.avatar_id).map(l => l.avatar_id);
        const [usersResult, avatarsResult] = await Promise.all([
            userIds.length > 0
                ? client.from('users').select('id, nickname, avatar').in('id', userIds)
                : { data: [] },
            avatarIds.length > 0
                ? client.from('avatars').select('id, name, avatar_url').in('id', avatarIds)
                : { data: [] }
        ]);
        const usersMap = new Map((usersResult.data || []).map((u) => [u.id, u]));
        const avatarsMap = new Map((avatarsResult.data || []).map((a) => [a.id, a]));
        return likes.map(like => {
            const user = usersMap.get(like.user_id);
            const avatar = avatarsMap.get(like.avatar_id);
            return {
                id: like.id,
                user_id: like.user_id,
                avatar_id: like.avatar_id,
                name: avatar?.name || user?.nickname || '匿名',
                avatar: avatar?.avatar_url || user?.avatar,
                is_ai: !!like.avatar_id
            };
        });
    }
    async getFollowersAndFollowing(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: followersData, error: followersError } = await client
            .from('follows')
            .select('follower_id, created_at')
            .eq('following_id', userId)
            .order('created_at', { ascending: false });
        if (followersError) {
            throw new Error(`获取粉丝列表失败: ${followersError.message}`);
        }
        const { data: followingData, error: followingError } = await client
            .from('follows')
            .select('following_id, created_at')
            .eq('follower_id', userId)
            .order('created_at', { ascending: false });
        if (followingError) {
            throw new Error(`获取关注列表失败: ${followingError.message}`);
        }
        const followerIds = (followersData || []).map((item) => item.follower_id);
        const { data: followerUsers } = followerIds.length > 0
            ? await client.from('users').select('id, nickname, avatar_url').in('id', followerIds)
            : { data: [] };
        const followingIds = (followingData || []).map((item) => item.following_id);
        const { data: followingUsers } = followingIds.length > 0
            ? await client.from('users').select('id, nickname, avatar_url').in('id', followingIds)
            : { data: [] };
        const userMap = new Map();
        (followerUsers || []).forEach((u) => userMap.set(u.id, u));
        (followingUsers || []).forEach((u) => userMap.set(u.id, u));
        const followers = (followersData || []).map((item) => {
            const user = userMap.get(item.follower_id) || {};
            return {
                id: item.follower_id,
                nickname: user.nickname || '未知用户',
                avatar: user.avatar_url,
                isAi: false,
                followedAt: item.created_at
            };
        });
        const following = (followingData || []).map((item) => {
            const user = userMap.get(item.following_id) || {};
            return {
                id: item.following_id,
                nickname: user.nickname || '未知用户',
                avatar: user.avatar_url,
                isAi: false,
                followedAt: item.created_at
            };
        });
        return { followers, following };
    }
    async followUser(userId, targetUserId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        if (userId === targetUserId) {
            throw new Error('不能关注自己');
        }
        const { data: existingFollow } = await client
            .from('follows')
            .select('id')
            .eq('follower_id', userId)
            .eq('following_id', targetUserId)
            .maybeSingle();
        if (existingFollow) {
            await client.from('follows').delete().eq('id', existingFollow.id);
            return { following: false };
        }
        else {
            await client.from('follows').insert({
                follower_id: userId,
                following_id: targetUserId
            });
            return { following: true };
        }
    }
    async getUserPosts(userId, page = 1, pageSize = 20) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const offset = (page - 1) * pageSize;
        const { data, error } = await client
            .from('posts')
            .select('*, avatars(name, avatar_url)')
            .eq('user_id', userId)
            .order('created_at', { ascending: false })
            .range(offset, offset + pageSize - 1);
        if (error) {
            throw new Error(`获取用户动态失败: ${error.message}`);
        }
        return data;
    }
    async sharePost(userId, postId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: post } = await client
            .from('posts')
            .select('shares_count')
            .eq('id', postId)
            .single();
        await client
            .from('posts')
            .update({ shares_count: (post?.shares_count || 0) + 1 })
            .eq('id', postId);
        return { shared: true, shares_count: (post?.shares_count || 0) + 1 };
    }
    async getAllPosts(page = 1, pageSize = 20, sort, filter) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const offset = (page - 1) * pageSize;
        let postsQuery = client.from('posts').select('*');
        let countQuery = client.from('posts').select('*', { count: 'exact', head: true });
        if (filter && filter !== 'all') {
            const tagMap = {
                'female': ['美妆', '护肤', '种草', '闺蜜'],
                'male': ['健身', '运动', '职场'],
                'landscape': ['风景', '旅行', '摄影', '日常'],
                'food': ['美食', '烹饪', '吃货'],
                'study': ['学习', '编程', '读书', '成长'],
                'life': ['生活', '日常', '好物推荐']
            };
            const keywords = tagMap[filter];
            if (keywords && keywords.length > 0) {
                const searchPattern = keywords.join('|');
                postsQuery = postsQuery.textSearch('tags', searchPattern);
                countQuery = countQuery.textSearch('tags', searchPattern);
            }
        }
        const { count } = await countQuery;
        if (sort === 'hot') {
            postsQuery = postsQuery.order('likes_count', { ascending: false });
        }
        else {
            postsQuery = postsQuery.order('created_at', { ascending: false });
        }
        const { data, error } = await postsQuery.range(offset, offset + pageSize - 1);
        if (error) {
            console.error('获取所有帖子失败:', error);
            return { posts: [], total: 0 };
        }
        const postsWithAuthors = await Promise.all((data || []).map(async (post) => {
            let authorName = '匿名';
            let authorAvatar = '';
            if (post.avatar_id) {
                const { data: avatar } = await client
                    .from('avatars')
                    .select('name, avatar_url')
                    .eq('id', post.avatar_id)
                    .single();
                if (avatar) {
                    authorName = avatar.name;
                    authorAvatar = avatar.avatar_url;
                }
            }
            else if (post.user_id) {
                const { data: user } = await client
                    .from('users')
                    .select('nickname, avatar')
                    .eq('id', post.user_id)
                    .single();
                if (user) {
                    authorName = user.nickname;
                    authorAvatar = user.avatar;
                }
            }
            const { data: likers } = await client
                .from('post_likes')
                .select('user_id, users!inner(nickname, avatar)')
                .eq('post_id', post.id)
                .limit(3);
            const likersList = likers?.map((like) => ({
                user_id: like.user_id,
                nickname: like.users?.nickname || '用户',
                avatar: like.users?.avatar || ''
            })) || [];
            const { data: comments } = await client
                .from('post_comments')
                .select('user_id, content, users!inner(nickname, avatar)')
                .eq('post_id', post.id)
                .order('created_at', { ascending: false })
                .limit(2);
            const commentsList = comments?.map((comment) => ({
                user_id: comment.user_id,
                nickname: comment.users?.nickname || '用户',
                user_avatar: comment.users?.avatar || '',
                content: comment.content
            })) || [];
            return {
                ...post,
                author_name: authorName,
                author_avatar: authorAvatar,
                likers: likersList,
                comments: commentsList
            };
        }));
        return {
            posts: postsWithAuthors,
            total: count || 0
        };
    }
    async getRelatedPosts(userId, page = 1, pageSize = 20) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        try {
            const { data: userAvatars } = await client
                .from('avatars')
                .select('id, name, avatar_url')
                .eq('user_id', userId);
            const avatarIds = userAvatars?.map(a => a.id) || [];
            if (avatarIds.length === 0) {
                return { posts: [], total: 0 };
            }
            const { data: myPosts } = await client
                .from('posts')
                .select('*')
                .in('avatar_id', avatarIds)
                .order('created_at', { ascending: false });
            const { data: myComments } = await client
                .from('post_comments')
                .select('post_id, content, created_at')
                .in('avatar_id', avatarIds)
                .order('created_at', { ascending: false });
            const commentedPostIds = [...new Set(myComments?.map(c => c.post_id) || [])];
            const { data: myLikes } = await client
                .from('post_likes')
                .select('post_id, created_at')
                .in('avatar_id', avatarIds)
                .order('created_at', { ascending: false });
            const likedPostIds = [...new Set(myLikes?.map(l => l.post_id) || [])];
            const relatedPostIds = [...new Set([...commentedPostIds, ...likedPostIds])];
            let relatedPosts = [];
            if (relatedPostIds.length > 0) {
                const { data: posts } = await client
                    .from('posts')
                    .select('*')
                    .in('id', relatedPostIds);
                relatedPosts = posts || [];
            }
            const allActivities = [];
            myPosts?.forEach(post => {
                allActivities.push({
                    ...post,
                    activity_type: 'published',
                    activity_text: '发布了帖子'
                });
            });
            myComments?.forEach(comment => {
                const post = relatedPosts.find(p => p.id === comment.post_id);
                if (post) {
                    allActivities.push({
                        ...post,
                        activity_type: 'commented',
                        activity_text: `评论：${comment.content.substring(0, 30)}${comment.content.length > 30 ? '...' : ''}`,
                        activity_time: comment.created_at
                    });
                }
            });
            myLikes?.forEach(like => {
                const exists = allActivities.find(a => a.id === like.post_id &&
                    (a.activity_type === 'commented' || a.activity_type === 'liked'));
                if (!exists) {
                    const post = relatedPosts.find(p => p.id === like.post_id);
                    if (post) {
                        allActivities.push({
                            ...post,
                            activity_type: 'liked',
                            activity_text: '点赞了帖子',
                            activity_time: like.created_at
                        });
                    }
                }
            });
            allActivities.sort((a, b) => {
                const timeA = new Date(a.activity_time || a.created_at).getTime();
                const timeB = new Date(b.activity_time || b.created_at).getTime();
                return timeB - timeA;
            });
            const total = allActivities.length;
            const offset = (page - 1) * pageSize;
            const paginatedActivities = allActivities.slice(offset, offset + pageSize);
            const postsWithAuthors = await Promise.all(paginatedActivities.map(async (post) => {
                let authorName = '匿名';
                let authorAvatar = '';
                if (post.avatar_id) {
                    const { data: avatar } = await client
                        .from('avatars')
                        .select('name, avatar_url')
                        .eq('id', post.avatar_id)
                        .single();
                    if (avatar) {
                        authorName = avatar.name;
                        authorAvatar = avatar.avatar_url;
                    }
                }
                return {
                    ...post,
                    author_name: authorName,
                    author_avatar: authorAvatar
                };
            }));
            return {
                posts: postsWithAuthors,
                total
            };
        }
        catch (error) {
            console.error('获取与我相关的动态失败:', error);
            return { posts: [], total: 0 };
        }
    }
};
exports.SocialService = SocialService;
exports.SocialService = SocialService = __decorate([
    (0, common_1.Injectable)()
], SocialService);
//# sourceMappingURL=social.service.js.map