export declare class VideoService {
    generateMorinaPromoVideo(duration: number, ratio: string, headers: Record<string, string>): Promise<{
        success: boolean;
        videoUrl: string | null;
        taskId: string;
        duration: number;
        ratio: string;
        resolution: string;
    }>;
}
