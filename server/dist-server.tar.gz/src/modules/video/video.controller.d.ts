import { VideoService } from './video.service';
export declare class VideoController {
    private readonly videoService;
    constructor(videoService: VideoService);
    generatePromoVideo(body: {
        duration?: number;
        ratio?: string;
    }, headers: Record<string, string>): Promise<{
        success: boolean;
        videoUrl: string | null;
        taskId: string;
        duration: number;
        ratio: string;
        resolution: string;
    }>;
}
