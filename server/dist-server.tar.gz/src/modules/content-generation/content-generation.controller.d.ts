import { ContentGenerationService } from './content-generation.service';
import { GeneratedContent } from './types';
export declare class ContentGenerationController {
    private readonly contentGenerationService;
    constructor(contentGenerationService: ContentGenerationService);
    generateContent(body: {
        orderId: string;
        requestId: string;
        avatarId: string;
        orderTitle: string;
        orderDescription: string;
        platforms: string[];
        contentType: string;
        targetAudience: string;
        avatarName?: string;
        avatarPersonality?: string;
    }): Promise<{
        code: number;
        message: string;
        data: GeneratedContent[];
        error?: undefined;
    } | {
        code: number;
        message: string;
        error: any;
        data?: undefined;
    }>;
    getGeneratedContent(requestId: string, avatarId: string): Promise<{
        code: number;
        message: string;
        data: GeneratedContent[];
        error?: undefined;
    } | {
        code: number;
        message: string;
        error: any;
        data?: undefined;
    }>;
    updateContentStatus(contentId: string, body: {
        status: 'draft' | 'approved' | 'published';
    }): Promise<{
        code: number;
        message: string;
        error?: undefined;
    } | {
        code: number;
        message: string;
        error: any;
    }>;
}
