"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentGenerationController = void 0;
const common_1 = require("@nestjs/common");
const content_generation_service_1 = require("./content-generation.service");
let ContentGenerationController = class ContentGenerationController {
    constructor(contentGenerationService) {
        this.contentGenerationService = contentGenerationService;
    }
    async generateContent(body) {
        try {
            const result = await this.contentGenerationService.generateContent(body);
            return {
                code: 200,
                message: '内容生成成功',
                data: result
            };
        }
        catch (error) {
            return {
                code: 500,
                message: '内容生成失败',
                error: error.message
            };
        }
    }
    async getGeneratedContent(requestId, avatarId) {
        try {
            const content = await this.contentGenerationService.getGeneratedContent(requestId, avatarId);
            return {
                code: 200,
                message: '获取成功',
                data: content
            };
        }
        catch (error) {
            return {
                code: 500,
                message: '获取失败',
                error: error.message
            };
        }
    }
    async updateContentStatus(contentId, body) {
        try {
            await this.contentGenerationService.updateContentStatus(contentId, body.status);
            return {
                code: 200,
                message: '状态更新成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                message: '状态更新失败',
                error: error.message
            };
        }
    }
};
exports.ContentGenerationController = ContentGenerationController;
__decorate([
    (0, common_1.Post)('generate'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "generateContent", null);
__decorate([
    (0, common_1.Get)('request/:requestId/avatar/:avatarId'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "getGeneratedContent", null);
__decorate([
    (0, common_1.Post)(':contentId/status'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('contentId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "updateContentStatus", null);
exports.ContentGenerationController = ContentGenerationController = __decorate([
    (0, common_1.Controller)('content-generation'),
    __metadata("design:paramtypes", [content_generation_service_1.ContentGenerationService])
], ContentGenerationController);
//# sourceMappingURL=content-generation.controller.js.map