export declare class ContentGenerationModule {
}
