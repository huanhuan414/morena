"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ContentGenerationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentGenerationService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
const tool_registry_1 = require("../avatar-agent/tools/tool-registry");
const PLATFORM_TOOL_MAPPING = {
    wechat_mp: 'write_wechat_mp_article',
    xiaohongshu: 'write_xiaohongshu_note',
    douyin: 'generate_video',
    weibo: 'write_wechat_mp_article',
    bilibili: 'generate_video',
    kuaishou: 'generate_video',
    wechat_moments: 'write_wechat_moments_content'
};
const PLATFORM_NAMES = {
    wechat_mp: '微信小程序',
    xiaohongshu: '小红书',
    douyin: '抖音',
    weibo: '微博',
    bilibili: 'B站',
    kuaishou: '快手',
    wechat_moments: '微信朋友圈'
};
let ContentGenerationService = ContentGenerationService_1 = class ContentGenerationService {
    constructor(toolRegistry) {
        this.toolRegistry = toolRegistry;
        this.logger = new common_1.Logger(ContentGenerationService_1.name);
    }
    async generateContent(input) {
        const { orderId, requestId, avatarId, orderTitle, orderDescription, platforms, contentType, targetAudience, avatarName = '分身', avatarPersonality, quantity = 1 } = input;
        const results = [];
        for (const platform of platforms) {
            try {
                this.logger.log(`为平台 ${platform} 生成内容，使用分身技能...`);
                const toolName = PLATFORM_TOOL_MAPPING[platform];
                if (!toolName) {
                    this.logger.warn(`平台 ${platform} 没有对应的工具`);
                    continue;
                }
                if (!this.toolRegistry.hasTool(toolName)) {
                    this.logger.warn(`工具 ${toolName} 不存在，跳过平台 ${platform}`);
                    continue;
                }
                const toolParams = this.buildToolParams(platform, orderTitle, orderDescription, contentType, targetAudience, avatarPersonality, quantity);
                const context = {
                    avatarId,
                    userId: '',
                    conversationId: requestId,
                    metadata: {
                        orderId,
                        requestId
                    }
                };
                const result = await this.toolRegistry.executeTool(toolName, toolParams, context);
                if (!result.success) {
                    this.logger.error(`工具 ${toolName} 执行失败:`, result.error);
                    continue;
                }
                const parsedContent = this.parseToolResult(result.data, platform);
                const contentRecord = await this.saveContent({
                    order_id: orderId,
                    request_id: requestId,
                    avatar_id: avatarId,
                    platform,
                    ...parsedContent
                });
                results.push(contentRecord);
                this.logger.log(`平台 ${platform} 内容生成成功 (${quantity} 张图片)`);
            }
            catch (error) {
                this.logger.error(`平台 ${platform} 内容生成失败:`, error);
            }
        }
        if (results.length === 0) {
            throw new Error('所有平台内容生成失败');
        }
        return results;
    }
    buildToolParams(platform, orderTitle, orderDescription, contentType, targetAudience, avatarPersonality, quantity = 1) {
        const baseParams = {
            topic: orderTitle,
            description: orderDescription,
            target_audience: targetAudience
        };
        if (platform === 'wechat_mp' || platform === 'weibo') {
            return {
                ...baseParams,
                emotion: this.mapContentTypeToEmotion(contentType),
                keywords: this.extractKeywords(orderDescription),
                include_cover: true
            };
        }
        else if (platform === 'xiaohongshu') {
            return {
                ...baseParams,
                style: this.mapContentTypeToStyle(contentType),
                keywords: this.extractKeywords(orderDescription),
                include_images: true
            };
        }
        else if (platform === 'douyin' || platform === 'bilibili' || platform === 'kuaishou') {
            return {
                ...baseParams,
                video_style: this.mapContentTypeToVideoStyle(contentType),
                duration: 'short',
                include_background_music: true
            };
        }
        else if (platform === 'wechat_moments') {
            return {
                topic: `${orderTitle}`,
                content_type: '图文',
                image_count: quantity,
                style: '产品推广',
                target_audience: `[重要提醒] 这是微信朋友圈（WeChat Moments）内容，不是小红书！\n朋友圈特点：\n- 简短精炼的文字（30-80字）\n- 生活化、口语化的表达\n- 真实自然，不做作\n- 适合与微信好友分享的内容\n\n${targetAudience}`
            };
        }
        return baseParams;
    }
    mapContentTypeToEmotion(contentType) {
        const emotionMap = {
            '文章': '干货',
            '图文': '情感',
            '短视频': '热点',
            '营销文案': '励志',
            '产品推广': '治愈',
            '品牌故事': '情感',
            '知识科普': '干货',
            '生活分享': '治愈',
            '娱乐八卦': '热点'
        };
        return emotionMap[contentType] || '干货';
    }
    mapContentTypeToStyle(contentType) {
        const styleMap = {
            '文章': '干货',
            '图文': '种草',
            '短视频': '分享',
            '营销文案': '吐槽',
            '产品推广': '安利',
            '品牌故事': '种草',
            '知识科普': '干货',
            '生活分享': '种草',
            '娱乐八卦': '分享',
            'image': '种草',
            '图片': '种草'
        };
        return styleMap[contentType] || '种草';
    }
    mapContentTypeToVideoStyle(contentType) {
        const styleMap = {
            '文章': '口播',
            '图文': '展示',
            '短视频': '快剪',
            '营销文案': '广告',
            '产品推广': '测评',
            '品牌故事': '叙事',
            '知识科普': '科普',
            '生活分享': 'vlog',
            '娱乐八卦': '搞笑'
        };
        return styleMap[contentType] || '快剪';
    }
    extractKeywords(description) {
        const keywords = [];
        const commonKeywords = ['技巧', '方法', '攻略', '推荐', '分享', '教程', '指南', '秘籍', '心得', '经验'];
        commonKeywords.forEach(keyword => {
            if (description.includes(keyword)) {
                keywords.push(keyword);
            }
        });
        return keywords.length > 0 ? keywords : ['干货', '分享'];
    }
    parseToolResult(toolData, platform) {
        try {
            let content = toolData.content || toolData.body || '';
            if (!content && toolData.text) {
                content = toolData.text;
            }
            if (!content && toolData.wechat_moments_content) {
                content = toolData.wechat_moments_content.text || '';
            }
            let finalImages = [];
            if (toolData.wechat_moments_content?.images && Array.isArray(toolData.wechat_moments_content.images)) {
                finalImages = toolData.wechat_moments_content.images;
            }
            else if (Array.isArray(toolData.images)) {
                finalImages = toolData.images;
            }
            if (toolData.cover_image) {
                finalImages = [...finalImages, toolData.cover_image];
            }
            return {
                title: toolData.title || toolData.topic || '',
                content: content,
                hashtags: Array.isArray(toolData.hashtags) ? toolData.hashtags : [],
                image_suggestions: finalImages,
                video_suggestions: toolData.video_url ? [toolData.video_url] : [],
                status: 'draft'
            };
        }
        catch (error) {
            this.logger.warn('解析工具输出失败，使用原始数据', error);
            return {
                content: typeof toolData === 'string' ? toolData : JSON.stringify(toolData),
                hashtags: [],
                image_suggestions: [],
                video_suggestions: [],
                status: 'draft'
            };
        }
    }
    async saveContent(contentData) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data, error } = await client
            .from('generated_content')
            .insert({
            order_id: contentData.order_id,
            request_id: contentData.request_id,
            avatar_id: contentData.avatar_id,
            platform: contentData.platform,
            content: contentData.content,
            hashtags: contentData.hashtags || [],
            image_suggestions: contentData.image_suggestions || [],
            video_suggestions: contentData.video_suggestions || [],
            title: contentData.title,
            status: contentData.status || 'draft'
        })
            .select()
            .single();
        if (error) {
            this.logger.error('保存内容失败:', error);
            throw error;
        }
        return data;
    }
    async getGeneratedContent(requestId, avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const isUuidFormat = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(avatarId);
        let query = client
            .from('generated_content')
            .select('*')
            .eq('request_id', requestId)
            .order('created_at', { ascending: true });
        if (isUuidFormat) {
            query = query.or(`avatar_id.eq.${avatarId},avatar_id.eq.${avatarId.replace(/-/g, '')}`);
        }
        else {
            query = query.eq('avatar_id', avatarId);
        }
        const { data, error } = await query;
        if (error) {
            this.logger.error('获取内容失败:', error);
            throw error;
        }
        return data || [];
    }
    async updateContentStatus(contentId, status) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { error } = await client
            .from('generated_content')
            .update({ status })
            .eq('id', contentId);
        if (error) {
            this.logger.error('更新内容状态失败:', error);
            throw error;
        }
    }
};
exports.ContentGenerationService = ContentGenerationService;
exports.ContentGenerationService = ContentGenerationService = ContentGenerationService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [tool_registry_1.AvatarToolRegistry])
], ContentGenerationService);
//# sourceMappingURL=content-generation.service.js.map