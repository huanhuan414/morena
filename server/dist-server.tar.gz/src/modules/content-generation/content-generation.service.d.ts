import { AvatarToolRegistry } from '../avatar-agent/tools/tool-registry';
import { GeneratedContent } from './types';
interface GenerateContentInput {
    orderId: string;
    requestId: string;
    avatarId: string;
    orderTitle: string;
    orderDescription: string;
    platforms: string[];
    contentType: string;
    targetAudience: string;
    avatarName?: string;
    avatarPersonality?: string;
    quantity?: number;
}
export declare class ContentGenerationService {
    private toolRegistry;
    private readonly logger;
    constructor(toolRegistry: AvatarToolRegistry);
    generateContent(input: GenerateContentInput): Promise<GeneratedContent[]>;
    private buildToolParams;
    private mapContentTypeToEmotion;
    private mapContentTypeToStyle;
    private mapContentTypeToVideoStyle;
    private extractKeywords;
    private parseToolResult;
    private saveContent;
    getGeneratedContent(requestId: string, avatarId: string): Promise<GeneratedContent[]>;
    updateContentStatus(contentId: string, status: 'draft' | 'approved' | 'published'): Promise<void>;
}
export {};
