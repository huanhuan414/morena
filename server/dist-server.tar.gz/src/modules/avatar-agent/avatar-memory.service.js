"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AvatarMemoryService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarMemoryService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
let AvatarMemoryService = AvatarMemoryService_1 = class AvatarMemoryService {
    constructor() {
        this.logger = new common_1.Logger(AvatarMemoryService_1.name);
        this.embeddingClient = null;
    }
    async getEmbeddingClient() {
        return null;
    }
    async generateEmbedding(text) {
        const client = await this.getEmbeddingClient();
        if (!client)
            return null;
        try {
            const result = await client.embed ? client.embed(text) : null;
            return result;
        }
        catch (error) {
            this.logger.error('Failed to generate embedding:', error);
            return null;
        }
    }
    async storeConversation(avatarId, userId, data) {
        try {
            const embedding = await this.generateEmbedding(`${data.userMessage}\n${data.assistantResponse}`);
            const { error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_memories')
                .insert({
                avatar_id: avatarId,
                memory_type: 'conversation',
                content: data.assistantResponse,
                embedding: embedding,
                metadata: {
                    user_id: userId,
                    user_message: data.userMessage,
                    thought: data.thought,
                    timestamp: new Date().toISOString()
                }
            });
            if (error) {
                this.logger.error('Failed to store conversation memory:', error);
            }
            else {
                this.logger.log(`Stored conversation memory for avatar ${avatarId}`);
            }
        }
        catch (error) {
            this.logger.error('Error storing conversation memory:', error);
        }
    }
    async retrieveRelevantMemories(avatarId, query, config = {}) {
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const embedding = await this.generateEmbedding(query);
            if (embedding) {
                const { data: memories, error } = await client
                    .from('avatar_memories')
                    .select('*')
                    .eq('avatar_id', avatarId)
                    .order('access_count', { ascending: false })
                    .limit(config.maxRetrieval || 10);
                if (error)
                    throw error;
                const processedMemories = (memories || [])
                    .map(mem => {
                    const memEmbedding = mem.embedding;
                    let similarity = 0;
                    if (memEmbedding) {
                        similarity = this.cosineSimilarity(embedding, memEmbedding);
                    }
                    return {
                        id: mem.id,
                        avatarId: mem.avatar_id,
                        memoryType: mem.memory_type,
                        content: mem.content,
                        embedding: memEmbedding,
                        metadata: mem.metadata,
                        accessCount: mem.access_count,
                        lastAccessedAt: mem.last_accessed_at,
                        createdAt: mem.created_at,
                        updatedAt: mem.updated_at,
                        similarity
                    };
                })
                    .filter(mem => {
                    if (config.allowedTypes && !config.allowedTypes.includes(mem.memoryType)) {
                        return false;
                    }
                    const threshold = config.similarityThreshold || 0.7;
                    return mem.similarity >= threshold;
                })
                    .sort((a, b) => b.similarity - a.similarity)
                    .slice(0, config.maxRetrieval || 5);
                const filteredMemories = processedMemories.map((mem) => ({
                    id: mem.id,
                    avatarId: mem.avatarId,
                    memoryType: mem.memoryType,
                    content: mem.content,
                    embedding: mem.embedding,
                    metadata: mem.metadata,
                    accessCount: mem.accessCount,
                    lastAccessedAt: mem.lastAccessedAt,
                    createdAt: mem.createdAt,
                    updatedAt: mem.updatedAt
                }));
                for (const mem of processedMemories) {
                    await client
                        .from('avatar_memories')
                        .update({
                        access_count: mem.accessCount + 1,
                        last_accessed_at: new Date().toISOString()
                    })
                        .eq('id', mem.id);
                }
                return filteredMemories;
            }
            const { data: memories, error } = await client
                .from('avatar_memories')
                .select('*')
                .eq('avatar_id', avatarId)
                .ilike('content', `%${query}%`)
                .limit(config.maxRetrieval || 5);
            if (error)
                throw error;
            const resultMemories = (memories || []).map((mem) => ({
                id: mem.id,
                avatarId: mem.avatar_id,
                memoryType: mem.memory_type,
                content: mem.content,
                embedding: null,
                metadata: mem.metadata,
                accessCount: mem.access_count,
                lastAccessedAt: mem.last_accessed_at,
                createdAt: mem.created_at,
                updatedAt: mem.updated_at
            }));
            return resultMemories;
        }
        catch (error) {
            this.logger.error('Error retrieving memories:', error);
            return [];
        }
    }
    async storePreference(avatarId, userId, preference) {
        try {
            const embedding = await this.generateEmbedding(preference.description);
            const { error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_memories')
                .insert({
                avatar_id: avatarId,
                memory_type: 'preference',
                content: preference.description,
                embedding: embedding,
                metadata: {
                    user_id: userId,
                    preference_type: preference.type,
                    value: preference.value,
                    timestamp: new Date().toISOString()
                }
            });
            if (error) {
                this.logger.error('Failed to store preference:', error);
            }
        }
        catch (error) {
            this.logger.error('Error storing preference:', error);
        }
    }
    async storeExperience(avatarId, experience) {
        try {
            const embedding = await this.generateEmbedding(experience.description);
            const { error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_memories')
                .insert({
                avatar_id: avatarId,
                memory_type: 'experience',
                content: experience.description,
                embedding: embedding,
                metadata: {
                    task_type: experience.taskType,
                    success: experience.success,
                    outcome: experience.outcome,
                    timestamp: new Date().toISOString()
                }
            });
            if (error) {
                this.logger.error('Failed to store experience:', error);
            }
            else {
                this.logger.log(`Stored experience for avatar ${avatarId}`);
            }
        }
        catch (error) {
            this.logger.error('Error storing experience:', error);
        }
    }
    async storeThought(avatarId, thought) {
        try {
            const embedding = await this.generateEmbedding(thought.content || '');
            const { error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_memories')
                .insert({
                avatar_id: avatarId,
                memory_type: 'learning',
                content: thought.content || '',
                embedding: embedding,
                metadata: {
                    thought_type: 'reasoning',
                    intent: thought.intent,
                    requires_tool: thought.requiresTool,
                    timestamp: new Date().toISOString()
                }
            });
            if (error) {
                this.logger.error('Failed to store thought:', error);
            }
        }
        catch (error) {
            this.logger.error('Error storing thought:', error);
        }
    }
    cosineSimilarity(a, b) {
        if (a.length !== b.length)
            return 0;
        let dotProduct = 0;
        let normA = 0;
        let normB = 0;
        for (let i = 0; i < a.length; i++) {
            dotProduct += a[i] * b[i];
            normA += a[i] * a[i];
            normB += b[i] * b[i];
        }
        if (normA === 0 || normB === 0)
            return 0;
        return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
    }
    async getUserPreferences(avatarId, userId) {
        try {
            const { data, error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_memories')
                .select('*')
                .eq('avatar_id', avatarId)
                .eq('memory_type', 'preference')
                .contains('metadata', `{"user_id":"${userId}"}`)
                .order('created_at', { ascending: false })
                .limit(20);
            if (error)
                throw error;
            return (data || []).map(mem => ({
                type: mem.metadata?.preference_type || 'unknown',
                description: mem.content,
                value: mem.metadata?.value
            }));
        }
        catch (error) {
            this.logger.error('Error getting user preferences:', error);
            return [];
        }
    }
    async getAvatarExperiences(avatarId, options) {
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            let query = client
                .from('avatar_memories')
                .select('*')
                .eq('avatar_id', avatarId)
                .eq('memory_type', 'experience');
            if (options?.taskType) {
                query = query.contains('metadata', `{"task_type":"${options.taskType}"}`);
            }
            if (options?.limit) {
                query = query.limit(options.limit);
            }
            const { data, error } = await query.order('created_at', { ascending: false });
            if (error)
                throw error;
            let experiences = (data || []).map(mem => ({
                description: mem.content,
                taskType: mem.metadata?.task_type || 'unknown',
                success: mem.metadata?.success || false,
                outcome: mem.metadata?.outcome
            }));
            if (options?.minSuccessRate) {
                const successCount = experiences.filter(e => e.success).length;
                const successRate = successCount / experiences.length;
                if (successRate < options.minSuccessRate) {
                    experiences = [];
                }
            }
            return experiences;
        }
        catch (error) {
            this.logger.error('Error getting avatar experiences:', error);
            return [];
        }
    }
};
exports.AvatarMemoryService = AvatarMemoryService;
exports.AvatarMemoryService = AvatarMemoryService = AvatarMemoryService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], AvatarMemoryService);
//# sourceMappingURL=avatar-memory.service.js.map