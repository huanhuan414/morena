import { Memory, MemoryConfig, ConversationData, Preference, Experience } from './avatar-agent.types';
export declare class AvatarMemoryService {
    private readonly logger;
    constructor();
    private embeddingClient;
    private getEmbeddingClient;
    private generateEmbedding;
    storeConversation(avatarId: string, userId: string, data: ConversationData): Promise<void>;
    retrieveRelevantMemories(avatarId: string, query: string, config?: MemoryConfig): Promise<Memory[]>;
    storePreference(avatarId: string, userId: string, preference: Preference): Promise<void>;
    storeExperience(avatarId: string, experience: Experience): Promise<void>;
    storeThought(avatarId: string, thought: any): Promise<void>;
    private cosineSimilarity;
    getUserPreferences(avatarId: string, userId: string): Promise<Preference[]>;
    getAvatarExperiences(avatarId: string, options?: {
        taskType?: string;
        minSuccessRate?: number;
        limit?: number;
    }): Promise<Experience[]>;
}
