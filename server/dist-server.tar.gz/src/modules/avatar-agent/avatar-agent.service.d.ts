import { AvatarThought, AvatarActionResult, AvatarResponse, AvatarContext, AvatarAgentConfig, ConversationMessage } from './avatar-agent.types';
import { AvatarMemoryService } from './avatar-memory.service';
import { AvatarLearningService } from './avatar-learning.service';
import { AvatarToolRegistry } from './tools/tool-registry';
export declare class AvatarAgentService {
    private readonly memoryService;
    private readonly learningService;
    private readonly toolRegistry;
    private readonly logger;
    private llmClient;
    constructor(memoryService: AvatarMemoryService, learningService: AvatarLearningService, toolRegistry: AvatarToolRegistry);
    think(avatarId: string, userMessage: string, context?: AvatarContext): Promise<AvatarThought>;
    act(avatarId: string, thought: AvatarThought, context?: AvatarContext): Promise<AvatarActionResult>;
    chat(avatarId: string, userId: string, message: string, conversationHistory?: ConversationMessage[]): Promise<AvatarResponse>;
    private loadAvatarConfig;
    private buildSystemPrompt;
    getDefaultConfig(avatarId: string, avatarData?: any): Promise<AvatarAgentConfig>;
    private buildReasoningContext;
    private executeReasoning;
    private parseReasoningResponse;
    private generateResponse;
    private executeToolByName;
    updateAvatarConfig(avatarId: string, updates: Partial<Omit<AvatarAgentConfig, 'id' | 'avatarId' | 'createdAt'>>): Promise<void>;
    initializeAvatarConfig(avatarId: string, options?: {
        systemPrompt?: string;
        rolePrompt?: string;
        personality?: string;
    }): Promise<void>;
}
