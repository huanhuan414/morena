"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AssignTaskTool = exports.QueryTasksTool = exports.UpdateTaskStatusTool = exports.CreateTaskTool = void 0;
const common_1 = require("@nestjs/common");
let CreateTaskTool = class CreateTaskTool {
    constructor() {
        this.name = 'create_task';
        this.displayName = '创建任务';
        this.description = '创建一个新任务';
        this.category = 'task';
        this.paramsSchema = {
            title: {
                type: 'string',
                description: '任务标题',
                required: true
            },
            description: {
                type: 'string',
                description: '任务描述',
                default: ''
            },
            priority: {
                type: 'string',
                description: '优先级：low-低, medium-中, high-高, urgent-紧急',
                default: 'medium'
            },
            dueDate: {
                type: 'string',
                description: '截止日期（ISO 8601格式）'
            },
            assignedToAvatarId: {
                type: 'string',
                description: '分配给哪个分身执行（分身ID）'
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const task = {
                id: `task_${Date.now()}`,
                userId: context.userId,
                avatarId: params.assignedToAvatarId || context.avatarId,
                title: params.title,
                description: params.description || '',
                priority: params.priority || 'medium',
                status: 'pending',
                dueDate: params.dueDate || null,
                createdAt: new Date().toISOString()
            };
            return {
                success: true,
                toolName: this.name,
                data: {
                    task,
                    result: '任务已创建'
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.CreateTaskTool = CreateTaskTool;
exports.CreateTaskTool = CreateTaskTool = __decorate([
    (0, common_1.Injectable)()
], CreateTaskTool);
let UpdateTaskStatusTool = class UpdateTaskStatusTool {
    constructor() {
        this.name = 'update_task_status';
        this.displayName = '更新任务状态';
        this.description = '更新任务的状态';
        this.category = 'task';
        this.paramsSchema = {
            taskId: {
                type: 'string',
                description: '任务ID',
                required: true
            },
            status: {
                type: 'string',
                description: '新状态：pending-待处理, in_progress-进行中, completed-已完成, cancelled-已取消',
                required: true,
                enum: ['pending', 'in_progress', 'completed', 'cancelled']
            },
            notes: {
                type: 'string',
                description: '备注或说明',
                default: ''
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            return {
                success: true,
                toolName: this.name,
                data: {
                    taskId: params.taskId,
                    newStatus: params.status,
                    notes: params.notes,
                    result: '任务状态已更新'
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.UpdateTaskStatusTool = UpdateTaskStatusTool;
exports.UpdateTaskStatusTool = UpdateTaskStatusTool = __decorate([
    (0, common_1.Injectable)()
], UpdateTaskStatusTool);
let QueryTasksTool = class QueryTasksTool {
    constructor() {
        this.name = 'query_tasks';
        this.displayName = '查询任务';
        this.description = '查询任务列表';
        this.category = 'task';
        this.paramsSchema = {
            userId: {
                type: 'string',
                description: '用户ID'
            },
            avatarId: {
                type: 'string',
                description: '分身ID'
            },
            status: {
                type: 'string',
                description: '任务状态过滤'
            },
            limit: {
                type: 'number',
                description: '返回数量',
                default: 20
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const filters = [];
            if (params.userId) {
                filters.push(`user_id.eq.${params.userId}`);
            }
            if (params.avatarId) {
                filters.push(`avatar_id.eq.${params.avatarId}`);
            }
            if (params.status) {
                filters.push(`status.eq.${params.status}`);
            }
            const data = [];
            return {
                success: true,
                toolName: this.name,
                data: {
                    tasks: data,
                    total: data.length
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.QueryTasksTool = QueryTasksTool;
exports.QueryTasksTool = QueryTasksTool = __decorate([
    (0, common_1.Injectable)()
], QueryTasksTool);
let AssignTaskTool = class AssignTaskTool {
    constructor() {
        this.name = 'assign_task';
        this.displayName = '分配任务';
        this.description = '将任务分配给指定分身';
        this.category = 'task';
        this.paramsSchema = {
            taskId: {
                type: 'string',
                description: '任务ID',
                required: true
            },
            avatarId: {
                type: 'string',
                description: '分身ID',
                required: true
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            return {
                success: true,
                toolName: this.name,
                data: {
                    taskId: params.taskId,
                    avatarId: params.avatarId,
                    result: '任务已分配'
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.AssignTaskTool = AssignTaskTool;
exports.AssignTaskTool = AssignTaskTool = __decorate([
    (0, common_1.Injectable)()
], AssignTaskTool);
//# sourceMappingURL=task-tools.js.map