import { AvatarTool, ToolContext, ToolResult } from './tool.interface';
export declare class PublishWechatMpTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "platform_publish";
    paramsSchema: {
        title: {
            type: "string";
            description: string;
            required: boolean;
        };
        content: {
            type: "string";
            description: string;
            required: boolean;
        };
        cover_url: {
            type: "string";
            description: string;
        };
        digest: {
            type: "string";
            description: string;
        };
        auto_image: {
            type: "boolean";
            description: string;
            default: boolean;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
    private getWechatErrorMessage;
    private isValidImageUrl;
    private uploadImage;
    private generateCoverImage;
    private generateDefaultCover;
    private addImagesToContent;
    private replaceImagesForWechat;
    private markdownToStyledHtml;
    private generateDigest;
}
export declare class PublishXiaohongshuTool implements AvatarTool {
    name: string;
    displayName: string;
    description: '准备发布笔记到小红书。注意：小红书暂无官方开放API，此工具仅用于生成内容，需要用户手动复制发布。';
    category: "platform_publish";
    paramsSchema: {
        title: {
            type: "string";
            description: string;
            required: boolean;
        };
        content: {
            type: "string";
            description: string;
            required: boolean;
        };
        images: {
            type: "array";
            description: string;
            items: {
                type: "string";
            };
        };
        tags: {
            type: "array";
            description: string;
            items: {
                type: "string";
            };
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class PublishWechatVideoTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "platform_publish";
    paramsSchema: {
        title: {
            type: "string";
            description: string;
            required: boolean;
        };
        video_url: {
            type: "string";
            description: string;
            required: boolean;
        };
        cover_url: {
            type: "string";
            description: string;
        };
        description: {
            type: "string";
            description: string;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
