import { AvatarTool, ToolContext, ToolResult } from './tool.interface';
export declare class WriteArticleTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "content";
    paramsSchema: {
        topic: {
            type: "string";
            description: string;
            required: boolean;
        };
        genre: {
            type: "string";
            description: string;
            default: string;
        };
        length: {
            type: "number";
            description: string;
            default: number;
        };
        style: {
            type: "string";
            description: string;
            default: string;
        };
        keywords: {
            type: "array";
            description: string;
            default: never[];
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class GenerateImageTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "content";
    paramsSchema: {
        prompt: {
            type: "string";
            description: string;
            required: boolean;
        };
        style: {
            type: "string";
            description: string;
            default: string;
        };
        width: {
            type: "number";
            description: string;
            default: number;
        };
        height: {
            type: "number";
            description: string;
            default: number;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class SummarizeTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "content";
    paramsSchema: {
        content: {
            type: "string";
            description: string;
            required: boolean;
        };
        maxLength: {
            type: "number";
            description: string;
            default: number;
        };
        format: {
            type: "string";
            description: string;
            default: string;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
