"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryAvatarProfileTool = exports.RemoveAvatarFriendTool = exports.AddAvatarFriendTool = exports.QueryAvatarFriendsTool = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../../storage/database/supabase-client");
let QueryAvatarFriendsTool = class QueryAvatarFriendsTool {
    constructor() {
        this.name = 'query_avatar_friends';
        this.displayName = '查询分身好友';
        this.description = '查询指定分身的好友列表';
        this.category = 'data';
        this.paramsSchema = {
            avatarId: {
                type: 'string',
                description: '分身ID',
                required: true
            },
            status: {
                type: 'string',
                description: '好友状态：active-已激活, pending-待确认',
                default: 'active'
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const { avatarId, status } = params;
            const { data: friendships, error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_friends')
                .select(`
          id,
          avatar_id,
          friend_avatar_id,
          match_reason,
          compatibility_score,
          status,
          created_at,
          friend_avatar:avatars!avatar_friends_friend_avatar_id_fkey (
            id,
            name,
            avatar_url,
            personality,
            level
          ),
          avatar:avatars!avatar_friends_avatar_id_fkey (
            id,
            name,
            avatar_url,
            personality,
            level
          )
        `)
                .or(`avatar_id.eq.${avatarId},friend_avatar_id.eq.${avatarId}`)
                .eq('status', status || 'active');
            if (error) {
                return {
                    success: false,
                    toolName: this.name,
                    error: error.message
                };
            }
            const friends = (friendships || []).map((friendship) => {
                const isInitiator = friendship.avatar_id === avatarId;
                const friendData = isInitiator ? friendship.friend_avatar : friendship.avatar;
                return {
                    id: friendData?.id,
                    name: friendData?.name,
                    avatarUrl: friendData?.avatar_url,
                    personality: friendData?.personality,
                    level: friendData?.level,
                    friendshipId: friendship.id,
                    matchReason: friendship.match_reason,
                    compatibilityScore: friendship.compatibility_score,
                    createdAt: friendship.created_at
                };
            });
            return {
                success: true,
                toolName: this.name,
                data: {
                    avatarId,
                    friends,
                    total: friends.length
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.QueryAvatarFriendsTool = QueryAvatarFriendsTool;
exports.QueryAvatarFriendsTool = QueryAvatarFriendsTool = __decorate([
    (0, common_1.Injectable)()
], QueryAvatarFriendsTool);
let AddAvatarFriendTool = class AddAvatarFriendTool {
    constructor() {
        this.name = 'add_avatar_friend';
        this.displayName = '添加分身好友';
        this.description = '为分身添加新的好友';
        this.category = 'social';
        this.paramsSchema = {
            avatarId: {
                type: 'string',
                description: '当前分身ID',
                required: true
            },
            friendAvatarId: {
                type: 'string',
                description: '要添加的好友分身ID',
                required: true
            },
            matchReason: {
                type: 'string',
                description: '匹配原因',
                default: '手动添加'
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const { avatarId, friendAvatarId, matchReason } = params;
            const { data: existing } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_friends')
                .select('id')
                .or(`avatar_id.eq.${avatarId},friend_avatar_id.eq.${avatarId}`)
                .eq('status', 'active')
                .maybeSingle();
            if (existing) {
                return {
                    success: false,
                    toolName: this.name,
                    error: '已经是好友关系'
                };
            }
            const { error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_friends')
                .insert({
                avatar_id: avatarId,
                friend_avatar_id: friendAvatarId,
                match_reason: matchReason || '手动添加',
                compatibility_score: Math.floor(Math.random() * 40) + 60,
                status: 'active',
                created_at: new Date().toISOString()
            });
            if (error) {
                return {
                    success: false,
                    toolName: this.name,
                    error: error.message
                };
            }
            return {
                success: true,
                toolName: this.name,
                data: {
                    message: '好友添加成功',
                    avatarId,
                    friendAvatarId
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.AddAvatarFriendTool = AddAvatarFriendTool;
exports.AddAvatarFriendTool = AddAvatarFriendTool = __decorate([
    (0, common_1.Injectable)()
], AddAvatarFriendTool);
let RemoveAvatarFriendTool = class RemoveAvatarFriendTool {
    constructor() {
        this.name = 'remove_avatar_friend';
        this.displayName = '移除分身好友';
        this.description = '移除分身的好友';
        this.category = 'social';
        this.paramsSchema = {
            avatarId: {
                type: 'string',
                description: '当前分身ID',
                required: true
            },
            friendAvatarId: {
                type: 'string',
                description: '要移除的好友分身ID',
                required: true
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const { avatarId, friendAvatarId } = params;
            await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_friends')
                .delete()
                .eq('avatar_id', avatarId)
                .eq('friend_avatar_id', friendAvatarId);
            await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_friends')
                .delete()
                .eq('avatar_id', friendAvatarId)
                .eq('friend_avatar_id', avatarId);
            return {
                success: true,
                toolName: this.name,
                data: {
                    message: '好友已移除',
                    avatarId,
                    friendAvatarId
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.RemoveAvatarFriendTool = RemoveAvatarFriendTool;
exports.RemoveAvatarFriendTool = RemoveAvatarFriendTool = __decorate([
    (0, common_1.Injectable)()
], RemoveAvatarFriendTool);
let QueryAvatarProfileTool = class QueryAvatarProfileTool {
    constructor() {
        this.name = 'query_avatar_profile';
        this.displayName = '查询分身信息';
        this.description = '查询分身的详细信息';
        this.category = 'data';
        this.paramsSchema = {
            avatarId: {
                type: 'string',
                description: '分身ID',
                required: true
            },
            fields: {
                type: 'array',
                description: '要查询的字段，不传则查询全部',
                default: []
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const { data, error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatars')
                .select('*')
                .eq('id', params.avatarId)
                .single();
            if (error) {
                return {
                    success: false,
                    toolName: this.name,
                    error: error.message
                };
            }
            const result = params.fields && params.fields.length > 0
                ? params.fields.reduce((acc, field) => {
                    acc[field] = data[field];
                    return acc;
                }, {})
                : data;
            return {
                success: true,
                toolName: this.name,
                data: result,
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.QueryAvatarProfileTool = QueryAvatarProfileTool;
exports.QueryAvatarProfileTool = QueryAvatarProfileTool = __decorate([
    (0, common_1.Injectable)()
], QueryAvatarProfileTool);
//# sourceMappingURL=avatar-management-tools.js.map