import { AvatarTool, ToolContext, ToolResult } from './tool.interface';
export declare class WriteWechatMpArticleTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "content_creation";
    paramsSchema: {
        topic: {
            type: "string";
            description: string;
            required: boolean;
        };
        target_audience: {
            type: "string";
            description: string;
        };
        emotion: {
            type: "string";
            description: string;
            enum: string[];
            default: string;
        };
        keywords: {
            type: "array";
            description: string;
            items: {
                type: "string";
            };
        };
        include_cover: {
            type: "boolean";
            description: string;
            default: boolean;
        };
        images_count: {
            type: "number";
            description: string;
            default: number;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
    private addImagesToArticleContent;
}
export declare class WriteXiaohongshuNoteTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "content_creation";
    paramsSchema: {
        topic: {
            type: "string";
            description: string;
            required: boolean;
        };
        style: {
            type: "string";
            description: string;
            enum: string[];
            default: string;
        };
        images_count: {
            type: "number";
            description: string;
            default: number;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class WriteWechatMomentsTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "content_creation";
    paramsSchema: {
        topic: {
            type: "string";
            description: string;
            required: boolean;
        };
        content_type: {
            type: "string";
            description: string;
            enum: string[];
            default: string;
        };
        image_count: {
            type: "number";
            description: string;
            default: number;
        };
        style: {
            type: "string";
            description: string;
            enum: string[];
            default: string;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
