import { AvatarTool, ToolContext, ToolResult } from './tool.interface';
export declare class SendMessageTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "social";
    paramsSchema: {
        toUserId: {
            type: "string";
            description: string;
            required: boolean;
        };
        content: {
            type: "string";
            description: string;
            required: boolean;
        };
        messageType: {
            type: "string";
            description: string;
            default: string;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class CreateMomentTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "social";
    paramsSchema: {
        content: {
            type: "string";
            description: string;
            required: boolean;
        };
        images: {
            type: "array";
            description: string;
            default: never[];
        };
        visibility: {
            type: "string";
            description: string;
            default: string;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class AddCommentTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "social";
    paramsSchema: {
        targetType: {
            type: "string";
            description: string;
            required: boolean;
        };
        targetId: {
            type: "string";
            description: string;
            required: boolean;
        };
        content: {
            type: "string";
            description: string;
            required: boolean;
        };
        replyToCommentId: {
            type: "string";
            description: string;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
