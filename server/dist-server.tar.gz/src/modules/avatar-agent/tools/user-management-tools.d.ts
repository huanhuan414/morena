import { AvatarTool, ToolContext, ToolResult } from './tool.interface';
export declare class ChangePasswordTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "system";
    paramsSchema: {
        userId: {
            type: "string";
            description: string;
            required: boolean;
        };
        oldPassword: {
            type: "string";
            description: string;
            required: boolean;
        };
        newPassword: {
            type: "string";
            description: string;
            required: boolean;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class UpdateProfileTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "system";
    paramsSchema: {
        userId: {
            type: "string";
            description: string;
            required: boolean;
        };
        username: {
            type: "string";
            description: string;
        };
        nickname: {
            type: "string";
            description: string;
        };
        bio: {
            type: "string";
            description: string;
        };
        avatarUrl: {
            type: "string";
            description: string;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class UploadAvatarTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "system";
    paramsSchema: {
        userId: {
            type: "string";
            description: string;
            required: boolean;
        };
        fileUrl: {
            type: "string";
            description: string;
            required: boolean;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class BindPhoneTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "system";
    paramsSchema: {
        userId: {
            type: "string";
            description: string;
            required: boolean;
        };
        phoneNumber: {
            type: "string";
            description: string;
            required: boolean;
        };
        verificationCode: {
            type: "string";
            description: string;
            required: boolean;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class DeleteAccountTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "system";
    paramsSchema: {
        userId: {
            type: "string";
            description: string;
            required: boolean;
        };
        confirm: {
            type: "boolean";
            description: string;
            required: boolean;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
