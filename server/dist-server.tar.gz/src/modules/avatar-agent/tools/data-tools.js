"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryFriendsTool = exports.QueryOrdersTool = exports.QueryUserProfileTool = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../../storage/database/supabase-client");
let QueryUserProfileTool = class QueryUserProfileTool {
    constructor() {
        this.name = 'query_user_profile';
        this.displayName = '查询用户信息';
        this.description = '查询用户的基本信息、偏好设置等';
        this.category = 'data';
        this.paramsSchema = {
            userId: {
                type: 'string',
                description: '用户ID',
                required: true
            },
            fields: {
                type: 'array',
                description: '要查询的字段，不传则查询全部',
                default: []
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const { data, error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('user_profiles')
                .select('*')
                .eq('id', params.userId)
                .single();
            if (error) {
                return {
                    success: false,
                    toolName: this.name,
                    error: error.message
                };
            }
            const result = params.fields && params.fields.length > 0
                ? params.fields.reduce((acc, field) => {
                    acc[field] = data[field];
                    return acc;
                }, {})
                : data;
            return {
                success: true,
                toolName: this.name,
                data: result,
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.QueryUserProfileTool = QueryUserProfileTool;
exports.QueryUserProfileTool = QueryUserProfileTool = __decorate([
    (0, common_1.Injectable)()
], QueryUserProfileTool);
let QueryOrdersTool = class QueryOrdersTool {
    constructor() {
        this.name = 'query_orders';
        this.displayName = '查询订单';
        this.description = '查询用户的订单列表';
        this.category = 'data';
        this.paramsSchema = {
            userId: {
                type: 'string',
                description: '用户ID',
                required: true
            },
            status: {
                type: 'string',
                description: '订单状态：pending-待处理, active-进行中, completed-已完成, cancelled-已取消',
                enum: ['pending', 'active', 'completed', 'cancelled']
            },
            limit: {
                type: 'number',
                description: '返回数量限制',
                default: 20
            },
            offset: {
                type: 'number',
                description: '偏移量',
                default: 0
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            let query = (0, supabase_client_1.getSupabaseClient)()
                .from('orders')
                .select('*')
                .eq('user_id', params.userId);
            if (params.status) {
                query = query.eq('status', params.status);
            }
            const { data, error } = await query
                .order('created_at', { ascending: false })
                .range(params.offset || 0, (params.offset || 0) + (params.limit || 20) - 1);
            if (error) {
                return {
                    success: false,
                    toolName: this.name,
                    error: error.message
                };
            }
            return {
                success: true,
                toolName: this.name,
                data: {
                    orders: data || [],
                    total: data?.length || 0,
                    pagination: {
                        limit: params.limit,
                        offset: params.offset
                    }
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.QueryOrdersTool = QueryOrdersTool;
exports.QueryOrdersTool = QueryOrdersTool = __decorate([
    (0, common_1.Injectable)()
], QueryOrdersTool);
let QueryFriendsTool = class QueryFriendsTool {
    constructor() {
        this.name = 'query_friends';
        this.displayName = '查询好友';
        this.description = '查询用户的好友列表';
        this.category = 'data';
        this.paramsSchema = {
            userId: {
                type: 'string',
                description: '用户ID',
                required: true
            },
            status: {
                type: 'string',
                description: '好友状态：accepted-已接受, pending-待确认',
                default: 'accepted'
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const { data: friendships, error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('friendships')
                .select(`
          *,
          user:users!friendships_user_id_fkey(id, username, avatar_url),
          friend:users!friendships_friend_id_fkey(id, username, avatar_url)
        `)
                .or(`user_id.eq.${params.userId},friend_id.eq.${params.userId}`)
                .eq('status', params.status || 'accepted');
            if (error) {
                return {
                    success: false,
                    toolName: this.name,
                    error: error.message
                };
            }
            const friends = (friendships || []).map(friendship => {
                const isRequester = friendship.user_id === params.userId;
                const friendData = isRequester ? friendship.friend : friendship.user;
                return {
                    id: friendData.id,
                    username: friendData.username,
                    avatarUrl: friendData.avatar_url,
                    friendshipId: friendship.id,
                    createdAt: friendship.created_at
                };
            });
            return {
                success: true,
                toolName: this.name,
                data: {
                    friends,
                    total: friends.length
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.QueryFriendsTool = QueryFriendsTool;
exports.QueryFriendsTool = QueryFriendsTool = __decorate([
    (0, common_1.Injectable)()
], QueryFriendsTool);
//# sourceMappingURL=data-tools.js.map