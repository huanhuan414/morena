"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AvatarToolRegistry_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarToolRegistry = void 0;
const common_1 = require("@nestjs/common");
const content_tools_1 = require("./content-tools");
const content_creation_tools_1 = require("./content-creation-tools");
const content_generation_tools_1 = require("./content-generation-tools");
const platform_publish_tools_1 = require("./platform-publish-tools");
const data_tools_1 = require("./data-tools");
const social_tools_1 = require("./social-tools");
const task_tools_1 = require("./task-tools");
const user_management_tools_1 = require("./user-management-tools");
const avatar_management_tools_1 = require("./avatar-management-tools");
let AvatarToolRegistry = AvatarToolRegistry_1 = class AvatarToolRegistry {
    constructor(writeArticleTool, generateImageTool, summarizeTool, writeWechatMpArticleTool, writeXiaohongshuNoteTool, writeWechatMomentsTool, contentGenerateImageTool, generateVideoTool, publishWechatMpTool, publishXiaohongshuTool, publishWechatVideoTool, queryUserProfileTool, queryOrdersTool, queryFriendsTool, sendMessageTool, createMomentTool, addCommentTool, createTaskTool, updateTaskStatusTool, queryTasksTool, assignTaskTool, changePasswordTool, updateProfileTool, uploadAvatarTool, bindPhoneTool, deleteAccountTool, queryAvatarFriendsTool, addAvatarFriendTool, removeAvatarFriendTool, queryAvatarProfileTool) {
        this.writeArticleTool = writeArticleTool;
        this.generateImageTool = generateImageTool;
        this.summarizeTool = summarizeTool;
        this.writeWechatMpArticleTool = writeWechatMpArticleTool;
        this.writeXiaohongshuNoteTool = writeXiaohongshuNoteTool;
        this.writeWechatMomentsTool = writeWechatMomentsTool;
        this.contentGenerateImageTool = contentGenerateImageTool;
        this.generateVideoTool = generateVideoTool;
        this.publishWechatMpTool = publishWechatMpTool;
        this.publishXiaohongshuTool = publishXiaohongshuTool;
        this.publishWechatVideoTool = publishWechatVideoTool;
        this.queryUserProfileTool = queryUserProfileTool;
        this.queryOrdersTool = queryOrdersTool;
        this.queryFriendsTool = queryFriendsTool;
        this.sendMessageTool = sendMessageTool;
        this.createMomentTool = createMomentTool;
        this.addCommentTool = addCommentTool;
        this.createTaskTool = createTaskTool;
        this.updateTaskStatusTool = updateTaskStatusTool;
        this.queryTasksTool = queryTasksTool;
        this.assignTaskTool = assignTaskTool;
        this.changePasswordTool = changePasswordTool;
        this.updateProfileTool = updateProfileTool;
        this.uploadAvatarTool = uploadAvatarTool;
        this.bindPhoneTool = bindPhoneTool;
        this.deleteAccountTool = deleteAccountTool;
        this.queryAvatarFriendsTool = queryAvatarFriendsTool;
        this.addAvatarFriendTool = addAvatarFriendTool;
        this.removeAvatarFriendTool = removeAvatarFriendTool;
        this.queryAvatarProfileTool = queryAvatarProfileTool;
        this.logger = new common_1.Logger(AvatarToolRegistry_1.name);
        this.tools = new Map();
        this.registerAllTools();
    }
    registerAllTools() {
        this.registerTool(this.writeArticleTool);
        this.registerTool(this.generateImageTool);
        this.registerTool(this.summarizeTool);
        this.registerTool(this.writeWechatMpArticleTool);
        this.registerTool(this.writeXiaohongshuNoteTool);
        this.registerTool(this.writeWechatMomentsTool);
        this.registerTool(this.contentGenerateImageTool);
        this.registerTool(this.generateVideoTool);
        this.registerTool(this.publishWechatMpTool);
        this.registerTool(this.publishXiaohongshuTool);
        this.registerTool(this.publishWechatVideoTool);
        this.registerTool(this.queryUserProfileTool);
        this.registerTool(this.queryOrdersTool);
        this.registerTool(this.queryFriendsTool);
        this.registerTool(this.sendMessageTool);
        this.registerTool(this.createMomentTool);
        this.registerTool(this.addCommentTool);
        this.registerTool(this.createTaskTool);
        this.registerTool(this.updateTaskStatusTool);
        this.registerTool(this.queryTasksTool);
        this.registerTool(this.assignTaskTool);
        this.registerTool(this.changePasswordTool);
        this.registerTool(this.updateProfileTool);
        this.registerTool(this.uploadAvatarTool);
        this.registerTool(this.bindPhoneTool);
        this.registerTool(this.deleteAccountTool);
        this.registerTool(this.queryAvatarFriendsTool);
        this.registerTool(this.addAvatarFriendTool);
        this.registerTool(this.removeAvatarFriendTool);
        this.registerTool(this.queryAvatarProfileTool);
        this.logger.log(`已注册 ${this.tools.size} 个工具`);
    }
    registerTool(tool) {
        this.tools.set(tool.name, tool);
        this.logger.log(`已注册工具: ${tool.name} (${tool.category})`);
    }
    getTool(name) {
        return this.tools.get(name);
    }
    getAllTools() {
        return Array.from(this.tools.values());
    }
    getToolsByCategory(category) {
        return this.getAllTools().filter(tool => tool.category === category);
    }
    hasTool(name) {
        return this.tools.has(name);
    }
    validateToolParams(toolName, params) {
        const tool = this.getTool(toolName);
        if (!tool) {
            return {
                valid: false,
                errors: [`工具 ${toolName} 不存在`]
            };
        }
        const errors = [];
        for (const [paramName, schema] of Object.entries(tool.paramsSchema)) {
            if (schema.required && !params[paramName]) {
                errors.push(`缺少必填参数: ${paramName}`);
                continue;
            }
            if (schema.enum && params[paramName] && !schema.enum.includes(params[paramName])) {
                errors.push(`参数 ${paramName} 的值无效，可选值为: ${schema.enum.join(', ')}`);
            }
            if (params[paramName]) {
                const actualType = Array.isArray(params[paramName]) ? 'array' : typeof params[paramName];
                if (actualType !== schema.type) {
                    errors.push(`参数 ${paramName} 类型错误，期望 ${schema.type}，实际 ${actualType}`);
                }
            }
        }
        return {
            valid: errors.length === 0,
            errors
        };
    }
    async executeTool(toolName, params, context) {
        try {
            const tool = this.getTool(toolName);
            if (!tool) {
                return {
                    success: false,
                    toolName,
                    error: `工具 ${toolName} 不存在`
                };
            }
            const validation = this.validateToolParams(toolName, params);
            if (!validation.valid) {
                return {
                    success: false,
                    toolName,
                    error: `参数验证失败: ${validation.errors.join('; ')}`
                };
            }
            this.logger.log(`执行工具: ${toolName}`, params);
            const result = await tool.execute(params, context);
            this.logger.log(`工具执行完成: ${toolName}, 成功: ${result.success}`);
            return result;
        }
        catch (error) {
            this.logger.error(`工具执行异常: ${toolName}`, error);
            return {
                success: false,
                toolName,
                error: error.message
            };
        }
    }
    getToolsDescription() {
        const tools = this.getAllTools();
        const descriptions = tools.map(tool => {
            const params = Object.entries(tool.paramsSchema)
                .map(([name, schema]) => {
                const required = schema.required ? '（必填）' : '（可选）';
                const enumValues = schema.enum ? `可选值: ${schema.enum.join(', ')}` : '';
                return `  - ${name}: ${schema.description}${required} ${enumValues}`;
            })
                .join('\n');
            return `
工具名称: ${tool.name}
显示名称: ${tool.displayName}
分类: ${tool.category}
描述: ${tool.description}
参数:
${params}
`;
        });
        return `可用工具列表:\n${descriptions.join('\n')}`;
    }
    getToolNames() {
        return Array.from(this.tools.keys());
    }
};
exports.AvatarToolRegistry = AvatarToolRegistry;
exports.AvatarToolRegistry = AvatarToolRegistry = AvatarToolRegistry_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [content_tools_1.WriteArticleTool,
        content_tools_1.GenerateImageTool,
        content_tools_1.SummarizeTool,
        content_creation_tools_1.WriteWechatMpArticleTool,
        content_creation_tools_1.WriteXiaohongshuNoteTool,
        content_creation_tools_1.WriteWechatMomentsTool,
        content_generation_tools_1.GenerateImageTool,
        content_generation_tools_1.GenerateVideoTool,
        platform_publish_tools_1.PublishWechatMpTool,
        platform_publish_tools_1.PublishXiaohongshuTool,
        platform_publish_tools_1.PublishWechatVideoTool,
        data_tools_1.QueryUserProfileTool,
        data_tools_1.QueryOrdersTool,
        data_tools_1.QueryFriendsTool,
        social_tools_1.SendMessageTool,
        social_tools_1.CreateMomentTool,
        social_tools_1.AddCommentTool,
        task_tools_1.CreateTaskTool,
        task_tools_1.UpdateTaskStatusTool,
        task_tools_1.QueryTasksTool,
        task_tools_1.AssignTaskTool,
        user_management_tools_1.ChangePasswordTool,
        user_management_tools_1.UpdateProfileTool,
        user_management_tools_1.UploadAvatarTool,
        user_management_tools_1.BindPhoneTool,
        user_management_tools_1.DeleteAccountTool,
        avatar_management_tools_1.QueryAvatarFriendsTool,
        avatar_management_tools_1.AddAvatarFriendTool,
        avatar_management_tools_1.RemoveAvatarFriendTool,
        avatar_management_tools_1.QueryAvatarProfileTool])
], AvatarToolRegistry);
//# sourceMappingURL=tool-registry.js.map