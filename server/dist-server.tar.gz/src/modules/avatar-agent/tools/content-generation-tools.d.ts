import { AvatarTool, ToolContext, ToolResult } from './tool.interface';
export declare class GenerateImageTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "content_creation";
    paramsSchema: {
        prompt: {
            type: "string";
            description: string;
            required: boolean;
        };
        style: {
            type: "string";
            description: string;
            enum: string[];
            default: string;
        };
        size: {
            type: "string";
            description: string;
            enum: string[];
            default: string;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class GenerateVideoTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "content_creation";
    paramsSchema: {
        prompt: {
            type: "string";
            description: string;
            required: boolean;
        };
        duration: {
            type: "number";
            description: string;
            default: number;
        };
        ratio: {
            type: "string";
            description: string;
            enum: string[];
            default: string;
        };
        reference_images: {
            type: "array";
            description: string;
            items: {
                type: "string";
            };
        };
        reference_videos: {
            type: "array";
            description: string;
            items: {
                type: "string";
            };
        };
        reference_audios: {
            type: "array";
            description: string;
            items: {
                type: "string";
            };
        };
        generate_audio: {
            type: "boolean";
            description: string;
            default: boolean;
        };
    };
    private storage;
    constructor();
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
