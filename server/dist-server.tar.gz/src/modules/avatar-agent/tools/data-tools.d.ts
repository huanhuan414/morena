import { AvatarTool, ToolContext, ToolResult } from './tool.interface';
export declare class QueryUserProfileTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "data";
    paramsSchema: {
        userId: {
            type: "string";
            description: string;
            required: boolean;
        };
        fields: {
            type: "array";
            description: string;
            default: never[];
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class QueryOrdersTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "data";
    paramsSchema: {
        userId: {
            type: "string";
            description: string;
            required: boolean;
        };
        status: {
            type: "string";
            description: string;
            enum: string[];
        };
        limit: {
            type: "number";
            description: string;
            default: number;
        };
        offset: {
            type: "number";
            description: string;
            default: number;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class QueryFriendsTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "data";
    paramsSchema: {
        userId: {
            type: "string";
            description: string;
            required: boolean;
        };
        status: {
            type: "string";
            description: string;
            default: string;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
