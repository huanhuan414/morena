"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddCommentTool = exports.CreateMomentTool = exports.SendMessageTool = void 0;
const common_1 = require("@nestjs/common");
let SendMessageTool = class SendMessageTool {
    constructor() {
        this.name = 'send_message';
        this.displayName = '发送消息';
        this.description = '向指定用户发送消息';
        this.category = 'social';
        this.paramsSchema = {
            toUserId: {
                type: 'string',
                description: '接收者用户ID',
                required: true
            },
            content: {
                type: 'string',
                description: '消息内容',
                required: true
            },
            messageType: {
                type: 'string',
                description: '消息类型：text-文本, image-图片, audio-语音, video-视频',
                default: 'text'
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const message = {
                id: `msg_${Date.now()}`,
                fromUserId: context.userId,
                toUserId: params.toUserId,
                content: params.content,
                messageType: params.messageType || 'text',
                createdAt: new Date().toISOString(),
                status: 'sent'
            };
            return {
                success: true,
                toolName: this.name,
                data: {
                    message,
                    result: '消息已发送'
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.SendMessageTool = SendMessageTool;
exports.SendMessageTool = SendMessageTool = __decorate([
    (0, common_1.Injectable)()
], SendMessageTool);
let CreateMomentTool = class CreateMomentTool {
    constructor() {
        this.name = 'create_moment';
        this.displayName = '发布朋友圈';
        this.description = '创建朋友圈动态';
        this.category = 'social';
        this.paramsSchema = {
            content: {
                type: 'string',
                description: '动态内容',
                required: true
            },
            images: {
                type: 'array',
                description: '图片URL列表',
                default: []
            },
            visibility: {
                type: 'string',
                description: '可见范围：public-公开, friends-好友可见, private-仅自己可见',
                default: 'friends'
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const moment = {
                id: `moment_${Date.now()}`,
                userId: context.userId,
                content: params.content,
                images: params.images || [],
                visibility: params.visibility || 'friends',
                createdAt: new Date().toISOString(),
                likes: 0,
                comments: []
            };
            return {
                success: true,
                toolName: this.name,
                data: {
                    moment,
                    result: '朋友圈动态已发布'
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.CreateMomentTool = CreateMomentTool;
exports.CreateMomentTool = CreateMomentTool = __decorate([
    (0, common_1.Injectable)()
], CreateMomentTool);
let AddCommentTool = class AddCommentTool {
    constructor() {
        this.name = 'add_comment';
        this.displayName = '添加评论';
        this.description = '为动态或内容添加评论';
        this.category = 'social';
        this.paramsSchema = {
            targetType: {
                type: 'string',
                description: '评论目标类型：moment-朋友圈动态, post-帖子',
                required: true
            },
            targetId: {
                type: 'string',
                description: '目标ID',
                required: true
            },
            content: {
                type: 'string',
                description: '评论内容',
                required: true
            },
            replyToCommentId: {
                type: 'string',
                description: '回复的评论ID（可选）'
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const comment = {
                id: `comment_${Date.now()}`,
                userId: context.userId,
                targetType: params.targetType,
                targetId: params.targetId,
                content: params.content,
                replyToCommentId: params.replyToCommentId || null,
                createdAt: new Date().toISOString()
            };
            return {
                success: true,
                toolName: this.name,
                data: {
                    comment,
                    result: '评论已添加'
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.AddCommentTool = AddCommentTool;
exports.AddCommentTool = AddCommentTool = __decorate([
    (0, common_1.Injectable)()
], AddCommentTool);
//# sourceMappingURL=social-tools.js.map