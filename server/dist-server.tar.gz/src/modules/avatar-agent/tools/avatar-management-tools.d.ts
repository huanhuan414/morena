import { AvatarTool, ToolContext, ToolResult } from './tool.interface';
export declare class QueryAvatarFriendsTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "data";
    paramsSchema: {
        avatarId: {
            type: "string";
            description: string;
            required: boolean;
        };
        status: {
            type: "string";
            description: string;
            default: string;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class AddAvatarFriendTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "social";
    paramsSchema: {
        avatarId: {
            type: "string";
            description: string;
            required: boolean;
        };
        friendAvatarId: {
            type: "string";
            description: string;
            required: boolean;
        };
        matchReason: {
            type: "string";
            description: string;
            default: string;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class RemoveAvatarFriendTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "social";
    paramsSchema: {
        avatarId: {
            type: "string";
            description: string;
            required: boolean;
        };
        friendAvatarId: {
            type: "string";
            description: string;
            required: boolean;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class QueryAvatarProfileTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "data";
    paramsSchema: {
        avatarId: {
            type: "string";
            description: string;
            required: boolean;
        };
        fields: {
            type: "array";
            description: string;
            default: never[];
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
