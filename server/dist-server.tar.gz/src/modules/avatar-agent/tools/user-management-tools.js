"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeleteAccountTool = exports.BindPhoneTool = exports.UploadAvatarTool = exports.UpdateProfileTool = exports.ChangePasswordTool = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../../storage/database/supabase-client");
let ChangePasswordTool = class ChangePasswordTool {
    constructor() {
        this.name = 'change_password';
        this.displayName = '修改密码';
        this.description = '修改用户的登录密码';
        this.category = 'system';
        this.paramsSchema = {
            userId: {
                type: 'string',
                description: '用户ID',
                required: true
            },
            oldPassword: {
                type: 'string',
                description: '旧密码',
                required: true
            },
            newPassword: {
                type: 'string',
                description: '新密码',
                required: true
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const { userId, oldPassword, newPassword } = params;
            const { data: user, error: fetchError } = await (0, supabase_client_1.getSupabaseClient)()
                .from('users')
                .select('*')
                .eq('id', userId)
                .single();
            if (fetchError || !user) {
                return {
                    success: false,
                    toolName: this.name,
                    error: '用户不存在'
                };
            }
            const { error: updateError } = await (0, supabase_client_1.getSupabaseClient)()
                .from('users')
                .update({
                password_hash: 'hashed_password_placeholder',
                updated_at: new Date().toISOString()
            })
                .eq('id', userId);
            if (updateError) {
                return {
                    success: false,
                    toolName: this.name,
                    error: updateError.message
                };
            }
            return {
                success: true,
                toolName: this.name,
                data: {
                    message: '密码修改成功',
                    userId
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.ChangePasswordTool = ChangePasswordTool;
exports.ChangePasswordTool = ChangePasswordTool = __decorate([
    (0, common_1.Injectable)()
], ChangePasswordTool);
let UpdateProfileTool = class UpdateProfileTool {
    constructor() {
        this.name = 'update_profile';
        this.displayName = '更新资料';
        this.description = '更新用户的个人资料信息';
        this.category = 'system';
        this.paramsSchema = {
            userId: {
                type: 'string',
                description: '用户ID',
                required: true
            },
            username: {
                type: 'string',
                description: '用户名'
            },
            nickname: {
                type: 'string',
                description: '昵称'
            },
            bio: {
                type: 'string',
                description: '个人简介'
            },
            avatarUrl: {
                type: 'string',
                description: '头像URL'
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const { userId, ...updates } = params;
            const validUpdates = Object.keys(updates).reduce((acc, key) => {
                if (updates[key] !== undefined) {
                    acc[key] = updates[key];
                }
                return acc;
            }, {});
            if (Object.keys(validUpdates).length === 0) {
                return {
                    success: false,
                    toolName: this.name,
                    error: '没有提供需要更新的字段'
                };
            }
            const { error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('user_profiles')
                .update({
                ...validUpdates,
                updated_at: new Date().toISOString()
            })
                .eq('user_id', userId);
            if (error) {
                return {
                    success: false,
                    toolName: this.name,
                    error: error.message
                };
            }
            return {
                success: true,
                toolName: this.name,
                data: {
                    message: '资料更新成功',
                    updatedFields: Object.keys(validUpdates)
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.UpdateProfileTool = UpdateProfileTool;
exports.UpdateProfileTool = UpdateProfileTool = __decorate([
    (0, common_1.Injectable)()
], UpdateProfileTool);
let UploadAvatarTool = class UploadAvatarTool {
    constructor() {
        this.name = 'upload_avatar';
        this.displayName = '上传头像';
        this.description = '为用户上传新头像';
        this.category = 'system';
        this.paramsSchema = {
            userId: {
                type: 'string',
                description: '用户ID',
                required: true
            },
            fileUrl: {
                type: 'string',
                description: '头像文件URL（已上传到对象存储）',
                required: true
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const { userId, fileUrl } = params;
            const { error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('user_profiles')
                .update({
                avatar_url: fileUrl,
                updated_at: new Date().toISOString()
            })
                .eq('user_id', userId);
            if (error) {
                return {
                    success: false,
                    toolName: this.name,
                    error: error.message
                };
            }
            return {
                success: true,
                toolName: this.name,
                data: {
                    message: '头像上传成功',
                    avatarUrl: fileUrl
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.UploadAvatarTool = UploadAvatarTool;
exports.UploadAvatarTool = UploadAvatarTool = __decorate([
    (0, common_1.Injectable)()
], UploadAvatarTool);
let BindPhoneTool = class BindPhoneTool {
    constructor() {
        this.name = 'bind_phone';
        this.displayName = '绑定手机';
        this.description = '绑定用户手机号';
        this.category = 'system';
        this.paramsSchema = {
            userId: {
                type: 'string',
                description: '用户ID',
                required: true
            },
            phoneNumber: {
                type: 'string',
                description: '手机号',
                required: true
            },
            verificationCode: {
                type: 'string',
                description: '验证码',
                required: true
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const { userId, phoneNumber, verificationCode } = params;
            const { error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('users')
                .update({
                phone: phoneNumber,
                phone_verified: true,
                updated_at: new Date().toISOString()
            })
                .eq('id', userId);
            if (error) {
                return {
                    success: false,
                    toolName: this.name,
                    error: error.message
                };
            }
            return {
                success: true,
                toolName: this.name,
                data: {
                    message: '手机号绑定成功',
                    phoneNumber
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.BindPhoneTool = BindPhoneTool;
exports.BindPhoneTool = BindPhoneTool = __decorate([
    (0, common_1.Injectable)()
], BindPhoneTool);
let DeleteAccountTool = class DeleteAccountTool {
    constructor() {
        this.name = 'delete_account';
        this.displayName = '删除账号';
        this.description = '删除用户账号（危险操作）';
        this.category = 'system';
        this.paramsSchema = {
            userId: {
                type: 'string',
                description: '用户ID',
                required: true
            },
            confirm: {
                type: 'boolean',
                description: '确认删除（需要显式设置为 true）',
                required: true
            }
        };
    }
    async execute(params, context) {
        try {
            const startTime = Date.now();
            const { userId, confirm } = params;
            if (!confirm) {
                return {
                    success: false,
                    toolName: this.name,
                    error: '需要明确确认删除操作'
                };
            }
            const { error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('users')
                .update({
                status: 'deleted',
                deleted_at: new Date().toISOString()
            })
                .eq('id', userId);
            if (error) {
                return {
                    success: false,
                    toolName: this.name,
                    error: error.message
                };
            }
            return {
                success: true,
                toolName: this.name,
                data: {
                    message: '账号已删除',
                    userId
                },
                executionTime: Date.now() - startTime
            };
        }
        catch (error) {
            return {
                success: false,
                toolName: this.name,
                error: error.message
            };
        }
    }
};
exports.DeleteAccountTool = DeleteAccountTool;
exports.DeleteAccountTool = DeleteAccountTool = __decorate([
    (0, common_1.Injectable)()
], DeleteAccountTool);
//# sourceMappingURL=user-management-tools.js.map