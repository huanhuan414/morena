import { AvatarTool, ToolContext, ToolResult } from './tool.interface';
export declare class CreateTaskTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "task";
    paramsSchema: {
        title: {
            type: "string";
            description: string;
            required: boolean;
        };
        description: {
            type: "string";
            description: string;
            default: string;
        };
        priority: {
            type: "string";
            description: string;
            default: string;
        };
        dueDate: {
            type: "string";
            description: string;
        };
        assignedToAvatarId: {
            type: "string";
            description: string;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class UpdateTaskStatusTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "task";
    paramsSchema: {
        taskId: {
            type: "string";
            description: string;
            required: boolean;
        };
        status: {
            type: "string";
            description: string;
            required: boolean;
            enum: string[];
        };
        notes: {
            type: "string";
            description: string;
            default: string;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class QueryTasksTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "task";
    paramsSchema: {
        userId: {
            type: "string";
            description: string;
        };
        avatarId: {
            type: "string";
            description: string;
        };
        status: {
            type: "string";
            description: string;
        };
        limit: {
            type: "number";
            description: string;
            default: number;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class AssignTaskTool implements AvatarTool {
    name: string;
    displayName: string;
    description: string;
    category: "task";
    paramsSchema: {
        taskId: {
            type: "string";
            description: string;
            required: boolean;
        };
        avatarId: {
            type: "string";
            description: string;
            required: boolean;
        };
    };
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
