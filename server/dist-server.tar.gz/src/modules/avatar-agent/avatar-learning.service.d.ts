import { AvatarMemoryService } from './avatar-memory.service';
import { AvatarThought, AvatarActionResult, AvatarResponse, Interaction } from './avatar-agent.types';
export declare class AvatarLearningService {
    private readonly memoryService;
    private readonly logger;
    constructor(memoryService: AvatarMemoryService);
    learnFromResult(avatarId: string, thought: AvatarThought, result: AvatarActionResult): Promise<void>;
    updateSkillLevel(avatarId: string, thought: AvatarThought, response: AvatarResponse): Promise<void>;
    personalize(avatarId: string, userId: string, interactions: Interaction[]): Promise<void>;
    private analyzeUserPreferences;
    private extractCommonThemes;
    private adjustAvatarConfig;
    knowledgeDistillation(sourceAvatarId: string, targetAvatarId: string): Promise<void>;
    recordFeedback(avatarId: string, userId: string, messageId: string, feedbackScore: number, feedbackText?: string): Promise<void>;
    getLearningStats(avatarId: string): Promise<any>;
    private getSkillDisplayName;
}
