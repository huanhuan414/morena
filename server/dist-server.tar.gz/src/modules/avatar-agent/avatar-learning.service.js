"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AvatarLearningService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarLearningService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
const avatar_memory_service_1 = require("./avatar-memory.service");
let AvatarLearningService = AvatarLearningService_1 = class AvatarLearningService {
    constructor(memoryService) {
        this.memoryService = memoryService;
        this.logger = new common_1.Logger(AvatarLearningService_1.name);
    }
    async learnFromResult(avatarId, thought, result) {
        try {
            const feedbackScore = result.success ? 5 : 1;
            const { error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_learning_records')
                .insert({
                avatar_id: avatarId,
                learning_type: 'task_completion',
                input_data: {
                    thought: thought.content,
                    intent: thought.intent,
                    requires_tool: thought.requiresTool
                },
                output_data: result,
                feedback_score: feedbackScore,
                learned_knowledge: result.success
                    ? `成功执行任务: ${thought.content}`
                    : `任务执行失败: ${result.error}`
            });
            if (error) {
                this.logger.error('Failed to record learning:', error);
                return;
            }
            if (result.success) {
                await this.memoryService.storeExperience(avatarId, {
                    description: `成功执行任务: ${thought.content}`,
                    taskType: thought.intent.type,
                    success: true,
                    outcome: result.data
                });
            }
            this.logger.log(`Learned from result for avatar ${avatarId}: ${result.success}`);
        }
        catch (error) {
            this.logger.error('Error learning from result:', error);
        }
    }
    async updateSkillLevel(avatarId, thought, response) {
        try {
            const skillType = thought.intent.skillType || thought.intent.type;
            if (!skillType || skillType === 'unknown')
                return;
            const { data: existingSkill, error: queryError } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_skills')
                .select('*')
                .eq('avatar_id', avatarId)
                .eq('skill_type', skillType)
                .single();
            if (queryError && queryError.code !== 'PGRST116') {
                this.logger.error('Error querying skill:', queryError);
                return;
            }
            const feedback = response.metadata?.feedback_score || 3;
            if (existingSkill) {
                const currentLevel = existingSkill.skill_level || 0;
                const newLevel = Math.min(currentLevel + 1, 10);
                const { error: updateError } = await (0, supabase_client_1.getSupabaseClient)()
                    .from('avatar_skills')
                    .update({
                    skill_level: newLevel,
                    usage_count: existingSkill.usage_count + 1,
                    last_used_at: new Date().toISOString(),
                    updated_at: new Date().toISOString()
                })
                    .eq('id', existingSkill.id);
                if (updateError) {
                    this.logger.error('Error updating skill:', updateError);
                }
            }
            else {
                const { error: insertError } = await (0, supabase_client_1.getSupabaseClient)()
                    .from('avatar_skills')
                    .insert({
                    avatar_id: avatarId,
                    skill_type: skillType,
                    skill_name: this.getSkillDisplayName(skillType),
                    skill_level: 1,
                    usage_count: 1,
                    last_used_at: new Date().toISOString()
                });
                if (insertError) {
                    this.logger.error('Error creating skill:', insertError);
                }
            }
        }
        catch (error) {
            this.logger.error('Error updating skill level:', error);
        }
    }
    async personalize(avatarId, userId, interactions) {
        try {
            const preferences = this.analyzeUserPreferences(interactions);
            for (const pref of preferences) {
                await this.memoryService.storePreference(avatarId, userId, pref);
            }
            await this.adjustAvatarConfig(avatarId, preferences);
            this.logger.log(`Personalized avatar ${avatarId} for user ${userId}`);
        }
        catch (error) {
            this.logger.error('Error personalizing avatar:', error);
        }
    }
    analyzeUserPreferences(interactions) {
        const preferences = [];
        const positiveFeedback = interactions.filter(i => i.feedback && i.feedback >= 4);
        const negativeFeedback = interactions.filter(i => i.feedback && i.feedback <= 2);
        if (positiveFeedback.length > 0) {
            const commonThemes = this.extractCommonThemes(positiveFeedback.map(i => i.response));
            preferences.push({
                type: 'response_style',
                description: `用户喜欢以下回复风格：${commonThemes.join(', ')}`,
                value: commonThemes
            });
        }
        if (negativeFeedback.length > 0) {
            const avoidedThemes = this.extractCommonThemes(negativeFeedback.map(i => i.response));
            preferences.push({
                type: 'avoided_content',
                description: `用户不喜欢以下内容：${avoidedThemes.join(', ')}`,
                value: avoidedThemes
            });
        }
        return preferences;
    }
    extractCommonThemes(texts) {
        const words = texts.join(' ').split(/\s+/);
        const wordCount = new Map();
        words.forEach(word => {
            if (word.length > 2) {
                wordCount.set(word, (wordCount.get(word) || 0) + 1);
            }
        });
        return Array.from(wordCount.entries())
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(entry => entry[0]);
    }
    async adjustAvatarConfig(avatarId, preferences) {
        try {
            const { data: currentConfig, error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_agent_configs')
                .select('*')
                .eq('avatar_id', avatarId)
                .single();
            if (error || !currentConfig) {
                return;
            }
            let systemPrompt = currentConfig.system_prompt;
            const preferenceText = preferences
                .map(p => `- ${p.description}`)
                .join('\n');
            if (!systemPrompt.includes('【用户偏好】')) {
                systemPrompt += `\n\n【用户偏好】\n${preferenceText}`;
            }
            else {
                systemPrompt = systemPrompt.replace(/【用户偏好】[\s\S]*?(?=\n\n|$)/, `【用户偏好】\n${preferenceText}`);
            }
            const { error: updateError } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_agent_configs')
                .update({
                system_prompt: systemPrompt,
                updated_at: new Date().toISOString()
            })
                .eq('avatar_id', avatarId);
            if (updateError) {
                this.logger.error('Error adjusting avatar config:', updateError);
            }
        }
        catch (error) {
            this.logger.error('Error adjusting avatar config:', error);
        }
    }
    async knowledgeDistillation(sourceAvatarId, targetAvatarId) {
        try {
            const experiences = await this.memoryService.getAvatarExperiences(sourceAvatarId, { minSuccessRate: 0.8 });
            for (const exp of experiences) {
                await this.memoryService.storeExperience(targetAvatarId, {
                    ...exp,
                    description: `[从分身 ${sourceAvatarId} 迁移] ${exp.description}`,
                    source: 'distillation'
                });
            }
            this.logger.log(`Distilled ${experiences.length} experiences from ${sourceAvatarId} to ${targetAvatarId}`);
        }
        catch (error) {
            this.logger.error('Error in knowledge distillation:', error);
        }
    }
    async recordFeedback(avatarId, userId, messageId, feedbackScore, feedbackText) {
        try {
            const { error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_learning_records')
                .insert({
                avatar_id: avatarId,
                learning_type: 'feedback',
                input_data: {
                    user_id: userId,
                    message_id: messageId
                },
                output_data: {
                    feedback_score: feedbackScore,
                    feedback_text: feedbackText
                },
                feedback_score: feedbackScore,
                learned_knowledge: feedbackText || `用户反馈: ${feedbackScore}/5`
            });
            if (error) {
                this.logger.error('Failed to record feedback:', error);
            }
            else {
                this.logger.log(`Recorded feedback for avatar ${avatarId}: ${feedbackScore}/5`);
            }
        }
        catch (error) {
            this.logger.error('Error recording feedback:', error);
        }
    }
    async getLearningStats(avatarId) {
        try {
            const { data: records, error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_learning_records')
                .select('*')
                .eq('avatar_id', avatarId)
                .order('created_at', { ascending: false });
            if (error || !records) {
                return null;
            }
            const stats = {
                totalRecords: records.length,
                byType: {},
                averageFeedback: 0,
                successRate: 0
            };
            records.forEach(record => {
                const type = record.learning_type;
                stats.byType[type] = (stats.byType[type] || 0) + 1;
            });
            const feedbackRecords = records.filter(r => r.feedback_score);
            if (feedbackRecords.length > 0) {
                const totalFeedback = feedbackRecords.reduce((sum, r) => sum + r.feedback_score, 0);
                stats.averageFeedback = totalFeedback / feedbackRecords.length;
            }
            const successRecords = records.filter(r => r.learning_type === 'task_completion' && r.feedback_score >= 4);
            if (stats.byType.task_completion > 0) {
                stats.successRate = successRecords.length / stats.byType.task_completion;
            }
            return stats;
        }
        catch (error) {
            this.logger.error('Error getting learning stats:', error);
            return null;
        }
    }
    getSkillDisplayName(skillType) {
        const displayNameMap = {
            'conversation': '对话能力',
            'writing': '内容创作',
            'image_gen': '图像生成',
            'video_gen': '视频生成',
            'publishing': '内容发布',
            'customer_service': '客服能力',
            'analysis': '数据分析',
            'planning': '任务规划',
            'problem_solving': '问题解决'
        };
        return displayNameMap[skillType] || skillType;
    }
};
exports.AvatarLearningService = AvatarLearningService;
exports.AvatarLearningService = AvatarLearningService = AvatarLearningService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [avatar_memory_service_1.AvatarMemoryService])
], AvatarLearningService);
//# sourceMappingURL=avatar-learning.service.js.map