export declare class AvatarAgentModule {
}
