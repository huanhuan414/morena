"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AvatarAgentService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarAgentService = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const supabase_client_1 = require("../../storage/database/supabase-client");
const avatar_memory_service_1 = require("./avatar-memory.service");
const avatar_learning_service_1 = require("./avatar-learning.service");
const tool_registry_1 = require("./tools/tool-registry");
let AvatarAgentService = AvatarAgentService_1 = class AvatarAgentService {
    constructor(memoryService, learningService, toolRegistry) {
        this.memoryService = memoryService;
        this.learningService = learningService;
        this.toolRegistry = toolRegistry;
        this.logger = new common_1.Logger(AvatarAgentService_1.name);
        const config = new coze_coding_dev_sdk_1.Config();
        this.llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
    }
    async think(avatarId, userMessage, context) {
        try {
            const config = await this.loadAvatarConfig(avatarId);
            const relevantMemories = await this.memoryService.retrieveRelevantMemories(avatarId, userMessage, config.memoryConfig);
            const reasoningContext = await this.buildReasoningContext(avatarId, userMessage, context, relevantMemories, config);
            const thought = await this.executeReasoning(avatarId, reasoningContext, config);
            await this.memoryService.storeThought(avatarId, thought);
            return thought;
        }
        catch (error) {
            this.logger.error('Error in think method:', error);
            return {
                id: `thought-${Date.now()}`,
                avatarId,
                content: '推理过程中发生错误',
                intent: {
                    type: 'error',
                    confidence: 0
                },
                requiresTool: false,
                createdAt: new Date().toISOString()
            };
        }
    }
    async act(avatarId, thought, context) {
        try {
            if (!thought.requiresTool || !thought.intent.toolName) {
                return {
                    success: true,
                    toolName: 'none',
                    data: { message: '无需执行工具' }
                };
            }
            const toolName = thought.intent.toolName;
            const params = thought.intent.params || {};
            this.logger.log(`Executing tool ${toolName} for avatar ${avatarId}`);
            const result = await this.executeToolByName(avatarId, toolName, params, context);
            return result;
        }
        catch (error) {
            this.logger.error('Error in act method:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
    async chat(avatarId, userId, message, conversationHistory) {
        try {
            const thought = await this.think(avatarId, message, {
                userId,
                history: conversationHistory
            });
            let response;
            if (thought.requiresTool && thought.intent.toolName) {
                const actionResult = await this.act(avatarId, thought, {
                    userId,
                    history: conversationHistory
                });
                response = await this.generateResponse(avatarId, thought, actionResult);
                if (actionResult.success) {
                    await this.learningService.learnFromResult(avatarId, thought, actionResult);
                }
            }
            else {
                response = await this.generateResponse(avatarId, thought);
                await this.learningService.learnFromResult(avatarId, thought, {
                    success: true,
                    toolName: 'none',
                    data: { message: response.content }
                });
            }
            await this.memoryService.storeConversation(avatarId, userId, {
                userMessage: message,
                assistantResponse: response.content,
                thought,
                metadata: response.metadata
            });
            await this.learningService.updateSkillLevel(avatarId, thought, response);
            return response;
        }
        catch (error) {
            this.logger.error('Error in chat method:', error);
            return {
                content: '抱歉，我遇到了一些问题，请稍后再试。',
                metadata: {
                    thought: {
                        id: 'error',
                        avatarId,
                        content: '',
                        intent: { type: 'error', confidence: 0 },
                        requiresTool: false,
                        createdAt: new Date().toISOString()
                    },
                    confidence: 0
                }
            };
        }
    }
    async loadAvatarConfig(avatarId) {
        try {
            const { data, error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_agent_configs')
                .select('*')
                .eq('avatar_id', avatarId)
                .single();
            const { data: avatarData, error: avatarError } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar')
                .select('name, personality, appearance_style, speaking_style, photo_analysis')
                .eq('id', avatarId)
                .single();
            if (error || !data) {
                return this.getDefaultConfig(avatarId, avatarData);
            }
            return {
                id: data.id,
                avatarId: data.avatar_id,
                systemPrompt: this.buildSystemPrompt(data.system_prompt, avatarData),
                rolePrompt: data.role_prompt,
                temperature: parseFloat(data.temperature),
                maxTokens: data.max_tokens,
                enabledTools: data.enabled_tools || [],
                knowledgeBases: data.knowledge_bases || [],
                reasoningMode: data.reasoning_mode,
                learningEnabled: data.learning_enabled,
                memoryConfig: data.memory_config || {},
                createdAt: data.created_at,
                updatedAt: data.updated_at
            };
        }
        catch (error) {
            this.logger.warn('Failed to load avatar config, using default:', error);
            return this.getDefaultConfig(avatarId);
        }
    }
    buildSystemPrompt(basePrompt, avatarData) {
        if (!avatarData) {
            return basePrompt || '你是一个智能分身助手。';
        }
        const parts = [basePrompt || '你是一个智能分身助手。'];
        if (avatarData.name) {
            parts.push(`\n## 你的名称\n你叫"${avatarData.name}"。`);
        }
        if (avatarData.personality) {
            const personalityMap = {
                'creative': '创意型 - 富有想象力，善于创新，思维跳跃，喜欢新事物',
                'analytical': '分析型 - 逻辑严密，善于推理，注重细节，善于分析',
                'empathetic': '共情型 - 善解人意，温暖体贴，善于倾听，富有同理心',
                'strategic': '战略型 - 目标导向，执行力强，善于规划，高效执行'
            };
            const personalityDesc = personalityMap[avatarData.personality] || avatarData.personality;
            parts.push(`\n## 你的性格\n${personalityDesc}。请始终保持这种性格特征进行对话。`);
        }
        if (avatarData.appearance_style) {
            const appearanceStyleMap = {
                'tech': '科技感 - 未来、理性、现代感',
                'warm': '温暖风 - 亲和、阳光、温馨',
                'mysterious': '神秘风 - 深邃、优雅、神秘感',
                'energetic': '活力风 - 热情、开朗、充满活力',
                'elegant': '优雅风 - 高贵、精致、典雅',
                'cute': '可爱风 - 萌趣、活泼、青春'
            };
            const styleDesc = appearanceStyleMap[avatarData.appearance_style] || avatarData.appearance_style;
            parts.push(`\n## 你的形象风格\n${styleDesc}`);
        }
        if (avatarData.speaking_style) {
            const speakingStyleMap = {
                'friendly': '亲切友好 - 像老朋友一样自然聊天，温暖亲切',
                'professional': '专业严谨 - 像专业顾问一样分析问题，条理清晰',
                'creative': '创意风趣 - 富有创意，幽默风趣，思维活跃',
                'gentle': '温柔治愈 - 温柔细腻，善解人意，富有同理心',
                'witty': '机智幽默 - 反应敏捷，妙语连珠，风趣幽默',
                'concise': '简洁高效 - 言简意赅，直击要点，高效沟通'
            };
            const styleDesc = speakingStyleMap[avatarData.speaking_style] || avatarData.speaking_style;
            parts.push(`\n## 你的说话方式\n${styleDesc}`);
        }
        if (avatarData.photo_analysis) {
            const analysis = avatarData.photo_analysis;
            if (analysis.temperament) {
                parts.push(`\n## 气质特征\n- 气质类型：${analysis.temperament.type}\n- 描述：${analysis.temperament.description}`);
            }
            if (analysis.facialFeatures) {
                parts.push(`\n## 面部特征\n- 表情特点：${analysis.facialFeatures.expression}\n- 眼神特点：${analysis.facialFeatures.eyes}\n- 整体印象：${analysis.facialFeatures.impression}`);
            }
            if (analysis.personality) {
                const coreTraits = analysis.personality.core?.join('、') || '';
                const strengths = analysis.personality.strengths?.join('、') || '';
                parts.push(`\n## 核心特质\n${coreTraits ? `- 核心特质：${coreTraits}` : ''}\n${strengths ? `- 优势：${strengths}` : ''}`);
            }
            if (analysis.communicationStyle) {
                parts.push(`\n## 沟通风格\n${analysis.communicationStyle}`);
            }
            if (analysis.strengths && analysis.strengths.length > 0) {
                parts.push(`\n## 擅长领域\n${analysis.strengths.join('、')}`);
            }
            if (analysis.summary) {
                parts.push(`\n## 综合画像\n${analysis.summary}`);
            }
        }
        return parts.join('\n');
    }
    async getDefaultConfig(avatarId, avatarData) {
        if (!avatarData) {
            try {
                const { data: data, error } = await (0, supabase_client_1.getSupabaseClient)()
                    .from('avatar')
                    .select('name, personality, appearance_style, speaking_style, photo_analysis')
                    .eq('id', avatarId)
                    .single();
                if (!error) {
                    avatarData = data;
                }
            }
            catch (err) {
                this.logger.warn('Failed to load avatar data:', err);
            }
        }
        return {
            id: 'default',
            avatarId,
            systemPrompt: this.buildSystemPrompt(undefined, avatarData) || `你是一个智能分身助手，负责回答用户问题。
- 使用友好和专业的语气
- 优先理解用户意图
- 根据用户需求提供帮助
- 记住用户的偏好和历史对话`,
            rolePrompt: undefined,
            temperature: 0.7,
            maxTokens: 2000,
            enabledTools: [],
            knowledgeBases: [],
            reasoningMode: 'react',
            learningEnabled: true,
            memoryConfig: {
                maxRetrieval: 5,
                similarityThreshold: 0.7,
                typeWeights: {
                    conversation: 1.0,
                    preference: 0.8,
                    experience: 0.6
                }
            },
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
    }
    async buildReasoningContext(avatarId, userMessage, context, relevantMemories, config) {
        const parts = [];
        if (config?.systemPrompt) {
            parts.push(`【系统角色】\n${config.systemPrompt}`);
        }
        if (config?.rolePrompt) {
            parts.push(`【角色设定】\n${config.rolePrompt}`);
        }
        const toolsDescription = this.toolRegistry.getToolsDescription();
        parts.push(`【可用工具】\n${toolsDescription}`);
        parts.push(`【工具使用指南】
当用户请求需要使用工具时，请：
1. 识别用户意图，判断是否需要工具
2. 如果需要工具，从【可用工具】中选择最合适的工具
3. 填写工具所需的参数（注意必填和可选参数）
4. 在回复中包含以下字段：
   - Requires Tool: true
   - Tool Name: [工具名称]
   - Parameters: [JSON格式的参数]

重要：好友查询的区别
- 当用户说"我的好友"、"我有多少好友"时，使用 query_friends 工具（查询用户的好友）
- 当用户说"我的分身好友"、"分身有多少好友"、"分身的好友"时，使用 query_avatar_friends 工具（查询分身的好友）
- 这两个是不同的好友列表，不要混淆！

注意：
- 只在真正需要时才使用工具
- 确保参数符合工具的要求
- 如果工具执行失败，请尝试分析原因并告知用户`);
        if (context?.history && context.history.length > 0) {
            const historyText = context.history
                .slice(-5)
                .map(msg => `${msg.role}: ${msg.content}`)
                .join('\n');
            parts.push(`【对话历史】\n${historyText}`);
        }
        if (relevantMemories && relevantMemories.length > 0) {
            const memoryText = relevantMemories
                .map(mem => `- ${mem.content}`)
                .join('\n');
            parts.push(`【相关记忆】\n${memoryText}`);
        }
        parts.push(`【用户消息】\n${userMessage}`);
        return parts.join('\n\n');
    }
    async executeReasoning(avatarId, context, config) {
        try {
            const prompt = `${context}

请分析用户的意图，并按以下格式回复：
Thought: [你的思考过程]
Intent Type: [意图类型]
Requires Tool: [true/false]
Tool Name: [工具名称，如果需要工具的话]
Parameters: [JSON格式的参数，如果需要工具的话]
Confidence: [置信度 0-1]`;
            const response = await this.llmClient.invoke([{ role: 'user', content: prompt }], {
                model: 'doubao-seed-1-8-251228',
                temperature: config.temperature
            });
            this.logger.log(`[大模型原始回复]\n${response.content}`);
            const thought = this.parseReasoningResponse(avatarId, response.content);
            return thought;
        }
        catch (error) {
            this.logger.error('Error executing reasoning:', error);
            return {
                id: `thought-${Date.now()}`,
                avatarId,
                content: '推理失败',
                intent: {
                    type: 'error',
                    confidence: 0
                },
                requiresTool: false,
                createdAt: new Date().toISOString()
            };
        }
    }
    parseReasoningResponse(avatarId, content) {
        const thought = {
            id: `thought-${Date.now()}`,
            avatarId,
            content: '',
            intent: {
                type: 'unknown',
                confidence: 0.5
            },
            requiresTool: false,
            createdAt: new Date().toISOString()
        };
        const thoughtMatch = content.match(/Thought:\s*(.+)/i);
        if (thoughtMatch) {
            thought.content = thoughtMatch[1].trim();
        }
        const intentMatch = content.match(/Intent Type:\s*(.+)/i);
        if (intentMatch) {
            thought.intent.type = intentMatch[1].trim();
        }
        const requiresToolMatch = content.match(/Requires Tool:\s*(.+)/i);
        if (requiresToolMatch) {
            thought.requiresTool = requiresToolMatch[1].trim().toLowerCase() === 'true';
        }
        const toolNameMatch = content.match(/Tool Name:\s*(.+)/i);
        if (toolNameMatch) {
            thought.intent.toolName = toolNameMatch[1].trim();
        }
        const paramsMatch = content.match(/Parameters:\s*(\{.*?\})/s);
        if (paramsMatch) {
            const rawParams = paramsMatch[1].trim();
            this.logger.log(`[原始参数内容] ${rawParams.substring(0, 500)}`);
            try {
                thought.intent.params = JSON.parse(rawParams);
                this.logger.log(`[解析成功] ${JSON.stringify(thought.intent.params)}`);
            }
            catch (e) {
                this.logger.warn(`[解析失败] ${e.message}`);
                this.logger.warn(`[参数内容] ${rawParams}`);
            }
        }
        else {
            this.logger.warn('[未找到参数]');
        }
        const confidenceMatch = content.match(/Confidence:\s*(.+)/i);
        if (confidenceMatch) {
            thought.intent.confidence = parseFloat(confidenceMatch[1].trim());
        }
        return thought;
    }
    async generateResponse(avatarId, thought, actionResult) {
        try {
            const config = await this.loadAvatarConfig(avatarId);
            let prompt = `${config.systemPrompt}\n\n`;
            if (actionResult) {
                prompt += `【思考过程】\n${thought.content}\n\n`;
                prompt += `【工具执行结果】\n`;
                prompt += actionResult.success
                    ? `工具 ${actionResult.toolName} 执行成功：\n${JSON.stringify(actionResult.data, null, 2)}`
                    : `工具 ${actionResult.toolName} 执行失败：${actionResult.error}`;
                prompt += '\n\n';
            }
            else {
                prompt += `【思考过程】\n${thought.content}\n\n`;
            }
            prompt += `【任务】\n根据以上信息，生成一个自然、友好的回复。`;
            const response = await this.llmClient.invoke([{ role: 'user', content: prompt }], {
                model: 'doubao-seed-1-8-251228',
                temperature: config.temperature
            });
            return {
                content: response.content,
                metadata: {
                    thought,
                    toolResults: actionResult ? [actionResult] : [],
                    confidence: thought.intent.confidence
                }
            };
        }
        catch (error) {
            this.logger.error('Error generating response:', error);
            return {
                content: thought.content || '抱歉，我无法生成合适的回复。',
                metadata: {
                    thought,
                    confidence: 0
                }
            };
        }
    }
    async executeToolByName(avatarId, toolName, params, context) {
        try {
            this.logger.log(`Executing tool: ${toolName} with params:`, params);
            const toolContext = {
                avatarId,
                userId: context?.userId || '',
                conversationId: context?.conversationId,
                metadata: context?.metadata
            };
            const result = await this.toolRegistry.executeTool(toolName, params, toolContext);
            return {
                success: result.success,
                toolName: result.toolName,
                data: result.data,
                error: result.error,
                executionTime: result.executionTime
            };
        }
        catch (error) {
            this.logger.error(`Error executing tool ${toolName}:`, error);
            return {
                success: false,
                toolName,
                error: error.message
            };
        }
    }
    async updateAvatarConfig(avatarId, updates) {
        try {
            const { error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_agent_configs')
                .upsert({
                avatar_id: avatarId,
                ...updates,
                updated_at: new Date().toISOString()
            });
            if (error) {
                throw error;
            }
            this.logger.log(`Updated config for avatar ${avatarId}`);
        }
        catch (error) {
            this.logger.error('Error updating avatar config:', error);
            throw error;
        }
    }
    async initializeAvatarConfig(avatarId, options) {
        const defaultConfig = await this.getDefaultConfig(avatarId);
        const config = {
            ...defaultConfig,
            systemPrompt: options?.systemPrompt || defaultConfig.systemPrompt,
            rolePrompt: options?.rolePrompt || defaultConfig.rolePrompt
        };
        await this.updateAvatarConfig(avatarId, config);
    }
};
exports.AvatarAgentService = AvatarAgentService;
exports.AvatarAgentService = AvatarAgentService = AvatarAgentService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, common_1.Inject)((0, common_1.forwardRef)(() => avatar_learning_service_1.AvatarLearningService))),
    __metadata("design:paramtypes", [avatar_memory_service_1.AvatarMemoryService,
        avatar_learning_service_1.AvatarLearningService,
        tool_registry_1.AvatarToolRegistry])
], AvatarAgentService);
//# sourceMappingURL=avatar-agent.service.js.map