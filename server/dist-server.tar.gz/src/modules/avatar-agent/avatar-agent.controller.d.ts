import { AvatarAgentService } from './avatar-agent.service';
import { AvatarMemoryService } from './avatar-memory.service';
import { AvatarLearningService } from './avatar-learning.service';
import { ConversationMessage } from './avatar-agent.types';
export declare class AvatarAgentController {
    private readonly agentService;
    private readonly memoryService;
    private readonly learningService;
    constructor(agentService: AvatarAgentService, memoryService: AvatarMemoryService, learningService: AvatarLearningService);
    chat(avatarId: string, userId: string, body: {
        message: string;
        conversationHistory?: ConversationMessage[];
    }): Promise<{
        code: number;
        data: import("./avatar-agent.types").AvatarResponse;
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    think(avatarId: string, body: {
        message: string;
        userId: string;
        conversationId?: string;
        conversationHistory?: ConversationMessage[];
    }): Promise<{
        code: number;
        data: import("./avatar-agent.types").AvatarThought;
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    getConfig(avatarId: string): Promise<{
        code: number;
        data: import("./avatar-agent.types").AvatarAgentConfig;
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    updateConfig(avatarId: string, body: {
        systemPrompt?: string;
        rolePrompt?: string;
        temperature?: number;
        maxTokens?: number;
        enabledTools?: string[];
        reasoningMode?: 'react' | 'chain_of_thought' | 'few_shot';
        learningEnabled?: boolean;
        memoryConfig?: any;
    }): Promise<{
        code: number;
        data: null;
        message: any;
    }>;
    initializeConfig(avatarId: string, body: {
        systemPrompt?: string;
        rolePrompt?: string;
        personality?: string;
    }): Promise<{
        code: number;
        data: null;
        message: any;
    }>;
    getMemories(avatarId: string, type?: string, limit?: string, userId?: string): Promise<{
        code: number;
        data: {
            memories: import("./avatar-agent.types").Memory[];
            count: number;
        };
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    getUserPreferences(avatarId: string, userId: string): Promise<{
        code: number;
        data: import("./avatar-agent.types").Preference[];
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    getExperiences(avatarId: string, taskType?: string, limit?: string): Promise<{
        code: number;
        data: import("./avatar-agent.types").Experience[];
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    recordFeedback(avatarId: string, userId: string, body: {
        messageId: string;
        feedbackScore: number;
        feedbackText?: string;
    }): Promise<{
        code: number;
        data: null;
        message: any;
    }>;
    getLearningStats(avatarId: string): Promise<{
        code: number;
        data: any;
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    getCapabilities(avatarId: string): Promise<{
        code: number;
        data: {
            memory: {
                total: number;
                byType: any;
                recentMemories: import("./avatar-agent.types").Memory[];
            };
            skills: any[];
            learning: any;
            thoughts: {
                id: any;
                action: any;
                intent: any;
                createdAt: any;
            }[];
        };
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    knowledgeDistillation(avatarId: string, sourceAvatarId: string): Promise<{
        code: number;
        data: null;
        message: any;
    }>;
    personalize(avatarId: string, userId: string, body: {
        interactions: any[];
    }): Promise<{
        code: number;
        data: null;
        message: any;
    }>;
}
