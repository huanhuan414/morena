"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
let NotificationService = class NotificationService {
    async getNotifications(userId, options) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        let query = client
            .from('notifications')
            .select('*')
            .eq('user_id', userId)
            .order('created_at', { ascending: false })
            .limit(50);
        if (options?.unreadOnly) {
            query = query.eq('is_read', false);
        }
        const { data, error } = await query;
        if (error) {
            console.error('获取通知失败:', error);
            return [];
        }
        return data || [];
    }
    async markAsRead(userId, notificationId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { error } = await client
            .from('notifications')
            .update({ is_read: true })
            .eq('id', notificationId)
            .eq('user_id', userId);
        if (error) {
            throw new Error(`标记已读失败: ${error.message}`);
        }
        return true;
    }
    async markAllAsRead(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { error } = await client
            .from('notifications')
            .update({ is_read: true })
            .eq('user_id', userId)
            .eq('is_read', false);
        if (error) {
            throw new Error(`标记全部已读失败: ${error.message}`);
        }
        return true;
    }
    async createNotification(userId, notification) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        if (!uuidRegex.test(userId)) {
            console.warn(`[NotificationService] 无效的 userId 格式: ${userId}，跳过创建通知`);
            return null;
        }
        const { data, error } = await client
            .from('notifications')
            .insert({
            user_id: userId,
            type: notification.type,
            title: notification.title,
            content: notification.content,
            data: notification.data || {}
        })
            .select()
            .single();
        if (error) {
            throw new Error(`创建通知失败: ${error.message}`);
        }
        return data;
    }
    async getNotificationSettings(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: user } = await client
            .from('users')
            .select('settings')
            .eq('id', userId)
            .single();
        const settings = user?.settings || {};
        return {
            message: settings.notification_message ?? true,
            like: settings.notification_like ?? true,
            follow: settings.notification_follow ?? true,
            system: settings.notification_system ?? true
        };
    }
    async updateNotificationSettings(userId, settings) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: user } = await client
            .from('users')
            .select('settings')
            .eq('id', userId)
            .single();
        const currentSettings = user?.settings || {};
        const newSettings = {
            ...currentSettings,
            notification_message: settings.message ?? currentSettings.notification_message,
            notification_like: settings.like ?? currentSettings.notification_like,
            notification_follow: settings.follow ?? currentSettings.notification_follow,
            notification_system: settings.system ?? currentSettings.notification_system
        };
        const { error } = await client
            .from('users')
            .update({ settings: newSettings })
            .eq('id', userId);
        if (error) {
            throw new Error(`更新设置失败: ${error.message}`);
        }
        return this.getNotificationSettings(userId);
    }
    async getUnreadCount(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { count, error } = await client
            .from('notifications')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId)
            .eq('is_read', false);
        if (error) {
            return 0;
        }
        return count || 0;
    }
    async getNotificationsByOrder(orderId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data, error } = await client
            .from('notifications')
            .select('*')
            .order('created_at', { ascending: false })
            .limit(50);
        if (error) {
            console.error('获取订单通知失败:', error);
            return [];
        }
        const filteredNotifications = (data || []).filter((notification) => {
            try {
                if (notification.data && typeof notification.data === 'object') {
                    if (notification.data.order_id === orderId) {
                        return true;
                    }
                    if (notification.data.orderId === orderId) {
                        return true;
                    }
                }
                if (notification.content && typeof notification.content === 'string') {
                    if (notification.content.includes(orderId)) {
                        return true;
                    }
                    try {
                        const contentData = JSON.parse(notification.content);
                        if (contentData.order_id === orderId || contentData.orderId === orderId) {
                            return true;
                        }
                    }
                    catch (e) {
                    }
                }
                return false;
            }
            catch (e) {
                console.warn('解析通知数据失败:', e);
                return false;
            }
        });
        const notificationsWithAvatar = await Promise.all(filteredNotifications.map(async (notification) => {
            let avatarInfo = null;
            if (notification.data && typeof notification.data === 'object') {
                const avatarId = notification.data.avatarId || notification.data.avatar_id;
                if (avatarId) {
                    try {
                        const { data: avatar } = await client
                            .from('avatars')
                            .select('id, name, avatar_url')
                            .eq('id', avatarId)
                            .single();
                        if (avatar) {
                            avatarInfo = {
                                id: avatar.id,
                                name: avatar.name,
                                avatar_url: avatar.avatar_url
                            };
                        }
                    }
                    catch (error) {
                        console.warn(`获取分身信息失败:`, error);
                    }
                }
            }
            if (!avatarInfo && notification.content) {
                const match = notification.content.match(/分身["\s]+([^"\s]+)/);
                if (match && match[1]) {
                    avatarInfo = {
                        id: null,
                        name: match[1],
                        avatar_url: null
                    };
                }
            }
            return {
                ...notification,
                avatar: avatarInfo
            };
        }));
        return notificationsWithAvatar;
    }
};
exports.NotificationService = NotificationService;
exports.NotificationService = NotificationService = __decorate([
    (0, common_1.Injectable)()
], NotificationService);
//# sourceMappingURL=notification.service.js.map