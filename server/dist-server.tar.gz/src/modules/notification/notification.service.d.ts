export declare class NotificationService {
    getNotifications(userId: string, options?: {
        unreadOnly?: boolean;
    }): Promise<any[]>;
    markAsRead(userId: string, notificationId: string): Promise<boolean>;
    markAllAsRead(userId: string): Promise<boolean>;
    createNotification(userId: string, notification: {
        type: string;
        title: string;
        content: string;
        data?: Record<string, any>;
    }): Promise<any>;
    getNotificationSettings(userId: string): Promise<{
        message: any;
        like: any;
        follow: any;
        system: any;
    }>;
    updateNotificationSettings(userId: string, settings: Record<string, boolean>): Promise<{
        message: any;
        like: any;
        follow: any;
        system: any;
    }>;
    getUnreadCount(userId: string): Promise<number>;
    getNotificationsByOrder(orderId: string): Promise<any[]>;
}
