export declare class NotificationModule {
}
