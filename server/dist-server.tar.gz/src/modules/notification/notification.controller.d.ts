import { NotificationService } from './notification.service';
export declare class NotificationController {
    private readonly notificationService;
    constructor(notificationService: NotificationService);
    getNotifications(userId: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
    getUnreadCount(userId: string): Promise<{
        code: number;
        data: {
            count: number;
        };
        message: string;
    }>;
    getSettings(userId: string): Promise<{
        code: number;
        data: {
            message: any;
            like: any;
            follow: any;
            system: any;
        };
        message: string;
    }>;
    updateSettings(userId: string, settings: Record<string, boolean>): Promise<{
        code: number;
        data: {
            message: any;
            like: any;
            follow: any;
            system: any;
        };
        message: string;
    }>;
    markAsRead(notificationId: string, userId: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    markAllAsRead(userId: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    createNotification(userId: string, body: {
        type: string;
        title: string;
        content: string;
        data?: any;
    }): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getNotificationsByOrder(orderId: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
}
