import { MessageEvent } from '@nestjs/common';
import { Observable } from 'rxjs';
import { ChatService } from './chat.service';
export declare class ChatController {
    private readonly chatService;
    constructor(chatService: ChatService);
    createConversation(userId: string, avatarId: string, title?: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getConversations(userId: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
    getMessages(conversationId: string, limit?: string, before?: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
    sendMessage(userId: string, body: {
        conversation_id: string;
        avatar_id: string;
        content: string;
        metadata?: any;
    }, req: any): Promise<{
        code: number;
        data: {
            role: string;
            content: string;
            taskId: string | undefined;
        };
        message: string;
    }>;
    streamMessage(userId: string, body: {
        conversation_id: string;
        avatar_id: string;
        content: string;
        metadata?: any;
    }, req: any): Promise<Observable<MessageEvent>>;
    deleteConversation(conversationId: string, userId: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    generateContent(prompt: string): Promise<{
        code: number;
        data: {
            content: string;
        };
        message: string;
    }>;
}
