"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatController = void 0;
const common_1 = require("@nestjs/common");
const rxjs_1 = require("rxjs");
const chat_service_1 = require("./chat.service");
let ChatController = class ChatController {
    constructor(chatService) {
        this.chatService = chatService;
    }
    async createConversation(userId, avatarId, title) {
        const conversation = await this.chatService.createConversation(userId, avatarId, title);
        return {
            code: 200,
            data: conversation,
            message: '创建成功'
        };
    }
    async getConversations(userId) {
        const conversations = await this.chatService.getConversations(userId);
        return {
            code: 200,
            data: conversations,
            message: '获取成功'
        };
    }
    async getMessages(conversationId, limit, before) {
        const limitNum = limit ? parseInt(limit, 10) : 20;
        const messages = await this.chatService.getConversationMessages(conversationId, limitNum, before);
        return {
            code: 200,
            data: messages,
            message: '获取成功'
        };
    }
    async sendMessage(userId, body, req) {
        const headers = req.headers;
        const message = await this.chatService.sendMessage(body.conversation_id, userId, body.avatar_id, body.content, body.metadata, headers);
        return {
            code: 200,
            data: message,
            message: '发送成功'
        };
    }
    async streamMessage(userId, body, req) {
        const headers = req.headers;
        return new rxjs_1.Observable(subscriber => {
            (async () => {
                try {
                    const generator = this.chatService.sendMessageStream(body.conversation_id, userId, body.avatar_id, body.content, body.metadata, headers);
                    for await (const chunk of generator) {
                        subscriber.next({ data: chunk });
                    }
                    subscriber.complete();
                }
                catch (error) {
                    subscriber.error(error);
                }
            })();
        });
    }
    async deleteConversation(conversationId, userId) {
        await this.chatService.deleteConversation(conversationId, userId);
        return {
            code: 200,
            data: null,
            message: '删除成功'
        };
    }
    async generateContent(prompt) {
        const content = await this.chatService.generateContent(prompt);
        return {
            code: 200,
            data: {
                content
            },
            message: '生成成功'
        };
    }
};
exports.ChatController = ChatController;
__decorate([
    (0, common_1.Post)('conversation'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)('avatar_id')),
    __param(2, (0, common_1.Body)('title')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "createConversation", null);
__decorate([
    (0, common_1.Get)('conversations'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "getConversations", null);
__decorate([
    (0, common_1.Get)('conversation/:id/messages'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('limit')),
    __param(2, (0, common_1.Query)('before')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "getMessages", null);
__decorate([
    (0, common_1.Post)('send'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "sendMessage", null);
__decorate([
    (0, common_1.Sse)('stream'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "streamMessage", null);
__decorate([
    (0, common_1.Delete)('conversation/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "deleteConversation", null);
__decorate([
    (0, common_1.Post)('generate'),
    __param(0, (0, common_1.Body)('prompt')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ChatController.prototype, "generateContent", null);
exports.ChatController = ChatController = __decorate([
    (0, common_1.Controller)('chat'),
    __metadata("design:paramtypes", [chat_service_1.ChatService])
], ChatController);
//# sourceMappingURL=chat.controller.js.map