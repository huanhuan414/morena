import { AgentService } from '../agent/agent.service';
import { LearningService } from '../avatar/learning.service';
import { StorageService } from '../storage/storage.service';
export declare class ChatService {
    private readonly agentService;
    private readonly learningService;
    private readonly storageService;
    constructor(agentService: AgentService, learningService: LearningService, storageService: StorageService);
    createConversation(userId: string, avatarId: string, title?: string): Promise<any>;
    getConversations(userId: string): Promise<any[]>;
    getConversationMessages(conversationId: string, limit?: number, before?: string): Promise<any[]>;
    sendMessage(conversationId: string, userId: string, avatarId: string, content: string, metadata?: any, headers?: Record<string, string>): Promise<{
        role: string;
        content: string;
        taskId: string | undefined;
    }>;
    sendMessageStream(conversationId: string, userId: string, avatarId: string, content: string, metadata?: any, headers?: Record<string, string>): AsyncGenerator<any>;
    executeTaskWithUpdates(taskId: string, userId: string, avatarId: string, content: string, headers?: Record<string, string>): AsyncGenerator<any>;
    private buildSystemPrompt;
    private calculateChatExp;
    private addAvatarExp;
    private updateAvatarLearning;
    private detectTaskIntent;
    private sanitizeMessage;
    private createTaskFromChat;
    private executeAgentTaskWithTaskId;
    deleteConversation(conversationId: string, userId: string): Promise<void>;
    generateContent(prompt: string): Promise<string>;
}
