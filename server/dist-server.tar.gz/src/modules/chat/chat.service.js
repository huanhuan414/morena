"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatService = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const supabase_client_1 = require("../../storage/database/supabase-client");
const agent_service_1 = require("../agent/agent.service");
const learning_service_1 = require("../avatar/learning.service");
const storage_service_1 = require("../storage/storage.service");
let ChatService = class ChatService {
    constructor(agentService, learningService, storageService) {
        this.agentService = agentService;
        this.learningService = learningService;
        this.storageService = storageService;
    }
    async createConversation(userId, avatarId, title) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        if (!avatarId) {
            avatarId = 'default-avatar';
        }
        const { data: avatar, error: avatarError } = await client
            .from('avatars')
            .select('id')
            .eq('id', avatarId)
            .maybeSingle();
        if (avatarError || !avatar) {
            console.warn(`分身 ${avatarId} 不存在，使用默认处理`);
        }
        const { data: existingUser, error: userError } = await client
            .from('users')
            .select('id')
            .eq('id', userId)
            .maybeSingle();
        if (userError || !existingUser) {
            await client
                .from('users')
                .insert({
                id: userId,
                openid: `mock_openid_${userId}`,
                nickname: userId ? `用户${userId.slice(-4)}` : '测试用户',
                avatar: '',
                level: 1,
                exp: 0,
                credits: 0
            });
        }
        const { data, error } = await client
            .from('conversations')
            .insert({
            user_id: userId,
            avatar_id: avatarId,
            title: title || '新对话',
            context: [],
            updated_at: new Date().toISOString()
        })
            .select()
            .maybeSingle();
        if (error) {
            if (error.message.includes('foreign key constraint')) {
                const { data: newData, error: newError } = await client
                    .from('conversations')
                    .insert({
                    user_id: userId,
                    avatar_id: null,
                    title: title || '新对话',
                    context: [],
                    updated_at: new Date().toISOString()
                })
                    .select()
                    .maybeSingle();
                if (newError) {
                    throw new Error(`创建对话失败: ${newError.message}`);
                }
                return newData;
            }
            throw new Error(`创建对话失败: ${error.message}`);
        }
        return data;
    }
    async getConversations(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data, error } = await client
            .from('conversations')
            .select('*, avatars(name, avatar_url)')
            .eq('user_id', userId)
            .order('updated_at', { ascending: false });
        if (error) {
            throw new Error(`获取对话列表失败: ${error.message}`);
        }
        return data;
    }
    async getConversationMessages(conversationId, limit = 20, before) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        let query = client
            .from('messages')
            .select('*')
            .eq('conversation_id', conversationId)
            .order('created_at', { ascending: false })
            .limit(limit);
        if (before) {
            const { data: beforeMsg } = await client
                .from('messages')
                .select('created_at')
                .eq('id', before)
                .single();
            if (beforeMsg) {
                query = query.lt('created_at', beforeMsg.created_at);
            }
        }
        const { data, error } = await query;
        if (error) {
            throw new Error(`获取消息失败: ${error.message}`);
        }
        const messages = (data || []).reverse();
        const processedMessages = await Promise.all(messages.map(async (msg) => {
            let mediaUrls = {};
            if (msg.metadata?.media) {
                console.log('[ChatService getConversationMessages] 处理消息', msg.id, '原始 media:', JSON.stringify(msg.metadata.media));
            }
            else {
                console.log('[ChatService getConversationMessages] 处理消息', msg.id, '没有 media 字段');
            }
            if (msg.metadata?.media_keys) {
                const urls = await Promise.all(msg.metadata.media_keys.map(async (key) => {
                    const url = await this.storageService.getFileUrl(key, 86400);
                    return { key, url };
                }));
                mediaUrls = urls.reduce((acc, { key, url }) => {
                    acc[key] = url;
                    return acc;
                }, {});
            }
            let mediaList = [];
            if (msg.metadata?.media && Array.isArray(msg.metadata.media)) {
                console.log('[ChatService] 开始处理 media 数组，数量:', msg.metadata.media.length);
                if (msg.metadata.media.length === 0) {
                    console.log('[ChatService] 警告：media 数组为空！');
                }
                mediaList = await Promise.all(msg.metadata.media.map(async (mediaItem) => {
                    console.log('[ChatService] 处理 mediaItem:', JSON.stringify(mediaItem));
                    if (mediaItem.key) {
                        if (mediaItem.url && (mediaItem.url.includes('ivolces.com') || mediaItem.url.includes('voic.51webjs.com'))) {
                            console.log('[ChatService] 检测到 veImageX URL，跳过签名链接生成:', mediaItem.url);
                            return mediaItem;
                        }
                        try {
                            const newUrl = await this.storageService.getFileUrl(mediaItem.key, 86400 * 7);
                            console.log('[ChatService] 重新生成签名链接成功:', mediaItem.key, '->', newUrl);
                            return {
                                ...mediaItem,
                                url: newUrl
                            };
                        }
                        catch (error) {
                            console.error('[ChatService] 重新生成签名链接失败:', mediaItem.key, error);
                            return mediaItem;
                        }
                    }
                    console.log('[ChatService] mediaItem 没有 key，返回原始数据');
                    return mediaItem;
                }));
                console.log('[ChatService] 处理完成，mediaList:', JSON.stringify(mediaList));
            }
            else {
                console.log('[ChatService] 没有找到 media 数组或不是数组');
            }
            if (msg.metadata?.media_urls && typeof msg.metadata.media_urls === 'object' && mediaList.length === 0) {
                mediaList = Object.entries(msg.metadata.media_urls).map(([key, url]) => {
                    const keyLower = key.toLowerCase();
                    if (keyLower.includes('.mp4') || keyLower.includes('.mov') || keyLower.includes('.webm') || keyLower.includes('video')) {
                        return { type: 'video', url, key };
                    }
                    else if (keyLower.includes('.jpg') || keyLower.includes('.jpeg') || keyLower.includes('.png') || keyLower.includes('.gif') || keyLower.includes('image')) {
                        return { type: 'image', url, key };
                    }
                    return { type: 'image', url, key };
                });
            }
            return {
                ...msg,
                metadata: {
                    ...msg.metadata,
                    media_urls: mediaUrls,
                    media: mediaList
                }
            };
        }));
        console.log('[ChatService] 处理完成的消息列表:', processedMessages.map(m => ({
            id: m.id,
            role: m.role,
            hasAgentResult: !!m.metadata?.agent_result,
            agentResultStepsCount: m.metadata?.agent_result?.steps?.length || 0,
            hasMedia: !!m.metadata?.media,
            mediaCount: m.metadata?.media?.length || 0
        })));
        return processedMessages;
    }
    async sendMessage(conversationId, userId, avatarId, content, metadata, headers) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: conversation } = await client
            .from('conversations')
            .select('context, title')
            .eq('id', conversationId)
            .single();
        if (conversation?.title?.includes('与') && conversation?.title?.includes('的对话')) {
            const friendId = conversation.context?.friend_id;
            if (friendId) {
                const { data: block } = await client
                    .from('avatar_blocks')
                    .select('id')
                    .eq('avatar_id', avatarId)
                    .eq('blocked_avatar_id', friendId)
                    .single();
                if (block) {
                    throw new Error('对方已将你拉黑，无法发送消息');
                }
                const { data: selfBlock } = await client
                    .from('avatar_blocks')
                    .select('id')
                    .eq('avatar_id', friendId)
                    .eq('blocked_avatar_id', avatarId)
                    .single();
                if (selfBlock) {
                    throw new Error('你已拉黑对方，无法发送消息');
                }
            }
        }
        const { data: avatar } = await client
            .from('avatars')
            .select('*')
            .eq('id', avatarId)
            .single();
        const privacyMode = avatar?.config?.privacy_mode ?? false;
        const userContent = privacyMode ? this.sanitizeMessage(content) : content;
        await client.from('messages').insert({
            conversation_id: conversationId,
            role: 'user',
            content: userContent,
            metadata: metadata || null
        });
        const messages = [
            {
                role: 'system',
                content: await this.buildSystemPrompt(avatar)
            },
            ...(conversation?.context || []).slice(-10),
            { role: 'user', content }
        ];
        const customHeaders = headers ? coze_coding_dev_sdk_1.HeaderUtils.extractForwardHeaders(headers) : undefined;
        const config = new coze_coding_dev_sdk_1.Config();
        const llmClient = new coze_coding_dev_sdk_1.LLMClient(config, customHeaders);
        const response = await llmClient.invoke(messages, {
            model: 'doubao-seed-1-8-251228',
            temperature: 0.8
        });
        const aiContent = privacyMode ? this.sanitizeMessage(response.content) : response.content;
        await client.from('messages').insert({
            conversation_id: conversationId,
            role: 'assistant',
            content: aiContent
        });
        const newContext = [
            ...(conversation?.context || []).slice(-8),
            { role: 'user', content },
            { role: 'assistant', content: response.content }
        ];
        const updateData = {
            context: newContext,
            updated_at: new Date().toISOString()
        };
        if (conversation?.title === '新对话' || !conversation?.title) {
            const title = content.length <= 30 ? content : content.substring(0, 30) + '...';
            updateData.title = title;
        }
        await client
            .from('conversations')
            .update(updateData)
            .eq('id', conversationId);
        const { data: avatarData } = await client
            .from('avatars')
            .select('exp, level')
            .eq('id', avatarId)
            .single();
        const chatExp = this.calculateChatExp(avatarData?.level || 1, content.length);
        await this.addAvatarExp(avatarId, chatExp);
        await this.updateAvatarLearning(avatarId, content, response.content, conversation?.context);
        const taskInfo = this.detectTaskIntent(content, response.content);
        if (taskInfo && !response.content.includes('开始执行任务')) {
            await this.createTaskFromChat(userId, avatarId, taskInfo);
        }
        let taskId;
        if (response.content.includes('开始执行任务')) {
            const { data: task } = await client
                .from('tasks')
                .insert({
                user_id: userId,
                avatar_id: avatarId,
                title: `🤖 ${content.substring(0, 50)}${content.length > 50 ? '...' : ''}`,
                description: content,
                task_type: 'agent',
                priority: 'high',
                status: 'pending',
                progress: 0,
                params: { source: 'chat_agent' },
                result: {},
                logs: []
            })
                .select()
                .single();
            if (task) {
                taskId = task.id;
                this.executeAgentTaskWithTaskId(task.id, userId, avatarId, conversationId, content, headers)
                    .catch(err => console.error('Agent 任务执行失败:', err));
            }
        }
        return {
            role: 'assistant',
            content: response.content,
            taskId
        };
    }
    async *sendMessageStream(conversationId, userId, avatarId, content, metadata, headers) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        yield { type: 'status', data: { stage: 'thinking', message: '正在思考...' } };
        const { data: conversation } = await client
            .from('conversations')
            .select('context, title')
            .eq('id', conversationId)
            .single();
        const { data: avatar } = await client
            .from('avatars')
            .select('*')
            .eq('id', avatarId)
            .single();
        yield { type: 'status', data: { stage: 'processing', message: '处理请求中...' } };
        await client.from('messages').insert({
            conversation_id: conversationId,
            role: 'user',
            content,
            metadata: metadata || null
        });
        const messages = [
            {
                role: 'system',
                content: await this.buildSystemPrompt(avatar)
            },
            ...(conversation?.context || []).slice(-10),
            { role: 'user', content }
        ];
        const customHeaders = headers ? coze_coding_dev_sdk_1.HeaderUtils.extractForwardHeaders(headers) : undefined;
        const config = new coze_coding_dev_sdk_1.Config();
        const llmClient = new coze_coding_dev_sdk_1.LLMClient(config, customHeaders);
        let fullResponse = '';
        yield { type: 'status', data: { stage: 'generating', message: '生成回复中...' } };
        try {
            const stream = llmClient.stream(messages, {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.8
            });
            for await (const chunk of stream) {
                if (chunk.content) {
                    const text = chunk.content.toString();
                    fullResponse += text;
                    yield { type: 'text', data: text };
                }
            }
        }
        catch (error) {
            console.error('LLM流式调用失败:', error);
            const response = await llmClient.invoke(messages, {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.8
            });
            fullResponse = response.content;
            yield { type: 'text', data: response.content };
        }
        if (fullResponse.includes('开始执行任务') || fullResponse.includes('正在处理')) {
            yield { type: 'status', data: { stage: 'task_start', message: '开始执行任务...' } };
            const { data: task } = await client
                .from('tasks')
                .insert({
                user_id: userId,
                avatar_id: avatarId,
                title: `🤖 ${content.substring(0, 50)}${content.length > 50 ? '...' : ''}`,
                description: content,
                task_type: 'agent',
                priority: 'high',
                status: 'pending',
                progress: 0,
                params: { source: 'chat_agent' },
                result: {},
                logs: []
            })
                .select()
                .single();
            if (task) {
                yield { type: 'task', data: { taskId: task.id, status: 'pending', progress: 0 } };
                try {
                    for await (const update of this.executeTaskWithUpdates(task.id, userId, avatarId, content, headers)) {
                        yield update;
                    }
                }
                catch (error) {
                    yield { type: 'task_error', data: { message: '任务执行失败' } };
                }
            }
        }
        await client.from('messages').insert({
            conversation_id: conversationId,
            role: 'assistant',
            content: fullResponse
        });
        const newContext = [
            ...(conversation?.context || []).slice(-8),
            { role: 'user', content },
            { role: 'assistant', content: fullResponse }
        ];
        const updateData = {
            context: newContext,
            updated_at: new Date().toISOString()
        };
        if (conversation?.title === '新对话' || !conversation?.title) {
            const title = content.length <= 30 ? content : content.substring(0, 30) + '...';
            updateData.title = title;
        }
        await client
            .from('conversations')
            .update(updateData)
            .eq('id', conversationId);
        const { data: avatarData } = await client
            .from('avatars')
            .select('exp, level')
            .eq('id', avatarId)
            .single();
        const chatExp = this.calculateChatExp(avatarData?.level || 1, content.length);
        await this.addAvatarExp(avatarId, chatExp);
        await this.updateAvatarLearning(avatarId, content, fullResponse, conversation?.context);
        yield { type: 'done', data: { message: '完成' } };
    }
    async *executeTaskWithUpdates(taskId, userId, avatarId, content, headers) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        yield { type: 'task', data: { taskId, status: 'running', progress: 10, message: '分析任务需求...' } };
        await client
            .from('tasks')
            .update({ status: 'running', progress: 10 })
            .eq('id', taskId);
        try {
            const stages = [
                { progress: 20, message: '规划执行步骤...' },
                { progress: 40, message: '调用AI能力处理...' },
                { progress: 60, message: '生成内容中...' },
                { progress: 80, message: '优化结果...' }
            ];
            for (const stage of stages) {
                await new Promise(resolve => setTimeout(resolve, 800));
                yield { type: 'task', data: { taskId, status: 'running', progress: stage.progress, message: stage.message } };
                await client
                    .from('tasks')
                    .update({ progress: stage.progress })
                    .eq('id', taskId);
            }
            const taskLower = content.toLowerCase();
            let result = { type: 'text', content: '任务已完成' };
            if (taskLower.includes('画') || taskLower.includes('生成图片') || taskLower.includes('设计')) {
                yield { type: 'task', data: { taskId, status: 'running', progress: 85, message: '正在生成图片...' } };
                const imageBuffer = Buffer.from('模拟图片数据');
                const imageUrl = await this.storageService.uploadImageFromBuffer(imageBuffer, `generated/${taskId}/image_${Date.now()}.png`);
                result = {
                    type: 'image',
                    url: imageUrl,
                    key: null
                };
                yield {
                    type: 'media',
                    data: {
                        type: 'image',
                        url: imageUrl,
                        key: null
                    }
                };
            }
            if (taskLower.includes('视频') || taskLower.includes('短片')) {
                yield { type: 'task', data: { taskId, status: 'running', progress: 85, message: '正在生成视频...' } };
                const videoBuffer = Buffer.from('模拟视频数据');
                const videoUrl = await this.storageService.uploadVideo(videoBuffer, `generated/${taskId}/video_${Date.now()}.mp4`);
                result = {
                    type: 'video',
                    url: videoUrl,
                    key: null
                };
                yield {
                    type: 'media',
                    data: {
                        type: 'video',
                        url: videoUrl,
                        key: null
                    }
                };
            }
            if (taskLower.includes('文章') || taskLower.includes('写') || taskLower.includes('创作')) {
                yield { type: 'task', data: { taskId, status: 'running', progress: 85, message: '正在撰写文章...' } };
                const articleContent = `# ${content}\n\n这是一篇由AI生成的文章...\n\n## 主要内容\n\n文章正文内容...`;
                result = {
                    type: 'article',
                    content: articleContent,
                    title: content
                };
                yield {
                    type: 'media',
                    data: {
                        type: 'article',
                        content: articleContent,
                        title: content
                    }
                };
            }
            await client
                .from('tasks')
                .update({
                status: 'completed',
                progress: 100,
                result,
                completed_at: new Date().toISOString()
            })
                .eq('id', taskId);
            yield { type: 'task', data: { taskId, status: 'completed', progress: 100, result } };
        }
        catch (error) {
            console.error('任务执行失败:', error);
            await client
                .from('tasks')
                .update({
                status: 'failed',
                result: { error: error.message }
            })
                .eq('id', taskId);
            yield { type: 'task_error', data: { taskId, message: error.message } };
        }
    }
    async buildSystemPrompt(avatar) {
        return this.learningService.buildPersonalizedPrompt(avatar.id, avatar);
    }
    calculateChatExp(level, messageLength) {
        let baseExp;
        if (level <= 5) {
            baseExp = 5 + (level - 1) * 2;
        }
        else {
            baseExp = 15 + (level - 5) * 5;
        }
        let lengthBonus = 0;
        if (messageLength >= 200) {
            lengthBonus = Math.floor(messageLength / 100);
        }
        else if (messageLength >= 50) {
            lengthBonus = 1;
        }
        return baseExp + lengthBonus;
    }
    async addAvatarExp(avatarId, exp) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: avatar } = await client
            .from('avatars')
            .select('exp, level')
            .eq('id', avatarId)
            .single();
        if (avatar) {
            const newExp = (avatar.exp || 0) + exp;
            const calculatedLevel = Math.floor(newExp / 100) + 1;
            const newLevel = Math.min(calculatedLevel, 10);
            const updateData = { exp: newExp };
            if (newLevel > (avatar.level || 1)) {
                updateData.level = newLevel;
            }
            await client
                .from('avatars')
                .update(updateData)
                .eq('id', avatarId);
        }
    }
    async updateAvatarLearning(avatarId, userMessage, aiMessage, conversationContext) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: { user } } = await client.auth.getUser();
        const userId = user?.id || 'anonymous';
        await this.learningService.analyzeAndUpdate(avatarId, userId, userMessage, aiMessage, conversationContext);
    }
    detectTaskIntent(userMessage, aiResponse) {
        const message = userMessage.toLowerCase();
        if (message.includes('提醒我') || message.includes('提醒')) {
            return { type: 'reminder', content: userMessage };
        }
        if (message.includes('安排') || message.includes('计划')) {
            return { type: 'schedule', content: userMessage };
        }
        return null;
    }
    sanitizeMessage(content) {
        if (!content)
            return content;
        let sanitized = content;
        sanitized = sanitized.replace(/1[3-9]\d{9}/g, (match) => {
            return match.slice(0, 3) + '****' + match.slice(-4);
        });
        sanitized = sanitized.replace(/\d{17}[\dXx]/g, (match) => {
            return match.slice(0, 6) + '********' + match.slice(-4);
        });
        sanitized = sanitized.replace(/\d{16,19}/g, (match) => {
            if (match.length >= 16) {
                return match.slice(0, 4) + '****' + match.slice(-4);
            }
            return match;
        });
        sanitized = sanitized.replace(/[\w.-]+@[\w.-]+\.\w+/g, (match) => {
            const [localPart, domain] = match.split('@');
            if (localPart.length > 2) {
                return localPart.slice(0, 2) + '***@' + domain;
            }
            return match;
        });
        return sanitized;
    }
    async createTaskFromChat(userId, avatarId, taskInfo) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        await client.from('tasks').insert({
            user_id: userId,
            avatar_id: avatarId,
            title: taskInfo.content.substring(0, 100),
            description: taskInfo.content,
            type: taskInfo.type,
            status: 'pending',
            progress: 0
        });
    }
    async executeAgentTaskWithTaskId(taskId, userId, avatarId, conversationId, content, headers) {
        let lastResponse = '任务已完成';
        for await (const update of this.executeTaskWithUpdates(taskId, userId, avatarId, content, headers)) {
            if (update.type === 'text' && update.data) {
                lastResponse = update.data;
            }
        }
        try {
            await this.updateAvatarLearning(avatarId, content, lastResponse);
        }
        catch (error) {
            console.error('[ChatService] executeAgentTaskWithTaskId 中调用 updateAvatarLearning 失败:', error);
        }
    }
    async deleteConversation(conversationId, userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        await client
            .from('conversations')
            .delete()
            .eq('id', conversationId)
            .eq('user_id', userId);
    }
    async generateContent(prompt) {
        const messages = [
            {
                role: 'system',
                content: '你是一个专业的AI助手，擅长根据用户的输入生成高质量的内容。请根据用户的提示词生成准确、有用的内容。'
            },
            {
                role: 'user',
                content: prompt
            }
        ];
        const config = new coze_coding_dev_sdk_1.Config();
        const llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
        const response = await llmClient.invoke(messages, {
            model: 'doubao-seed-1-8-251228',
            temperature: 0.8
        });
        return response.content;
    }
};
exports.ChatService = ChatService;
exports.ChatService = ChatService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)((0, common_1.forwardRef)(() => agent_service_1.AgentService))),
    __metadata("design:paramtypes", [agent_service_1.AgentService,
        learning_service_1.LearningService,
        storage_service_1.StorageService])
], ChatService);
//# sourceMappingURL=chat.service.js.map