export declare class RecommendationModule {
}
