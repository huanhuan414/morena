import { RecommendationService } from './recommendation.service';
export declare class RecommendationController {
    private readonly recommendationService;
    constructor(recommendationService: RecommendationService);
    getRecommendations(userId: string, body: any): Promise<{
        code: number;
        msg: string;
        data: {
            id: any;
            name: any;
            avatar_url: any;
            level: any;
            personality: any;
            abilities: any;
            exp: any;
            distance: any;
            matchScore: any;
            description: any;
            location: {
                latitude: any;
                longitude: any;
            } | undefined;
        }[];
    }>;
}
