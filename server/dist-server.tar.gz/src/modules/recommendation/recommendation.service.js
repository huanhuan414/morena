"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RecommendationService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
let RecommendationService = class RecommendationService {
    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371;
        const dLat = this.toRad(lat2 - lat1);
        const dLon = this.toRad(lon2 - lon1);
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(this.toRad(lat1)) *
                Math.cos(this.toRad(lat2)) *
                Math.sin(dLon / 2) *
                Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const distance = R * c;
        return distance;
    }
    toRad(degrees) {
        return degrees * (Math.PI / 180);
    }
    calculatePersonalityMatch(userPersonality, avatarPersonality) {
        if (!userPersonality)
            return 50;
        const personalityTypes = {
            creative: ['creative', 'analytical'],
            analytical: ['analytical', 'strategic'],
            empathetic: ['empathetic', 'creative'],
            strategic: ['strategic', 'analytical']
        };
        const userMatches = personalityTypes[userPersonality] || [];
        if (userMatches.includes(avatarPersonality)) {
            return 85;
        }
        else if (userPersonality === avatarPersonality) {
            return 70;
        }
        return 50;
    }
    calculateAbilityMatch(userAbilities, avatarAbilities) {
        if (!userAbilities.length || !avatarAbilities.length)
            return 50;
        const userAbilityNames = userAbilities.map(a => {
            if (typeof a === 'object' && 'tool_name' in a) {
                return a.tool_name;
            }
            return a;
        });
        const avatarAbilityNames = avatarAbilities.map(a => {
            if (typeof a === 'object' && 'tool_name' in a) {
                return a.tool_name;
            }
            return a;
        });
        const commonAbilities = userAbilityNames.filter(name => avatarAbilityNames.includes(name));
        const matchRatio = commonAbilities.length / Math.max(userAbilityNames.length, 1);
        return Math.min(50 + matchRatio * 50, 100);
    }
    async getRecommendations(userId, location, limit = 20) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        console.log('[推荐服务] 开始获取推荐分身，userId:', userId);
        try {
            const { data: user, error: userError } = await client
                .from('users')
                .select(`
          *,
          avatars (
            id,
            personality,
            abilities
          )
        `)
                .eq('id', userId)
                .maybeSingle();
            console.log('[推荐服务] 用户信息:', user ? '已获取' : '不存在');
            const latestAvatar = user?.avatars && user.avatars.length > 0 ? user.avatars[0] : null;
            const userPersonality = latestAvatar?.personality || null;
            const userAbilities = latestAvatar?.abilities || [];
            console.log('[推荐服务] 用户分身:', latestAvatar ? '存在' : '不存在');
            const { data: otherAvatars, error: avatarsError } = await client
                .from('avatars')
                .select('*')
                .neq('user_id', userId)
                .eq('is_public', true)
                .eq('status', 'active')
                .limit(limit * 2);
            console.log('[推荐服务] 公开分身数量:', otherAvatars?.length || 0);
            if (avatarsError) {
                console.error('[推荐服务] 获取公开分身失败:', avatarsError);
                return [];
            }
            if (!otherAvatars || otherAvatars.length === 0) {
                console.log('[推荐服务] 没有公开分身可用');
                return [];
            }
            const userIds = [...new Set(otherAvatars.map(a => a.user_id))];
            const { data: users } = await client
                .from('users')
                .select('id, latitude, longitude')
                .in('id', userIds);
            const userMap = new Map(users?.map(u => [u.id, u]) || []);
            const scoredAvatars = otherAvatars.map(avatar => {
                let matchScore = 50;
                const reasons = [];
                const levelScore = Math.min(avatar.level / 50 * 20, 20);
                matchScore += levelScore;
                if (avatar.level >= 10)
                    reasons.push('High Level');
                let distance;
                const user = userMap.get(avatar.user_id);
                if (location?.latitude && location?.longitude && user?.latitude && user?.longitude) {
                    distance = this.calculateDistance(location.latitude, location.longitude, user.latitude, user.longitude);
                    const distanceScore = Math.max(25 - distance * 0.5, 0);
                    matchScore += distanceScore;
                    if (distance < 50)
                        reasons.push('Nearby');
                }
                const personalityMatch = this.calculatePersonalityMatch(userPersonality, avatar.personality);
                matchScore += personalityMatch * 0.3;
                if (personalityMatch >= 70)
                    reasons.push('Personality Match');
                const abilityMatch = this.calculateAbilityMatch(userAbilities, avatar.abilities || []);
                matchScore += abilityMatch * 0.25;
                if (abilityMatch >= 60)
                    reasons.push('Skill Complementarity');
                if (avatar.exp > 1000) {
                    matchScore += 5;
                    reasons.push('High Activity');
                }
                return {
                    ...avatar,
                    distance,
                    matchScore: Math.round(matchScore),
                    matchReasons: reasons
                };
            });
            const recommendations = scoredAvatars
                .sort((a, b) => b.matchScore - a.matchScore)
                .slice(0, limit)
                .map(avatar => {
                const abilities = (avatar.abilities || []).map((a) => {
                    if (typeof a === 'string') {
                        return a;
                    }
                    return a.tool_name || a.name || '未知';
                });
                return {
                    id: avatar.id,
                    name: avatar.name,
                    avatar_url: avatar.avatar_url,
                    level: avatar.level,
                    personality: avatar.personality,
                    abilities,
                    exp: avatar.exp,
                    distance: avatar.distance,
                    matchScore: avatar.matchScore,
                    description: avatar.description || `一个${avatar.personality}的AI分身`,
                    location: user?.latitude && user?.longitude ? {
                        latitude: user.latitude,
                        longitude: user.longitude
                    } : undefined
                };
            })
                .sort((a, b) => b.matchScore - a.matchScore)
                .slice(0, limit);
            return recommendations;
        }
        catch (error) {
            console.error('[推荐服务] 推荐分身失败:', error);
            return [];
        }
    }
};
exports.RecommendationService = RecommendationService;
exports.RecommendationService = RecommendationService = __decorate([
    (0, common_1.Injectable)()
], RecommendationService);
//# sourceMappingURL=recommendation.service.js.map