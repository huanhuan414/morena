export declare class RecommendationService {
    private calculateDistance;
    private toRad;
    private calculatePersonalityMatch;
    private calculateAbilityMatch;
    getRecommendations(userId: string, location?: {
        latitude: number | null;
        longitude: number | null;
    }, limit?: number): Promise<{
        id: any;
        name: any;
        avatar_url: any;
        level: any;
        personality: any;
        abilities: any;
        exp: any;
        distance: any;
        matchScore: any;
        description: any;
        location: {
            latitude: any;
            longitude: any;
        } | undefined;
    }[]>;
}
