import { UserService } from './user.service';
export declare class UserController {
    private readonly userService;
    constructor(userService: UserService);
    getProfile(userId: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    updateProfile(userId: string, updates: Record<string, any>): Promise<{
        code: number;
        data: {
            affectedRows: number;
        } | null;
        message: string;
    }>;
    getStats(userId: string): Promise<{
        code: number;
        data: {
            avatarCount: number;
            taskCount: number;
            postCount: number;
            friendCount: number;
            totalXp: any;
            level: number;
        };
        message: string;
    }>;
    getLearningProgress(userId: string): Promise<{
        code: number;
        data: {
            total_hours: number;
            courses_completed: number;
            skills_learned: any;
            streak_days: number;
        };
        message: string;
    }>;
    getSecurityStatus(userId: string): Promise<{
        code: number;
        data: {
            hasPassword: boolean;
            hasPhone: boolean;
            hasEmail: boolean;
            lastLoginTime: string;
            loginDevice: string;
        };
        message: string;
    }>;
    changePassword(userId: string, body: {
        oldPassword: string;
        newPassword: string;
    }): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
}
