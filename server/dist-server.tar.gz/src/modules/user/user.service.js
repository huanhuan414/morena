"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
let UserService = class UserService {
    async getUserProfile(userId) {
        const users = (0, mysql_client_1.usersTable)();
        const { data, error } = await users.where({ id: userId }).first();
        if (error) {
            throw new Error(`获取用户信息失败: ${error.message}`);
        }
        return data;
    }
    async updateUserProfile(userId, updates) {
        const users = (0, mysql_client_1.usersTable)();
        const { data, error } = await users.where({ id: userId }).update({
            ...updates,
            updated_at: new Date()
        });
        if (error) {
            throw new Error(`更新用户信息失败: ${error.message}`);
        }
        return data;
    }
    async getUserStats(userId) {
        const { data: user } = await (0, mysql_client_1.usersTable)().where({ id: userId }).select('level, exp').first();
        const { data: avatarCount } = await (0, mysql_client_1.avatarsTable)().where({ user_id: userId }).count();
        const { data: userAvatars } = await (0, mysql_client_1.avatarsTable)().where({ user_id: userId }).select('id, exp, level');
        const avatarIds = (userAvatars || []).map((a) => a.id);
        const totalAvatarExp = (userAvatars || []).reduce((sum, a) => sum + (a.exp || 0), 0);
        const maxAvatarLevel = userAvatars?.length ? Math.max(...userAvatars.map((a) => a.level || 1)) : 1;
        let orderCount = 0;
        if (avatarIds.length > 0) {
            const { data: pendingCount } = await (0, mysql_client_1.ordersTable)().whereIn('avatar_id', avatarIds).where({ status: 'pending' }).count();
            const { data: executingCount } = await (0, mysql_client_1.ordersTable)().whereIn('avatar_id', avatarIds).where({ status: 'generating' }).count();
            orderCount = (pendingCount || 0) + (executingCount || 0);
        }
        const { data: postCount } = await (0, mysql_client_1.conversationsTable)().where({ user_id: userId }).count();
        const friendCount = 0;
        return {
            avatarCount: avatarCount || 0,
            taskCount: orderCount,
            postCount: postCount || 0,
            friendCount: friendCount,
            totalXp: totalAvatarExp,
            level: maxAvatarLevel
        };
    }
    async getLearningProgress(userId) {
        const { data: user } = await (0, mysql_client_1.usersTable)().where({ id: userId }).select('level, exp').first();
        const { data: learningSessions } = await (0, mysql_client_1.conversationsTable)().where({ user_id: userId }).count();
        const totalHours = Math.floor((learningSessions || 0) / 10);
        const { data: completedTasks } = await (0, mysql_client_1.tasksTable)().where({ user_id: userId }).where({ status: 'completed' }).count();
        const { data: avatars } = await (0, mysql_client_1.avatarsTable)().where({ user_id: userId }).select('level');
        const skillsLearned = avatars?.reduce((sum, a) => sum + (a.level || 1), 0) || 0;
        const streakDays = Math.min(Math.floor((learningSessions || 0) / 3), 30);
        return {
            total_hours: totalHours,
            courses_completed: completedTasks || 0,
            skills_learned: skillsLearned,
            streak_days: streakDays
        };
    }
    async getSecurityStatus(userId) {
        const { data: user } = await (0, mysql_client_1.usersTable)().where({ id: userId }).select('phone, created_at').first();
        return {
            hasPassword: true,
            hasPhone: !!user?.phone,
            hasEmail: false,
            lastLoginTime: '刚刚',
            loginDevice: '微信小程序'
        };
    }
    async changePassword(userId, oldPassword, newPassword) {
        return true;
    }
};
exports.UserService = UserService;
exports.UserService = UserService = __decorate([
    (0, common_1.Injectable)()
], UserService);
//# sourceMappingURL=user.service.js.map