"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
let UserService = class UserService {
    async getUserProfile(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data, error } = await client
            .from('users')
            .select('*')
            .eq('id', userId)
            .maybeSingle();
        if (error) {
            throw new Error(`获取用户信息失败: ${error.message}`);
        }
        return data;
    }
    async updateUserProfile(userId, updates) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data, error } = await client
            .from('users')
            .update({
            ...updates,
            updated_at: new Date().toISOString()
        })
            .eq('id', userId)
            .select()
            .single();
        if (error) {
            throw new Error(`更新用户信息失败: ${error.message}`);
        }
        return data;
    }
    async getUserStats(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: user } = await client
            .from('users')
            .select('level, exp')
            .eq('id', userId)
            .single();
        const { count: avatarCount } = await client
            .from('avatars')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId);
        const { data: userAvatars } = await client
            .from('avatars')
            .select('id, exp, level')
            .eq('user_id', userId);
        const avatarIds = (userAvatars || []).map(a => a.id);
        const totalAvatarExp = (userAvatars || []).reduce((sum, a) => sum + (a.exp || 0), 0);
        const maxAvatarLevel = userAvatars?.length ? Math.max(...userAvatars.map(a => a.level || 1)) : 1;
        let orderCount = 0;
        if (avatarIds.length > 0) {
            const { count: pendingCount } = await client
                .from('orders')
                .select('*', { count: 'exact', head: true })
                .in('avatar_id', avatarIds)
                .eq('status', 'pending');
            const { count: executingCount } = await client
                .from('orders')
                .select('*', { count: 'exact', head: true })
                .in('avatar_id', avatarIds)
                .eq('status', 'generating');
            orderCount = (pendingCount || 0) + (executingCount || 0);
        }
        const { count: postCount } = await client
            .from('posts')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId);
        let friendCount = 0;
        if (avatarIds.length > 0) {
            const { count } = await client
                .from('avatar_friends')
                .select('*', { count: 'exact', head: true })
                .in('avatar_id', avatarIds);
            friendCount = count || 0;
        }
        return {
            avatarCount: avatarCount || 0,
            taskCount: orderCount,
            postCount: postCount || 0,
            friendCount: friendCount,
            totalXp: totalAvatarExp,
            level: maxAvatarLevel
        };
    }
    async getLearningProgress(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: user } = await client
            .from('users')
            .select('level, exp')
            .eq('id', userId)
            .single();
        const { count: learningSessions } = await client
            .from('conversations')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId);
        const totalHours = Math.floor((learningSessions || 0) / 10);
        const { count: completedTasks } = await client
            .from('tasks')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId)
            .eq('status', 'completed');
        const { data: avatars } = await client
            .from('avatars')
            .select('level')
            .eq('user_id', userId);
        const skillsLearned = avatars?.reduce((sum, a) => sum + (a.level || 1), 0) || 0;
        const streakDays = Math.min(Math.floor((learningSessions || 0) / 3), 30);
        return {
            total_hours: totalHours,
            courses_completed: completedTasks || 0,
            skills_learned: skillsLearned,
            streak_days: streakDays
        };
    }
    async getSecurityStatus(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: user } = await client
            .from('users')
            .select('phone, created_at')
            .eq('id', userId)
            .single();
        return {
            hasPassword: true,
            hasPhone: !!user?.phone,
            hasEmail: false,
            lastLoginTime: '刚刚',
            loginDevice: '微信小程序'
        };
    }
    async changePassword(userId, oldPassword, newPassword) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        return true;
    }
};
exports.UserService = UserService;
exports.UserService = UserService = __decorate([
    (0, common_1.Injectable)()
], UserService);
//# sourceMappingURL=user.service.js.map