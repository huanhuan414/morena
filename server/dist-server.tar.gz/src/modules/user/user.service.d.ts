export declare class UserService {
    getUserProfile(userId: string): Promise<any>;
    updateUserProfile(userId: string, updates: Record<string, any>): Promise<any>;
    getUserStats(userId: string): Promise<{
        avatarCount: number;
        taskCount: number;
        postCount: number;
        friendCount: number;
        totalXp: any;
        level: number;
    }>;
    getLearningProgress(userId: string): Promise<{
        total_hours: number;
        courses_completed: number;
        skills_learned: any;
        streak_days: number;
    }>;
    getSecurityStatus(userId: string): Promise<{
        hasPassword: boolean;
        hasPhone: boolean;
        hasEmail: boolean;
        lastLoginTime: string;
        loginDevice: string;
    }>;
    changePassword(userId: string, oldPassword: string, newPassword: string): Promise<boolean>;
}
