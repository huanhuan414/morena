export declare class EarningModule {
}
