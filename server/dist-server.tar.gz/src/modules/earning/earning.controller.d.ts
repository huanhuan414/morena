import { EarningService } from './earning.service';
export declare class EarningController {
    private readonly earningService;
    constructor(earningService: EarningService);
    getOverview(userId: string): Promise<{
        code: number;
        data: {
            balance: any;
            totalEarnings: any;
            pendingAmount: number;
            monthlyAmount: number;
            totalOrders: number;
            totalReferrals: number;
        };
        message: string;
    }>;
    getList(userId: string, type?: string, status?: string, page?: string, pageSize?: string): Promise<{
        code: number;
        data: {
            list: any[];
            total: number;
            page: number;
            pageSize: number;
        };
        message: string;
    }>;
    createWithdrawal(userId: string, body: {
        amount: number;
        method: string;
        accountInfo: Record<string, any>;
    }): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getWithdrawals(userId: string, page?: string, pageSize?: string): Promise<{
        code: number;
        data: {
            list: any[];
            total: number;
            page: number;
            pageSize: number;
        };
        message: string;
    }>;
    getAvatarEarningsStats(userId: string): Promise<{
        code: number;
        data: {
            avatarId: any;
            avatarName: any;
            avatarUrl: any;
            totalOrders: number;
            completedOrders: number;
            pendingOrders: number;
            openOrders: number;
            totalEarnings: number;
            pendingAmount: number;
            monthlyAmount: number;
        }[];
        message: string;
    }>;
}
