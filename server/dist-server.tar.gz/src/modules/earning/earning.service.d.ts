export declare class EarningService {
    getEarningsOverview(userId: string): Promise<{
        balance: any;
        totalEarnings: any;
        pendingAmount: number;
        monthlyAmount: number;
        totalOrders: number;
        totalReferrals: number;
    }>;
    getEarningsList(userId: string, options?: {
        type?: string;
        status?: string;
        page?: number;
        pageSize?: number;
    }): Promise<{
        list: any[];
        total: number;
        page: number;
        pageSize: number;
    }>;
    createEarning(data: {
        userId: string;
        avatarId?: string;
        orderId?: string;
        type: string;
        amount: number;
        description?: string;
    }): Promise<any>;
    settleEarning(earningId: string): Promise<{
        success: boolean;
        newBalance: any;
    }>;
    settleOrderEarnings(orderId: string): Promise<void>;
    createWithdrawal(userId: string, data: {
        amount: number;
        method: string;
        accountInfo: Record<string, any>;
    }): Promise<any>;
    getWithdrawals(userId: string, page?: number, pageSize?: number): Promise<{
        list: any[];
        total: number;
        page: number;
        pageSize: number;
    }>;
    getAvatarEarningsStats(userId: string): Promise<{
        avatarId: any;
        avatarName: any;
        avatarUrl: any;
        totalOrders: number;
        completedOrders: number;
        pendingOrders: number;
        openOrders: number;
        totalEarnings: number;
        pendingAmount: number;
        monthlyAmount: number;
    }[]>;
    processWithdrawal(withdrawalId: string, status: string, transactionId?: string): Promise<{
        success: boolean;
    }>;
}
