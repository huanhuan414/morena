"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EarningService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
let EarningService = class EarningService {
    async getEarningsOverview(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: user } = await client
            .from('users')
            .select('balance, total_earnings')
            .eq('id', userId)
            .single();
        const { data: pendingEarnings } = await client
            .from('earnings')
            .select('amount')
            .eq('user_id', userId)
            .eq('status', 'pending');
        const pendingAmount = pendingEarnings?.reduce((sum, e) => sum + Number(e.amount), 0) || 0;
        const now = new Date();
        const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
        const { data: monthlyEarnings } = await client
            .from('earnings')
            .select('amount')
            .eq('user_id', userId)
            .gte('created_at', monthStart);
        const monthlyAmount = monthlyEarnings?.reduce((sum, e) => sum + Number(e.amount), 0) || 0;
        const { count: totalOrders } = await client
            .from('earnings')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId)
            .eq('type', 'order_reward');
        const { count: totalReferrals } = await client
            .from('earnings')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId)
            .eq('type', 'referral_bonus');
        return {
            balance: user?.balance || 0,
            totalEarnings: user?.total_earnings || 0,
            pendingAmount,
            monthlyAmount,
            totalOrders: totalOrders || 0,
            totalReferrals: totalReferrals || 0
        };
    }
    async getEarningsList(userId, options) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const page = options?.page || 1;
        const pageSize = options?.pageSize || 20;
        const offset = (page - 1) * pageSize;
        let query = client
            .from('earnings')
            .select('*, avatars(name), orders(title)', { count: 'exact' })
            .eq('user_id', userId);
        if (options?.type) {
            query = query.eq('type', options.type);
        }
        if (options?.status) {
            query = query.eq('status', options.status);
        }
        const { data, error, count } = await query
            .order('created_at', { ascending: false })
            .range(offset, offset + pageSize - 1);
        if (error) {
            throw new Error(`获取收益明细失败: ${error.message}`);
        }
        return {
            list: data || [],
            total: count || 0,
            page,
            pageSize
        };
    }
    async createEarning(data) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: earning, error } = await client
            .from('earnings')
            .insert({
            user_id: data.userId,
            avatar_id: data.avatarId,
            order_id: data.orderId,
            type: data.type,
            amount: data.amount,
            description: data.description,
            status: 'pending'
        })
            .select()
            .single();
        if (error) {
            throw new Error(`创建收益记录失败: ${error.message}`);
        }
        return earning;
    }
    async settleEarning(earningId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: earning } = await client
            .from('earnings')
            .select('*')
            .eq('id', earningId)
            .single();
        if (!earning) {
            throw new Error('收益记录不存在');
        }
        if (earning.status !== 'pending') {
            throw new Error('该收益已结算');
        }
        await client
            .from('earnings')
            .update({ status: 'settled' })
            .eq('id', earningId);
        await client
            .from('users')
            .update({
            balance: client.rpc('increment_balance', { amount: earning.amount }),
            total_earnings: client.rpc('increment_total_earnings', { amount: earning.amount })
        })
            .eq('id', earning.user_id);
        const { data: user } = await client
            .from('users')
            .select('balance, total_earnings')
            .eq('id', earning.user_id)
            .single();
        const newBalance = (user?.balance || 0) + Number(earning.amount);
        const newTotal = (user?.total_earnings || 0) + Number(earning.amount);
        await client
            .from('users')
            .update({
            balance: newBalance,
            total_earnings: newTotal
        })
            .eq('id', earning.user_id);
        return { success: true, newBalance };
    }
    async settleOrderEarnings(orderId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: order } = await client
            .from('orders')
            .select('*, avatars(user_id, name)')
            .eq('id', orderId)
            .single();
        if (!order || !order.avatars) {
            return;
        }
        const orderBudget = Number(order.budget) || 0;
        const rewardAmount = orderBudget * 0.8;
        if (rewardAmount > 0) {
            await this.createEarning({
                userId: order.avatars.user_id,
                avatarId: order.avatar_id,
                orderId: orderId,
                type: 'order_reward',
                amount: rewardAmount,
                description: `完成订单「${order.title}」奖励`
            });
        }
    }
    async createWithdrawal(userId, data) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: user } = await client
            .from('users')
            .select('balance')
            .eq('id', userId)
            .single();
        if (!user || Number(user.balance) < data.amount) {
            throw new Error('余额不足');
        }
        if (data.amount < 1) {
            throw new Error('最低提现金额为1元');
        }
        const { data: withdrawal, error } = await client
            .from('withdrawals')
            .insert({
            user_id: userId,
            amount: data.amount,
            method: data.method,
            account_info: data.accountInfo,
            status: 'pending'
        })
            .select()
            .single();
        if (error) {
            throw new Error(`创建提现申请失败: ${error.message}`);
        }
        await client
            .from('users')
            .update({
            balance: Number(user.balance) - data.amount
        })
            .eq('id', userId);
        return withdrawal;
    }
    async getWithdrawals(userId, page = 1, pageSize = 20) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const offset = (page - 1) * pageSize;
        const { data, error, count } = await client
            .from('withdrawals')
            .select('*', { count: 'exact' })
            .eq('user_id', userId)
            .order('created_at', { ascending: false })
            .range(offset, offset + pageSize - 1);
        if (error) {
            throw new Error(`获取提现记录失败: ${error.message}`);
        }
        return {
            list: data || [],
            total: count || 0,
            page,
            pageSize
        };
    }
    async getAvatarEarningsStats(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: avatars } = await client
            .from('avatars')
            .select('id, name, avatar_url')
            .eq('user_id', userId)
            .order('created_at', { ascending: false });
        if (!avatars || avatars.length === 0) {
            return [];
        }
        const avatarStats = await Promise.all(avatars.map(async (avatar) => {
            const { data: orders } = await client
                .from('orders')
                .select('id, status, budget, created_at, completed_at')
                .eq('avatar_id', avatar.id);
            const allOrders = orders || [];
            const totalOrders = allOrders.length;
            const completedOrders = allOrders.filter(o => o.status === 'completed').length;
            const pendingOrders = allOrders.filter(o => o.status === 'in_progress' || o.status === 'accepted').length;
            const openOrders = allOrders.filter(o => o.status === 'open').length;
            const { data: earnings } = await client
                .from('earnings')
                .select('amount, status, created_at')
                .eq('user_id', userId)
                .eq('avatar_id', avatar.id);
            const allEarnings = earnings || [];
            const settledEarnings = allEarnings.filter(e => e.status === 'settled');
            const pendingEarnings = allEarnings.filter(e => e.status === 'pending');
            const totalEarnings = settledEarnings.reduce((sum, e) => sum + Number(e.amount), 0);
            const pendingAmount = pendingEarnings.reduce((sum, e) => sum + Number(e.amount), 0);
            const now = new Date();
            const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
            const monthlyEarnings = settledEarnings.filter(e => e.created_at >= monthStart);
            const monthlyAmount = monthlyEarnings.reduce((sum, e) => sum + Number(e.amount), 0);
            return {
                avatarId: avatar.id,
                avatarName: avatar.name,
                avatarUrl: avatar.avatar_url,
                totalOrders,
                completedOrders,
                pendingOrders,
                openOrders,
                totalEarnings,
                pendingAmount,
                monthlyAmount
            };
        }));
        return avatarStats;
    }
    async processWithdrawal(withdrawalId, status, transactionId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: withdrawal } = await client
            .from('withdrawals')
            .select('*')
            .eq('id', withdrawalId)
            .single();
        if (!withdrawal) {
            throw new Error('提现记录不存在');
        }
        const updates = {
            status,
            processed_at: new Date().toISOString()
        };
        if (transactionId) {
            updates.transaction_id = transactionId;
        }
        await client
            .from('withdrawals')
            .update(updates)
            .eq('id', withdrawalId);
        if (status === 'failed') {
            const { data: user } = await client
                .from('users')
                .select('balance')
                .eq('id', withdrawal.user_id)
                .single();
            await client
                .from('users')
                .update({
                balance: Number(user?.balance || 0) + Number(withdrawal.amount)
            })
                .eq('id', withdrawal.user_id);
        }
        return { success: true };
    }
};
exports.EarningService = EarningService;
exports.EarningService = EarningService = __decorate([
    (0, common_1.Injectable)()
], EarningService);
//# sourceMappingURL=earning.service.js.map