"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const upload_service_1 = require("./upload.service");
const multerOptions = {
    limits: {
        fileSize: 100 * 1024 * 1024,
    },
};
let UploadController = class UploadController {
    constructor(uploadService) {
        this.uploadService = uploadService;
    }
    async uploadOrderScreenshot(file) {
        try {
            const result = await this.uploadService.uploadOrderScreenshot(file);
            return {
                code: 200,
                message: '上传成功',
                data: result
            };
        }
        catch (error) {
            return {
                code: 500,
                message: error.message || '上传失败',
                error: error.message
            };
        }
    }
    async uploadAvatarImage(file) {
        try {
            const result = await this.uploadService.uploadAvatarImage(file);
            return {
                code: 200,
                message: '上传成功',
                data: result
            };
        }
        catch (error) {
            return {
                code: 500,
                message: error.message || '上传失败',
                error: error.message
            };
        }
    }
    async uploadImage(file) {
        try {
            const result = await this.uploadService.uploadImage(file);
            return {
                code: 200,
                message: '上传成功',
                data: result
            };
        }
        catch (error) {
            return {
                code: 500,
                message: error.message || '上传失败',
                error: error.message
            };
        }
    }
    async uploadAudio(file) {
        console.log('[UploadController] 接收到音频上传请求');
        console.log('[UploadController] 文件信息:', {
            originalname: file?.originalname,
            size: file?.size,
            mimetype: file?.mimetype,
            hasBuffer: !!file?.buffer
        });
        if (!file) {
            return {
                code: 400,
                message: '未接收到文件'
            };
        }
        try {
            const result = await this.uploadService.uploadAudio(file);
            return {
                code: 200,
                message: '上传成功',
                data: result
            };
        }
        catch (error) {
            console.error('[UploadController] 音频上传失败:', error);
            return {
                code: 500,
                message: error.message || '上传失败',
                error: error.message
            };
        }
    }
    async uploadVideo(file) {
        console.log('[UploadController] 接收到视频上传请求');
        console.log('[UploadController] 文件信息:', {
            originalname: file?.originalname,
            size: file?.size,
            mimetype: file?.mimetype,
            hasBuffer: !!file?.buffer
        });
        if (!file) {
            console.error('[UploadController] 未接收到文件');
            return {
                code: 400,
                message: '未接收到文件',
                error: 'File not found'
            };
        }
        try {
            const result = await this.uploadService.uploadVideo(file);
            return {
                code: 200,
                message: '上传成功',
                data: result
            };
        }
        catch (error) {
            console.error('[UploadController] 视频上传失败:', error);
            return {
                code: 500,
                message: error.message || '上传失败',
                error: error.message
            };
        }
    }
};
exports.UploadController = UploadController;
__decorate([
    (0, common_1.Post)('order-screenshot'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', multerOptions)),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadOrderScreenshot", null);
__decorate([
    (0, common_1.Post)('avatar-image'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', multerOptions)),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadAvatarImage", null);
__decorate([
    (0, common_1.Post)('image'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', multerOptions)),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadImage", null);
__decorate([
    (0, common_1.Post)('audio'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', multerOptions)),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadAudio", null);
__decorate([
    (0, common_1.Post)('video'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', multerOptions)),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadVideo", null);
exports.UploadController = UploadController = __decorate([
    (0, common_1.Controller)('upload'),
    __metadata("design:paramtypes", [upload_service_1.UploadService])
], UploadController);
//# sourceMappingURL=upload.controller.js.map