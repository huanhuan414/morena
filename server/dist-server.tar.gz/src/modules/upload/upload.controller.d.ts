import { UploadService } from './upload.service';
export declare class UploadController {
    private readonly uploadService;
    constructor(uploadService: UploadService);
    uploadOrderScreenshot(file: Express.Multer.File): Promise<{
        code: number;
        message: string;
        data: {
            url: string;
        };
        error?: undefined;
    } | {
        code: number;
        message: any;
        error: any;
        data?: undefined;
    }>;
    uploadAvatarImage(file: Express.Multer.File): Promise<{
        code: number;
        message: string;
        data: {
            url: string;
        };
        error?: undefined;
    } | {
        code: number;
        message: any;
        error: any;
        data?: undefined;
    }>;
    uploadImage(file: Express.Multer.File): Promise<{
        code: number;
        message: string;
        data: {
            url: string;
        };
        error?: undefined;
    } | {
        code: number;
        message: any;
        error: any;
        data?: undefined;
    }>;
    uploadAudio(file: Express.Multer.File): Promise<{
        code: number;
        message: string;
        data?: undefined;
        error?: undefined;
    } | {
        code: number;
        message: string;
        data: {
            url: string;
        };
        error?: undefined;
    } | {
        code: number;
        message: any;
        error: any;
        data?: undefined;
    }>;
    uploadVideo(file: Express.Multer.File): Promise<{
        code: number;
        message: string;
        data: {
            url: string;
        };
        error?: undefined;
    } | {
        code: number;
        message: any;
        error: any;
        data?: undefined;
    }>;
}
