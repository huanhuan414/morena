import { VolcengineService } from './volcengine.service';
import { StorageService } from '../storage/storage.service';
export declare class UploadService {
    private readonly volcengineService;
    private readonly storageService;
    private readonly logger;
    constructor(volcengineService: VolcengineService, storageService: StorageService);
    uploadOrderScreenshot(file: Express.Multer.File): Promise<{
        url: string;
    }>;
    uploadAvatarImage(file: Express.Multer.File): Promise<{
        url: string;
    }>;
    uploadImage(file: Express.Multer.File): Promise<{
        url: string;
    }>;
    uploadVideo(file: Express.Multer.File): Promise<{
        url: string;
    }>;
    uploadAudio(file: Express.Multer.File): Promise<{
        url: string;
    }>;
}
