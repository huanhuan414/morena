export declare class VolcengineService {
    private readonly logger;
    private client;
    private readonly FULL_SERVICE_ID;
    private readonly SHORT_ID;
    private readonly CUSTOM_DOMAIN;
    constructor();
    uploadImage(file: Express.Multer.File): Promise<{
        url: string;
    }>;
    private generateStoreKey;
    private getExtensionFromMime;
}
