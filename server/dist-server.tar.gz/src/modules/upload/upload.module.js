"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadModule = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const upload_controller_1 = require("./upload.controller");
const upload_service_1 = require("./upload.service");
const volcengine_service_1 = require("./volcengine.service");
const storage_module_1 = require("../storage/storage.module");
const multer = require("multer");
let UploadModule = class UploadModule {
};
exports.UploadModule = UploadModule;
exports.UploadModule = UploadModule = __decorate([
    (0, common_1.Module)({
        imports: [
            storage_module_1.StorageModule,
            platform_express_1.MulterModule.register({
                storage: multer.memoryStorage(),
                limits: {
                    fileSize: 500 * 1024 * 1024,
                },
                fileFilter: (req, file, callback) => {
                    const allowedMimes = [
                        'image/jpeg',
                        'image/jpg',
                        'image/png',
                        'image/gif',
                        'image/webp',
                        'video/mp4',
                        'video/mpeg',
                        'video/quicktime',
                        'video/x-msvideo',
                        'video/x-ms-wmv',
                        'audio/mpeg',
                        'audio/wav',
                        'audio/wave',
                        'audio/ogg',
                        'audio/x-wav',
                        'audio/webm',
                        'application/octet-stream'
                    ];
                    console.log(`[MulterFileFilter] 检查文件: ${file.originalname}, MIME: ${file.mimetype}`);
                    if (allowedMimes.includes(file.mimetype)) {
                        if (!file.originalname || !file.originalname.includes('.')) {
                            const mimeToExt = {
                                'image/jpeg': 'jpg',
                                'image/jpg': 'jpg',
                                'image/png': 'png',
                                'image/gif': 'gif',
                                'image/webp': 'webp',
                                'image/bmp': 'bmp',
                                'video/mp4': 'mp4',
                                'video/mpeg': 'mpeg',
                                'video/quicktime': 'mov',
                                'video/x-msvideo': 'avi',
                                'video/x-ms-wmv': 'wmv',
                                'audio/mpeg': 'mp3',
                                'audio/wav': 'wav',
                                'audio/wave': 'wav',
                                'audio/ogg': 'ogg',
                                'audio/x-wav': 'wav',
                                'audio/webm': 'webm',
                            };
                            const ext = mimeToExt[file.mimetype] || 'png';
                            file.originalname = `image_${Date.now()}.${ext}`;
                            console.log(`[MulterFileFilter] 修正文件名: ${file.originalname}`);
                        }
                        callback(null, true);
                    }
                    else {
                        console.log(`[MulterFileFilter] 不支持的MIME类型: ${file.mimetype}`);
                        callback(new Error('只支持图片、视频和音频格式（jpg, png, gif, webp, mp4, mov, avi, mp3, wav, ogg）'), false);
                    }
                }
            })
        ],
        controllers: [upload_controller_1.UploadController],
        providers: [upload_service_1.UploadService, volcengine_service_1.VolcengineService],
        exports: [upload_service_1.UploadService]
    })
], UploadModule);
//# sourceMappingURL=upload.module.js.map