import { ReferralService } from './referral.service';
export declare class ReferralController {
    private readonly referralService;
    constructor(referralService: ReferralService);
    getReferralCode(userId: string): Promise<{
        code: number;
        data: {
            referralCode: string;
        };
        message: string;
    }>;
    useReferralCode(userId: string, code: string): Promise<{
        code: number;
        data: {
            success: boolean;
            inviterId: any;
        };
        message: string;
    }>;
    getStats(userId: string): Promise<{
        code: number;
        data: {
            referralCode: any;
            totalInvited: number;
            activeInvited: number;
            rewardedInvited: number;
            totalReward: number;
        };
        message: string;
    }>;
    getList(userId: string, page?: string, pageSize?: string): Promise<{
        code: number;
        data: {
            list: any[];
            total: number;
            page: number;
            pageSize: number;
        };
        message: string;
    }>;
}
