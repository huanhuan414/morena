export declare class ReferralModule {
}
