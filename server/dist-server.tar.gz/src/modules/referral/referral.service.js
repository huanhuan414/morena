"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReferralService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
const earning_service_1 = require("../earning/earning.service");
let ReferralService = class ReferralService {
    constructor(earningService) {
        this.earningService = earningService;
    }
    async generateReferralCode(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: user } = await client
            .from('users')
            .select('referral_code')
            .eq('id', userId)
            .single();
        if (user?.referral_code) {
            return user.referral_code;
        }
        const code = this.generateUniqueCode();
        await client
            .from('users')
            .update({ referral_code: code })
            .eq('id', userId);
        return code;
    }
    generateUniqueCode() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let code = '';
        for (let i = 0; i < 6; i++) {
            code += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return code;
    }
    async useReferralCode(inviteeId, code) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: inviter } = await client
            .from('users')
            .select('id')
            .eq('referral_code', code)
            .single();
        if (!inviter) {
            throw new Error('邀请码无效');
        }
        if (inviter.id === inviteeId) {
            throw new Error('不能使用自己的邀请码');
        }
        const { data: existingReferral } = await client
            .from('referrals')
            .select('id')
            .eq('invitee_id', inviteeId)
            .single();
        if (existingReferral) {
            throw new Error('您已被邀请过');
        }
        const { error } = await client
            .from('referrals')
            .insert({
            inviter_id: inviter.id,
            invitee_id: inviteeId,
            status: 'registered'
        });
        if (error) {
            throw new Error(`创建邀请记录失败: ${error.message}`);
        }
        await client
            .from('users')
            .update({ invited_by: inviter.id })
            .eq('id', inviteeId);
        return { success: true, inviterId: inviter.id };
    }
    async getReferralStats(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: user } = await client
            .from('users')
            .select('referral_code')
            .eq('id', userId)
            .single();
        let referralCode = user?.referral_code;
        if (!referralCode) {
            referralCode = await this.generateReferralCode(userId);
        }
        const { count: totalInvited } = await client
            .from('referrals')
            .select('*', { count: 'exact', head: true })
            .eq('inviter_id', userId);
        const { count: activeInvited } = await client
            .from('referrals')
            .select('*', { count: 'exact', head: true })
            .eq('inviter_id', userId)
            .eq('status', 'active');
        const { count: rewardedInvited } = await client
            .from('referrals')
            .select('*', { count: 'exact', head: true })
            .eq('inviter_id', userId)
            .eq('status', 'rewarded');
        const { data: earnings } = await client
            .from('earnings')
            .select('amount')
            .eq('user_id', userId)
            .eq('type', 'referral_bonus');
        const totalReward = earnings?.reduce((sum, e) => sum + Number(e.amount), 0) || 0;
        return {
            referralCode: referralCode || '',
            totalInvited: totalInvited || 0,
            activeInvited: activeInvited || 0,
            rewardedInvited: rewardedInvited || 0,
            totalReward
        };
    }
    async getReferralList(userId, page = 1, pageSize = 20) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const offset = (page - 1) * pageSize;
        const { data, error, count } = await client
            .from('referrals')
            .select('*, invitee:users!referrals_invitee_id_fkey(nickname, avatar, created_at)', { count: 'exact' })
            .eq('inviter_id', userId)
            .order('created_at', { ascending: false })
            .range(offset, offset + pageSize - 1);
        if (error) {
            throw new Error(`获取邀请列表失败: ${error.message}`);
        }
        return {
            list: data || [],
            total: count || 0,
            page,
            pageSize
        };
    }
    async rewardInviter(inviteeId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: referral } = await client
            .from('referrals')
            .select('*, inviter:users!referrals_inviter_id_fkey(id)')
            .eq('invitee_id', inviteeId)
            .single();
        if (!referral || referral.status === 'rewarded') {
            return;
        }
        await client
            .from('referrals')
            .update({
            status: 'rewarded',
            reward_amount: 10,
            rewarded_at: new Date().toISOString()
        })
            .eq('id', referral.id);
        await this.earningService.createEarning({
            userId: referral.inviter_id,
            type: 'referral_bonus',
            amount: 10,
            description: '邀请好友奖励'
        });
        const { data: earnings } = await client
            .from('earnings')
            .select('id')
            .eq('user_id', referral.inviter_id)
            .eq('type', 'referral_bonus')
            .eq('status', 'pending')
            .order('created_at', { ascending: false })
            .limit(1);
        if (earnings && earnings.length > 0) {
            await this.earningService.settleEarning(earnings[0].id);
        }
        return { success: true };
    }
    async activateReferral(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        await client
            .from('referrals')
            .update({ status: 'active' })
            .eq('invitee_id', userId)
            .eq('status', 'registered');
    }
};
exports.ReferralService = ReferralService;
exports.ReferralService = ReferralService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [earning_service_1.EarningService])
], ReferralService);
//# sourceMappingURL=referral.service.js.map