import { EarningService } from '../earning/earning.service';
export declare class ReferralService {
    private readonly earningService;
    constructor(earningService: EarningService);
    generateReferralCode(userId: string): Promise<string>;
    private generateUniqueCode;
    useReferralCode(inviteeId: string, code: string): Promise<{
        success: boolean;
        inviterId: any;
    }>;
    getReferralStats(userId: string): Promise<{
        referralCode: any;
        totalInvited: number;
        activeInvited: number;
        rewardedInvited: number;
        totalReward: number;
    }>;
    getReferralList(userId: string, page?: number, pageSize?: number): Promise<{
        list: any[];
        total: number;
        page: number;
        pageSize: number;
    }>;
    rewardInviter(inviteeId: string): Promise<{
        success: boolean;
    } | undefined>;
    activateReferral(userId: string): Promise<void>;
}
