export declare class TaskService {
    createTask(userId: string, taskData: Record<string, any>): Promise<any>;
    getTasksByUser(userId: string, status?: string): Promise<any[]>;
    getTaskById(taskId: string, userId?: string): Promise<any>;
    executeTask(taskId: string, userId: string): Promise<{
        success: boolean;
        result: {
            steps: {
                step: string;
                output: string;
            }[];
            summary: string;
            completedAt: string;
        };
    }>;
    private planTaskExecution;
    private getDefaultPlan;
    private executePlan;
    private updateProgress;
    private addTaskLog;
    private calculateTaskExp;
    private addAvatarExperience;
    updateTask(taskId: string, userId: string, updates: Record<string, any>): Promise<any>;
    deleteTask(taskId: string, userId: string): Promise<{
        success: boolean;
    }>;
    cancelTask(taskId: string, userId: string): Promise<any>;
    getTaskStats(userId: string): Promise<{
        total: number;
        pending: number;
        executing: number;
        completed: number;
        failed: number;
        cancelled: number;
        byType: {};
    }>;
}
