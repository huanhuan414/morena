export declare class TaskModule {
}
