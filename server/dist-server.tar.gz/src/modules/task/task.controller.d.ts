import { TaskService } from './task.service';
export declare class TaskController {
    private readonly taskService;
    constructor(taskService: TaskService);
    createTask(userId: string, body: any): Promise<{
        code: number;
        msg: string;
        data: any;
    }>;
    getTasks(userId: string, status?: string): Promise<{
        code: number;
        data: any[];
    }>;
    getTaskStats(userId: string): Promise<{
        code: number;
        data: {
            total: number;
            pending: number;
            executing: number;
            completed: number;
            failed: number;
            cancelled: number;
            byType: {};
        };
    }>;
    getTask(userId: string, taskId: string): Promise<{
        code: number;
        data: any;
    }>;
    executeTask(userId: string, taskId: string): Promise<{
        code: number;
        msg: string;
        data: {
            success: boolean;
            result: {
                steps: {
                    step: string;
                    output: string;
                }[];
                summary: string;
                completedAt: string;
            };
        };
    }>;
    updateTask(userId: string, taskId: string, body: any): Promise<{
        code: number;
        msg: string;
        data: any;
    }>;
    cancelTask(userId: string, taskId: string): Promise<{
        code: number;
        msg: string;
        data: any;
    }>;
    deleteTask(userId: string, taskId: string): Promise<{
        code: number;
        msg: string;
    }>;
}
