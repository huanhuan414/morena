"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
const reverse_geocoding_service_1 = require("../../services/reverse-geocoding.service");
const earning_service_1 = require("../earning/earning.service");
let OrderService = class OrderService {
    constructor(reverseGeocodingService, earningService) {
        this.reverseGeocodingService = reverseGeocodingService;
        this.earningService = earningService;
    }
    async createOrder(userId, orderData) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        let locationData = {
            latitude: orderData.latitude || null,
            longitude: orderData.longitude || null,
            location_text: orderData.location_text || null
        };
        if (locationData.latitude && locationData.longitude) {
            try {
                const geoResult = await this.reverseGeocodingService.reverseGeocode(locationData.latitude, locationData.longitude);
                locationData.location_text = geoResult.formatted_address;
                console.log('[创建订单] 逆地理编码成功:', geoResult.formatted_address);
            }
            catch (error) {
                console.warn('[创建订单] 逆地理编码失败，使用原始坐标:', error);
                locationData.location_text = `${locationData.latitude.toFixed(6)}, ${locationData.longitude.toFixed(6)}`;
            }
        }
        const isPaid = orderData.is_paid !== undefined ? orderData.is_paid : (orderData.budget && orderData.budget > 0 ? false : true);
        const status = isPaid ? 'open' : 'pending_payment';
        const requirements = orderData.requirements || {};
        if (orderData.content_config?.quantity_per_avatar) {
            requirements.quantity_per_avatar = orderData.content_config.quantity_per_avatar;
        }
        const { data, error } = await client
            .from('orders')
            .insert({
            user_id: userId,
            title: orderData.title,
            description: orderData.description,
            content_type: orderData.content_type || 'text',
            platforms: orderData.platforms || [],
            target_audience: orderData.target_audience || null,
            requirements,
            budget: orderData.budget || 0,
            is_paid: isPaid,
            expected_quantity: orderData.expected_quantity || 1,
            deadline: orderData.deadline || null,
            status,
            ...locationData
        })
            .select()
            .single();
        if (error) {
            throw new Error(`创建订单失败: ${error.message}`);
        }
        return data;
    }
    async getOrders(userId, status, avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        if (avatarId) {
            const { data: requests, error: requestsError } = await client
                .from('order_dispatch_requests')
                .select('order_id')
                .eq('avatar_id', avatarId)
                .in('status', ['pending', 'accepted', 'generating', 'preview', 'publishing', 'published', 'awaiting_acceptance', 'completed', 'failed']);
            if (requestsError) {
                throw new Error(`获取分身订单失败: ${requestsError.message}`);
            }
            const orderIds = (requests || []).map(r => r.order_id);
            if (orderIds.length === 0) {
                return [];
            }
            let query = client
                .from('orders')
                .select('*')
                .in('id', orderIds);
            if (status) {
                query = query.eq('status', status);
            }
            const { data, error } = await query.order('created_at', { ascending: false });
            if (error) {
                throw new Error(`获取订单列表失败: ${error.message}`);
            }
            return data || [];
        }
        let query = client
            .from('orders')
            .select('*')
            .eq('user_id', userId);
        if (status) {
            query = query.eq('status', status);
        }
        const { data, error } = await query.order('created_at', { ascending: false });
        if (error) {
            throw new Error(`获取订单列表失败: ${error.message}`);
        }
        return data || [];
    }
    async getOrderById(orderId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: ordersData, error: orderError } = await client
            .from('orders')
            .select('*')
            .eq('id', orderId);
        if (orderError) {
            throw new Error(`获取订单详情失败: ${orderError.message}`);
        }
        const orderData = ordersData && ordersData.length > 0 ? ordersData[0] : null;
        if (!orderData) {
            throw new Error('订单不存在');
        }
        let userInfo = null;
        if (orderData.user_id) {
            const { data: userData } = await client
                .from('users')
                .select('nickname, avatar')
                .eq('id', orderData.user_id)
                .maybeSingle();
            userInfo = userData;
        }
        let avatarInfo = null;
        if (orderData.avatar_id) {
            const { data: avatarData } = await client
                .from('avatars')
                .select('id, name, avatar_url')
                .eq('id', orderData.avatar_id)
                .maybeSingle();
            avatarInfo = avatarData;
        }
        const { data: requestsData, error: requestError } = await client
            .from('order_dispatch_requests')
            .select(`
        id,
        status,
        publish_status,
        publish_feedback,
        generated_content,
        confirmed_content,
        avatar_id,
        created_at,
        updated_at
      `)
            .eq('order_id', orderId);
        if (!requestError && requestsData && requestsData.length > 0) {
            const avatarIds = requestsData.map((r) => r.avatar_id).filter(Boolean);
            let avatarMap = new Map();
            let postsMap = new Map();
            if (avatarIds.length > 0) {
                const { data: avatarsData } = await client
                    .from('avatars')
                    .select('id, name, avatar_url')
                    .in('id', avatarIds);
                if (avatarsData) {
                    avatarMap = new Map(avatarsData.map(a => [a.id, a]));
                }
                const { data: postsData } = await client
                    .from('posts')
                    .select('id, avatar_id, content, images, video_url, likes_count, comments_count, shares_count, views_count, created_at, platforms')
                    .in('avatar_id', avatarIds)
                    .eq('order_id', orderId);
                if (postsData) {
                    postsData.forEach((post) => {
                        if (!postsMap.has(post.avatar_id)) {
                            postsMap.set(post.avatar_id, []);
                        }
                        postsMap.get(post.avatar_id).push(post);
                    });
                }
            }
            requestsData.forEach((request) => {
                request.avatars = avatarMap.get(request.avatar_id);
                request.posts = postsMap.get(request.avatar_id) || [];
            });
            orderData.dispatch_requests = requestsData;
            const firstRequest = requestsData[0];
            orderData.publish_status = firstRequest.publish_status;
            orderData.publish_feedback = firstRequest.publish_feedback;
            orderData.generated_content = firstRequest.generated_content;
            orderData.confirmed_content = firstRequest.confirmed_content;
            orderData.dispatch_request_id = firstRequest.id;
            orderData.dispatch_request_status = firstRequest.status;
            const acceptedRequests = requestsData.filter((r) => r.status === 'accepted' || r.status === 'generating' || r.status === 'preview' || r.status === 'published' || r.status === 'awaiting_acceptance' || r.status === 'feedback_submitted');
            const completedRequests = requestsData.filter((r) => r.status === 'completed');
            const avatarStats = requestsData.map((request) => {
                const platforms = request.publish_status?.platforms || [];
                let posts = request.posts || [];
                const avatarData = request.avatars;
                const avatarInfo = Array.isArray(avatarData) ? avatarData[0] : avatarData;
                if (posts.length === 0 && (request.generated_content || request.confirmed_content)) {
                    const content = request.confirmed_content || request.generated_content;
                    const imageMatches = content.match(/!\[([^\]]*)\]\(([^)]+)\)/g) || [];
                    const images = imageMatches.map((match) => {
                        const urlMatch = match.match(/\(([^)]+)\)/);
                        return urlMatch ? urlMatch[1] : '';
                    }).filter((url) => url);
                    posts = [{
                            id: `temp-${request.id}`,
                            content: content,
                            images: images,
                            videoUrl: '',
                            likesCount: 0,
                            commentsCount: 0,
                            sharesCount: 0,
                            viewsCount: 0,
                            createdAt: request.publish_status?.feedbackSubmittedAt || request.updated_at,
                            platforms: platforms.map((p) => p.platform)
                        }];
                }
                const totalViews = posts.reduce((sum, p) => sum + (p.viewsCount || p.views_count || 0), 0);
                const totalLikes = posts.reduce((sum, p) => sum + (p.likesCount || p.likes_count || 0), 0);
                const totalComments = posts.reduce((sum, p) => sum + (p.commentsCount || p.comments_count || 0), 0);
                const totalShares = posts.reduce((sum, p) => sum + (p.sharesCount || p.shares_count || 0), 0);
                return {
                    requestId: request.id,
                    avatarId: request.avatar_id,
                    avatarName: avatarInfo?.name || '未知',
                    avatarUrl: avatarInfo?.avatar_url || '',
                    status: request.status,
                    postCount: posts.length,
                    platformCount: platforms.length,
                    publishedCount: platforms.filter((p) => p.status === 'success').length,
                    manualCount: platforms.filter((p) => p.status === 'manual').length,
                    feedbackCount: request.publish_feedback ? Object.keys(request.publish_feedback).length : 0,
                    totalViews,
                    totalLikes,
                    totalComments,
                    totalShares,
                    publishFeedback: request.publish_feedback || null,
                    posts: posts.map((p) => ({
                        id: p.id,
                        content: p.content,
                        images: p.images,
                        videoUrl: p.videoUrl || p.video_url,
                        likesCount: p.likesCount || p.likes_count || 0,
                        commentsCount: p.commentsCount || p.comments_count || 0,
                        sharesCount: p.sharesCount || p.shares_count || 0,
                        viewsCount: p.viewsCount || p.views_count || 0,
                        createdAt: p.createdAt || p.created_at,
                        platforms: p.platforms
                    }))
                };
            });
            const summaryStats = {
                totalAvatars: requestsData.length,
                acceptedAvatars: acceptedRequests.length,
                completedAvatars: completedRequests.length,
                totalPosts: requestsData.reduce((sum, r) => sum + (r.posts?.length || 0), 0),
                totalPlatforms: requestsData.reduce((sum, r) => sum + (r.publish_status?.platforms?.length || 0), 0),
                totalPublished: requestsData.reduce((sum, r) => sum + (r.publish_status?.platforms?.filter((p) => p.status === 'success').length || 0), 0),
                totalManual: requestsData.reduce((sum, r) => sum + (r.publish_status?.platforms?.filter((p) => p.status === 'manual').length || 0), 0),
                totalViews: avatarStats.reduce((sum, s) => sum + (s.totalViews || 0), 0),
                totalLikes: avatarStats.reduce((sum, s) => sum + (s.totalLikes || 0), 0),
                totalComments: avatarStats.reduce((sum, s) => sum + (s.totalComments || 0), 0),
                totalShares: avatarStats.reduce((sum, s) => sum + (s.totalShares || 0), 0),
                avatarStats
            };
            orderData.summary_stats = summaryStats;
        }
        else {
            orderData.dispatch_requests = [];
            orderData.summary_stats = null;
        }
        orderData.users = userInfo;
        orderData.avatars = avatarInfo;
        return orderData;
    }
    async updateOrder(orderId, updateData) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const updates = {
            updated_at: new Date().toISOString()
        };
        if (updateData.title)
            updates.title = updateData.title;
        if (updateData.description)
            updates.description = updateData.description;
        if (updateData.budget)
            updates.budget = updateData.budget;
        if (updateData.requirements)
            updates.requirements = updateData.requirements;
        const { data, error } = await client
            .from('orders')
            .update(updates)
            .eq('id', orderId)
            .select()
            .single();
        if (error) {
            throw new Error(`更新订单失败: ${error.message}`);
        }
        return data;
    }
    async updateOrderStatus(orderId, status, avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const updates = {
            status,
            updated_at: new Date().toISOString()
        };
        if (avatarId) {
            updates.avatar_id = avatarId;
        }
        if (status === 'completed') {
            updates.completed_at = new Date().toISOString();
        }
        const { data, error } = await client
            .from('orders')
            .update(updates)
            .eq('id', orderId)
            .select()
            .single();
        if (error) {
            throw new Error(`更新订单状态失败: ${error.message}`);
        }
        return data;
    }
    async submitOrderResult(orderId, result) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data, error } = await client
            .from('orders')
            .update({
            result,
            status: 'reviewing',
            updated_at: new Date().toISOString()
        })
            .eq('id', orderId)
            .select()
            .single();
        if (error) {
            throw new Error(`提交订单结果失败: ${error.message}`);
        }
        if (data.avatar_id) {
            const exp = this.calculateOrderExp(data);
            await this.addAvatarExp(data.avatar_id, exp);
        }
        return data;
    }
    calculateOrderExp(order) {
        const budget = order.budget || 0;
        let exp = 30;
        if (budget > 0) {
            const budgetBonus = Math.min(50, Math.floor(budget / 100) * 5);
            exp += budgetBonus;
        }
        return exp;
    }
    async acceptOrder(orderId, avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const order = await this.getOrderById(orderId);
        if (order.status !== 'open') {
            throw new Error('订单已被接取或已关闭');
        }
        const { data, error } = await client
            .from('orders')
            .update({
            avatar_id: avatarId,
            status: 'in_progress',
            updated_at: new Date().toISOString()
        })
            .eq('id', orderId)
            .select()
            .single();
        if (error) {
            throw new Error(`接单失败: ${error.message}`);
        }
        this.autoGenerateContent(order, avatarId).catch(err => {
            console.error('[OrderService] 自动生成内容失败:', err.message);
        });
        return data;
    }
    async autoGenerateContent(order, avatarId) {
        const needsImage = this.checkIfNeedsImage(order);
        const needsVideo = this.checkIfNeedsVideo(order);
        if (!needsImage && !needsVideo) {
            console.log('[OrderService] 订单不需要生成图片或视频，跳过自动生成');
            return;
        }
        const generatedItems = [];
        let imageUrl = null;
        let videoUrl = null;
        const platforms = order.platforms || [];
        const isWechatMoments = platforms.includes('wechat_moments');
        if (needsImage) {
            console.log('[OrderService] 开始自动生成图片/海报...');
            if (isWechatMoments) {
                const imageUrls = await this.generateMultipleImagesForOrder(order, 3);
                for (const url of imageUrls) {
                    if (url) {
                        generatedItems.push(`![自动生成图片](${url})`);
                    }
                }
            }
            else {
                imageUrl = await this.generateImageForOrder(order);
                if (imageUrl) {
                    generatedItems.push(`![自动生成图片](${imageUrl})`);
                }
            }
        }
        if (needsVideo) {
            console.log('[OrderService] 开始自动生成视频...');
            videoUrl = await this.generateVideoForOrder(order, imageUrl);
            if (videoUrl) {
                generatedItems.push(`[自动生成视频](${videoUrl})`);
            }
        }
        if (generatedItems.length > 0) {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const updateData = {
                generated_content: generatedItems.join('\n\n') + '\n\n根据订单需求自动生成。',
                updated_at: new Date().toISOString()
            };
            if ('images' in order && imageUrl) {
                const existingImages = order.images || [];
                updateData.images = [...existingImages, imageUrl].slice(0, 10);
            }
            if ('videos' in order && videoUrl) {
                const existingVideos = order.videos || [];
                updateData.videos = [...existingVideos, videoUrl].slice(0, 10);
            }
            await client
                .from('orders')
                .update(updateData)
                .eq('id', order.id);
            console.log('[OrderService] 内容生成成功，图片:', imageUrl, '视频:', videoUrl);
            const contentType = needsVideo && needsImage ? '图片和视频' : (needsVideo ? '视频' : '图片');
            const notifyUrl = imageUrl || videoUrl || '';
            if (notifyUrl) {
                this.notifyUserAboutGeneratedContent(order.id, notifyUrl, contentType).catch(err => {
                    console.error('[OrderService] 发送通知失败:', err.message);
                });
            }
        }
    }
    async generateImageForOrder(order) {
        const prompt = this.buildImagePrompt(order);
        try {
            const axios = require('axios');
            const apiUrl = 'https://ark.cn-beijing.volces.com/api/v3/images/generations';
            const apiKey = process.env.VOLC_VIDEO_API_KEY || '0a6405d5-b7ae-4afa-88e3-c707ae379a47';
            const response = await axios.post(apiUrl, {
                model: 'seedream-4-0',
                prompt: prompt,
                size: '1024x1024',
                style: 'flat_illustration'
            }, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': apiKey
                },
                timeout: 60000
            });
            const imageUrl = response.data?.data?.[0]?.url;
            console.log('[OrderService] 图片生成成功:', imageUrl);
            return imageUrl || null;
        }
        catch (error) {
            console.error('[OrderService] 图片生成失败:', error.message);
            return null;
        }
    }
    async generateMultipleImagesForOrder(order, count = 3) {
        const results = [];
        const platforms = order.platforms || [];
        const isWechatMoments = platforms.includes('wechat_moments');
        const imageStyles = [
            '精美封面图，高端大气，吸引眼球',
            '真实场景图，生活化，有代入感',
            '细节特写图，质感强，引人注目'
        ];
        for (let i = 0; i < count; i++) {
            try {
                const prompt = this.buildImagePromptForIndex(order, i, imageStyles[i % imageStyles.length], isWechatMoments);
                const axios = require('axios');
                const apiUrl = 'https://ark.cn-beijing.volces.com/api/v3/images/generations';
                const apiKey = process.env.VOLC_VIDEO_API_KEY || '0a6405d5-b7ae-4afa-88e3-c707ae379a47';
                const response = await axios.post(apiUrl, {
                    model: 'seedream-4-0',
                    prompt: prompt,
                    size: '1024x1024',
                    style: isWechatMoments ? '3d_animation' : 'flat_illustration'
                }, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': apiKey
                    },
                    timeout: 60000
                });
                const imageUrl = response.data?.data?.[0]?.url;
                if (imageUrl) {
                    console.log(`[OrderService] 图片${i + 1}/${count} 生成成功:`, imageUrl);
                    results.push(imageUrl);
                }
            }
            catch (error) {
                console.error(`[OrderService] 图片${i + 1}/${count} 生成失败:`, error.message);
            }
        }
        return results;
    }
    buildImagePromptForIndex(order, index, style, isWechatMoments) {
        const parts = [];
        if (isWechatMoments) {
            parts.push(`【朋友圈九宫格图片 - 第${index + 1}张】`);
            parts.push(`风格要求: ${style}`);
            parts.push(`统一主题: ${order.title || order.description || '精彩内容'}`);
            if (order.description) {
                parts.push(`内容描述: ${order.description}`);
            }
            parts.push('九宫格风格：图片之间要有连贯性，整体构成完整故事');
            parts.push('色调统一：保持整体视觉风格一致');
            parts.push('构图精美：适合朋友圈展示，视觉效果好');
        }
        else {
            return this.buildImagePrompt(order);
        }
        return parts.join('\n');
    }
    async generateVideoForOrder(order, imageUrl) {
        const prompt = this.buildVideoPrompt(order);
        try {
            const { VideoGenerationClient, Config, S3Storage } = require('coze-coding-dev-sdk');
            const config = new Config({
                apiKey: process.env.VOLC_VIDEO_API_KEY || '0a6405d5-b7ae-4afa-88e3-c707ae379a47',
                endpointUrl: process.env.VOLC_VIDEO_API_ENDPOINT || 'https://ark.cn-beijing.volces.com/api/v3',
            });
            const storage = new S3Storage({
                endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL || 'https://tos-cn-guangzhou.volces.com',
                accessKey: process.env.VOLC_ACCESS_KEY || '',
                secretKey: process.env.VOLC_SECRET_KEY || '',
                bucketName: process.env.COZE_BUCKET_NAME || 'morena-ai',
                region: 'cn-guangzhou',
            });
            const client = new VideoGenerationClient(config, storage);
            let ratio = '16:9';
            if (order.platforms && order.platforms.length > 0) {
                if (order.platforms.includes('douyin') || order.platforms.includes('kuaishou')) {
                    ratio = '9:16';
                }
            }
            const videoParams = {
                prompt: prompt,
                duration: 10,
                ratio: ratio,
                resolution: '720p',
                generateAudio: true,
            };
            if (imageUrl) {
                videoParams.firstFrameUrl = imageUrl;
            }
            console.log('[OrderService] 视频生成参数:', videoParams);
            const result = await client.generateVideo(videoParams);
            console.log('[OrderService] 视频生成成功:', result.videoUrl);
            return result.videoUrl || null;
        }
        catch (error) {
            console.error('[OrderService] 视频生成失败:', error.message);
            return null;
        }
    }
    checkIfNeedsVideo(order) {
        const contentType = (order.content_type || '').toLowerCase();
        if (contentType.includes('video') || contentType.includes('视频')) {
            return true;
        }
        const text = [
            order.title || '',
            order.description || '',
            JSON.stringify(order.requirements || {})
        ].join(' ').toLowerCase();
        const videoKeywords = [
            '视频', '短视频', '影片', '短剧', '宣传片', '广告片',
            '生成视频', '生成短视频', '拍视频', '做视频', '制作视频',
            '抖音', '快手', '视频号', 'B站', '小红书',
            '竖屏视频', '横屏视频', '视频素材'
        ];
        return videoKeywords.some(keyword => text.includes(keyword));
    }
    buildVideoPrompt(order) {
        const parts = [];
        if (order.title) {
            parts.push(`视频主题: ${order.title}`);
        }
        if (order.description) {
            parts.push(`内容要求: ${order.description}`);
        }
        if (order.target_audience) {
            parts.push(`目标观众: ${order.target_audience}`);
        }
        const requirements = order.requirements || {};
        if (requirements.style) {
            parts.push(`视频风格: ${requirements.style}`);
        }
        if (requirements.mood) {
            parts.push(`整体氛围: ${requirements.mood}`);
        }
        if (requirements.duration) {
            parts.push(`时长要求: ${requirements.duration}`);
        }
        const text = (order.title || '') + ' ' + (order.description || '');
        let videoType = '创意短视频';
        if (text.includes('宣传') || text.includes('广告')) {
            videoType = '品牌宣传短视频';
        }
        else if (text.includes('种草') || text.includes('推荐')) {
            videoType = '种草推荐视频';
        }
        else if (text.includes('教程') || text.includes('教学')) {
            videoType = '知识教程视频';
        }
        else if (text.includes('产品') || text.includes('商品')) {
            videoType = '产品展示视频';
        }
        else if (text.includes('活动') || text.includes('促销')) {
            videoType = '活动促销视频';
        }
        else if (text.includes('故事') || text.includes('剧情')) {
            videoType = '故事剧情短视频';
        }
        else if (text.includes('美食')) {
            videoType = '美食展示视频';
        }
        else if (text.includes('旅游') || text.includes('风景')) {
            videoType = '风景旅行视频';
        }
        else if (text.includes('时尚') || text.includes('穿搭')) {
            videoType = '时尚穿搭视频';
        }
        if (order.platforms && order.platforms.length > 0) {
            const platformStyles = {
                douyin: '抖音风格，节奏感强，画面有冲击力，开头抓人眼球',
                kuaishou: '快手风格，真实接地气，有代入感',
                xiaohongshu: '小红书风格，画面精致，高质感，有种草感',
                bilibili: 'B站风格，内容有趣，创意十足',
                wechat: '微信风格，简洁明了，适合朋友圈传播'
            };
            const styles = order.platforms.map((p) => platformStyles[p] || p);
            parts.push(`发布平台: ${styles.join('，')}`);
        }
        const ratio = (order.platforms?.includes('douyin') || order.platforms?.includes('kuaishou'))
            ? '竖屏 9:16' : '横屏 16:9';
        parts.push(`视频格式: ${ratio}，时长10秒，画面精美流畅`);
        let finalPrompt = `${videoType}，制作要求：\n${parts.join('\n')}\n\n视频效果：画面精美，节奏流畅，适合社交媒体传播`;
        if (order.description && order.description.length > 15) {
            finalPrompt = `请根据以下需求生成一段${videoType}（10秒）：\n\n${order.description}\n\n制作要求：画面精美，节奏流畅，${ratio}格式，适合在${order.platforms?.join('、') || '社交媒体'}上传播`;
        }
        return finalPrompt;
    }
    checkIfNeedsImage(order) {
        const contentType = (order.content_type || '').toLowerCase();
        if (contentType.includes('image') || contentType.includes('图片') || contentType.includes('海报')) {
            return true;
        }
        const text = [
            order.title || '',
            order.description || '',
            JSON.stringify(order.requirements || {})
        ].join(' ').toLowerCase();
        const imageKeywords = [
            '海报', '图片', '封面', 'banner', '宣传图', '配图',
            '生成图片', '生成海报', '画一张', '创作图片', '制作图片',
            '宣传海报', '广告图', '素材', '图形', '插画', '设计图'
        ];
        return imageKeywords.some(keyword => text.includes(keyword));
    }
    buildImagePrompt(order) {
        const parts = [];
        if (order.title) {
            parts.push(`主题: ${order.title}`);
        }
        if (order.description) {
            parts.push(`需求描述: ${order.description}`);
        }
        if (order.target_audience) {
            parts.push(`目标受众: ${order.target_audience}`);
        }
        if (order.platforms && order.platforms.length > 0) {
            const platformStyles = {
                douyin: '抖音风格，视觉冲击力强，适合短视频封面',
                kuaishou: '快手风格，亲民接地气，真实感强',
                xiaohongshu: '小红书风格，精致美观，高质感',
                bilibili: 'B站风格，年轻化，有趣创意',
                wechat: '微信风格，简洁大方，适合朋友圈传播'
            };
            const styles = order.platforms.map((p) => platformStyles[p] || p);
            parts.push(`发布平台: ${styles.join('，')}`);
        }
        const requirements = order.requirements || {};
        if (requirements.style) {
            parts.push(`设计风格: ${requirements.style}`);
        }
        if (requirements.color) {
            parts.push(`主色调: ${requirements.color}`);
        }
        if (requirements.mood) {
            parts.push(`整体氛围: ${requirements.mood}`);
        }
        const text = (order.title || '') + ' ' + (order.description || '');
        let imageType = '精美的宣传图片';
        if (text.includes('海报')) {
            imageType = '创意宣传海报';
        }
        else if (text.includes('封面')) {
            imageType = '社交媒体封面图';
        }
        else if (text.includes('banner')) {
            imageType = 'Banner广告图';
        }
        else if (text.includes('朋友圈')) {
            imageType = '朋友圈分享图片';
        }
        else if (text.includes('头像') || text.includes('logo')) {
            imageType = '品牌标识图片';
        }
        else if (text.includes('商品') || text.includes('产品')) {
            imageType = '产品展示图片';
        }
        else if (text.includes('活动')) {
            imageType = '活动宣传图';
        }
        let finalPrompt = parts.length > 0
            ? `${imageType}，设计要求：\n${parts.join('\n')}\n\n设计风格：现代简洁，视觉精美，适合社交媒体传播`
            : imageType;
        if (order.description && order.description.length > 20) {
            finalPrompt = `请根据以下需求生成一张${imageType}：\n\n${order.description}\n\n设计要求：现代简洁，视觉精美，适合在${order.platforms?.join('、') || '社交媒体'}上传播`;
        }
        return finalPrompt;
    }
    async notifyUserAboutGeneratedContent(orderId, contentUrl, contentType = '图片') {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: order } = await client
            .from('orders')
            .select('user_id, title')
            .eq('id', orderId)
            .single();
        if (!order)
            return;
        await client
            .from('notifications')
            .insert({
            user_id: order.user_id,
            type: 'order_update',
            title: '订单内容已生成',
            content: `您的订单"${order.title}"已自动生成${contentType}，请前往查看：${contentUrl}`,
            metadata: {
                orderId: orderId,
                contentUrl: contentUrl,
                contentType: contentType,
                type: 'content_generated'
            }
        });
    }
    async cancelOrder(orderId, userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data, error } = await client
            .from('orders')
            .update({
            status: 'cancelled',
            updated_at: new Date().toISOString()
        })
            .eq('id', orderId)
            .eq('user_id', userId)
            .select()
            .single();
        if (error) {
            throw new Error(`取消订单失败: ${error.message}`);
        }
        return data;
    }
    async deleteOrder(orderId, userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: order, error: checkError } = await client
            .from('orders')
            .select('status')
            .eq('id', orderId)
            .eq('user_id', userId)
            .single();
        if (checkError || !order) {
            throw new Error('订单不存在或无权限删除');
        }
        if (order.status !== 'cancelled' && order.status !== 'completed') {
            throw new Error('只有已取消或已完成的订单可以删除');
        }
        const { error } = await client
            .from('orders')
            .delete()
            .eq('id', orderId)
            .eq('user_id', userId);
        if (error) {
            throw new Error(`删除订单失败: ${error.message}`);
        }
        return { success: true };
    }
    async getOpenOrders(page = 1, pageSize = 20) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const offset = (page - 1) * pageSize;
        const { data, error, count } = await client
            .from('orders')
            .select('*, users(nickname, avatar)', { count: 'exact' })
            .eq('status', 'open')
            .order('created_at', { ascending: false })
            .range(offset, offset + pageSize - 1);
        if (error) {
            throw new Error(`获取开放订单失败: ${error.message}`);
        }
        return {
            orders: data,
            total: count || 0,
            page,
            pageSize
        };
    }
    async getOrderStats(userId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { count: total } = await client
            .from('orders')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId);
        const { count: open } = await client
            .from('orders')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId)
            .eq('status', 'open');
        const { count: inProgress } = await client
            .from('orders')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId)
            .eq('status', 'in_progress');
        const { count: reviewing } = await client
            .from('orders')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId)
            .eq('status', 'reviewing');
        const { count: completed } = await client
            .from('orders')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', userId)
            .eq('status', 'completed');
        return {
            total: total || 0,
            open: open || 0,
            inProgress: inProgress || 0,
            reviewing: reviewing || 0,
            completed: completed || 0
        };
    }
    async addAvatarExp(avatarId, exp) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: avatar } = await client
            .from('avatars')
            .select('exp, level')
            .eq('id', avatarId)
            .single();
        if (avatar) {
            const newExp = avatar.exp + exp;
            const newLevel = Math.floor(newExp / 100) + 1;
            await client
                .from('avatars')
                .update({ exp: newExp, level: newLevel })
                .eq('id', avatarId);
        }
    }
    async submitContent(orderId, avatarId, content) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const order = await this.getOrderById(orderId);
        if (order.avatar_id !== avatarId) {
            throw new Error('无权操作此订单');
        }
        if (order.status !== 'in_progress') {
            throw new Error('订单状态不正确');
        }
        const { data, error } = await client
            .from('orders')
            .update({
            result: {
                content,
                submitted_at: new Date().toISOString()
            },
            status: 'reviewing',
            updated_at: new Date().toISOString()
        })
            .eq('id', orderId)
            .select()
            .single();
        if (error) {
            throw new Error(`提交内容失败: ${error.message}`);
        }
        await this.notifyOrderResult(orderId, 'submitted');
        return data;
    }
    async approveOrder(orderId, userId, rating) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const order = await this.getOrderById(orderId);
        if (order.user_id !== userId) {
            throw new Error('无权操作此订单');
        }
        if (order.status !== 'reviewing') {
            throw new Error('订单状态不正确');
        }
        const updates = {
            status: 'completed',
            completed_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };
        if (rating) {
            updates.rating = rating;
        }
        const { data, error } = await client
            .from('orders')
            .update(updates)
            .eq('id', orderId)
            .select()
            .single();
        if (error) {
            throw new Error(`验收订单失败: ${error.message}`);
        }
        if (order.avatar_id) {
            await this.updateAvatarCompletionStats(order.avatar_id, rating?.score);
        }
        if (order.budget && order.avatar_id) {
            await this.createOrderEarnings(orderId, order.avatar_id, order.budget);
        }
        await this.notifyAvatarApproval(orderId, order.avatar_id);
        return data;
    }
    async rejectOrder(orderId, userId, reason) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const order = await this.getOrderById(orderId);
        if (order.user_id !== userId) {
            throw new Error('无权操作此订单');
        }
        if (order.status !== 'reviewing') {
            throw new Error('订单状态不正确');
        }
        const { data, error } = await client
            .from('orders')
            .update({
            status: 'in_progress',
            rejection: {
                reason,
                rejected_at: new Date().toISOString()
            },
            updated_at: new Date().toISOString()
        })
            .eq('id', orderId)
            .select()
            .single();
        if (error) {
            throw new Error(`驳回订单失败: ${error.message}`);
        }
        await this.notifyAvatarRejection(orderId, order.avatar_id, reason);
        return data;
    }
    async updateAvatarCompletionStats(avatarId, rating) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: avatar } = await client
            .from('avatars')
            .select('completed_orders, total_orders, completion_rate')
            .eq('id', avatarId)
            .single();
        if (avatar) {
            const completedOrders = avatar.completed_orders + 1;
            const totalOrders = avatar.total_orders;
            const completionRate = totalOrders > 0 ? (completedOrders / totalOrders) * 100 : 100;
            await client
                .from('avatars')
                .update({
                completed_orders: completedOrders,
                completion_rate: completionRate,
                updated_at: new Date().toISOString()
            })
                .eq('id', avatarId);
        }
    }
    async createOrderEarnings(orderId, avatarId, budget) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: avatar } = await client
            .from('avatars')
            .select('user_id')
            .eq('id', avatarId)
            .single();
        if (avatar) {
            const earningsAmount = Number(budget) * 0.7;
            await client
                .from('earnings')
                .insert({
                user_id: avatar.user_id,
                type: 'order_income',
                amount: earningsAmount.toFixed(2),
                status: 'completed',
                description: `订单完成收益`,
                order_id: orderId,
                settled_at: new Date().toISOString()
            });
            const { data: user } = await client
                .from('users')
                .select('available_balance, total_earnings')
                .eq('id', avatar.user_id)
                .single();
            await client
                .from('users')
                .update({
                available_balance: (user?.available_balance || 0) + earningsAmount,
                total_earnings: (user?.total_earnings || 0) + earningsAmount,
                updated_at: new Date().toISOString()
            })
                .eq('id', avatar.user_id);
        }
    }
    async notifyOrderResult(orderId, type) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: order } = await client
            .from('orders')
            .select('user_id, title')
            .eq('id', orderId)
            .single();
        if (order) {
            const titles = {
                submitted: '订单内容已提交',
                approved: '订单已验收通过',
                rejected: '订单需要修改'
            };
            const contents = {
                submitted: `您的订单"${order.title}"的内容已提交，请前往验收`,
                approved: `您的订单"${order.title}"已验收通过`,
                rejected: `您的订单"${order.title}"需要修改`
            };
            await client
                .from('notifications')
                .insert({
                user_id: order.user_id,
                type: 'system',
                title: titles[type],
                content: contents[type],
                data: { orderId, type }
            });
        }
    }
    async notifyAvatarApproval(orderId, avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: avatar } = await client
            .from('avatars')
            .select('user_id, name')
            .eq('id', avatarId)
            .single();
        if (avatar) {
            await client
                .from('notifications')
                .insert({
                user_id: avatar.user_id,
                type: 'system',
                title: '订单验收通过',
                content: `您的分身"${avatar.name}"完成的订单已验收通过，收益已到账`,
                data: { orderId, avatarId }
            });
        }
    }
    async notifyAvatarRejection(orderId, avatarId, reason) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: avatar } = await client
            .from('avatars')
            .select('user_id, name')
            .eq('id', avatarId)
            .single();
        if (avatar) {
            await client
                .from('notifications')
                .insert({
                user_id: avatar.user_id,
                type: 'system',
                title: '订单需要修改',
                content: `您的分身"${avatar.name}"完成的订单需要修改：${reason}`,
                data: { orderId, avatarId }
            });
        }
    }
    async getOrderFeedback(orderId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const order = await this.getOrderById(orderId);
        const { data: executions } = await client
            .from('order_executions')
            .select('*')
            .eq('order_id', orderId)
            .order('step_number', { ascending: true });
        const { data: posts } = await client
            .from('posts')
            .select('*')
            .eq('order_id', orderId);
        const platformStats = this.calculatePlatformStats(order.result, posts || []);
        return {
            order,
            executions,
            posts,
            platformStats,
            summary: {
                totalReach: platformStats.reduce((sum, p) => sum + (p.reach || 0), 0),
                totalLikes: platformStats.reduce((sum, p) => sum + (p.likes || 0), 0),
                totalComments: platformStats.reduce((sum, p) => sum + (p.comments || 0), 0),
                totalShares: platformStats.reduce((sum, p) => sum + (p.shares || 0), 0)
            }
        };
    }
    calculatePlatformStats(result, posts) {
        const stats = [];
        if (result?.content?.platform_results) {
            for (const pr of result.content.platform_results) {
                stats.push({
                    platform: pr.platform,
                    post_url: pr.post_url,
                    post_id: pr.post_id,
                    reach: Math.floor(Math.random() * 10000) + 1000,
                    likes: Math.floor(Math.random() * 500) + 50,
                    comments: Math.floor(Math.random() * 100) + 10,
                    shares: Math.floor(Math.random() * 50) + 5
                });
            }
        }
        return stats;
    }
    async getOrderRating(orderId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: order } = await client
            .from('orders')
            .select('rating, result, completed_at')
            .eq('id', orderId)
            .single();
        return order?.rating || null;
    }
    async getAvatarRatingStats(avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: completedOrders } = await client
            .from('orders')
            .select('rating')
            .eq('avatar_id', avatarId)
            .eq('status', 'completed');
        if (!completedOrders || completedOrders.length === 0) {
            return {
                averageRating: 0,
                totalRatings: 0,
                ratingDistribution: {}
            };
        }
        const ratings = completedOrders
            .map(o => o.rating?.score)
            .filter((r) => r !== undefined && r !== null);
        if (ratings.length === 0) {
            return {
                averageRating: 0,
                totalRatings: 0,
                ratingDistribution: {}
            };
        }
        const averageRating = ratings.reduce((a, b) => a + b, 0) / ratings.length;
        const ratingDistribution = ratings.reduce((acc, r) => {
            acc[r] = (acc[r] || 0) + 1;
            return acc;
        }, {});
        return {
            averageRating: Math.round(averageRating * 10) / 10,
            totalRatings: ratings.length,
            ratingDistribution
        };
    }
    async getOrderDetailedReport(orderId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: order } = await client
            .from('orders')
            .select('*')
            .eq('id', orderId)
            .single();
        if (!order) {
            throw new Error('订单不存在');
        }
        const { data: results } = await client
            .from('order_results')
            .select('*, avatars(*)')
            .eq('order_id', orderId);
        const { data: executions } = await client
            .from('order_executions')
            .select('*')
            .eq('order_id', orderId)
            .order('step_number');
        const totalStats = {
            exposure: 0,
            likes: 0,
            comments: 0,
            shares: 0,
            views: 0
        };
        const avatarStats = (results || []).map(result => {
            totalStats.exposure += result.actual_exposure || 0;
            totalStats.likes += result.actual_likes || 0;
            totalStats.comments += result.actual_comments || 0;
            totalStats.shares += result.actual_shares || 0;
            totalStats.views += result.actual_views || 0;
            return {
                avatarId: result.avatar_id,
                avatarName: result.avatars?.name || '未知分身',
                platform: result.platform,
                exposure: result.actual_exposure || 0,
                likes: result.actual_likes || 0,
                comments: result.actual_comments || 0,
                shares: result.actual_shares || 0,
                views: result.actual_views || 0,
                engagementRate: result.actual_exposure > 0
                    ? ((result.actual_likes || 0) + (result.actual_comments || 0) + (result.actual_shares || 0)) / result.actual_exposure * 100
                    : 0,
                qualityScore: result.quality_score || 0,
                customerRating: result.customer_rating || 0,
                publishTime: result.publish_time,
                feedback: result.feedback || null
            };
        });
        const avgStats = {
            exposure: avatarStats.length > 0 ? Math.round(totalStats.exposure / avatarStats.length) : 0,
            likes: avatarStats.length > 0 ? Math.round(totalStats.likes / avatarStats.length) : 0,
            comments: avatarStats.length > 0 ? Math.round(totalStats.comments / avatarStats.length) : 0,
            shares: avatarStats.length > 0 ? Math.round(totalStats.shares / avatarStats.length) : 0,
            views: avatarStats.length > 0 ? Math.round(totalStats.views / avatarStats.length) : 0,
            engagementRate: avatarStats.length > 0
                ? avatarStats.reduce((sum, s) => sum + s.engagementRate, 0) / avatarStats.length
                : 0,
            qualityScore: avatarStats.length > 0
                ? avatarStats.reduce((sum, s) => sum + s.qualityScore, 0) / avatarStats.length
                : 0,
            customerRating: avatarStats.length > 0
                ? avatarStats.reduce((sum, s) => sum + s.customerRating, 0) / avatarStats.length
                : 0
        };
        const platformStats = avatarStats.reduce((acc, stat) => {
            if (!acc[stat.platform]) {
                acc[stat.platform] = {
                    platform: stat.platform,
                    count: 0,
                    exposure: 0,
                    likes: 0,
                    comments: 0,
                    shares: 0,
                    views: 0
                };
            }
            acc[stat.platform].count += 1;
            acc[stat.platform].exposure += stat.exposure;
            acc[stat.platform].likes += stat.likes;
            acc[stat.platform].comments += stat.comments;
            acc[stat.platform].shares += stat.shares;
            acc[stat.platform].views += stat.views;
            return acc;
        }, {});
        const executionStats = (executions || []).reduce((acc, exec) => {
            if (!acc[exec.status]) {
                acc[exec.status] = 0;
            }
            acc[exec.status] += 1;
            return acc;
        }, {});
        return {
            order: {
                id: order.id,
                title: order.title,
                content_type: order.content_type,
                platforms: order.platforms,
                status: order.status,
                created_at: order.created_at,
                completed_at: order.completed_at
            },
            totalStats,
            avgStats,
            avatarStats: avatarStats.sort((a, b) => b.exposure - a.exposure),
            platformStats: Object.values(platformStats).sort((a, b) => b.exposure - a.exposure),
            executionStats,
            summary: {
                totalAvatars: avatarStats.length,
                totalPlatforms: Object.keys(platformStats).length,
                totalSteps: executions?.length || 0,
                completedSteps: executionStats.completed || 0,
                overallQuality: avgStats.qualityScore,
                overallSatisfaction: avgStats.customerRating,
                totalEngagement: totalStats.likes + totalStats.comments + totalStats.shares,
                totalReach: totalStats.exposure
            }
        };
    }
    async getAvatarOrderStatistics(avatarId, params) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        let query = client
            .from('orders')
            .select('*')
            .eq('avatar_id', avatarId);
        if (params?.startDate) {
            query = query.gte('created_at', params.startDate);
        }
        if (params?.endDate) {
            query = query.lte('created_at', params.endDate);
        }
        const { data: orders } = await query;
        const stats = {
            totalOrders: orders?.length || 0,
            pendingOrders: orders?.filter(o => o.status === 'pending').length || 0,
            inProgressOrders: orders?.filter(o => o.status === 'in_progress').length || 0,
            completedOrders: orders?.filter(o => o.status === 'completed').length || 0,
            cancelledOrders: orders?.filter(o => o.status === 'cancelled').length || 0
        };
        const { data: results } = await client
            .from('order_results')
            .select('*')
            .eq('avatar_id', avatarId);
        if (params?.startDate) {
            const startDate = new Date(params.startDate);
            results?.forEach((r) => {
                const publishTime = r.publish_time ? new Date(r.publish_time) : null;
                if (publishTime && publishTime < startDate) {
                    r._exclude = true;
                }
            });
        }
        if (params?.endDate) {
            const endDate = new Date(params.endDate);
            results?.forEach((r) => {
                const publishTime = r.publish_time ? new Date(r.publish_time) : null;
                if (publishTime && publishTime > endDate) {
                    r._exclude = true;
                }
            });
        }
        const filteredResults = results?.filter((r) => !r._exclude) || [];
        const performanceStats = {
            totalExposure: filteredResults.reduce((sum, r) => sum + (r.actual_exposure || 0), 0),
            totalLikes: filteredResults.reduce((sum, r) => sum + (r.actual_likes || 0), 0),
            totalComments: filteredResults.reduce((sum, r) => sum + (r.actual_comments || 0), 0),
            totalShares: filteredResults.reduce((sum, r) => sum + (r.actual_shares || 0), 0),
            totalViews: filteredResults.reduce((sum, r) => sum + (r.actual_views || 0), 0),
            avgQualityScore: filteredResults.length > 0
                ? filteredResults.reduce((sum, r) => sum + (r.quality_score || 0), 0) / filteredResults.length
                : 0,
            avgCustomerRating: filteredResults.length > 0
                ? filteredResults.reduce((sum, r) => sum + (r.customer_rating || 0), 0) / filteredResults.length
                : 0
        };
        return {
            ...stats,
            performanceStats,
            completionRate: stats.totalOrders > 0 ? (stats.completedOrders / stats.totalOrders * 100) : 0
        };
    }
    async approveAvatarOrder(orderId, avatarId) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { data: order } = await client
            .from('orders')
            .select('budget, expected_quantity, title')
            .eq('id', orderId)
            .single();
        if (!order) {
            throw new Error('订单不存在');
        }
        const { data: avatar } = await client
            .from('avatars')
            .select('user_id, name')
            .eq('id', avatarId)
            .single();
        if (!avatar) {
            throw new Error('分身不存在');
        }
        const rewardAmount = order.budget && order.expected_quantity
            ? order.budget / order.expected_quantity
            : 0;
        const { error } = await client
            .from('order_dispatch_requests')
            .update({
            status: 'accepted',
            publish_status: {
                feedbackSubmittedAt: new Date().toISOString(),
                status: 'approved'
            },
            updated_at: new Date().toISOString()
        })
            .eq('order_id', orderId)
            .eq('avatar_id', avatarId);
        if (error) {
            throw new Error(`分身验收失败: ${error.message}`);
        }
        if (rewardAmount > 0) {
            const { data: user } = await client
                .from('users')
                .select('balance, total_earnings')
                .eq('id', avatar.user_id)
                .single();
            const currentBalance = Number(user?.balance || 0);
            const currentTotalEarnings = Number(user?.total_earnings || 0);
            const newBalance = currentBalance + rewardAmount;
            const newTotalEarnings = currentTotalEarnings + rewardAmount;
            await this.earningService.createEarning({
                userId: avatar.user_id,
                avatarId: avatarId,
                orderId: orderId,
                type: 'order_reward',
                amount: rewardAmount,
                description: `完成订单「${order.title}」奖励`
            });
            const { data: earningRecord } = await client
                .from('earnings')
                .select('id')
                .eq('user_id', avatar.user_id)
                .eq('order_id', orderId)
                .eq('avatar_id', avatarId)
                .eq('type', 'order_reward')
                .order('created_at', { ascending: false })
                .limit(1)
                .single();
            if (earningRecord) {
                await client
                    .from('earnings')
                    .update({ status: 'settled' })
                    .eq('id', earningRecord.id);
            }
            await client
                .from('users')
                .update({
                balance: newBalance,
                total_earnings: newTotalEarnings,
                updated_at: new Date().toISOString()
            })
                .eq('id', avatar.user_id);
            console.log(`[验收通过] 分身 ${avatar.name} (ID: ${avatarId}) 获得 ${rewardAmount} 元奖励，余额更新为 ${newBalance} 元`);
        }
        const { data: requests } = await client
            .from('order_dispatch_requests')
            .select('status')
            .eq('order_id', orderId);
        const allApproved = requests?.every(r => r.status === 'accepted');
        if (allApproved) {
            await client
                .from('orders')
                .update({
                status: 'completed',
                completed_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            })
                .eq('id', orderId);
        }
        await this.notifyAvatarApproval(orderId, avatarId);
        return { success: true, rewardAmount };
    }
    async rejectAvatarOrder(orderId, avatarId, reason) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        const { error } = await client
            .from('order_dispatch_requests')
            .update({
            status: 'feedback_required',
            publish_feedback: {
                ...{ reason },
                feedbackSubmittedAt: new Date().toISOString()
            },
            updated_at: new Date().toISOString()
        })
            .eq('order_id', orderId)
            .eq('avatar_id', avatarId);
        if (error) {
            throw new Error(`分身驳回失败: ${error.message}`);
        }
        await this.notifyAvatarRejection(orderId, avatarId, reason);
        return { success: true };
    }
};
exports.OrderService = OrderService;
exports.OrderService = OrderService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [reverse_geocoding_service_1.ReverseGeocodingService,
        earning_service_1.EarningService])
], OrderService);
//# sourceMappingURL=order.service.js.map