import { ReverseGeocodingService } from '../../services/reverse-geocoding.service';
import { EarningService } from '../earning/earning.service';
export declare class OrderService {
    private readonly reverseGeocodingService;
    private readonly earningService;
    constructor(reverseGeocodingService: ReverseGeocodingService, earningService: EarningService);
    createOrder(userId: string, orderData: Record<string, any>): Promise<any>;
    getOrders(userId: string, status?: string, avatarId?: string): Promise<any[]>;
    getOrderById(orderId: string): Promise<any>;
    updateOrder(orderId: string, updateData: Record<string, any>): Promise<any>;
    updateOrderStatus(orderId: string, status: string, avatarId?: string): Promise<any>;
    submitOrderResult(orderId: string, result: Record<string, any>): Promise<any>;
    private calculateOrderExp;
    acceptOrder(orderId: string, avatarId: string): Promise<any>;
    private autoGenerateContent;
    private generateImageForOrder;
    private generateMultipleImagesForOrder;
    private buildImagePromptForIndex;
    private generateVideoForOrder;
    private checkIfNeedsVideo;
    private buildVideoPrompt;
    private checkIfNeedsImage;
    private buildImagePrompt;
    private notifyUserAboutGeneratedContent;
    cancelOrder(orderId: string, userId: string): Promise<any>;
    deleteOrder(orderId: string, userId: string): Promise<{
        success: boolean;
    }>;
    getOpenOrders(page?: number, pageSize?: number): Promise<{
        orders: any[];
        total: number;
        page: number;
        pageSize: number;
    }>;
    getOrderStats(userId: string): Promise<{
        total: number;
        open: number;
        inProgress: number;
        reviewing: number;
        completed: number;
    }>;
    private addAvatarExp;
    submitContent(orderId: string, avatarId: string, content: {
        title?: string;
        content: string;
        images?: string[];
        videos?: string[];
        platform_results?: Array<{
            platform: string;
            post_id?: string;
            post_url?: string;
            status: string;
        }>;
    }): Promise<any>;
    approveOrder(orderId: string, userId: string, rating?: {
        score: number;
        comment?: string;
    }): Promise<any>;
    rejectOrder(orderId: string, userId: string, reason: string): Promise<any>;
    private updateAvatarCompletionStats;
    private createOrderEarnings;
    private notifyOrderResult;
    private notifyAvatarApproval;
    private notifyAvatarRejection;
    getOrderFeedback(orderId: string): Promise<{
        order: any;
        executions: any[] | null;
        posts: any[] | null;
        platformStats: {
            platform: string;
            reach?: number;
            likes?: number;
            comments?: number;
            shares?: number;
            post_url?: string;
            post_id?: string;
        }[];
        summary: {
            totalReach: number;
            totalLikes: number;
            totalComments: number;
            totalShares: number;
        };
    }>;
    private calculatePlatformStats;
    getOrderRating(orderId: string): Promise<any>;
    getAvatarRatingStats(avatarId: string): Promise<{
        averageRating: number;
        totalRatings: number;
        ratingDistribution: Record<number, number>;
    }>;
    getOrderDetailedReport(orderId: string): Promise<{
        order: {
            id: any;
            title: any;
            content_type: any;
            platforms: any;
            status: any;
            created_at: any;
            completed_at: any;
        };
        totalStats: {
            exposure: number;
            likes: number;
            comments: number;
            shares: number;
            views: number;
        };
        avgStats: {
            exposure: number;
            likes: number;
            comments: number;
            shares: number;
            views: number;
            engagementRate: number;
            qualityScore: number;
            customerRating: number;
        };
        avatarStats: {
            avatarId: any;
            avatarName: any;
            platform: any;
            exposure: any;
            likes: any;
            comments: any;
            shares: any;
            views: any;
            engagementRate: number;
            qualityScore: any;
            customerRating: any;
            publishTime: any;
            feedback: any;
        }[];
        platformStats: any[];
        executionStats: any;
        summary: {
            totalAvatars: number;
            totalPlatforms: number;
            totalSteps: number;
            completedSteps: any;
            overallQuality: number;
            overallSatisfaction: number;
            totalEngagement: number;
            totalReach: number;
        };
    }>;
    getAvatarOrderStatistics(avatarId: string, params?: {
        startDate?: string;
        endDate?: string;
    }): Promise<{
        performanceStats: {
            totalExposure: any;
            totalLikes: any;
            totalComments: any;
            totalShares: any;
            totalViews: any;
            avgQualityScore: number;
            avgCustomerRating: number;
        };
        completionRate: number;
        totalOrders: number;
        pendingOrders: number;
        inProgressOrders: number;
        completedOrders: number;
        cancelledOrders: number;
    }>;
    approveAvatarOrder(orderId: string, avatarId: string): Promise<{
        success: boolean;
        rewardAmount: number;
    }>;
    rejectAvatarOrder(orderId: string, avatarId: string, reason: string): Promise<{
        success: boolean;
    }>;
}
