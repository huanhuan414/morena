"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderController = void 0;
const common_1 = require("@nestjs/common");
const order_service_1 = require("./order.service");
const order_dispatch_service_1 = require("../order-dispatch/order-dispatch.service");
let OrderController = class OrderController {
    constructor(orderService, dispatchService) {
        this.orderService = orderService;
        this.dispatchService = dispatchService;
    }
    async create(userId, orderData) {
        console.log('[OrderController] 创建订单，用户ID:', userId, '订单数据:', orderData);
        const order = await this.orderService.createOrder(userId, orderData);
        console.log('[OrderController] 订单创建成功，订单ID:', order.id, '状态:', order.status, '预算:', order.budget);
        return {
            code: 200,
            data: order,
            message: order.status === 'pending_payment' ? '创建成功，请完成支付' : '创建成功'
        };
        return {
            code: 200,
            data: order,
            message: '创建成功'
        };
    }
    async update(orderId, updateData) {
        const order = await this.orderService.updateOrder(orderId, updateData);
        return {
            code: 200,
            data: order,
            message: '更新成功'
        };
    }
    async list(userId, status, avatarId) {
        console.log('[OrderController] list 被调用, userId:', userId, 'status:', status, 'avatarId:', avatarId);
        const orders = await this.orderService.getOrders(userId, status, avatarId);
        return {
            code: 200,
            data: orders,
            message: '获取成功'
        };
    }
    async getOpenOrders(page, pageSize) {
        const result = await this.orderService.getOpenOrders(page ? parseInt(page) : 1, pageSize ? parseInt(pageSize) : 20);
        return {
            code: 200,
            data: result,
            message: '获取成功'
        };
    }
    async stats(userId) {
        console.log('[OrderController] stats 被调用, userId:', userId);
        const stats = await this.orderService.getOrderStats(userId || '');
        return {
            code: 200,
            data: stats,
            message: '获取成功'
        };
    }
    async get(orderId) {
        console.log('[OrderController] get 被调用, orderId:', orderId);
        const order = await this.orderService.getOrderById(orderId);
        return {
            code: 200,
            data: order,
            message: '获取成功'
        };
    }
    async getFeedback(orderId) {
        const feedback = await this.orderService.getOrderFeedback(orderId);
        return {
            code: 200,
            data: feedback,
            message: '获取成功'
        };
    }
    async getRating(orderId) {
        const rating = await this.orderService.getOrderRating(orderId);
        return {
            code: 200,
            data: rating,
            message: '获取成功'
        };
    }
    async getDispatchStatus(orderId) {
        const status = await this.dispatchService.getDispatchStatus(orderId);
        return {
            code: 200,
            data: status,
            message: '获取成功'
        };
    }
    async updateStatus(orderId, status, avatarId) {
        const order = await this.orderService.updateOrderStatus(orderId, status, avatarId);
        return {
            code: 200,
            data: order,
            message: '更新成功'
        };
    }
    async acceptOrder(orderId, avatarId) {
        const order = await this.orderService.acceptOrder(orderId, avatarId);
        return {
            code: 200,
            data: order,
            message: '接单成功'
        };
    }
    async submitResult(orderId, result) {
        const order = await this.orderService.submitOrderResult(orderId, result);
        return {
            code: 200,
            data: order,
            message: '提交成功'
        };
    }
    async submitContent(orderId, avatarId, content) {
        const order = await this.orderService.submitContent(orderId, avatarId, content);
        return {
            code: 200,
            data: order,
            message: '内容提交成功'
        };
    }
    async approveOrder(orderId, userId, rating) {
        const order = await this.orderService.approveOrder(orderId, userId, rating);
        return {
            code: 200,
            data: order,
            message: '验收通过'
        };
    }
    async rejectOrder(orderId, userId, reason) {
        const order = await this.orderService.rejectOrder(orderId, userId, reason);
        return {
            code: 200,
            data: order,
            message: '订单已驳回'
        };
    }
    async approveAvatarOrder(orderId, avatarId) {
        const result = await this.orderService.approveAvatarOrder(orderId, avatarId);
        return {
            code: 200,
            data: result,
            message: '分身验收通过'
        };
    }
    async rejectAvatarOrder(orderId, avatarId, reason) {
        const result = await this.orderService.rejectAvatarOrder(orderId, avatarId, reason);
        return {
            code: 200,
            data: result,
            message: '分身已驳回'
        };
    }
    async cancel(orderId, userId) {
        const order = await this.orderService.cancelOrder(orderId, userId);
        return {
            code: 200,
            data: order,
            message: '取消成功'
        };
    }
    async cancelDispatch(orderId, userId) {
        const result = await this.dispatchService.cancelDispatch(orderId, userId);
        return {
            code: 200,
            data: result,
            message: '分配已取消'
        };
    }
    async delete(orderId, userId) {
        const result = await this.orderService.deleteOrder(orderId, userId);
        return {
            code: 200,
            data: result,
            message: '删除成功'
        };
    }
    async getDetailedReport(orderId) {
        const report = await this.orderService.getOrderDetailedReport(orderId);
        return {
            code: 200,
            data: report,
            message: '获取成功'
        };
    }
    async getAvatarStatistics(avatarId, startDate, endDate) {
        const stats = await this.orderService.getAvatarOrderStatistics(avatarId, {
            startDate,
            endDate
        });
        return {
            code: 200,
            data: stats,
            message: '获取成功'
        };
    }
};
exports.OrderController = OrderController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "update", null);
__decorate([
    (0, common_1.Get)('list'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('status')),
    __param(2, (0, common_1.Query)('avatar_id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('open'),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "getOpenOrders", null);
__decorate([
    (0, common_1.Get)('stats'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "stats", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "get", null);
__decorate([
    (0, common_1.Get)(':id/feedback'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "getFeedback", null);
__decorate([
    (0, common_1.Get)(':id/rating'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "getRating", null);
__decorate([
    (0, common_1.Get)(':id/dispatch-status'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "getDispatchStatus", null);
__decorate([
    (0, common_1.Put)(':id/status'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('status')),
    __param(2, (0, common_1.Body)('avatar_id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Put)(':id/accept'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('avatar_id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "acceptOrder", null);
__decorate([
    (0, common_1.Put)(':id/result'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('result')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "submitResult", null);
__decorate([
    (0, common_1.Put)(':id/content'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('avatar_id')),
    __param(2, (0, common_1.Body)('content')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "submitContent", null);
__decorate([
    (0, common_1.Put)(':id/approve'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __param(2, (0, common_1.Body)('rating')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "approveOrder", null);
__decorate([
    (0, common_1.Put)(':id/reject'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __param(2, (0, common_1.Body)('reason')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "rejectOrder", null);
__decorate([
    (0, common_1.Put)(':id/avatar/:avatarId/approve'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "approveAvatarOrder", null);
__decorate([
    (0, common_1.Put)(':id/avatar/:avatarId/reject'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('avatarId')),
    __param(2, (0, common_1.Body)('reason')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "rejectAvatarOrder", null);
__decorate([
    (0, common_1.Put)(':id/cancel'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "cancel", null);
__decorate([
    (0, common_1.Put)(':id/cancel-dispatch'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "cancelDispatch", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "delete", null);
__decorate([
    (0, common_1.Get)(':id/detailed-report'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "getDetailedReport", null);
__decorate([
    (0, common_1.Get)('avatar/:avatarId/statistics'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "getAvatarStatistics", null);
exports.OrderController = OrderController = __decorate([
    (0, common_1.Controller)('order'),
    __metadata("design:paramtypes", [order_service_1.OrderService,
        order_dispatch_service_1.OrderDispatchService])
], OrderController);
//# sourceMappingURL=order.controller.js.map