import { OrderService } from './order.service';
import { OrderDispatchService } from '../order-dispatch/order-dispatch.service';
export declare class OrderController {
    private readonly orderService;
    private readonly dispatchService;
    constructor(orderService: OrderService, dispatchService: OrderDispatchService);
    create(userId: string, orderData: Record<string, any>): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    update(orderId: string, updateData: Record<string, any>): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    list(userId: string, status?: string, avatarId?: string): Promise<{
        code: number;
        data: any[];
        message: string;
    }>;
    getOpenOrders(page?: string, pageSize?: string): Promise<{
        code: number;
        data: {
            orders: any[];
            total: number;
            page: number;
            pageSize: number;
        };
        message: string;
    }>;
    stats(userId: string): Promise<{
        code: number;
        data: {
            total: number;
            open: number;
            inProgress: number;
            reviewing: number;
            completed: number;
        };
        message: string;
    }>;
    get(orderId: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getFeedback(orderId: string): Promise<{
        code: number;
        data: {
            order: any;
            executions: any[] | null;
            posts: any[] | null;
            platformStats: {
                platform: string;
                reach?: number;
                likes?: number;
                comments?: number;
                shares?: number;
                post_url?: string;
                post_id?: string;
            }[];
            summary: {
                totalReach: number;
                totalLikes: number;
                totalComments: number;
                totalShares: number;
            };
        };
        message: string;
    }>;
    getRating(orderId: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    getDispatchStatus(orderId: string): Promise<{
        code: number;
        data: {
            order: any;
            pendingRequest: any;
            acceptedAvatar: any;
            executions: any[];
            currentStep: any;
        };
        message: string;
    }>;
    updateStatus(orderId: string, status: string, avatarId?: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    acceptOrder(orderId: string, avatarId: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    submitResult(orderId: string, result: Record<string, any>): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    submitContent(orderId: string, avatarId: string, content: {
        title?: string;
        content: string;
        images?: string[];
        videos?: string[];
        platform_results?: Array<{
            platform: string;
            post_id?: string;
            post_url?: string;
            status: string;
        }>;
    }): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    approveOrder(orderId: string, userId: string, rating?: {
        score: number;
        comment?: string;
    }): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    rejectOrder(orderId: string, userId: string, reason: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    approveAvatarOrder(orderId: string, avatarId: string): Promise<{
        code: number;
        data: {
            success: boolean;
            rewardAmount: number;
        };
        message: string;
    }>;
    rejectAvatarOrder(orderId: string, avatarId: string, reason: string): Promise<{
        code: number;
        data: {
            success: boolean;
        };
        message: string;
    }>;
    cancel(orderId: string, userId: string): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    cancelDispatch(orderId: string, userId: string): Promise<{
        code: number;
        data: boolean;
        message: string;
    }>;
    delete(orderId: string, userId: string): Promise<{
        code: number;
        data: {
            success: boolean;
        };
        message: string;
    }>;
    getDetailedReport(orderId: string): Promise<{
        code: number;
        data: {
            order: {
                id: any;
                title: any;
                content_type: any;
                platforms: any;
                status: any;
                created_at: any;
                completed_at: any;
            };
            totalStats: {
                exposure: number;
                likes: number;
                comments: number;
                shares: number;
                views: number;
            };
            avgStats: {
                exposure: number;
                likes: number;
                comments: number;
                shares: number;
                views: number;
                engagementRate: number;
                qualityScore: number;
                customerRating: number;
            };
            avatarStats: {
                avatarId: any;
                avatarName: any;
                platform: any;
                exposure: any;
                likes: any;
                comments: any;
                shares: any;
                views: any;
                engagementRate: number;
                qualityScore: any;
                customerRating: any;
                publishTime: any;
                feedback: any;
            }[];
            platformStats: any[];
            executionStats: any;
            summary: {
                totalAvatars: number;
                totalPlatforms: number;
                totalSteps: number;
                completedSteps: any;
                overallQuality: number;
                overallSatisfaction: number;
                totalEngagement: number;
                totalReach: number;
            };
        };
        message: string;
    }>;
    getAvatarStatistics(avatarId: string, startDate?: string, endDate?: string): Promise<{
        code: number;
        data: {
            performanceStats: {
                totalExposure: any;
                totalLikes: any;
                totalComments: any;
                totalShares: any;
                totalViews: any;
                avgQualityScore: number;
                avgCustomerRating: number;
            };
            completionRate: number;
            totalOrders: number;
            pendingOrders: number;
            inProgressOrders: number;
            completedOrders: number;
            cancelledOrders: number;
        };
        message: string;
    }>;
}
