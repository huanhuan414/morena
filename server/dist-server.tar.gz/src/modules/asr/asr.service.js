"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AsrService = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
let AsrService = class AsrService {
    async recognizeAudio(audioUrl) {
        try {
            console.log('[ASR] 开始识别音频:', { audioUrl });
            const config = new coze_coding_dev_sdk_1.Config();
            const asrClient = new coze_coding_dev_sdk_1.ASRClient(config);
            const result = await asrClient.recognize({
                uid: 'user_' + Date.now(),
                url: audioUrl
            });
            console.log('[ASR] 识别结果:', {
                text: result.text,
                duration: result.duration
            });
            return {
                text: result.text || '',
                duration: result.duration
            };
        }
        catch (error) {
            console.error('[ASR] 识别失败:', error);
            throw new common_1.HttpException(error.message || '语音识别失败', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.AsrService = AsrService;
exports.AsrService = AsrService = __decorate([
    (0, common_1.Injectable)()
], AsrService);
//# sourceMappingURL=asr.service.js.map