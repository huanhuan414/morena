import { Request } from 'express';
declare class AsrRequestDto {
    audioUrl: string;
    uid?: string;
}
declare class AsrResponseDto {
    code: number;
    msg: string;
    data?: {
        text: string;
        duration?: number;
    };
}
export declare class AsrController {
    recognize(body: AsrRequestDto, req: Request): Promise<AsrResponseDto>;
}
export {};
