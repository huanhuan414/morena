export declare class AsrModule {
}
