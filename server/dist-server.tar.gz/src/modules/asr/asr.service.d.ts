export declare class AsrService {
    recognizeAudio(audioUrl: string): Promise<{
        text: string;
        duration?: number;
    }>;
}
