export declare class StorageService {
    private storage;
    private volcengineService;
    private readonly logger;
    constructor();
    uploadFile(fileContent: Buffer, fileName: string, contentType: string): Promise<string>;
    uploadImage(file: Express.Multer.File): Promise<string>;
    uploadImageFromBuffer(imageBuffer: Buffer, fileName: string): Promise<string>;
    uploadVideo(videoBuffer: Buffer, fileName: string): Promise<string>;
    uploadAudio(audioBuffer: Buffer, fileName: string): Promise<string>;
    uploadFromUrl(url: string): Promise<string>;
    getFileUrl(key: string, expireTime?: number): Promise<string>;
    deleteFile(key: string): Promise<boolean>;
    fileExists(key: string): Promise<boolean>;
    listFiles(prefix?: string, maxKeys?: number): Promise<import("coze-coding-dev-sdk").ListFilesResult>;
    uploadBase64Image(base64Data: string, fileName: string): Promise<string>;
    batchGetFileUrls(keys: string[], expireTime?: number): Promise<Record<string, string>>;
}
