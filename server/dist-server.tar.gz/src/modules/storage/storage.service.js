"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var StorageService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.StorageService = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const volcengine_service_1 = require("../upload/volcengine.service");
let StorageService = StorageService_1 = class StorageService {
    constructor() {
        this.logger = new common_1.Logger(StorageService_1.name);
        this.storage = new coze_coding_dev_sdk_1.S3Storage({
            endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL || 'https://tos-cn-guangzhou.volces.com',
            accessKey: process.env.VOLC_ACCESS_KEY || '',
            secretKey: process.env.VOLC_SECRET_KEY || '',
            bucketName: process.env.COZE_BUCKET_NAME || 'morena-ai',
            region: 'cn-guangzhou',
        });
        this.volcengineService = new volcengine_service_1.VolcengineService();
    }
    async uploadFile(fileContent, fileName, contentType) {
        const key = await this.storage.uploadFile({
            fileContent,
            fileName: `uploads/${fileName}`,
            contentType
        });
        return key;
    }
    async uploadImage(file) {
        try {
            const result = await this.volcengineService.uploadImage(file);
            this.logger.log(`[StorageService] 使用 veImageX 上传图片成功: ${result.url}`);
            return result.url;
        }
        catch (error) {
            this.logger.warn('[StorageService] veImageX 上传失败，降级到对象存储:', error);
            const key = await this.storage.uploadFile({
                fileContent: file.buffer,
                fileName: `images/${Date.now()}_${file.originalname}`,
                contentType: file.mimetype || 'image/jpeg'
            });
            return await this.storage.generatePresignedUrl({ key, expireTime: 86400 * 30 });
        }
    }
    async uploadImageFromBuffer(imageBuffer, fileName) {
        const file = {
            buffer: imageBuffer,
            originalname: fileName,
            mimetype: fileName.endsWith('.png') ? 'image/png' : 'image/jpeg',
            size: imageBuffer.length,
            fieldname: 'file',
            encoding: '7bit',
            stream: null,
            destination: '',
            filename: fileName,
            path: ''
        };
        return this.uploadImage(file);
    }
    async uploadVideo(videoBuffer, fileName) {
        this.logger.log(`[StorageService] 上传视频到对象存储: ${fileName}, 大小: ${videoBuffer.length} bytes`);
        try {
            this.logger.log(`[StorageService] 开始上传文件到 TOS...`);
            this.logger.log(`[StorageService] endpoint: ${process.env.COZE_BUCKET_ENDPOINT_URL || 'https://tos-cn-guangzhou.volces.com'}`);
            this.logger.log(`[StorageService] bucket: ${process.env.COZE_BUCKET_NAME || 'morena-ai'}`);
            const key = await this.storage.uploadFile({
                fileContent: videoBuffer,
                fileName: `videos/${fileName}`,
                contentType: 'video/mp4'
            });
            this.logger.log(`[StorageService] 文件上传成功, key: ${key}`);
            this.logger.log(`[StorageService] 开始生成预签名URL...`);
            const url = await this.storage.generatePresignedUrl({ key, expireTime: 86400 * 30 });
            this.logger.log(`[StorageService] 视频上传成功: ${url.substring(0, 80)}...`);
            return url;
        }
        catch (error) {
            this.logger.error('[StorageService] 视频上传失败:', error);
            this.logger.error('[StorageService] 错误详情:', error.message);
            if (error.$response) {
                this.logger.error('[StorageService] 原始响应:', error.$response);
            }
            throw new Error(`视频上传到CDN失败: ${error.message}`);
        }
    }
    async uploadAudio(audioBuffer, fileName) {
        this.logger.log(`[StorageService] 上传音频到对象存储: ${fileName}`);
        try {
            const key = await this.storage.uploadFile({
                fileContent: audioBuffer,
                fileName: `audio/${fileName}`,
                contentType: 'audio/mp3'
            });
            const url = await this.storage.generatePresignedUrl({ key, expireTime: 86400 * 30 });
            this.logger.log(`[StorageService] 音频上传成功: ${url}`);
            return url;
        }
        catch (error) {
            this.logger.error('[StorageService] 音频上传失败:', error);
            throw error;
        }
    }
    async uploadFromUrl(url) {
        const key = await this.storage.uploadFromUrl({ url });
        return key;
    }
    async getFileUrl(key, expireTime = 86400) {
        return this.storage.generatePresignedUrl({ key, expireTime });
    }
    async deleteFile(key) {
        return this.storage.deleteFile({ fileKey: key });
    }
    async fileExists(key) {
        return this.storage.fileExists({ fileKey: key });
    }
    async listFiles(prefix, maxKeys = 100) {
        return this.storage.listFiles({ prefix, maxKeys });
    }
    async uploadBase64Image(base64Data, fileName) {
        const base64String = base64Data.replace(/^data:image\/\w+;base64,/, '');
        const buffer = Buffer.from(base64String, 'base64');
        return this.uploadImageFromBuffer(buffer, fileName);
    }
    async batchGetFileUrls(keys, expireTime = 86400) {
        const urls = {};
        for (const key of keys) {
            urls[key] = await this.getFileUrl(key, expireTime);
        }
        return urls;
    }
};
exports.StorageService = StorageService;
exports.StorageService = StorageService = StorageService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], StorageService);
//# sourceMappingURL=storage.service.js.map