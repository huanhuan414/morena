"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const common_1 = require("@nestjs/common");
const auth_service_1 = require("./auth.service");
let AuthController = class AuthController {
    constructor(authService) {
        this.authService = authService;
    }
    async sendCode(phone) {
        const result = await this.authService.sendVerificationCode(phone);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message,
        };
    }
    async phoneLogin(phone, code, nickname, referralCode) {
        const result = await this.authService.phoneLogin(phone, code, nickname, referralCode);
        return {
            code: 200,
            data: result,
            message: result.isNewUser ? '注册成功' : '登录成功',
        };
    }
    async wechatLogin(code) {
        const result = await this.authService.wechatLogin(code);
        return {
            code: 200,
            data: result,
            message: '登录成功',
        };
    }
    async getCurrentUser(authorization) {
        const token = authorization?.replace('Bearer ', '');
        if (!token) {
            return {
                code: 401,
                data: null,
                message: '未登录',
            };
        }
        try {
            const decoded = Buffer.from(token, 'base64').toString();
            const [userId] = decoded.split(':');
            const user = await this.authService.getUserById(userId);
            return {
                code: 200,
                data: user,
                message: '获取成功',
            };
        }
        catch (error) {
            return {
                code: 401,
                data: null,
                message: 'token 无效',
            };
        }
    }
};
exports.AuthController = AuthController;
__decorate([
    (0, common_1.Post)('send-code'),
    __param(0, (0, common_1.Body)('phone')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "sendCode", null);
__decorate([
    (0, common_1.Post)('phone-login'),
    __param(0, (0, common_1.Body)('phone')),
    __param(1, (0, common_1.Body)('code')),
    __param(2, (0, common_1.Body)('nickname')),
    __param(3, (0, common_1.Body)('referral_code')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "phoneLogin", null);
__decorate([
    (0, common_1.Post)('wechat-login'),
    __param(0, (0, common_1.Body)('code')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "wechatLogin", null);
__decorate([
    (0, common_1.Get)('me'),
    __param(0, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "getCurrentUser", null);
exports.AuthController = AuthController = __decorate([
    (0, common_1.Controller)('auth'),
    __metadata("design:paramtypes", [auth_service_1.AuthService])
], AuthController);
//# sourceMappingURL=auth.controller.js.map