import { SmsService } from './sms.service';
export declare class AuthService {
    private readonly smsService;
    private codeCache;
    constructor(smsService: SmsService);
    sendVerificationCode(phone: string): Promise<{
        success: boolean;
        message: string;
    }>;
    phoneLogin(phone: string, code: string, nickname?: string, referralCode?: string): Promise<{
        user: any;
        isNewUser: boolean;
        token: string;
        referralReward?: number;
    }>;
    private processReferral;
    wechatLogin(code: string): Promise<{
        user: any;
        isNewUser: boolean;
        token: string;
    }>;
    private createOrGetUser;
    private generateToken;
    getUserById(userId: string): Promise<any[]>;
}
