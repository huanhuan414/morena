"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const sms_service_1 = require("./sms.service");
let AuthService = class AuthService {
    constructor(smsService) {
        this.smsService = smsService;
        this.codeCache = new Map();
    }
    async sendVerificationCode(phone) {
        if (!/^1[3-9]\d{9}$/.test(phone)) {
            throw new common_1.BadRequestException('请输入正确的手机号');
        }
        const cached = this.codeCache.get(phone);
        if (cached && cached.expiresAt > Date.now() + 4 * 60 * 1000) {
            const remainingTime = Math.ceil((cached.expiresAt - 4 * 60 * 1000 - Date.now()) / 1000);
            if (remainingTime > 0) {
                throw new common_1.BadRequestException(`${remainingTime}秒后可重新发送`);
            }
        }
        const code = this.smsService.generateCode();
        this.codeCache.set(phone, {
            code,
            expiresAt: Date.now() + 5 * 60 * 1000,
        });
        const result = await this.smsService.sendVerificationCode(phone, code);
        console.log(`[验证码] 手机号: ${phone}, 验证码: ${code}`);
        return result;
    }
    async phoneLogin(phone, code, nickname, referralCode) {
        if (!/^1[3-9]\d{9}$/.test(phone)) {
            throw new common_1.BadRequestException('请输入正确的手机号');
        }
        const cached = this.codeCache.get(phone);
        if (!cached) {
            throw new common_1.BadRequestException('请先获取验证码');
        }
        if (cached.expiresAt < Date.now()) {
            this.codeCache.delete(phone);
            throw new common_1.BadRequestException('验证码已过期，请重新获取');
        }
        if (cached.code !== code) {
            throw new common_1.BadRequestException('验证码错误');
        }
        this.codeCache.delete(phone);
        const users = (0, mysql_client_1.usersTable)();
        const { data: existingUser, error: findError } = await users.where({ phone });
        if (findError) {
            throw new Error(`查询用户失败: ${findError.message}`);
        }
        if (existingUser && existingUser.length > 0) {
            return {
                user: existingUser[0],
                isNewUser: false,
                token: this.generateToken(existingUser[0].id),
            };
        }
        const newUserData = {
            id: undefined,
            phone,
            openid: `phone_${phone}`,
            nickname: nickname || `用户${phone.slice(-4)}`,
            avatar: '',
            level: 1,
            exp: 0,
            credits: 100,
        };
        const { data: newUser, error: createError } = await users.insert(newUserData);
        if (createError) {
            throw new Error(`创建用户失败: ${createError.message}`);
        }
        if (!newUser) {
            throw new Error('创建用户失败：未返回用户数据');
        }
        let referralReward = 0;
        if (referralCode && newUser) {
            try {
                const referralResult = await this.processReferral(newUser.id, referralCode);
                referralReward = referralResult.reward;
            }
            catch (error) {
                console.error('[AuthService] 处理邀请码失败:', error.message);
            }
        }
        return {
            user: newUser,
            isNewUser: true,
            token: this.generateToken(newUser.id),
            referralReward
        };
    }
    async processReferral(inviteeId, referralCode) {
        const users = (0, mysql_client_1.usersTable)();
        const { data: inviter } = await users.where({ referralCode });
        if (!inviter || inviter.length === 0) {
            throw new Error('邀请码无效');
        }
        const inviterData = inviter[0];
        if (inviterData.id === inviteeId) {
            throw new Error('不能使用自己的邀请码');
        }
        await users.update(inviteeId, { invitedBy: inviterData.id });
        const REWARD_AMOUNT = 10;
        const REWARD_CREDITS = 50;
        const earnings = (0, mysql_client_1.earningsTable)();
        await earnings.insert({
            userId: inviterData.id,
            type: 'referral_bonus',
            amount: REWARD_AMOUNT,
            description: `邀请新用户奖励`,
            status: 'settled'
        });
        const currentBalance = parseFloat(inviterData.balance || '0');
        const currentTotalEarnings = parseFloat(inviterData.totalEarnings || '0');
        const currentCredits = parseInt(inviterData.credits || '0');
        await users.update(inviterData.id, {
            balance: currentBalance + REWARD_AMOUNT,
            totalEarnings: currentTotalEarnings + REWARD_AMOUNT,
            credits: currentCredits + REWARD_CREDITS
        });
        console.log(`[AuthService] 邀请奖励发放成功: 邀请人=${inviterData.id}, 被邀请人=${inviteeId}, 奖励金额=${REWARD_AMOUNT}, 积分=${REWARD_CREDITS}`);
        return {
            inviterId: inviterData.id,
            reward: REWARD_AMOUNT
        };
    }
    async wechatLogin(code) {
        const wxAppId = process.env.WX_APP_ID;
        const wxSecret = process.env.WX_APP_SECRET;
        if (!wxAppId || !wxSecret) {
            console.log('开发环境：模拟微信登录');
            const mockOpenid = `dev_${Date.now()}`;
            return this.createOrGetUser(mockOpenid, '模拟用户', undefined);
        }
        try {
            const response = await fetch(`https://api.weixin.qq.com/sns/jscode2session?appid=${wxAppId}&secret=${wxSecret}&js_code=${code}&grant_type=authorization_code`);
            const data = await response.json();
            if (data.errcode) {
                throw new common_1.UnauthorizedException(`微信登录失败: ${data.errmsg}`);
            }
            return this.createOrGetUser(data.openid, '微信用户', undefined);
        }
        catch (error) {
            console.error('微信登录错误:', error);
            throw new common_1.UnauthorizedException('登录失败，请重试');
        }
    }
    async createOrGetUser(openid, nickname, avatar) {
        const users = (0, mysql_client_1.usersTable)();
        const { data: existingUser, error: findError } = await users.where({ openid });
        if (findError) {
            throw new Error(`查询用户失败: ${findError.message}`);
        }
        if (existingUser && existingUser.length > 0) {
            return {
                user: existingUser[0],
                isNewUser: false,
                token: this.generateToken(existingUser[0].id)
            };
        }
        const newUserData = {
            openid,
            nickname: nickname || '莫瑞娜用户',
            avatar: avatar || '',
            level: 1,
            exp: 0,
            credits: 100
        };
        const { data: newUser, error: createError } = await users.insert(newUserData);
        if (createError) {
            throw new Error(`创建用户失败: ${createError.message}`);
        }
        if (!newUser) {
            throw new Error('创建用户失败：未返回用户数据');
        }
        return {
            user: newUser,
            isNewUser: true,
            token: this.generateToken(newUser.id)
        };
    }
    generateToken(userId) {
        return Buffer.from(`${userId}:${Date.now()}`).toString('base64');
    }
    async getUserById(userId) {
        const users = (0, mysql_client_1.usersTable)();
        const { data, error } = await users.findById(userId);
        if (error) {
            throw new Error(`获取用户失败: ${error.message}`);
        }
        if (!data) {
            throw new Error('用户不存在');
        }
        return data;
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [sms_service_1.SmsService])
], AuthService);
//# sourceMappingURL=auth.service.js.map