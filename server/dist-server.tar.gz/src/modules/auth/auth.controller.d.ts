import { AuthService } from './auth.service';
export declare class AuthController {
    private readonly authService;
    constructor(authService: AuthService);
    sendCode(phone: string): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    phoneLogin(phone: string, code: string, nickname?: string, referralCode?: string): Promise<{
        code: number;
        data: {
            user: any;
            isNewUser: boolean;
            token: string;
            referralReward?: number;
        };
        message: string;
    }>;
    wechatLogin(code: string): Promise<{
        code: number;
        data: {
            user: any;
            isNewUser: boolean;
            token: string;
        };
        message: string;
    }>;
    getCurrentUser(authorization: string): Promise<{
        code: number;
        data: null;
        message: string;
    } | {
        code: number;
        data: any[];
        message: string;
    }>;
}
