export declare class SmsService {
    private accessKeyId;
    private accessKeySecret;
    private signName;
    private templateCode;
    sendVerificationCode(phone: string, code: string): Promise<{
        success: boolean;
        message: string;
    }>;
    private percentEncode;
    generateCode(): string;
}
