"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SkillsService = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const supabase_client_1 = require("../../storage/database/supabase-client");
let SkillsService = class SkillsService {
    constructor() {
        const config = new coze_coding_dev_sdk_1.Config();
        this.llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
        this.initializeEssentialSkills();
    }
    async initializeEssentialSkills() {
        try {
            const { data: existingOrderSkill } = await (0, supabase_client_1.getSupabaseClient)()
                .from('skills')
                .select('id')
                .eq('tool_name', 'app_assign_order')
                .single();
            if (!existingOrderSkill) {
                console.log('[SkillsService] 初始化 app_assign_order 技能...');
                await (0, supabase_client_1.getSupabaseClient)()
                    .from('skills')
                    .insert({
                    name: '分配订单/找分身',
                    description: '根据订单需求智能匹配合适的分身。系统会根据分身的能力、等级、优先级等因素自动选择最合适的分身，并创建订单执行记录。分身完成后可获得奖励。',
                    category: '订单管理',
                    price: 0,
                    icon: '📋',
                    tags: ['订单', '分配', '匹配', '任务'],
                    capabilities: {
                        features: ['智能匹配', '多选分身', '订单追踪', '自动分配'],
                        matchCriteria: ['等级', '优先级', '能力'],
                        maxAssignCount: 50
                    },
                    requirements: '无',
                    status: 'active',
                    rating: 5.0,
                    rating_count: 100,
                    purchase_count: 50,
                    tool_name: 'app_assign_order',
                    type: 'prebuilt'
                });
                console.log('[SkillsService] app_assign_order 技能初始化成功');
            }
            const { data: existingPostSkill } = await (0, supabase_client_1.getSupabaseClient)()
                .from('skills')
                .select('id')
                .eq('tool_name', 'auto_post_to_home')
                .single();
            if (!existingPostSkill) {
                console.log('[SkillsService] 初始化 auto_post_to_home 技能...');
                await (0, supabase_client_1.getSupabaseClient)()
                    .from('skills')
                    .insert({
                    name: '自动发帖助手',
                    description: '让分身自动在首页发布动态帖子。系统会根据分身的等级、订阅情况智能分配发帖配额，支持纯文字、图文、视频多种格式。等级越高、订阅越好，发帖权限越大。',
                    category: '内容创作',
                    price: 0,
                    icon: '📝',
                    tags: ['自动发帖', '内容创作', '社交', '首页'],
                    capabilities: {
                        features: ['自动发帖', '智能配额', '多格式支持', '等级权益'],
                        postTypes: ['纯文字', '图文', '视频'],
                        quotaRules: {
                            free: { textOnly: 1, imageText: 0, video: 0 },
                            basic: { textOnly: 2, imageText: 1, video: 0 },
                            premium: { textOnly: 3, imageText: 3, video: 2 }
                        },
                        levelBonus: '每升1级增加1条图文配额'
                    },
                    requirements: '分身等级≥1，需开启托管模式',
                    status: 'active',
                    rating: 4.8,
                    rating_count: 88,
                    purchase_count: 256,
                    tool_name: 'auto_post_to_home',
                    type: 'prebuilt'
                });
                console.log('[SkillsService] auto_post_to_home 技能初始化成功');
            }
        }
        catch (error) {
            console.error('[SkillsService] 初始化必要技能失败:', error);
        }
    }
    async getSkills(filter, page = 1, pageSize = 20) {
        try {
            let query = (0, supabase_client_1.getSupabaseClient)()
                .from('skills')
                .select('*', { count: 'exact' })
                .eq('status', 'active');
            if (filter) {
                if (filter.type) {
                    query = query.eq('type', filter.type);
                }
                if (filter.category) {
                    query = query.eq('category', filter.category);
                }
                if (filter.minPrice !== undefined) {
                    query = query.gte('price', filter.minPrice);
                }
                if (filter.maxPrice !== undefined) {
                    query = query.lte('price', filter.maxPrice);
                }
                if (filter.minRating !== undefined) {
                    query = query.gte('rating', filter.minRating);
                }
                if (filter.tags && filter.tags.length > 0) {
                    query = query.overlaps('tags', filter.tags);
                }
                if (filter.search) {
                    query = query.or(`name.ilike.%${filter.search}%,description.ilike.%${filter.search}%`);
                }
            }
            const from = (page - 1) * pageSize;
            const to = from + pageSize - 1;
            query = query.range(from, to).order('created_at', { ascending: false });
            const { data, error, count } = await query;
            if (error) {
                throw new Error(`获取技能列表失败: ${error.message}`);
            }
            return {
                skills: data || [],
                total: count || 0,
                page,
                pageSize,
                totalPages: Math.ceil((count || 0) / pageSize)
            };
        }
        catch (error) {
            console.error('[SkillsService] getSkills error:', error);
            throw error;
        }
    }
    async getSkillById(skillId) {
        try {
            const { data, error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('skills')
                .select('*')
                .eq('id', skillId)
                .single();
            if (error || !data) {
                throw new Error('技能不存在');
            }
            return data;
        }
        catch (error) {
            console.error('[SkillsService] getSkillById error:', error);
            throw error;
        }
    }
    async createSkill(userId, dto) {
        try {
            const { data, error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('skills')
                .insert({
                name: dto.name,
                description: dto.description,
                type: dto.type,
                toolName: dto.toolName,
                price: dto.price || 0,
                creatorId: userId,
                category: dto.category,
                icon: dto.icon,
                tags: dto.tags || [],
                capabilities: dto.capabilities || {},
                requirements: dto.requirements,
                status: 'active'
            })
                .select()
                .single();
            if (error || !data) {
                throw new Error(`创建技能失败: ${error?.message || '未知错误'}`);
            }
            return data;
        }
        catch (error) {
            console.error('[SkillsService] createSkill error:', error);
            throw error;
        }
    }
    async purchaseSkill(userId, dto) {
        try {
            const skill = await this.getSkillById(dto.skillId);
            const skillToolName = skill.tool_name || skill.toolName || 'custom';
            console.log('[SkillsService] purchaseSkill - 技能信息:', {
                skillId: dto.skillId,
                skillName: skill.name,
                tool_name: skill.tool_name,
                toolName: skill.toolName,
                skillToolName
            });
            const { data: existing, error: checkError } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_skills')
                .select('*')
                .eq('avatar_id', dto.avatarId)
                .eq('skill_type', skillToolName)
                .maybeSingle();
            console.log('[SkillsService] purchaseSkill - 检查技能是否存在:', {
                avatarId: dto.avatarId,
                skillType: skillToolName,
                skillId: dto.skillId,
                existing: existing,
                checkError: checkError
            });
            if (existing) {
                console.log('[SkillsService] 技能已存在，更新 metadata');
                const { data: updated, error: updateError } = await (0, supabase_client_1.getSupabaseClient)()
                    .from('avatar_skills')
                    .update({
                    metadata: {
                        ...existing.metadata,
                        skill_id: dto.skillId,
                        skill_name: skill.name,
                        purchase_price: skill.price,
                        updated_at: new Date().toISOString()
                    }
                })
                    .eq('id', existing.id)
                    .select()
                    .single();
                if (updateError) {
                    console.error('[SkillsService] 更新技能失败:', updateError);
                    throw new Error(`更新技能失败: ${updateError.message}`);
                }
                if (!updated) {
                    throw new Error('更新技能失败：未返回数据');
                }
                console.log('[SkillsService] 技能更新成功:', updated);
                return updated;
            }
            console.log('[SkillsService] 技能不存在，准备插入新记录');
            if (skill.price > 0) {
                const { data: user } = await (0, supabase_client_1.getSupabaseClient)()
                    .from('users')
                    .select('balance')
                    .eq('id', userId)
                    .single();
                if (!user || user.balance < skill.price) {
                    throw new Error('余额不足，请先充值');
                }
                await (0, supabase_client_1.getSupabaseClient)()
                    .from('users')
                    .update({ balance: user.balance - skill.price })
                    .eq('id', userId);
            }
            const { data: avatarSkill, error: insertError } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_skills')
                .insert({
                id: crypto.randomUUID(),
                avatar_id: dto.avatarId,
                skill_type: skillToolName,
                skill_level: 1,
                usage_count: 0,
                metadata: {
                    skill_id: dto.skillId,
                    skill_name: skill.name,
                    purchase_price: skill.price,
                    purchased_at: new Date().toISOString()
                }
            })
                .select()
                .single();
            if (insertError || !avatarSkill) {
                throw new Error(`购买技能失败: ${insertError?.message || '未知错误'}`);
            }
            console.log('[SkillsService] 技能插入成功:', avatarSkill);
            await (0, supabase_client_1.getSupabaseClient)()
                .from('skills')
                .update({ purchase_count: (skill.purchaseCount || 0) + 1 })
                .eq('id', dto.skillId);
            return avatarSkill;
        }
        catch (error) {
            console.error('[SkillsService] purchaseSkill error:', error);
            throw error;
        }
    }
    async getAvatarSkills(avatarId) {
        try {
            const { data, error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_skills')
                .select('*')
                .eq('avatar_id', avatarId)
                .order('created_at', { ascending: false });
            if (error) {
                throw new Error(`获取分身技能失败: ${error.message}`);
            }
            console.log('[SkillsService] getAvatarSkills - 原始数据:', data);
            console.log('[SkillsService] getAvatarSkills - 数据长度:', data?.length);
            if (data && data.length > 0) {
                data.forEach((item, index) => {
                    console.log(`[SkillsService] avatar_skills[${index}]:`, {
                        id: item.id,
                        avatar_id: item.avatar_id,
                        skill_type: item.skill_type,
                        metadata: item.metadata,
                        全部字段: Object.keys(item)
                    });
                });
            }
            const result = [];
            for (const item of data || []) {
                const skillType = item.skill_type;
                console.log('[SkillsService] 查询技能，skill_type:', skillType);
                let query = (0, supabase_client_1.getSupabaseClient)()
                    .from('skills')
                    .select('id, name, tool_name, category');
                if (skillType === 'generate_image' || skillType === 'generate_video' || skillType === 'write_article') {
                    query = query.eq('tool_name', skillType).eq('category', '内容创作');
                }
                else {
                    query = query.eq('tool_name', skillType);
                }
                const { data: skillData, error: skillError } = await query.limit(1).single();
                if (skillError) {
                    console.warn(`[SkillsService] 未找到技能，skill_type: ${skillType}, error:`, skillError);
                    continue;
                }
                result.push({
                    ...item,
                    skillId: skillData.id
                });
                console.log('[SkillsService] 找到技能匹配:', {
                    skill_type: skillType,
                    skill_id: skillData.id,
                    skill_name: skillData.name,
                    skill_category: skillData.category
                });
            }
            console.log('[SkillsService] getAvatarSkills - 返回数据:', result);
            return result;
        }
        catch (error) {
            console.error('[SkillsService] getAvatarSkills error:', error);
            throw error;
        }
    }
    async addReview(userId, skillId, rating, comment) {
        try {
            const { data: existing } = await (0, supabase_client_1.getSupabaseClient)()
                .from('skill_reviews')
                .select('*')
                .eq('user_id', userId)
                .eq('skill_id', skillId)
                .single();
            if (existing) {
                throw new Error('您已评价过此技能');
            }
            const { data: review, error: insertError } = await (0, supabase_client_1.getSupabaseClient)()
                .from('skill_reviews')
                .insert({
                userId,
                skillId,
                rating,
                comment
            })
                .select()
                .single();
            if (insertError || !review) {
                throw new Error(`添加评价失败: ${insertError?.message || '未知错误'}`);
            }
            const { data: allReviews } = await (0, supabase_client_1.getSupabaseClient)()
                .from('skill_reviews')
                .select('rating')
                .eq('skill_id', skillId);
            if (allReviews && allReviews.length > 0) {
                const avgRating = allReviews.reduce((sum, r) => sum + r.rating, 0) / allReviews.length;
                await (0, supabase_client_1.getSupabaseClient)()
                    .from('skills')
                    .update({
                    rating: parseFloat(avgRating.toFixed(2)),
                    ratingCount: allReviews.length
                })
                    .eq('id', skillId);
            }
            return review;
        }
        catch (error) {
            console.error('[SkillsService] addReview error:', error);
            throw error;
        }
    }
    async getSkillReviews(skillId, page = 1, pageSize = 10) {
        try {
            const from = (page - 1) * pageSize;
            const to = from + pageSize - 1;
            const { data, error, count } = await (0, supabase_client_1.getSupabaseClient)()
                .from('skill_reviews')
                .select(`
          *,
          user:users(id, nickname, avatar_url)
        `, { count: 'exact' })
                .eq('skill_id', skillId)
                .range(from, to)
                .order('created_at', { ascending: false });
            if (error) {
                throw new Error(`获取评价列表失败: ${error.message}`);
            }
            return {
                reviews: data || [],
                total: count || 0,
                page,
                pageSize
            };
        }
        catch (error) {
            console.error('[SkillsService] getSkillReviews error:', error);
            throw error;
        }
    }
    async getCategories() {
        try {
            const { data } = await (0, supabase_client_1.getSupabaseClient)()
                .from('skills')
                .select('category')
                .not('category', 'is', null)
                .order('category');
            const categories = [...new Set(data?.map(s => s.category).filter(Boolean))];
            return categories || [];
        }
        catch (error) {
            console.error('[SkillsService] getCategories error:', error);
            return [];
        }
    }
    async searchSkills(keyword, limit = 10) {
        try {
            const { data, error } = await (0, supabase_client_1.getSupabaseClient)()
                .from('skills')
                .select('*')
                .eq('status', 'active')
                .or(`name.ilike.%${keyword}%,description.ilike.%${keyword}%`)
                .limit(limit);
            if (error) {
                throw new Error(`搜索技能失败: ${error.message}`);
            }
            return data || [];
        }
        catch (error) {
            console.error('[SkillsService] searchSkills error:', error);
            return [];
        }
    }
    async generateSkillWithAI(prompt) {
        try {
            const systemPrompt = `你是一个专业的技能设计专家，擅长从用户描述中提取关键信息，生成详细的技能描述和标签。

用户会提供一个简短的需求描述，你需要：
1. 生成一个专业的技能名称（8-20字）
2. 生成详细的技能描述（50-100字）
3. 识别技能所属分类（从以下分类中选择：内容创作、平台发布、平台管理、社交互动、订阅管理、图像生成、视频生成、文本分析、语音识别）
4. 生成3-5个相关标签
5. 描述技能的核心能力（JSON格式）
6. 说明使用要求（如果没有，填"无"）`;
            const userPrompt = `用户需求描述：
${prompt}

请以 JSON 格式返回以下信息：
{
  "name": "优化后的技能名称",
  "description": "优化后的详细描述（50-100字）",
  "category": "技能分类（从以下选择：内容创作、平台发布、平台管理、社交互动、订阅管理、图像生成、视频生成、文本分析、语音识别）",
  "tags": ["标签1", "标签2", "标签3"],
  "capabilities": {
    "功能描述": "这个技能的主要功能"
  },
  "requirements": "使用要求（如需要特定配置）",
  "icon": "推荐一个emoji图标"
}

直接返回 JSON，不要有任何额外文字说明。`;
            const response = await this.llmClient.invoke([
                {
                    role: 'system',
                    content: systemPrompt
                },
                {
                    role: 'user',
                    content: userPrompt
                }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.7
            });
            const content = response.content || '';
            const jsonMatch = content.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                const generatedData = JSON.parse(jsonMatch[0]);
                const toolNameMap = {
                    '内容创作': 'write_article',
                    '平台发布': 'publish_content',
                    '平台管理': 'manage_platform',
                    '社交互动': 'social_interaction',
                    '订阅管理': 'manage_subscription',
                    '图像生成': 'generate_image',
                    '视频生成': 'generate_video',
                    '文本分析': 'analyze_text',
                    '语音识别': 'recognize_speech'
                };
                return {
                    name: generatedData.name || '未命名技能',
                    description: generatedData.description || prompt,
                    category: generatedData.category || '内容创作',
                    tags: generatedData.tags || [],
                    capabilities: generatedData.capabilities || {},
                    requirements: generatedData.requirements || '无',
                    icon: generatedData.icon || '🎯',
                    tool_name: toolNameMap[generatedData.category] || 'custom'
                };
            }
            return {
                name: '自定义技能',
                description: prompt,
                category: '内容创作',
                tags: [],
                capabilities: {},
                requirements: '无',
                icon: '🎯',
                tool_name: 'custom'
            };
        }
        catch (error) {
            console.error('[SkillsService] AI 生成失败:', error);
            return {
                name: '自定义技能',
                description: prompt,
                category: '内容创作',
                tags: [],
                capabilities: {},
                requirements: '无',
                icon: '🎯',
                tool_name: 'custom'
            };
        }
    }
    async purchaseSkillByToolName(userId, toolName, avatarId) {
        try {
            console.log('[SkillsService] purchaseSkillByToolName - 开始:', {
                userId,
                toolName,
                avatarId
            });
            const { data: skill, error: skillError } = await (0, supabase_client_1.getSupabaseClient)()
                .from('skills')
                .select('*')
                .eq('tool_name', toolName)
                .maybeSingle();
            if (skillError) {
                console.error('[SkillsService] purchaseSkillByToolName - 查询技能失败:', skillError);
                throw new Error(`查询技能失败: ${skillError.message}`);
            }
            if (!skill) {
                console.warn('[SkillsService] purchaseSkillByToolName - 未找到技能:', toolName);
                throw new Error(`未找到技能: ${toolName}`);
            }
            console.log('[SkillsService] purchaseSkillByToolName - 查询到技能:', {
                skillId: skill.id,
                skillName: skill.name,
                tool_name: skill.tool_name
            });
            const { data: existing, error: checkError } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_skills')
                .select('*')
                .eq('avatar_id', avatarId)
                .eq('skill_type', toolName)
                .maybeSingle();
            if (checkError && checkError.code !== 'PGRST116') {
                console.error('[SkillsService] purchaseSkillByToolName - 检查技能失败:', checkError);
                throw new Error(`检查技能失败: ${checkError.message}`);
            }
            if (existing) {
                console.log('[SkillsService] purchaseSkillByToolName - 技能已存在，返回现有记录');
                return existing;
            }
            const { data: newAvatarSkill, error: insertError } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_skills')
                .insert({
                avatar_id: avatarId,
                skill_type: toolName,
                skill_level: 1,
                usage_count: 0,
                metadata: {
                    skill_id: skill.id,
                    skill_name: skill.name,
                    purchase_price: skill.price,
                    purchased_at: new Date().toISOString()
                }
            })
                .select()
                .single();
            if (insertError) {
                console.error('[SkillsService] purchaseSkillByToolName - 添加技能失败:', insertError);
                throw new Error(`添加技能失败: ${insertError.message}`);
            }
            if (!newAvatarSkill) {
                throw new Error('添加技能失败：未返回数据');
            }
            console.log('[SkillsService] purchaseSkillByToolName - 添加成功:', newAvatarSkill);
            return newAvatarSkill;
        }
        catch (error) {
            console.error('[SkillsService] purchaseSkillByToolName error:', error);
            throw error;
        }
    }
    async removeSkill(userId, dto) {
        try {
            let skillToolName;
            try {
                const skill = await this.getSkillById(dto.skillId);
                skillToolName = skill.tool_name || skill.toolName || 'custom';
                console.log('[SkillsService] removeSkill - 通过 skillId 查询到技能信息:', {
                    skillId: dto.skillId,
                    skillName: skill.name,
                    tool_name: skillToolName
                });
            }
            catch (skillError) {
                skillToolName = dto.skillId;
                console.log('[SkillsService] removeSkill - 通过 skillId 查询失败，将 skillId 作为 skill_type 使用:', {
                    skillId: dto.skillId,
                    skillType: skillToolName
                });
            }
            console.log('[SkillsService] removeSkill - 开始删除:', {
                avatarId: dto.avatarId,
                skillType: skillToolName
            });
            const { data: existingData, error: checkError } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_skills')
                .select('id')
                .eq('avatar_id', dto.avatarId)
                .eq('skill_type', skillToolName)
                .maybeSingle();
            if (checkError && checkError.code !== 'PGRST116') {
                console.error('[SkillsService] 检查技能是否存在时出错:', checkError);
                throw new Error(`检查技能失败: ${checkError.message}`);
            }
            if (!existingData) {
                console.warn('[SkillsService] 未找到该技能记录');
                throw new Error('未找到该技能，可能已经移除');
            }
            const { error: deleteError } = await (0, supabase_client_1.getSupabaseClient)()
                .from('avatar_skills')
                .delete()
                .eq('avatar_id', dto.avatarId)
                .eq('skill_type', skillToolName);
            if (deleteError) {
                console.error('[SkillsService] 移除技能失败:', deleteError);
                throw new Error(`移除技能失败: ${deleteError.message}`);
            }
            console.log('[SkillsService] 技能移除成功');
        }
        catch (error) {
            console.error('[SkillsService] removeSkill error:', error);
            throw error;
        }
    }
};
exports.SkillsService = SkillsService;
exports.SkillsService = SkillsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], SkillsService);
//# sourceMappingURL=skills.service.js.map