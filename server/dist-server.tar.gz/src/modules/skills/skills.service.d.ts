import { Skill, AvatarSkill, SkillReview, CreateSkillDto, PurchaseSkillDto, SkillFilter } from './skills.types';
export declare class SkillsService {
    private llmClient;
    constructor();
    private initializeEssentialSkills;
    getSkills(filter?: SkillFilter, page?: number, pageSize?: number): Promise<{
        skills: any[];
        total: number;
        page: number;
        pageSize: number;
        totalPages: number;
    }>;
    getSkillById(skillId: string): Promise<Skill>;
    createSkill(userId: string, dto: CreateSkillDto): Promise<Skill>;
    purchaseSkill(userId: string, dto: PurchaseSkillDto): Promise<AvatarSkill>;
    getAvatarSkills(avatarId: string): Promise<AvatarSkill[]>;
    addReview(userId: string, skillId: string, rating: number, comment?: string): Promise<SkillReview>;
    getSkillReviews(skillId: string, page?: number, pageSize?: number): Promise<{
        reviews: any[];
        total: number;
        page: number;
        pageSize: number;
    }>;
    getCategories(): Promise<string[]>;
    searchSkills(keyword: string, limit?: number): Promise<Skill[]>;
    generateSkillWithAI(prompt: string): Promise<{
        name: any;
        description: any;
        category: any;
        tags: any;
        capabilities: any;
        requirements: any;
        icon: any;
        tool_name: string;
    }>;
    purchaseSkillByToolName(userId: string, toolName: string, avatarId: string): Promise<any>;
    removeSkill(userId: string, dto: {
        skillId: string;
        avatarId: string;
    }): Promise<void>;
}
