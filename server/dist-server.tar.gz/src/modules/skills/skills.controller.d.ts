import { SkillsService } from './skills.service';
import { CreateSkillDto, PurchaseSkillDto } from './skills.types';
export declare class SkillsController {
    private readonly skillsService;
    constructor(skillsService: SkillsService);
    getSkillsList(type?: 'prebuilt' | 'custom' | 'paid', category?: string, minPrice?: string, maxPrice?: string, minRating?: string, tags?: string, search?: string, page?: string, pageSize?: string): Promise<{
        code: number;
        data: {
            skills: any[];
            total: number;
            page: number;
            pageSize: number;
            totalPages: number;
        };
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    getAvatarSkills(avatarId: string): Promise<{
        code: number;
        data: import("./skills.types").AvatarSkill[];
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    getSkillDetail(id: string): Promise<{
        code: number;
        data: import("./skills.types").Skill;
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    createSkill(userId: string, dto: CreateSkillDto): Promise<{
        code: number;
        data: import("./skills.types").Skill;
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    purchaseSkill(userId: string, dto: PurchaseSkillDto): Promise<{
        code: number;
        data: import("./skills.types").AvatarSkill;
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    addReview(userId: string, skillId: string, body: {
        rating: number;
        comment?: string;
    }): Promise<{
        code: number;
        data: import("./skills.types").SkillReview;
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    getSkillReviews(skillId: string, page?: string, pageSize?: string): Promise<{
        code: number;
        data: {
            reviews: any[];
            total: number;
            page: number;
            pageSize: number;
        };
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
    getCategories(): Promise<{
        code: number;
        data: string[];
        message: string;
    }>;
    searchSkills(keyword: string, limit?: string): Promise<{
        code: number;
        data: import("./skills.types").Skill[];
        message: string;
    }>;
    generateSkillWithAI(body: {
        prompt: string;
    }): Promise<{
        code: number;
        data: {
            skill: {
                name: any;
                description: any;
                category: any;
                tags: any;
                capabilities: any;
                requirements: any;
                icon: any;
                tool_name: string;
            };
        };
        message: string;
    } | {
        code: number;
        data: null;
        message: string;
    }>;
    removeSkill(userId: string, body: {
        skillId: string;
        avatarId: string;
    }): Promise<{
        code: number;
        data: null;
        message: any;
    }>;
    purchaseSkillByToolName(userId: string, body: {
        toolName: string;
        avatarId: string;
    }): Promise<{
        code: number;
        data: any;
        message: string;
    } | {
        code: number;
        data: null;
        message: any;
    }>;
}
