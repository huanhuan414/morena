"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SkillsController = void 0;
const common_1 = require("@nestjs/common");
const skills_service_1 = require("./skills.service");
let SkillsController = class SkillsController {
    constructor(skillsService) {
        this.skillsService = skillsService;
    }
    async getSkillsList(type, category, minPrice, maxPrice, minRating, tags, search, page, pageSize) {
        try {
            const filter = {};
            if (type)
                filter.type = type;
            if (category)
                filter.category = category;
            if (minPrice)
                filter.minPrice = parseFloat(minPrice);
            if (maxPrice)
                filter.maxPrice = parseFloat(maxPrice);
            if (minRating)
                filter.minRating = parseFloat(minRating);
            if (tags)
                filter.tags = tags.split(',').map(t => t.trim());
            if (search)
                filter.search = search;
            const result = await this.skillsService.getSkills(filter, page ? parseInt(page) : 1, pageSize ? parseInt(pageSize) : 20);
            return {
                code: 200,
                data: result,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '获取技能列表失败'
            };
        }
    }
    async getAvatarSkills(avatarId) {
        try {
            const skills = await this.skillsService.getAvatarSkills(avatarId);
            return {
                code: 200,
                data: skills,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '获取分身技能失败'
            };
        }
    }
    async getSkillDetail(id) {
        try {
            const skill = await this.skillsService.getSkillById(id);
            return {
                code: 200,
                data: skill,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 404,
                data: null,
                message: error.message || '技能不存在'
            };
        }
    }
    async createSkill(userId, dto) {
        try {
            const skill = await this.skillsService.createSkill(userId, dto);
            return {
                code: 200,
                data: skill,
                message: '创建成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '创建技能失败'
            };
        }
    }
    async purchaseSkill(userId, dto) {
        try {
            const avatarSkill = await this.skillsService.purchaseSkill(userId, dto);
            return {
                code: 200,
                data: avatarSkill,
                message: '购买成功'
            };
        }
        catch (error) {
            return {
                code: 400,
                data: null,
                message: error.message || '购买技能失败'
            };
        }
    }
    async addReview(userId, skillId, body) {
        try {
            const review = await this.skillsService.addReview(userId, skillId, body.rating, body.comment);
            return {
                code: 200,
                data: review,
                message: '评价成功'
            };
        }
        catch (error) {
            return {
                code: 400,
                data: null,
                message: error.message || '添加评价失败'
            };
        }
    }
    async getSkillReviews(skillId, page, pageSize) {
        try {
            const result = await this.skillsService.getSkillReviews(skillId, page ? parseInt(page) : 1, pageSize ? parseInt(pageSize) : 10);
            return {
                code: 200,
                data: result,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '获取评价列表失败'
            };
        }
    }
    async getCategories() {
        try {
            const categories = await this.skillsService.getCategories();
            return {
                code: 200,
                data: categories,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: [],
                message: '获取分类失败'
            };
        }
    }
    async searchSkills(keyword, limit) {
        try {
            const skills = await this.skillsService.searchSkills(keyword, limit ? parseInt(limit) : 10);
            return {
                code: 200,
                data: skills,
                message: '搜索成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: [],
                message: '搜索失败'
            };
        }
    }
    async generateSkillWithAI(body) {
        try {
            const generatedSkill = await this.skillsService.generateSkillWithAI(body.prompt);
            return {
                code: 200,
                data: { skill: generatedSkill },
                message: 'AI 生成成功'
            };
        }
        catch (error) {
            console.error('[SkillsController] AI 生成失败:', error);
            return {
                code: 500,
                data: null,
                message: 'AI 生成失败'
            };
        }
    }
    async removeSkill(userId, body) {
        try {
            await this.skillsService.removeSkill(userId, body);
            return {
                code: 200,
                data: null,
                message: '移除成功'
            };
        }
        catch (error) {
            return {
                code: 400,
                data: null,
                message: error.message || '移除技能失败'
            };
        }
    }
    async purchaseSkillByToolName(userId, body) {
        try {
            const result = await this.skillsService.purchaseSkillByToolName(userId, body.toolName, body.avatarId);
            return {
                code: 200,
                data: result,
                message: '添加成功'
            };
        }
        catch (error) {
            return {
                code: 400,
                data: null,
                message: error.message || '添加技能失败'
            };
        }
    }
};
exports.SkillsController = SkillsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('type')),
    __param(1, (0, common_1.Query)('category')),
    __param(2, (0, common_1.Query)('minPrice')),
    __param(3, (0, common_1.Query)('maxPrice')),
    __param(4, (0, common_1.Query)('minRating')),
    __param(5, (0, common_1.Query)('tags')),
    __param(6, (0, common_1.Query)('search')),
    __param(7, (0, common_1.Query)('page')),
    __param(8, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String, String, String, String]),
    __metadata("design:returntype", Promise)
], SkillsController.prototype, "getSkillsList", null);
__decorate([
    (0, common_1.Get)('avatar/:avatarId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SkillsController.prototype, "getAvatarSkills", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SkillsController.prototype, "getSkillDetail", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SkillsController.prototype, "createSkill", null);
__decorate([
    (0, common_1.Post)('purchase'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SkillsController.prototype, "purchaseSkill", null);
__decorate([
    (0, common_1.Post)(':skillId/reviews'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Param)('skillId')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], SkillsController.prototype, "addReview", null);
__decorate([
    (0, common_1.Get)(':skillId/reviews'),
    __param(0, (0, common_1.Param)('skillId')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], SkillsController.prototype, "getSkillReviews", null);
__decorate([
    (0, common_1.Get)('categories/list'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SkillsController.prototype, "getCategories", null);
__decorate([
    (0, common_1.Get)('search/:keyword'),
    __param(0, (0, common_1.Param)('keyword')),
    __param(1, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], SkillsController.prototype, "searchSkills", null);
__decorate([
    (0, common_1.Post)('ai-generate'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], SkillsController.prototype, "generateSkillWithAI", null);
__decorate([
    (0, common_1.Delete)('remove'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SkillsController.prototype, "removeSkill", null);
__decorate([
    (0, common_1.Post)('purchase-by-tool-name'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SkillsController.prototype, "purchaseSkillByToolName", null);
exports.SkillsController = SkillsController = __decorate([
    (0, common_1.Controller)('skills'),
    __metadata("design:paramtypes", [skills_service_1.SkillsService])
], SkillsController);
//# sourceMappingURL=skills.controller.js.map