export declare class SkillsModule {
}
