export declare class VisionModule {
}
