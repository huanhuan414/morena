export declare class VisionController {
    private readonly llmClient;
    constructor();
    analyzeImage(body: {
        imageUrl: string;
    }): Promise<{
        description: string;
    }>;
}
