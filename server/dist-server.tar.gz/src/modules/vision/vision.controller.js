"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VisionController = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
let VisionController = class VisionController {
    constructor() {
        const config = new coze_coding_dev_sdk_1.Config();
        this.llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
    }
    async analyzeImage(body) {
        const { imageUrl } = body;
        const messages = [
            {
                role: 'user',
                content: [
                    {
                        type: 'text',
                        text: '请详细描述这个UI界面的布局和样式，包括：1. 输入框的样式和位置 2. 上传按钮的样式和位置 3. 整体布局结构 4. 颜色、圆角、边距等视觉细节 5. 任何文字内容。请尽可能详细地描述，以便我能够完全复刻这个界面。',
                    },
                    {
                        type: 'image_url',
                        image_url: {
                            url: imageUrl,
                            detail: 'high',
                        },
                    },
                ],
            },
        ];
        const response = await this.llmClient.invoke(messages, {
            model: 'doubao-seed-1-6-vision-250815',
            temperature: 0.7,
        });
        return { description: response.content };
    }
};
exports.VisionController = VisionController;
__decorate([
    (0, common_1.Post)('analyze'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], VisionController.prototype, "analyzeImage", null);
exports.VisionController = VisionController = __decorate([
    (0, common_1.Controller)('vision'),
    __metadata("design:paramtypes", [])
], VisionController);
//# sourceMappingURL=vision.controller.js.map