import { EarningsService } from './earnings.service';
export declare class EarningsController {
    private readonly earningsService;
    constructor(earningsService: EarningsService);
    getLeaderboard(limit?: string): Promise<{
        code: number;
        msg: string;
        data: import("./earnings.service").LeaderboardResponse;
    }>;
}
