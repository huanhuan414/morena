"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EarningsService = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../storage/database/supabase-client");
let EarningsService = class EarningsService {
    async getLeaderboard(limit = 50) {
        const client = (0, supabase_client_1.getSupabaseClient)();
        try {
            const { data: dispatchRequests, error: requestsError } = await client
                .from('order_dispatch_requests')
                .select('id, avatar_id, status, order_id')
                .eq('status', 'completed');
            if (requestsError) {
                console.error('[EarningsService] 查询分发请求失败:', requestsError);
                return { records: [], stats: { totalPlatformEarnings: 0, totalAvatars: 0, totalCompletedOrders: 0, averageEarnings: 0 } };
            }
            if (!dispatchRequests || dispatchRequests.length === 0) {
                return { records: [], stats: { totalPlatformEarnings: 0, totalAvatars: 0, totalCompletedOrders: 0, averageEarnings: 0 } };
            }
            const convertOrderId = (orderId) => {
                if (!orderId)
                    return '';
                if (typeof orderId === 'string')
                    return orderId;
                if (orderId instanceof Buffer) {
                    return orderId.toString('hex').replace(/(.{8})(.{4})(.{4})(.{4})(.{12})/, '$1-$2-$3-$4-$5');
                }
                if (orderId.data) {
                    const hex = Buffer.from(orderId.data).toString('hex');
                    return hex.replace(/(.{8})(.{4})(.{4})(.{4})(.{12})/, '$1-$2-$3-$4-$5');
                }
                return String(orderId);
            };
            const orderIds = dispatchRequests
                .map(r => convertOrderId(r.order_id))
                .filter(Boolean);
            if (orderIds.length === 0) {
                return { records: [], stats: { totalPlatformEarnings: 0, totalAvatars: 0, totalCompletedOrders: 0, averageEarnings: 0 } };
            }
            const { data: orders, error: ordersError } = await client
                .from('orders')
                .select('id, budget, platforms')
                .in('id', orderIds);
            if (ordersError) {
                console.error('[EarningsService] 查询订单失败:', ordersError);
                return { records: [], stats: { totalPlatformEarnings: 0, totalAvatars: 0, totalCompletedOrders: 0, averageEarnings: 0 } };
            }
            const orderBudgetMap = new Map();
            for (const order of orders || []) {
                let budgetValue = 0;
                if (order.budget) {
                    const budgetStr = String(order.budget);
                    const parts = budgetStr.match(/[^\s{}]+/g);
                    if (parts && parts.length >= 1) {
                        const amount = parseFloat(parts[0]);
                        const scale = parts.length >= 2 ? parseInt(parts[1]) : 0;
                        budgetValue = amount / Math.pow(10, Math.abs(scale));
                    }
                }
                orderBudgetMap.set(order.id, {
                    budget: Math.floor(budgetValue),
                    platforms: order.platforms
                });
            }
            const { data: orderAvatarCounts, error: countError } = await client
                .from('order_dispatch_requests')
                .select('order_id')
                .in('status', ['completed', 'awaiting_acceptance', 'published', 'preview', 'generating', 'accepted']);
            if (countError) {
                console.error('[EarningsService] 查询分身数量失败:', countError);
            }
            const orderAvatarCountMap = new Map();
            for (const record of orderAvatarCounts || []) {
                const convertedOrderId = convertOrderId(record.order_id);
                const count = orderAvatarCountMap.get(convertedOrderId) || 0;
                orderAvatarCountMap.set(convertedOrderId, count + 1);
            }
            const avatarIds = [...new Set(dispatchRequests.map(r => r.avatar_id).filter(Boolean))];
            const { data: avatars, error: avatarsError } = await client
                .from('avatars')
                .select('id, name, avatar_url')
                .in('id', avatarIds);
            if (avatarsError) {
                console.error('[EarningsService] 查询分身失败:', avatarsError);
            }
            const avatarInfoMap = new Map();
            for (const avatar of avatars || []) {
                avatarInfoMap.set(avatar.id, { name: avatar.name, avatar_url: avatar.avatar_url });
            }
            const avatarEarningsMap = new Map();
            let totalPlatformEarnings = 0;
            let totalCompletedOrders = 0;
            for (const request of dispatchRequests) {
                const avatarId = request.avatar_id;
                if (!avatarId)
                    continue;
                const orderId = convertOrderId(request.order_id);
                const orderInfo = orderBudgetMap.get(orderId);
                if (!orderInfo)
                    continue;
                const avatarCount = orderAvatarCountMap.get(orderId) || 1;
                const budget = orderInfo.budget;
                const earnings = Math.floor(budget / avatarCount);
                const existing = avatarEarningsMap.get(avatarId);
                const avatarInfo = avatarInfoMap.get(avatarId);
                if (existing) {
                    existing.totalEarnings += earnings;
                    existing.completedOrders += 1;
                }
                else {
                    avatarEarningsMap.set(avatarId, {
                        avatarId,
                        avatarName: avatarInfo?.name || `分身${avatarId.slice(0, 8)}`,
                        avatarAvatar: avatarInfo?.avatar_url,
                        totalEarnings: earnings,
                        completedOrders: 1,
                        platform: orderInfo.platforms?.[0]
                    });
                }
                totalPlatformEarnings += earnings;
                totalCompletedOrders += 1;
            }
            const records = Array.from(avatarEarningsMap.values())
                .sort((a, b) => b.totalEarnings - a.totalEarnings)
                .slice(0, limit)
                .map((record, index) => ({
                ...record,
                rank: index + 1
            }));
            const totalAvatars = avatarEarningsMap.size;
            const averageEarnings = totalAvatars > 0
                ? Math.floor(totalPlatformEarnings / totalAvatars)
                : 0;
            return {
                records,
                stats: {
                    totalPlatformEarnings,
                    totalAvatars,
                    totalCompletedOrders,
                    averageEarnings
                }
            };
        }
        catch (error) {
            console.error('[EarningsService] 获取排行榜失败:', error);
            return { records: [], stats: { totalPlatformEarnings: 0, totalAvatars: 0, totalCompletedOrders: 0, averageEarnings: 0 } };
        }
    }
};
exports.EarningsService = EarningsService;
exports.EarningsService = EarningsService = __decorate([
    (0, common_1.Injectable)()
], EarningsService);
//# sourceMappingURL=earnings.service.js.map