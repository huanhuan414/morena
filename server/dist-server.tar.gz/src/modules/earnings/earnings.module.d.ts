export declare class EarningsModule {
}
