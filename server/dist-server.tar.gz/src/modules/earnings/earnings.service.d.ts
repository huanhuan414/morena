interface EarningsRecord {
    avatarId: string;
    avatarName: string;
    avatarAvatar?: string;
    totalEarnings: number;
    completedOrders: number;
    rank: number;
    platform?: string;
}
interface EarningsStats {
    totalPlatformEarnings: number;
    totalAvatars: number;
    totalCompletedOrders: number;
    averageEarnings: number;
}
export interface LeaderboardResponse {
    records: EarningsRecord[];
    stats: EarningsStats;
}
export declare class EarningsService {
    getLeaderboard(limit?: number): Promise<LeaderboardResponse>;
}
export {};
