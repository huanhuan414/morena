export declare class AnalyzeController {
    analyzeLayout(body: {
        imageUrl: string;
    }): Promise<{
        code: number;
        msg: string;
        data: {
            analysis: string;
        };
    }>;
}
