export type PlatformType = 'wechat' | 'xiaohongshu' | 'bilibili' | 'weibo' | 'douyin';
export type ToolCategory = 'app_function' | 'content_creation' | 'platform_publish' | 'data_analysis';
export type StepType = 'think' | 'action' | 'observe' | 'result';
export type PlatformConfigStatus = 'active' | 'expired' | 'unconfigured';
export interface ToolDefinition {
    name: string;
    displayName: string;
    description: string;
    category: ToolCategory;
    paramsSchema: Record<string, any>;
    requiresPlatform?: PlatformType;
}
export interface ToolResult {
    success: boolean;
    data?: any;
    error?: string;
    requires_config?: boolean;
    config_platform?: PlatformType;
    config_fields?: ConfigField[];
}
export interface ConfigField {
    name: string;
    label: string;
    type: 'text' | 'password' | 'textarea';
    required: boolean;
    placeholder?: string;
    description?: string;
}
export interface PlatformConfig {
    id: string;
    user_id: string;
    platform_type: PlatformType;
    config_data: Record<string, any>;
    status: PlatformConfigStatus;
    last_used_at?: string;
    created_at: string;
    updated_at: string;
}
export interface AvatarSkill {
    id: string;
    avatar_id: string;
    skill_type: string;
    skill_level: number;
    usage_count: number;
    last_used_at?: string;
    metadata: Record<string, any>;
    created_at: string;
}
export interface AgentTaskLog {
    id: string;
    task_id: string;
    avatar_id: string;
    step_index: number;
    step_type: StepType;
    content: string;
    tool_name?: string;
    tool_params?: Record<string, any>;
    tool_result?: Record<string, any>;
    requires_config?: boolean;
    config_platform?: PlatformType;
    created_at: string;
}
export interface ReActStep {
    step_index: number;
    thought: string;
    action?: string;
    action_input?: any;
    observation?: any;
    requires_config?: boolean;
    config_platform?: PlatformType;
    config_fields?: ConfigField[];
}
export interface AgentContext {
    userId: string;
    avatarId: string;
    avatarInfo?: {
        name: string;
        description: string;
        personality: string;
        level: number;
        avatar_url: string;
    };
    conversationId?: string;
    taskId?: string;
    taskDescription: string;
    availableTools: ToolDefinition[];
    platformConfigs: Map<PlatformType, PlatformConfig>;
    avatarSkills: AvatarSkill[];
    executionHistory: ReActStep[];
    conversationHistory: ConversationMessage[];
    uploadedImages?: string[];
    uploadedVideos?: string[];
    maxSteps: number;
    currentStep: number;
}
export interface ConversationMessage {
    role: 'user' | 'assistant' | 'system';
    content: string;
    created_at?: string;
}
export interface AgentExecutionResult {
    success: boolean;
    finalAnswer: string;
    steps: ReActStep[];
    requiresConfig: boolean;
    configPlatform?: PlatformType;
    configFields?: ConfigField[];
    taskId?: string;
    createdResources?: any[];
}
export interface PlatformConfigRequirement {
    platform: PlatformType;
    platform_name: string;
    fields: ConfigField[];
    instructions: string;
    help_url?: string;
}
export declare const PLATFORM_CONFIG_TEMPLATES: Record<PlatformType, PlatformConfigRequirement>;
