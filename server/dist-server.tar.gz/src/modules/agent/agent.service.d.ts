import { AgentExecutionResult, AvatarSkill, PlatformConfig, PlatformType, ToolDefinition } from './agent.types';
import { AgentGateway } from './agent.gateway';
import { ProgressCacheService } from './progress-cache.service';
import { LearningService } from '../avatar/learning.service';
interface ConversationMessage {
    role: 'user' | 'assistant' | 'system';
    content: string;
    created_at?: string;
}
export declare class AgentService {
    private readonly gateway;
    private readonly progressCache;
    private readonly learningService;
    private tools;
    private llmClient;
    private currentTaskMap;
    constructor(gateway: AgentGateway, progressCache: ProgressCacheService, learningService: LearningService);
    private emitProgress;
    private registerTools;
    getAvailableTools(): ToolDefinition[];
    getAvatarTools(avatarId: string): Promise<ToolDefinition[]>;
    private getToolsByNames;
    executeTaskWithProgress(userId: string, avatarId: string, taskDescription: string, options?: {
        conversationId?: string;
        taskId?: string;
        headers?: Record<string, string>;
        uploadedImages?: string[];
        uploadedVideos?: string[];
    }): AsyncGenerator<any>;
    executeTask(userId: string, avatarId: string, taskDescription: string, options?: {
        conversationId?: string;
        taskId?: string;
        headers?: Record<string, string>;
        conversationHistory?: ConversationMessage[];
        uploadedImages?: string[];
        uploadedVideos?: string[];
    }): Promise<AgentExecutionResult>;
    executeTaskAsync(userId: string, avatarId: string, taskDescription: string, options?: {
        conversationId?: string;
        taskId?: string;
        headers?: Record<string, string>;
        conversationHistory?: ConversationMessage[];
        uploadedImages?: string[];
        uploadedVideos?: string[];
    }): Promise<AgentExecutionResult>;
    private createInitialAssistantMessage;
    private updateAssistantMessageProgress;
    private updateAssistantMessage;
    private cleanDebugInfo;
    private initContext;
    private runReActLoop;
    private think;
    private getTaskUnderstandingHint;
    private formatConversationHistory;
    private executeTool;
    private getSkillDisplayName;
    private parseAction;
    private extractFinalAnswer;
    private hasMediaContent;
    private hasVideoContent;
    private extractShortdramaParams;
    private generateDirectAnswer;
    private summarizeExecution;
    private formatToolsForPrompt;
    private formatHistory;
    private logStep;
    checkPlatformConfig(userId: string, platform: PlatformType): Promise<{
        configured: boolean;
        config?: PlatformConfig;
        requiredFields?: any[];
    }>;
    validatePlatformConfig(platform: PlatformType, configData: Record<string, any>): Promise<{
        valid: boolean;
        message?: string;
        accountInfo?: any;
        serverIp?: string;
    }>;
    private validateWechatMpConfig;
    private validateXiaohongshuConfig;
    private validateBilibiliConfig;
    private validateWeiboConfig;
    private validateDouyinConfig;
    private validateWechatVideoConfig;
    savePlatformConfig(userId: string, platform: PlatformType, configData: Record<string, any>): Promise<{
        success: boolean;
        message: string;
    }>;
    getUserPlatformConfigs(userId: string): Promise<PlatformConfig[]>;
    deletePlatformConfig(userId: string, platform: PlatformType): Promise<{
        success: boolean;
    }>;
    addAvatarSkill(avatarId: string, skillType: string, metadata?: Record<string, any>): Promise<{
        success: boolean;
    }>;
    getAvatarSkills(avatarId: string): Promise<AvatarSkill[]>;
    publishContent(userId: string, platform: PlatformType, content: {
        title?: string;
        content?: string;
        cover_url?: string;
        images?: string[];
        tags?: string[];
    }): Promise<{
        success: boolean;
        data?: any;
        message?: string;
    }>;
    private checkRequiredSkills;
    private getToolDisplayNameChinese;
    private detectUnknownSkillRequirements;
    private matchesAvailableTaskTypes;
}
export {};
