import { OnGatewayConnection, OnGatewayDisconnect } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
interface TaskProgress {
    taskId: string;
    userId: string;
    type: string;
    message: string;
    data?: any;
    timestamp: number;
}
export declare class AgentGateway implements OnGatewayConnection, OnGatewayDisconnect {
    server: Server;
    private userSockets;
    handleConnection(client: Socket): void;
    handleDisconnect(client: Socket): void;
    emitProgress(userId: string, progress: TaskProgress): void;
    handleSubscribeTask(client: Socket, payload: {
        taskId: string;
    }): {
        success: boolean;
        message: string;
    };
    handleUnsubscribeTask(client: Socket, payload: {
        taskId: string;
    }): {
        success: boolean;
        message: string;
    };
    getOnlineUserCount(): number;
}
export {};
