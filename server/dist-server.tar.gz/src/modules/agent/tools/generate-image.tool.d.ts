import { ITool, ToolExecutionContext, ToolResult } from '../tools.interface';
export declare class GenerateImageTool implements ITool {
    name: string;
    description: string;
    private storage;
    constructor();
    parameters: {
        type: "object";
        properties: {
            prompt: {
                type: "string";
                description: string;
            };
            size: {
                type: "string";
                description: string;
                default: string;
            };
            style: {
                type: "string";
                description: string;
                default: string;
            };
        };
        required: string[];
    };
    execute(params: Record<string, any>, context: ToolExecutionContext): Promise<ToolResult>;
    private buildEnhancedPrompt;
}
