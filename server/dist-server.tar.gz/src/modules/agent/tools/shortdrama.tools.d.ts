import { ITool, ToolContext, ToolDefinition } from './tool.interface';
import { ToolResult } from '../agent.types';
export declare class GenerateShortDramaScriptTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class GenerateStoryboardTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class ProduceShortDramaTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
