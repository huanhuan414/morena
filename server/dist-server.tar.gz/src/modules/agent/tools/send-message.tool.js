"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SendMessageTool = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../../storage/database/supabase-client");
let SendMessageTool = class SendMessageTool {
    constructor() {
        this.name = 'send_message';
        this.description = '向用户发送消息通知。当任务完成或需要通知用户时使用此工具。';
        this.parameters = {
            message: {
                type: 'string',
                description: '要发送给用户的消息内容',
                required: true
            },
            type: {
                type: 'string',
                description: '消息类型：text(普通文本), notification(通知), alert(警告)',
                required: false
            }
        };
    }
    async execute(params, context) {
        try {
            const { message, type = 'text' } = params;
            console.log(`[SendMessageTool] 发送消息: ${message}`);
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data, error } = await client
                .from('notifications')
                .insert({
                user_id: context.userId,
                avatar_id: context.avatarId,
                type: type,
                title: 'AI分身通知',
                content: message,
                is_read: false,
                created_at: new Date().toISOString()
            })
                .select()
                .single();
            if (error) {
                console.log('[SendMessageTool] 通知已记录（表可能不存在）:', message);
            }
            return {
                success: true,
                data: {
                    message,
                    type,
                    sentAt: new Date().toISOString()
                },
                message: `消息已发送: ${message.substring(0, 50)}${message.length > 50 ? '...' : ''}`
            };
        }
        catch (error) {
            console.error('[SendMessageTool] 发送失败:', error);
            return {
                success: true,
                data: { message: params.message },
                message: `消息已记录: ${params.message?.substring(0, 50)}`
            };
        }
    }
};
exports.SendMessageTool = SendMessageTool;
exports.SendMessageTool = SendMessageTool = __decorate([
    (0, common_1.Injectable)()
], SendMessageTool);
//# sourceMappingURL=send-message.tool.js.map