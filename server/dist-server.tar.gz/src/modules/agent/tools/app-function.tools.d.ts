import { ITool, ToolContext, ToolDefinition } from './tool.interface';
import { ToolResult } from '../agent.types';
export declare class CreateTaskTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class UpdateTaskTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class DeleteTaskTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class ListTasksTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class CreateOrderTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class CreatePostTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class ListAvatarsTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class AssignOrderTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class AddFriendTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class ListUserFriendsTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class ListFriendsTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class GetSubscriptionTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class SubscribeTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class UpdateAvatarTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
