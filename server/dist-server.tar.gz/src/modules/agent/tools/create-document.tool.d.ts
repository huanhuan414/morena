import { Tool, ToolExecutionContext, ToolResult } from '../tools.interface';
export declare class CreateDocumentTool implements Tool {
    name: string;
    description: string;
    parameters: {
        title: {
            type: string;
            description: string;
            required: boolean;
        };
        content: {
            type: string;
            description: string;
            required: boolean;
        };
        type: {
            type: string;
            description: string;
            required: boolean;
        };
    };
    execute(params: Record<string, any>, context: ToolExecutionContext): Promise<ToolResult>;
}
