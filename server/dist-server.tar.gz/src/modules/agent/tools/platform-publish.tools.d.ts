import { ITool, ToolContext, ToolDefinition } from './tool.interface';
import { ToolResult } from '../agent.types';
export declare class ListAvatarAccountsTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class CheckPlatformConfigTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class PublishWechatMpTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
    private isValidImageUrl;
    private generateCoverImage;
    private generateDefaultCover;
    private addImagesToContent;
    private replaceImagesForWechat;
    private uploadArticleImage;
    private parseArticleSections;
    private findInsertPosition;
    private generateImagePrompt;
    private uploadImage;
    private generateDigest;
    private markdownToStyledHtml;
    private getWechatErrorMessage;
}
export declare class PublishXiaohongshuTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class PublishBilibiliTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class PublishWeiboTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class PublishDouyinTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class PublishWechatVideoTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
