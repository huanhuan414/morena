"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatchGenerateTool = exports.GenerateVideoTool = exports.GenerateImageTool = exports.WriteXiaohongshuNoteTool = exports.WriteWechatMpArticleTool = exports.WriteArticleTool = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const axios_1 = require("axios");
class ImagePromptOptimizer {
    static identifyScene(prompt) {
        const sceneKeywords = [];
        if (prompt.match(/人|人物|肖像|face|portrait|character/i)) {
            sceneKeywords.push('detailed facial features', 'expressive eyes', 'natural skin texture', 'hair details', 'professional portrait lighting');
        }
        if (prompt.match(/风景|landscape|mountain|ocean|forest|sky|sunset|sunrise/i)) {
            sceneKeywords.push('epic landscape', 'dramatic sky', 'volumetric clouds', 'atmospheric perspective', 'natural environment', 'environmental details');
        }
        if (prompt.match(/城市|city|building|street|urban|architecture/i)) {
            sceneKeywords.push('urban landscape', 'architecture details', 'cityscape', 'night city', 'street photography', 'urban atmosphere');
        }
        if (prompt.match(/科幻|sci-fi|future|space|alien|cyberpunk/i)) {
            sceneKeywords.push('futuristic', 'sci-fi', 'high-tech', 'advanced technology', 'otherworldly', 'extraterrestrial', 'neon lights', 'cybernetic');
        }
        if (prompt.match(/奇幻|fantasy|magic|dragon|elf|mythical/i)) {
            sceneKeywords.push('fantasy world', 'magical atmosphere', 'mythical creatures', 'enchanted forest', 'mystical lighting', 'ethereal glow');
        }
        return sceneKeywords;
    }
    static identifyAction(prompt) {
        const actionKeywords = [];
        if (prompt.match(/跑|跑动|run|sprint|dash/i)) {
            actionKeywords.push('dynamic motion', 'motion blur', 'dynamic composition');
        }
        if (prompt.match(/飞|飞行|fly|floating|hovering/i)) {
            actionKeywords.push('levitation', 'aerial view', 'dynamic perspective');
        }
        if (prompt.match(/跳|跳跃|jump|leap|hop/i)) {
            actionKeywords.push('action shot', 'dynamic pose', 'freeze frame');
        }
        if (prompt.match(/战斗|fight|battle|combat|war/i)) {
            actionKeywords.push('epic battle', 'action scene', 'dynamic movement', 'intense atmosphere');
        }
        return actionKeywords;
    }
    static identifyEmotion(prompt) {
        const emotionMap = {
            悲伤: ['melancholic', 'sorrowful', 'somber', 'introspective'],
            快乐: ['joyful', 'cheerful', 'uplifting', 'radiant'],
            恐惧: ['menacing', 'ominous', 'threatening', 'dark'],
            愤怒: ['fierce', 'aggressive', 'intense', 'powerful'],
            爱: ['romantic', 'tender', 'affectionate', 'warm'],
            孤独: ['lonely', 'isolated', 'solitary', 'contemplative'],
            希望: ['hopeful', 'inspiring', 'optimistic', 'bright'],
            神秘: ['mysterious', 'enigmatic', 'intriguing', 'hidden']
        };
        for (const [emotion, keywords] of Object.entries(emotionMap)) {
            if (prompt.includes(emotion)) {
                return keywords;
            }
        }
        return [];
    }
    static optimize(userPrompt, style = 'realistic') {
        console.log('提示词优化 - 原始描述:', userPrompt);
        const styleTemplate = this.styleTemplates[style] || this.styleTemplates.realistic;
        const allKeywords = [];
        allKeywords.push(styleTemplate.base);
        allKeywords.push(styleTemplate.lighting);
        allKeywords.push(styleTemplate.camera);
        allKeywords.push(styleTemplate.post);
        const sceneKeywords = this.identifyScene(userPrompt);
        allKeywords.push(...sceneKeywords);
        const actionKeywords = this.identifyAction(userPrompt);
        allKeywords.push(...actionKeywords);
        const emotionKeywords = this.identifyEmotion(userPrompt);
        allKeywords.push(...emotionKeywords);
        const randomLighting = this.lightingKeywords[Math.floor(Math.random() * 3)];
        const randomComposition = this.compositionKeywords[Math.floor(Math.random() * 3)];
        const randomRendering = this.renderingKeywords[Math.floor(Math.random() * 3)];
        allKeywords.push(randomLighting, randomComposition, randomRendering);
        const optimizedPrompt = `${userPrompt}, ${allKeywords.join(', ')}`;
        console.log('提示词优化 - 优化后:', optimizedPrompt.substring(0, 200) + '...');
        return optimizedPrompt;
    }
}
ImagePromptOptimizer.lightingKeywords = [
    'cinematic lighting', 'natural light', 'golden hour', 'dramatic shadows',
    'soft ambient light', 'studio lighting', 'rim light', 'volumetric lighting',
    'light rays', 'god rays', 'backlighting', 'side lighting', 'subsurface scattering',
    'global illumination', 'ambient occlusion', 'ray tracing', 'physically based rendering',
    'HDR lighting', 'bloom effect', 'lens flare', 'specular highlights', 'caustics'
];
ImagePromptOptimizer.compositionKeywords = [
    'rule of thirds', 'golden ratio', 'symmetrical composition', 'dynamic composition',
    'depth of field', 'shallow depth of field', 'bokeh', 'foreground and background',
    'leading lines', 'negative space', 'center composition', 'low angle shot',
    'high angle shot', 'extreme wide angle', 'macro shot', 'telephoto compression',
    'layering', 'visual hierarchy', 'framing', 'camera movement'
];
ImagePromptOptimizer.colorKeywords = [
    'color grading', 'color palette', 'complementary colors', 'analogous colors',
    'triadic colors', 'warm tones', 'cool tones', 'desaturated', 'vibrant colors',
    'pastel colors', 'muted tones', 'high contrast', 'low contrast', 'color temperature',
    'duotone', 'split toning', 'monochrome', 'black and white', 'sepia'
];
ImagePromptOptimizer.renderingKeywords = [
    '8K resolution', 'ultra detailed', 'photorealistic', 'hyperrealistic',
    'octane render', 'unreal engine 5', 'ray tracing', 'ambient occlusion',
    'global illumination', 'subsurface scattering', 'volumetric fog', 'particle effects',
    'motion blur', 'depth of field', 'anti-aliasing', 'post-processing',
    'sharp focus', 'crisp details', 'fine texture', 'realistic materials'
];
ImagePromptOptimizer.atmosphereKeywords = [
    'epic scale', 'grand scale', 'intimate', 'mysterious', 'whimsical',
    'melancholic', 'joyful', 'tense', 'peaceful', 'chaotic', 'ethereal',
    'surreal', 'dreamlike', 'nightmare', 'utopian', 'dystopian',
    'nostalgic', 'futuristic', 'timeless', 'timeless elegance'
];
ImagePromptOptimizer.styleTemplates = {
    realistic: {
        base: 'photorealistic, professional photography, 8K, ultra detailed, cinematic composition',
        lighting: 'natural lighting, soft shadows, volumetric light, ambient occlusion',
        camera: 'shot on Sony A7R IV, 85mm f/1.4 GM, sharp focus, shallow depth of field',
        post: 'color graded, cinematic look, film grain, professional post-processing'
    },
    artistic: {
        base: 'masterpiece, museum quality, award-winning artwork, fine art composition',
        lighting: 'dramatic lighting, chiaroscuro, strong shadows, ethereal glow',
        camera: 'oil painting style, watercolor, mixed media, digital art',
        post: 'artistic brushstrokes, vibrant palette, expressionist style'
    },
    anime: {
        base: 'high quality anime art, studio Ghibli style, Makoto Shinkai style',
        lighting: 'anime lighting, soft bloom, vibrant colors, glowing effects',
        camera: 'manga style, detailed line art, clean composition',
        post: 'anime color palette, vibrant saturation, smooth gradients'
    },
    '3d': {
        base: '3D render, octane render, unreal engine 5, physically based rendering',
        lighting: 'global illumination, ambient occlusion, subsurface scattering, ray tracing',
        camera: 'cinematic camera, depth of field, motion blur, anti-aliasing',
        post: 'post-processing, bloom, chromatic aberration, color grading'
    },
    logo: {
        base: 'professional logo design, minimalist, clean, vector art, scalable',
        lighting: 'flat design, solid colors, subtle gradients',
        camera: 'icon design, symbol design, brand identity',
        post: 'modern branding, corporate identity, versatile usage'
    }
};
class VideoPromptOptimizer {
    static identifyVideoScene(prompt) {
        const sceneKeywords = [];
        if (prompt.match(/叙事|story|narrative|plot/i)) {
            sceneKeywords.push('narrative structure', 'storytelling', 'character development');
        }
        if (prompt.match(/动作|action|chase|fight/i)) {
            sceneKeywords.push('action sequence', 'dynamic editing', 'fast-paced', 'intense');
        }
        if (prompt.match(/风景|landscape|travel|journey/i)) {
            sceneKeywords.push('travel video', 'b-roll footage', 'scenic shots', 'establishing shot');
        }
        if (prompt.match(/采访|interview|documentary/i)) {
            sceneKeywords.push('documentary style', 'interview shot', 'talking head', 'observational');
        }
        if (prompt.match(/音乐|music|dance|performance/i)) {
            sceneKeywords.push('music video', 'performance shot', 'rhythmically edited', 'dynamic');
        }
        return sceneKeywords;
    }
    static optimize(userPrompt, duration = 5, ratio = '9:16') {
        console.log('视频提示词优化 - 原始描述:', userPrompt);
        const allKeywords = [];
        allKeywords.push(...this.videoKeywords.slice(0, 4));
        if (ratio === '9:16') {
            allKeywords.push('vertical composition', 'mobile-first', 'social media vertical');
        }
        else if (ratio === '16:9') {
            allKeywords.push('widescreen', 'cinematic aspect ratio', 'horizontal composition');
        }
        const sceneKeywords = this.identifyVideoScene(userPrompt);
        allKeywords.push(...sceneKeywords);
        if (duration <= 5) {
            allKeywords.push('short video', 'quick impact', 'hook opening');
        }
        else if (duration >= 10) {
            allKeywords.push('long-form video', 'build-up', 'story progression');
        }
        const randomCameraMovement = this.cameraMovement[Math.floor(Math.random() * 5)];
        const randomEffect = this.videoEffects[Math.floor(Math.random() * 3)];
        allKeywords.push(randomCameraMovement, randomEffect);
        const optimizedPrompt = `${userPrompt}, ${allKeywords.join(', ')}`;
        console.log('视频提示词优化 - 优化后:', optimizedPrompt.substring(0, 200) + '...');
        return optimizedPrompt;
    }
}
VideoPromptOptimizer.videoKeywords = [
    'cinematic video', 'high production value', 'smooth motion', 'professional cinematography',
    'dynamic camera movement', 'stabilized footage', 'fluid motion', 'natural movement',
    'atmospheric video', 'immersive experience', 'visual storytelling', 'narrative composition'
];
VideoPromptOptimizer.cameraMovement = [
    'camera pan', 'camera tilt', 'tracking shot', 'dolly shot', 'crane shot',
    'handheld camera', 'steady cam', 'drone shot', 'aerial view', 'POV shot',
    'zoom in', 'zoom out', 'rack focus', 'follow focus', 'dutch angle',
    'slow motion', 'fast motion', 'time-lapse', 'hyper-lapse', 'reverse motion'
];
VideoPromptOptimizer.videoEffects = [
    'motion blur', 'depth of field', 'lens flare', 'film grain', 'vignette',
    'color grading', 'cinematic color', 'anamorphic look', 'letterbox', 'film look',
    'glitch effect', 'motion graphics', 'visual effects', 'CGI', 'practical effects'
];
VideoPromptOptimizer.editingKeywords = [
    'smooth transition', 'cross dissolve', 'fade in', 'fade out', 'match cut',
    'jump cut', 'parallel editing', 'montage', 'slow-motion sequence', 'rhythmic editing'
];
async function analyzeImageContent(imageUrl) {
    try {
        const config = new coze_coding_dev_sdk_1.Config();
        const client = new coze_coding_dev_sdk_1.LLMClient(config);
        console.log(`[图片理解] 分析图片: ${imageUrl}`);
        const response = await client.invoke([
            {
                role: 'user',
                content: [
                    { type: 'text', text: '请详细描述这张图片的内容，包括：1. 图片主题/场景 2. 主要元素 3. 文字内容（如果有）4. 图片风格/氛围。请用简洁的语言描述，便于与文章段落匹配。' },
                    { type: 'image_url', image_url: { url: imageUrl } }
                ]
            }
        ], {
            model: 'doubao-vision-pro-251228',
            temperature: 0.3
        });
        const description = response.content.trim();
        console.log(`[图片理解] 图片分析结果: ${description.substring(0, 100)}...`);
        return description;
    }
    catch (error) {
        console.error(`[图片理解] 分析图片失败: ${imageUrl}`, error);
        return '';
    }
}
function calculateSimilarity(text1, text2) {
    const normalize = (text) => {
        return text.toLowerCase()
            .replace(/[^\u4e00-\u9fa5a-z0-9]/g, ' ')
            .split(/\s+/)
            .filter(w => w.length > 1);
    };
    const words1 = normalize(text1);
    const words2 = normalize(text2);
    if (words1.length === 0 || words2.length === 0)
        return 0;
    const commonWords = words1.filter(w => words2.includes(w));
    const uniqueWords = [...new Set([...words1, ...words2])];
    return commonWords.length / uniqueWords.length;
}
async function smartInsertImagesToArticle(content, title, uploadedImages) {
    console.log(`[智能配图] 开始为文章智能配图，共 ${uploadedImages.length} 张图片`);
    console.log(`[智能配图] 图片URLs:`, uploadedImages);
    if (!content || content.trim().length === 0) {
        console.log('[智能配图] 文章内容为空，直接返回原文');
        return content;
    }
    if (!uploadedImages || uploadedImages.length === 0) {
        console.log('[智能配图] 没有用户上传的图片，直接返回原文');
        return content;
    }
    const imageAnalyses = await Promise.all(uploadedImages.map(async (url, idx) => {
        const description = await analyzeImageContent(url);
        return {
            url,
            description,
            index: idx
        };
    }));
    console.log('[智能配图] 图片分析完成:', imageAnalyses.map(img => ({
        index: img.index,
        description: img.description.substring(0, 50) + '...'
    })));
    const paragraphs = content.split('\n\n').filter(p => p.trim());
    console.log(`[智能配图] 文章共 ${paragraphs.length} 个段落`);
    if (paragraphs.length === 0) {
        console.log('[智能配图] 文章没有段落，直接在开头插入所有图片');
        let contentWithImages = '';
        for (const imageAnalysis of imageAnalyses) {
            contentWithImages += `\n![${imageAnalysis.description.substring(0, 30)}](${imageAnalysis.url})\n\n`;
        }
        return contentWithImages + content;
    }
    const imageInsertions = [];
    for (const imageAnalysis of imageAnalyses) {
        let bestMatch = { paragraphIndex: 0, score: 0 };
        for (let i = 0; i < paragraphs.length; i++) {
            const paragraph = paragraphs[i];
            if (paragraph.startsWith('#') || paragraph.startsWith('>') || paragraph.length < 20) {
                continue;
            }
            const score = calculateSimilarity(paragraph, imageAnalysis.description);
            console.log(`[智能配图] 图片${imageAnalysis.index} 与段落${i} 相似度: ${score.toFixed(3)}`);
            if (score > bestMatch.score) {
                bestMatch = { paragraphIndex: i, score };
            }
        }
        if (bestMatch.score < 0.05 && imageAnalyses.length > 0) {
            bestMatch.paragraphIndex = Math.floor((imageAnalysis.index + 1) * paragraphs.length / (imageAnalyses.length + 1));
            console.log(`[智能配图] 图片${imageAnalysis.index} 相似度太低，使用默认位置: ${bestMatch.paragraphIndex}`);
        }
        imageInsertions.push({
            paragraphIndex: bestMatch.paragraphIndex,
            imageUrl: imageAnalysis.url,
            description: imageAnalysis.description,
            score: bestMatch.score
        });
    }
    imageInsertions.sort((a, b) => a.paragraphIndex - b.paragraphIndex);
    console.log('[智能配图] 插入位置规划:', imageInsertions.map(img => ({
        paragraphIndex: img.paragraphIndex,
        score: img.score.toFixed(3)
    })));
    let contentWithImages = '';
    let lastParagraphIndex = 0;
    for (const insertion of imageInsertions) {
        for (let i = lastParagraphIndex; i <= insertion.paragraphIndex && i < paragraphs.length; i++) {
            contentWithImages += paragraphs[i] + '\n\n';
        }
        contentWithImages += `\n![${insertion.description.substring(0, 30)}](${insertion.imageUrl})\n\n`;
        console.log(`[智能配图] 已在段落 ${insertion.paragraphIndex} 后插入图片，URL: ${insertion.imageUrl.substring(0, 50)}...`);
        lastParagraphIndex = insertion.paragraphIndex + 1;
    }
    for (let i = lastParagraphIndex; i < paragraphs.length; i++) {
        contentWithImages += paragraphs[i] + '\n\n';
    }
    const finalImageMatches = contentWithImages.match(/!\[.*?\]\(.*?\)/g);
    console.log(`[智能配图] 最终文章中的图片数量:`, finalImageMatches?.length || 0);
    return contentWithImages.trim();
}
async function generateAIImagesForArticle(content, title, uploadedImagePositions, imageClient) {
    console.log(`[AI配图] 为用户图片未覆盖的段落生成 AI 配图`);
    console.log(`[AI配图] 已包含用户图片的段落索引:`, [...uploadedImagePositions]);
    let contentWithImages = content;
    const paragraphs = content.split('\n\n').filter(p => p.trim());
    console.log(`[AI配图] 总段落数:`, paragraphs.length);
    const aiImagePositions = [];
    let currentPos = 0;
    let contentParagraphCount = 0;
    for (let i = 0; i < paragraphs.length; i++) {
        const paragraph = paragraphs[i];
        const isContentParagraph = !paragraph.startsWith('#') && !paragraph.startsWith('>') && paragraph.length > 20;
        if (isContentParagraph) {
            contentParagraphCount++;
            if (contentParagraphCount % 3 === 0 && !uploadedImagePositions.has(i) && aiImagePositions.length < 3) {
                aiImagePositions.push({
                    index: i,
                    position: currentPos,
                    text: paragraph.substring(0, 100)
                });
            }
        }
        currentPos += paragraph.length + 2;
    }
    console.log(`[AI配图] 计划生成 ${aiImagePositions.length} 张 AI 配图`);
    for (let i = aiImagePositions.length - 1; i >= 0; i--) {
        const { position, text } = aiImagePositions[i];
        try {
            console.log(`[AI配图] 正在生成第 ${i + 1} 张 AI 配图...`);
            const imgResponse = await imageClient.generate({
                prompt: `公众号文章配图，${title}相关，抽象概念图，简约现代风格，${text.substring(0, 80)}`,
                size: '1K',
                watermark: false
            });
            const imgHelper = imageClient.getResponseHelper(imgResponse);
            if (imgHelper.success && imgHelper.imageUrls.length > 0) {
                const imgUrl = imgHelper.imageUrls[0];
                const imageMarkdown = `\n\n![AI生成配图](${imgUrl})\n\n`;
                contentWithImages = contentWithImages.slice(0, position) + imageMarkdown + contentWithImages.slice(position);
                console.log(`[AI配图] 第 ${i + 1} 张 AI 配图插入成功`);
            }
        }
        catch (error) {
            console.error(`[AI配图] 生成第 ${i + 1} 张配图失败:`, error);
        }
    }
    return contentWithImages;
}
async function addImagesToArticleContent(content, title, uploadedImages) {
    try {
        const config = new coze_coding_dev_sdk_1.Config();
        const imageClient = new coze_coding_dev_sdk_1.ImageGenerationClient(config);
        let contentWithImages = '';
        if (uploadedImages && uploadedImages.length > 0) {
            console.log(`[文章配图] 用户上传了 ${uploadedImages.length} 张图片，先进行智能匹配`);
            const contentWithUserImages = await smartInsertImagesToArticle(content, title, uploadedImages);
            console.log('[文章配图] 文章内容前200字符:', content.substring(0, 200));
            console.log('[文章配图] 配图后的内容前500字符:', contentWithUserImages.substring(0, 500));
            const paragraphs = content.split('\n\n').filter(p => p.trim());
            const uploadedImagePositions = new Set();
            const contentParagraphsWithUserImages = contentWithUserImages.split('\n\n');
            console.log(`[文章配图] 配图后的段落数量:`, contentParagraphsWithUserImages.length);
            for (let i = 0; i < contentParagraphsWithUserImages.length; i++) {
                const paragraph = contentParagraphsWithUserImages[i];
                const hasUserImage = uploadedImages.some(url => {
                    const isIncluded = paragraph.includes(url);
                    if (isIncluded) {
                        console.log(`[文章配图] 段落 ${i} 包含图片:`, url.substring(0, 50));
                    }
                    return isIncluded;
                });
                if (hasUserImage) {
                    uploadedImagePositions.add(i);
                    console.log(`[文章配图] 段落 ${i} 已标记为包含用户图片`);
                }
            }
            console.log(`[文章配图] 用户图片覆盖了 ${uploadedImagePositions.size} 个段落，段落索引:`, [...uploadedImagePositions]);
            contentWithImages = await generateAIImagesForArticle(contentWithUserImages, title, uploadedImagePositions, imageClient);
            return contentWithImages;
        }
        const coverPrompt = `${title}，文章配图，简约现代风格，专业设计`;
        console.log('正在生成文章开头配图...');
        const coverResponse = await imageClient.generate({
            prompt: `${coverPrompt}, social media style, clean layout`,
            size: '1K',
            watermark: false
        });
        const coverHelper = imageClient.getResponseHelper(coverResponse);
        if (coverHelper.success && coverHelper.imageUrls.length > 0) {
            const coverUrl = coverHelper.imageUrls[0];
            contentWithImages = `![${title}](${coverUrl})\n\n`;
            console.log('开头配图生成成功');
        }
        contentWithImages += content;
        const paragraphs = content.split('\n\n').filter(p => p.trim());
        const imagePositions = [];
        let currentPos = 0;
        for (let i = 0; i < paragraphs.length; i++) {
            currentPos += paragraphs[i].length + 2;
            if ((i + 1) % 4 === 0 && imagePositions.length < 3) {
                imagePositions.push(currentPos);
            }
        }
        for (let i = imagePositions.length - 1; i >= 0; i--) {
            const pos = imagePositions[i];
            const nearbyText = content.substring(Math.max(0, pos - 100), pos + 100);
            try {
                console.log(`正在生成第 ${i + 1} 张章节配图...`);
                const imgResponse = await imageClient.generate({
                    prompt: `文章配图，抽象概念图，简约现代风格，${nearbyText.substring(0, 50)}`,
                    size: '1K',
                    watermark: false
                });
                const imgHelper = imageClient.getResponseHelper(imgResponse);
                if (imgHelper.success && imgHelper.imageUrls.length > 0) {
                    const imgUrl = imgHelper.imageUrls[0];
                    const imageMarkdown = `\n\n![文章配图](${imgUrl})\n\n`;
                    contentWithImages = contentWithImages.slice(0, pos) + imageMarkdown + contentWithImages.slice(pos);
                    console.log(`第 ${i + 1} 张配图插入成功`);
                }
            }
            catch (err) {
                console.error(`生成第 ${i + 1} 张配图失败:`, err);
            }
        }
        console.log(`文章配图完成，共生成配图`);
        return contentWithImages;
    }
    catch (err) {
        console.error('文章配图失败:', err);
        return content;
    }
}
let WriteArticleTool = class WriteArticleTool {
    constructor() {
        this.definition = {
            name: 'write_article',
            displayName: '撰写文章',
            description: '【通用文章写作】当用户要求"写文章"、"写文案"、"写内容"、"撰写文本"时使用此工具。适用于一般的文章、文案、内容生成，不限于特定平台。如果用户明确要求"公众号图文"或"小红书笔记"，请使用相应的专用工具（write_wechat_mp_article 或 write_xiaohongshu_note）。',
            category: 'content_creation',
            paramsSchema: {
                topic: { type: 'string', description: '文章主题', required: true },
                style: { type: 'string', enum: ['formal', 'casual', 'professional', 'creative'], default: 'professional' },
                length: { type: 'number', description: '目标字数', default: 800 },
                keywords: { type: 'array', items: { type: 'string' }, description: '关键词' },
                outline: { type: 'string', description: '文章大纲' }
            }
        };
    }
    async execute(params, context) {
        try {
            const config = new coze_coding_dev_sdk_1.Config();
            const client = new coze_coding_dev_sdk_1.LLMClient(config);
            const styleGuide = {
                formal: '正式、严谨、专业',
                casual: '轻松、活泼、亲切',
                professional: '专业、客观、有深度',
                creative: '创意、独特、有想象力'
            };
            let imageContext = '';
            if (context.uploadedImages && context.uploadedImages.length > 0) {
                imageContext = `\n\n【用户上传的图片】\n用户上传了 ${context.uploadedImages.length} 张图片，请理解这些图片的内容，并在生成文章时恰当地引用和描述这些图片。\n图片链接：${context.uploadedImages.join(', ')}\n\n`;
            }
            const prompt = `请撰写一篇关于「${params.topic}」的文章。${imageContext}
要求：
- 风格：${styleGuide[params.style] || '专业、客观'}
- 目标字数：${params.length || 800}字左右
${params.keywords ? `- 包含关键词：${params.keywords.join('、')}` : ''}
${params.outline ? `- 参考大纲：${params.outline}` : ''}
${context.uploadedImages && context.uploadedImages.length > 0 ? '- 请在文章的合适位置插入用户上传的图片，并描述图片内容' : ''}

请直接输出文章内容，使用Markdown格式。`;
            const response = await client.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.7
            });
            const content = response.content.trim();
            const titleMatch = content.match(/^#\s*(.+)$/m);
            const title = titleMatch ? titleMatch[1] : params.topic;
            let finalContent = content;
            if (context.uploadedImages && context.uploadedImages.length > 0) {
                finalContent = await addImagesToArticleContent(content, title, context.uploadedImages);
            }
            return {
                success: true,
                data: {
                    title,
                    content: finalContent,
                    word_count: content.length,
                    style: params.style,
                    message: `${title}`
                }
            };
        }
        catch (err) {
            return { success: false, error: `撰写文章失败: ${err.message}` };
        }
    }
};
exports.WriteArticleTool = WriteArticleTool;
exports.WriteArticleTool = WriteArticleTool = __decorate([
    (0, common_1.Injectable)()
], WriteArticleTool);
let WriteWechatMpArticleTool = class WriteWechatMpArticleTool {
    constructor() {
        this.definition = {
            name: 'write_wechat_mp_article',
            displayName: '撰写公众号爆款图文',
            description: '【专门用于微信公众号】生成适合微信公众号传播的爆款图文，包含吸睛标题、短段落、金句、引导关注等元素。当用户要求"写公众号图文"、"写文章"、"写公众号爆款"时使用此工具。此工具仅生成内容，发布需要配合 publish_wechat_mp 工具。',
            category: 'content_creation',
            paramsSchema: {
                topic: { type: 'string', description: '文章主题/话题', required: true },
                target_audience: { type: 'string', description: '目标受众（如：职场人、宝妈、大学生）' },
                emotion: { type: 'string', enum: ['励志', '治愈', '干货', '情感', '热点'], default: '干货' },
                keywords: { type: 'array', items: { type: 'string' }, description: '关键词/标签' },
                include_cover: { type: 'boolean', description: '是否生成封面图', default: true }
            }
        };
    }
    async execute(params, context) {
        try {
            const config = new coze_coding_dev_sdk_1.Config();
            const client = new coze_coding_dev_sdk_1.LLMClient(config);
            const emotionStyles = {
                励志: '积极向上，激发斗志，让人充满力量',
                治愈: '温暖人心，缓解焦虑，给人安慰',
                干货: '实用有价值，解决实际问题，方法论明确',
                情感: '引发共鸣，触动人心，情感真挚',
                热点: '紧跟时事，观点鲜明，引发讨论'
            };
            const prompt = `你是一位专业的公众号爆款文案撰写专家。请为以下主题撰写一篇公众号爆款图文：

主题：${params.topic}
${params.target_audience ? `目标受众：${params.target_audience}` : ''}
情感基调：${emotionStyles[params.emotion] || emotionStyles.干货}
${params.keywords?.length ? `关键词：${params.keywords.join('、')}` : ''}

请严格按照以下公众号爆款格式输出：

## 标题
（生成3-5个吸睛标题选项，使用标题党技巧：数字、疑问、反差、悬念、情绪词等）

## 封面图提示词
（用一句话描述适合的封面图片风格和内容，用于AI生成封面图）

## 正文

（正文要求：）
1. 开头用一个金句或故事引入，快速抓住读者注意力
2. 段落要短，每段不超过3行，方便手机阅读
3. 每2-3段插入一个「金句卡片」或「重点标记」，格式如下：
   > 💡 金句内容

4. 适当使用emoji增加亲和力 😊
5. 正文1000-2000字为宜
6. 结尾要有行动引导（点赞、在看、关注、转发）

## 标签
（生成3-5个适合的公众号标签）

---

现在开始创作：`;
            const response = await client.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.8
            });
            let articleContent = response.content.trim();
            const titleSection = articleContent.match(/## 标题\n([\s\S]*?)(?=## 封面图|$)/i);
            let titles = [];
            if (titleSection) {
                titles = titleSection[1].split('\n')
                    .map((t) => t.replace(/^[\d\.\-\*]+\s*/, '').trim())
                    .filter((t) => t.length > 0);
            }
            const coverMatch = articleContent.match(/## 封面图提示词\n([\s\S]*?)(?=## 正文|$)/i);
            const coverPrompt = coverMatch ? coverMatch[1].trim() : `${params.topic}，清新简约风格`;
            const contentMatch = articleContent.match(/## 正文\n([\s\S]*?)(?=## 标签|$)/i);
            const mainContent = contentMatch ? contentMatch[1].trim() : articleContent;
            const tagsMatch = articleContent.match(/## 标签\n([\s\S]*?)$/i);
            let tags = [];
            if (tagsMatch) {
                tags = tagsMatch[1].split(/[,，\n]/)
                    .map((t) => t.replace(/^[\#\－\*]+\s*/, '').trim())
                    .filter((t) => t.length > 0);
            }
            let coverImageUrl;
            if (params.include_cover) {
                try {
                    const imageClient = new coze_coding_dev_sdk_1.ImageGenerationClient(config);
                    const imageResponse = await imageClient.generate({
                        prompt: `${coverPrompt}, social media cover style, clean and modern, text-friendly background`,
                        size: '1K',
                        watermark: false
                    });
                    const helper = imageClient.getResponseHelper(imageResponse);
                    if (helper.success && helper.imageUrls.length > 0) {
                        coverImageUrl = helper.imageUrls[0];
                    }
                }
                catch (imgErr) {
                    console.error('生成封面图失败:', imgErr);
                }
            }
            console.log('[公众号写作] 用户上传图片数量:', context.uploadedImages?.length || 0);
            console.log('[公众号写作] 用户上传图片URLs:', context.uploadedImages || []);
            console.log('[公众号写作] 正在为文章添加配图...');
            const contentWithImages = await addImagesToArticleContent(mainContent, titles[0] || params.topic, context.uploadedImages);
            console.log('[公众号写作] 配图后内容长度:', contentWithImages.length);
            const imageMatches = contentWithImages.match(/!\[.*?\]\(.*?\)/g);
            console.log('[公众号写作] 内容中图片数量:', imageMatches?.length || 0);
            console.log('[公众号写作] 内容中图片URLs:', imageMatches || []);
            const publishParams = {
                title: titles[0] || params.topic,
                content: contentWithImages,
                cover_url: coverImageUrl,
                digest: mainContent.substring(0, 54).replace(/\n/g, ' ') + '...'
            };
            return {
                success: true,
                data: {
                    title: titles[0] || params.topic,
                    title_options: titles,
                    content: contentWithImages,
                    cover_image_url: coverImageUrl,
                    cover_prompt: coverPrompt,
                    tags,
                    word_count: mainContent.length,
                    message: `✅ 公众号文章已生成！你可以在上方查看完整内容（包含标题、正文和封面图）。

文章标题：《${titles[0] || params.topic}》
文章字数：${mainContent.length} 字

如需发布到微信公众号，请先绑定公众号授权，然后发送"发布到公众号"即可。

📝 提示：文章内容显示在当前对话中，你可以直接查看、复制或编辑。`,
                    next_action_hint: `文章已生成。如果用户要求发布到公众号，请使用 publish_wechat_mp 工具，参数如下：
{
  "title": "${publishParams.title}",
  "content": "请使用上方完整的 content 内容",
  "cover_url": "${publishParams.cover_url || '自动生成'}"
}`
                }
            };
        }
        catch (err) {
            return { success: false, error: `撰写公众号图文失败: ${err.message}` };
        }
    }
};
exports.WriteWechatMpArticleTool = WriteWechatMpArticleTool;
exports.WriteWechatMpArticleTool = WriteWechatMpArticleTool = __decorate([
    (0, common_1.Injectable)()
], WriteWechatMpArticleTool);
let WriteXiaohongshuNoteTool = class WriteXiaohongshuNoteTool {
    constructor() {
        this.definition = {
            name: 'write_xiaohongshu_note',
            displayName: '撰写小红书笔记',
            description: '【专门用于小红书】生成适合小红书传播的爆款笔记，包含emoji标题、分段式正文、话题标签、多张配图。当用户要求"写小红书笔记"、"小红书文案"、"小红书内容"时使用此工具。此工具仅生成内容，发布需要配合 publish_xiaohongshu 工具。',
            category: 'content_creation',
            paramsSchema: {
                topic: { type: 'string', description: '笔记主题', required: true },
                style: { type: 'string', enum: ['种草', '干货', '分享', '吐槽', '安利'], default: '干货' },
                images_count: { type: 'number', description: '配图数量（1-9张）', default: 3 }
            }
        };
    }
    async execute(params, context) {
        try {
            const config = new coze_coding_dev_sdk_1.Config();
            const client = new coze_coding_dev_sdk_1.LLMClient(config);
            const imageClient = new coze_coding_dev_sdk_1.ImageGenerationClient(config);
            let imageContext = '';
            if (context.uploadedImages && context.uploadedImages.length > 0) {
                imageContext = `\n\n【用户上传的图片】\n用户上传了 ${context.uploadedImages.length} 张图片，请理解这些图片的内容，并在生成小红书笔记时恰当地引用和描述这些图片。\n图片链接：${context.uploadedImages.join(', ')}\n\n`;
            }
            const prompt = `你是一位小红书爆款笔记撰写专家。请为以下主题撰写一篇小红书笔记：

主题：${params.topic}
风格：${params.style}
${imageContext}
请严格按照以下小红书爆款格式输出：

## 标题
（生成3个带emoji的吸睛标题，20字以内）

## 正文
（小红书风格：）
1. 开头用emoji和提问/感叹句吸引注意
2. 分点阐述，每点用emoji开头
3. 中间穿插「」强调关键词
4. 结尾引导互动（点赞收藏评论）
5. 正文300-500字，短小精悍
6. 每段1-2行，方便阅读
${context.uploadedImages && context.uploadedImages.length > 0 ? '7. 在合适的位置引用用户上传的图片，并描述图片内容' : ''}

## 话题标签
（生成5-10个热门话题标签，带#号）

---

现在开始创作：`;
            const response = await client.invoke([
                { role: 'user', content: prompt }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.8
            });
            const content = response.content.trim();
            const titleSection = content.match(/## 标题\n([\s\S]*?)(?=## 正文|$)/i);
            let titles = [];
            if (titleSection) {
                titles = titleSection[1].split('\n')
                    .map((t) => t.replace(/^[\d\.\-\*]+\s*/, '').trim())
                    .filter((t) => t.length > 0);
            }
            const contentMatch = content.match(/## 正文\n([\s\S]*?)(?=## 话题|$)/i);
            const mainContent = contentMatch ? contentMatch[1].trim() : content;
            const tagsMatch = content.match(/## 话题标签\n([\s\S]*?)$/i);
            let tags = [];
            if (tagsMatch) {
                tags = tagsMatch[1].match(/#[^\s#]+/g) || [];
            }
            const imageUrls = [];
            if (context.uploadedImages && context.uploadedImages.length > 0) {
                console.log(`使用用户上传的 ${context.uploadedImages.length} 张图片作为小红书笔记配图`);
                imageUrls.push(...context.uploadedImages);
            }
            else {
                const imageCount = Math.min(Math.max(params.images_count || 3, 1), 9);
                for (let i = 0; i < imageCount; i++) {
                    try {
                        const imgPrompt = `小红书风格${params.style}笔记配图，${params.topic}，${titles[0] || ''}，ins风格，色彩鲜艳，种草感强，简洁明了`;
                        const imgResponse = await imageClient.generate({
                            prompt: imgPrompt,
                            size: '1K',
                            watermark: false
                        });
                        const imgHelper = imageClient.getResponseHelper(imgResponse);
                        if (imgHelper.success && imgHelper.imageUrls.length > 0) {
                            imageUrls.push(imgHelper.imageUrls[0]);
                        }
                    }
                    catch (err) {
                        console.error(`生成第 ${i + 1} 张配图失败:`, err);
                    }
                }
            }
            return {
                success: true,
                data: {
                    title: titles[0] || params.topic,
                    title_options: titles,
                    content: mainContent,
                    tags,
                    images: imageUrls,
                    image_count: imageUrls.length,
                    message: `${titles[0] || params.topic}`,
                    xiaohongshu_content: {
                        title: titles[0] || params.topic,
                        content: mainContent,
                        tags,
                        images: imageUrls
                    }
                }
            };
        }
        catch (err) {
            return { success: false, error: `撰写小红书笔记失败: ${err.message}` };
        }
    }
};
exports.WriteXiaohongshuNoteTool = WriteXiaohongshuNoteTool;
exports.WriteXiaohongshuNoteTool = WriteXiaohongshuNoteTool = __decorate([
    (0, common_1.Injectable)()
], WriteXiaohongshuNoteTool);
let GenerateImageTool = class GenerateImageTool {
    constructor() {
        this.definition = {
            name: 'generate_image',
            displayName: '生成图片',
            description: '根据文字描述生成高质量图片，适用于Logo设计、海报、插画、产品设计等。当用户需要"生成图片"、"画一张图"、"设计Logo"时使用此工具。',
            category: 'content_creation',
            paramsSchema: {
                prompt: { type: 'string', description: '图片描述，详细描述想要生成的图片内容、风格、色彩等', required: true },
                style: { type: 'string', enum: ['realistic', 'artistic', 'anime', '3d', 'logo'], default: 'realistic', description: '图片风格' },
                size: { type: 'string', enum: ['1K', '2K', '4K'], default: '2K', description: '图片分辨率' }
            }
        };
    }
    async execute(params, context) {
        try {
            console.log('Agent工具 - 生成图片:', params.prompt);
            const optimizedPrompt = ImagePromptOptimizer.optimize(params.prompt, params.style || 'realistic');
            const apiUrl = 'https://ark.cn-beijing.volces.com/api/v3/images/generations';
            const apiKey = process.env.VOLC_VIDEO_API_KEY || '0a6405d5-b7ae-4afa-88e3-c707ae379a47';
            console.log('Agent工具 - 调用豆包图片生成 API:', {
                prompt_length: optimizedPrompt.length,
                size: params.size || '2K',
                style: params.style || 'realistic'
            });
            const response = await axios_1.default.post(apiUrl, {
                model: 'doubao-seedream-4-0-250828',
                prompt: optimizedPrompt,
                sequential_image_generation: 'disabled',
                response_format: 'url',
                size: params.size || '2K',
                stream: false,
                watermark: false
            }, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${apiKey}`
                },
                timeout: 120000
            });
            console.log('Agent工具 - 豆包图片生成 API响应:', response.status, response.statusText);
            if (response.status !== 200) {
                const errorMsg = response.data?.error?.message || response.data?.message || '图片生成失败';
                console.error('Agent工具 - 图片生成失败:', errorMsg);
                return { success: false, error: `图片生成失败: ${errorMsg}` };
            }
            const responseData = response.data;
            const imageData = responseData?.data || responseData;
            let imageUrls = [];
            if (Array.isArray(imageData)) {
                imageUrls = imageData.map((img) => img.url).filter(Boolean);
            }
            else if (imageData?.url) {
                imageUrls = [imageData.url];
            }
            else if (imageData?.image_urls) {
                imageUrls = imageData.image_urls;
            }
            else if (typeof responseData === 'string') {
                imageUrls = [responseData];
            }
            if (imageUrls.length === 0) {
                const errorMsg = responseData?.message || '未获取到图片URL';
                console.error('Agent工具 - 未获取到图片URL:', errorMsg, responseData);
                return { success: false, error: `图片生成失败: ${errorMsg}` };
            }
            console.log('Agent工具 - 图片生成成功，CDN URL:', imageUrls[0]);
            console.log('Agent工具 - URL来源:', imageUrls[0].includes('tos-cn-guangzhou') ? '火山引擎TOS CDN' : '未知');
            return {
                success: true,
                data: {
                    image_urls: imageUrls,
                    prompt: params.prompt,
                    optimized_prompt: optimizedPrompt,
                    style: params.style,
                    size: params.size,
                    cdn_urls: imageUrls,
                    message: `图片已生成`
                }
            };
        }
        catch (err) {
            console.error('Agent工具 - 图片生成异常:', err);
            let errorMsg = err.message || '未知错误';
            if (err.response) {
                const apiError = err.response.data;
                errorMsg = apiError?.error?.message || apiError?.message || `API错误 (${err.response.status})`;
            }
            else if (err.code === 'ECONNABORTED' || errorMsg.includes('timeout') || errorMsg.includes('Timeout')) {
                errorMsg = '图片生成超时，请稍后重试。图片生成通常需要30-60秒。';
            }
            else if (err.message?.includes('403') || err.statusCode === 403) {
                errorMsg = '图片生成服务暂时不可用，可能是API配额已用完或权限问题，请稍后再试或联系管理员';
            }
            else if (err.message?.includes('rate limit') || err.message?.includes('429')) {
                errorMsg = '图片生成请求过于频繁，请稍等片刻再试';
            }
            return { success: false, error: `生成图片失败: ${errorMsg}` };
        }
    }
};
exports.GenerateImageTool = GenerateImageTool;
exports.GenerateImageTool = GenerateImageTool = __decorate([
    (0, common_1.Injectable)()
], GenerateImageTool);
let GenerateVideoTool = class GenerateVideoTool {
    constructor() {
        this.definition = {
            name: 'generate_video',
            displayName: '生成视频',
            description: '【个人IP打造】使用AI生成高质量视频，支持文字描述生成视频，支持用户上传的图片/视频/音频作为参考（如果用户上传了这些素材，优先使用用户上传的素材；如果没有上传，可以使用分身头像作为参考图片）。适用于个人IP打造、口播视频、产品展示等场景。当用户需要"生成视频"、"做一个视频"、"创作视频"时使用此工具。注意：视频生成需要1-5分钟，请耐心等待。',
            category: 'content_creation',
            paramsSchema: {
                prompt: { type: 'string', description: '视频内容描述，详细描述想要生成的视频画面、动作、风格等', required: true },
                duration: { type: 'number', description: '视频时长（秒），支持4-12秒，默认5秒', default: 5 },
                ratio: { type: 'string', enum: ['16:9', '9:16', '1:1', 'adaptive'], default: '9:16', description: '视频比例，9:16适合手机竖屏，16:9适合横屏，adaptive自动选择' },
                reference_images: { type: 'array', items: { type: 'string' }, description: '参考图片URL列表（可选）。如果用户上传了图片，优先使用用户上传的图片；如果没有上传图片，可以使用分身头像作为参考图片' },
                reference_videos: { type: 'array', items: { type: 'string' }, description: '参考视频URL列表（可选），如果用户上传了视频，优先使用用户上传的视频' },
                reference_audios: { type: 'array', items: { type: 'string' }, description: '参考音频URL列表（可选），如果用户上传了音频，优先使用用户上传的音频' },
                generate_audio: { type: 'boolean', description: '是否自动生成音频', default: true }
            }
        };
        this.storage = new coze_coding_dev_sdk_1.S3Storage({
            endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL || 'https://tos-cn-guangzhou.volces.com',
            accessKey: process.env.VOLC_ACCESS_KEY || '',
            secretKey: process.env.VOLC_SECRET_KEY || '',
            bucketName: process.env.COZE_BUCKET_NAME || 'morena-ai',
            region: 'cn-guangzhou',
        });
    }
    async execute(params, context) {
        try {
            console.log('Agent工具 - 生成视频开始:', params.prompt?.substring(0, 100));
            console.log('Agent工具 - 视频参数:', { duration: params.duration, ratio: params.ratio });
            const hasReferenceImages = params.reference_images && Array.isArray(params.reference_images) && params.reference_images.length > 0;
            let userPrompt = params.prompt;
            if (hasReferenceImages) {
                if (!userPrompt.includes('图片') && !userPrompt.includes('参考') && !userPrompt.includes('基于')) {
                    userPrompt = `基于提供的参考图片，${userPrompt}`;
                }
                console.log('[ContentCreationTool] 用户上传了参考图片，优化后的提示词:', userPrompt.substring(0, 100));
            }
            const optimizedPrompt = VideoPromptOptimizer.optimize(userPrompt, params.duration || 5, params.ratio || '9:16');
            const content = [];
            if (params.reference_images && Array.isArray(params.reference_images) && params.reference_images.length > 0) {
                console.log('[ContentCreationTool] 用户上传了参考图片，需要先上传到TOS以确保可访问');
                for (const imgUrl of params.reference_images) {
                    try {
                        if (imgUrl.includes('tos-cn-') && imgUrl.includes('volces.com')) {
                            console.log('[ContentCreationTool] 图片已在TOS上，直接使用:', imgUrl.substring(0, 60));
                            if (typeof imgUrl === 'string' && imgUrl.length > 0) {
                                content.push({
                                    type: 'image_url',
                                    image_url: { url: imgUrl },
                                    role: 'first_frame'
                                });
                                console.log('[ContentCreationTool] 已添加首帧图片到content:', imgUrl.substring(0, 60));
                            }
                        }
                        else {
                            console.log('[ContentCreationTool] 下载用户图片并上传到TOS:', imgUrl.substring(0, 60));
                            const imgResponse = await fetch(imgUrl);
                            if (!imgResponse.ok) {
                                throw new Error(`下载图片失败: ${imgResponse.status}`);
                            }
                            const imgBuffer = Buffer.from(await imgResponse.arrayBuffer());
                            const timestamp = Date.now();
                            const imgKey = await this.storage.uploadFile({
                                fileContent: imgBuffer,
                                fileName: `video-reference/${timestamp}.jpg`,
                                contentType: 'image/jpeg'
                            });
                            const tosImgUrl = await this.storage.generatePresignedUrl({
                                key: imgKey,
                                expireTime: 86400 * 7
                            });
                            console.log('[ContentCreationTool] 图片已上传到TOS:', tosImgUrl.substring(0, 60));
                            if (typeof tosImgUrl === 'string' && tosImgUrl.length > 0) {
                                content.push({
                                    type: 'image_url',
                                    image_url: { url: tosImgUrl },
                                    role: 'first_frame'
                                });
                                console.log('[ContentCreationTool] 已添加首帧图片到content:', tosImgUrl.substring(0, 60));
                            }
                            else {
                                console.error('[ContentCreationTool] TOS URL无效:', tosImgUrl);
                            }
                        }
                    }
                    catch (imgError) {
                        console.error('[ContentCreationTool] 处理参考图片失败:', imgError.message);
                    }
                }
            }
            content.push({
                type: 'text',
                text: optimizedPrompt
            });
            if (params.reference_audios && Array.isArray(params.reference_audios)) {
                for (const audioUrl of params.reference_audios) {
                    content.push({
                        type: 'audio_url',
                        audio_url: { url: audioUrl },
                        role: 'reference_audio'
                    });
                }
            }
            const apiUrl = 'https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks';
            const apiKey = process.env.VOLC_VIDEO_API_KEY || '0a6405d5-b7ae-4afa-88e3-c707ae379a47';
            console.log('Agent工具 - 构建的content数组:', JSON.stringify(content, null, 2));
            console.log('Agent工具 - 调用豆包视频生成 API:', {
                content_count: content.length,
                has_reference_images: params.reference_images?.length || 0,
                has_reference_videos: params.reference_videos?.length || 0,
                has_reference_audios: params.reference_audios?.length || 0,
                ratio: params.ratio || '9:16',
                duration: params.duration || 5,
                watermark: params.watermark !== false
            });
            const response = await axios_1.default.post(apiUrl, {
                model: 'doubao-seedance-2-0-260128',
                content: content,
                generate_audio: params.generate_audio !== false,
                ratio: params.ratio || '9:16',
                duration: params.duration || 5,
                watermark: params.watermark !== false
            }, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${apiKey}`
                },
                timeout: 300000
            });
            console.log('Agent工具 - 豆包API响应:', response.status, response.statusText);
            if (response.status !== 200) {
                const errorMsg = response.data?.error?.message || response.data?.message || '视频生成失败';
                console.error('Agent工具 - 视频生成失败:', errorMsg);
                return { success: false, error: `视频生成失败: ${errorMsg}` };
            }
            const taskId = response.data?.id || response.data?.task_id;
            if (!taskId) {
                const errorMsg = response.data?.message || '未返回任务ID';
                console.error('Agent工具 - 未获取到任务ID:', errorMsg, response.data);
                return { success: false, error: `视频生成失败: ${errorMsg}` };
            }
            console.log('Agent工具 - 视频生成任务已提交，任务ID:', taskId);
            console.log('Agent工具 - 开始轮询任务状态...');
            const maxAttempts = 200;
            let videoUrl = null;
            let taskStatus = 'pending';
            let attempt = 0;
            while (attempt < maxAttempts && !videoUrl) {
                attempt++;
                await new Promise(resolve => setTimeout(resolve, 3000));
                try {
                    console.log(`Agent工具 - 轮询任务状态 (${attempt}/${maxAttempts})...`);
                    const statusResponse = await axios_1.default.get(`https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks/${taskId}`, {
                        headers: {
                            'Authorization': `Bearer ${apiKey}`
                        },
                        timeout: 30000
                    });
                    if (statusResponse.status !== 200) {
                        console.error('Agent工具 - 查询任务状态失败:', statusResponse.status);
                        continue;
                    }
                    const taskData = statusResponse.data;
                    taskStatus = taskData?.status || 'unknown';
                    console.log('Agent工具 - 任务状态:', taskStatus);
                    if (taskStatus === 'succeeded' || taskStatus === 'succeed' || taskStatus === 'success') {
                        videoUrl = taskData?.content?.video_url || taskData?.data?.result_url || taskData?.result_url || taskData?.video_url;
                        if (videoUrl) {
                            console.log('Agent工具 - 任务完成，获取到视频URL:', videoUrl);
                            break;
                        }
                    }
                    else if (taskStatus === 'failed' || taskStatus === 'error') {
                        const errorMsg = taskData?.error?.message || taskData?.message || '视频生成任务失败';
                        console.error('Agent工具 - 视频生成任务失败:', errorMsg);
                        return { success: false, error: `视频生成任务失败: ${errorMsg}` };
                    }
                    else if (taskStatus === 'processing' || taskStatus === 'pending' || taskStatus === 'running') {
                        console.log('Agent工具 - 任务进行中，继续等待...');
                        continue;
                    }
                }
                catch (pollErr) {
                    console.error('Agent工具 - 轮询任务状态异常:', pollErr.message);
                    continue;
                }
            }
            if (!videoUrl) {
                const errorMsg = `视频生成超时，任务状态：${taskStatus}。视频生成通常需要1-5分钟，请稍后再试。`;
                console.error('Agent工具 - 未获取到视频URL:', errorMsg);
                return { success: false, error: errorMsg };
            }
            console.log('Agent工具 - 视频生成成功，原始URL:', videoUrl);
            console.log('Agent工具 - URL来源:', videoUrl.includes('tos-cn-guangzhou') ? '火山引擎TOS CDN' : '需要上传到CDN');
            let finalVideoUrl = videoUrl;
            let videoKey;
            const isTosUrl = videoUrl.includes('tos-cn-') && videoUrl.includes('volces.com');
            console.log(`Agent工具 - 检查URL类型: isTosUrl=${isTosUrl}, url=${videoUrl.substring(0, 80)}`);
            if (!isTosUrl) {
                console.log('Agent工具 - 视频需要上传到火山引擎CDN...');
                try {
                    console.log('Agent工具 - 开始下载视频...');
                    const response = await fetch(videoUrl);
                    if (!response.ok) {
                        throw new Error(`下载视频失败: ${response.status} ${response.statusText}`);
                    }
                    const buffer = Buffer.from(await response.arrayBuffer());
                    console.log(`Agent工具 - 视频下载完成, 大小: ${buffer.length} bytes`);
                    const timestamp = Date.now();
                    const filename = `agent-video-${timestamp}.mp4`;
                    console.log(`Agent工具 - 开始上传到TOS: ${filename}`);
                    videoKey = await this.storage.uploadFile({
                        fileContent: buffer,
                        fileName: `agent-videos/${filename}`,
                        contentType: 'video/mp4'
                    });
                    console.log(`Agent工具 - TOS上传成功, key: ${videoKey}`);
                    console.log('Agent工具 - 生成预签名URL...');
                    finalVideoUrl = await this.storage.generatePresignedUrl({
                        key: videoKey,
                        expireTime: 86400 * 30
                    });
                    console.log('Agent工具 - 视频已上传到CDN:', finalVideoUrl.substring(0, 80));
                }
                catch (uploadErr) {
                    console.error('Agent工具 - 视频上传失败:', uploadErr);
                    console.error('Agent工具 - 错误堆栈:', uploadErr.stack);
                    if (uploadErr.$response) {
                        console.error('Agent工具 - 原始响应:', uploadErr.$response);
                    }
                    return { success: false, error: `视频上传到CDN失败: ${uploadErr.message}` };
                }
            }
            else {
                console.log('Agent工具 - 视频已经在TOS上，跳过上传');
            }
            const resultData = {
                video_url: finalVideoUrl,
                prompt: params.prompt,
                optimized_prompt: optimizedPrompt,
                duration: params.duration || 5,
                ratio: params.ratio || '9:16',
                cdn_url: finalVideoUrl,
                generate_audio: params.generate_audio !== false,
                has_reference_images: params.reference_images?.length || 0,
                has_reference_videos: params.reference_videos?.length || 0,
                has_reference_audios: params.reference_audios?.length || 0,
                message: `成功生成视频，已保存到火山引擎CDN，时长${params.duration || 5}秒，比例${params.ratio || '9:16'}`
            };
            if (videoKey) {
                resultData.video_key = videoKey;
            }
            return {
                success: true,
                data: resultData
            };
        }
        catch (err) {
            console.error('Agent工具 - 视频生成异常:', err);
            let errorMsg = err.message || '未知错误';
            if (err.response) {
                const apiError = err.response.data;
                errorMsg = apiError?.error?.message || apiError?.message || `API错误 (${err.response.status})`;
            }
            else if (err.code === 'ECONNABORTED' || errorMsg.includes('timeout') || errorMsg.includes('Timeout')) {
                errorMsg = '视频生成超时，请稍后重试。视频生成通常需要1-5分钟。';
            }
            else if (err.message?.includes('403') || err.statusCode === 403) {
                errorMsg = '视频生成服务暂时不可用，可能是API配额已用完或权限问题，请稍后再试或联系管理员';
            }
            else if (err.message?.includes('rate limit') || err.message?.includes('429')) {
                errorMsg = '视频生成请求过于频繁，请稍等片刻再试';
            }
            return { success: false, error: `生成视频失败: ${errorMsg}` };
        }
    }
};
exports.GenerateVideoTool = GenerateVideoTool;
exports.GenerateVideoTool = GenerateVideoTool = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], GenerateVideoTool);
let BatchGenerateTool = class BatchGenerateTool {
    constructor() {
        this.definition = {
            name: 'batch_generate',
            displayName: '批量生成内容',
            description: '批量生成文章、图片或视频',
            category: 'content_creation',
            paramsSchema: {
                items: {
                    type: 'array',
                    items: {
                        type: 'object',
                        properties: {
                            type: { type: 'string', enum: ['article', 'image', 'video'] },
                            params: { type: 'object' }
                        }
                    },
                    description: '生成项目列表',
                    required: true
                }
            }
        };
    }
    async execute(params, context) {
        try {
            const results = [];
            const items = params.items || [];
            for (const item of items) {
                results.push({
                    type: item.type,
                    params: item.params,
                    status: 'queued'
                });
            }
            return {
                success: true,
                data: {
                    total: items.length,
                    results,
                    message: `已创建${items.length}个生成任务`
                }
            };
        }
        catch (err) {
            return { success: false, error: `批量生成失败: ${err.message}` };
        }
    }
};
exports.BatchGenerateTool = BatchGenerateTool;
exports.BatchGenerateTool = BatchGenerateTool = __decorate([
    (0, common_1.Injectable)()
], BatchGenerateTool);
//# sourceMappingURL=content-creation.tools.js.map