import { ITool, ToolContext, ToolDefinition } from './tool.interface';
import { ToolResult } from '../agent.types';
export declare class GenerateMultiEpisodeDramaTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class GenerateDramaVoiceoverTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class EditShortDramaVideoTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class GenerateSubtitleTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class RecommendBGMTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
