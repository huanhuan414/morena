"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchTool = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
let SearchTool = class SearchTool {
    constructor() {
        this.name = 'search';
        this.description = '搜索互联网获取最新信息。当需要查找实时信息、新闻、资料、数据时使用此工具。';
        this.parameters = {
            query: {
                type: 'string',
                description: '搜索关键词或问题',
                required: true
            },
            count: {
                type: 'number',
                description: '返回结果数量，默认5条',
                required: false
            }
        };
    }
    async execute(params, context) {
        try {
            const query = params.query;
            const count = params.count || 5;
            console.log(`[SearchTool] 执行搜索: ${query}`);
            const customHeaders = context.headers ? coze_coding_dev_sdk_1.HeaderUtils.extractForwardHeaders(context.headers) : undefined;
            const config = new coze_coding_dev_sdk_1.Config();
            const client = new coze_coding_dev_sdk_1.SearchClient(config, customHeaders);
            const response = await client.webSearch(query, count, true);
            if (!response.web_items || response.web_items.length === 0) {
                return {
                    success: false,
                    message: `未找到关于 "${query}" 的相关信息`
                };
            }
            const results = response.web_items.map((item, index) => ({
                index: index + 1,
                title: item.title,
                url: item.url,
                source: item.site_name,
                snippet: item.snippet,
                publishTime: item.publish_time
            }));
            const summary = response.summary || '';
            return {
                success: true,
                data: {
                    query,
                    totalResults: results.length,
                    summary,
                    results
                },
                message: `找到 ${results.length} 条关于 "${query}" 的结果${summary ? '，已生成摘要' : ''}`
            };
        }
        catch (error) {
            console.error('[SearchTool] 搜索失败:', error);
            return {
                success: false,
                error: error.message,
                message: `搜索失败: ${error.message}`
            };
        }
    }
};
exports.SearchTool = SearchTool;
exports.SearchTool = SearchTool = __decorate([
    (0, common_1.Injectable)()
], SearchTool);
//# sourceMappingURL=search.tool.js.map