"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenerateVideoTool = void 0;
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const supabase_client_1 = require("../../../storage/database/supabase-client");
class GenerateVideoTool {
    constructor() {
        this.name = 'generate_video';
        this.description = '根据文本描述生成高质量视频，支持4-12秒时长，可生成带音频的视频，适用于短视频、动画、广告等场景。如果用户上传了图片，可以使用图片作为首帧参考（first_frame），确保视频内容与图片一致。如果用户没有上传图片，只使用文本描述生成视频。';
        this.parameters = {
            type: 'object',
            properties: {
                prompt: {
                    type: 'string',
                    description: '视频内容描述，详细描述视频场景、动作、镜头运动等'
                },
                duration: {
                    type: 'number',
                    description: '视频时长（秒），支持4-12秒，默认5秒',
                    default: 5
                },
                ratio: {
                    type: 'string',
                    description: '视频比例：16:9（横屏）、9:16（竖屏）、1:1（方形）',
                    default: '16:9'
                },
                resolution: {
                    type: 'string',
                    description: '分辨率：480p、720p、1080p',
                    default: '720p'
                },
                generateAudio: {
                    type: 'boolean',
                    description: '是否生成音频（配音、音效、背景音乐）',
                    default: true
                },
                firstFrameUrl: {
                    type: 'string',
                    description: '首帧图片URL（可选），用于图片转视频。注意：只支持AI生成的图片，不支持真实人物照片。'
                }
            },
            required: ['prompt']
        };
        this.storage = new coze_coding_dev_sdk_1.S3Storage({
            endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL || 'https://tos-cn-guangzhou.volces.com',
            accessKey: process.env.VOLC_ACCESS_KEY || '',
            secretKey: process.env.VOLC_SECRET_KEY || '',
            bucketName: process.env.COZE_BUCKET_NAME || 'morena-ai',
            region: 'cn-guangzhou',
        });
    }
    async execute(params, context) {
        const { prompt, duration = 5, ratio = '16:9', resolution = '720p', generateAudio = true, firstFrameUrl } = params;
        const { userId, avatarId, taskId, headers } = context;
        console.log('[GenerateVideoTool] 开始生成视频:', { prompt, duration, ratio, resolution, hasFirstFrame: !!firstFrameUrl });
        const client = (0, supabase_client_1.getSupabaseClient)();
        try {
            await client
                .from('tasks')
                .update({
                progress: 10,
                logs: [{
                        tool: 'generate_video',
                        action: '正在生成视频，预计需要1-3分钟...',
                        timestamp: new Date().toISOString()
                    }]
            })
                .eq('id', taskId);
            const config = new coze_coding_dev_sdk_1.Config();
            const customHeaders = headers ? coze_coding_dev_sdk_1.HeaderUtils.extractForwardHeaders(headers) : undefined;
            const videoClient = new coze_coding_dev_sdk_1.VideoGenerationClient(config, customHeaders);
            const content = [];
            let finalPrompt = prompt;
            if (firstFrameUrl) {
                if (!finalPrompt.includes('图片') && !finalPrompt.includes('参考') && !finalPrompt.includes('基于')) {
                    finalPrompt = `基于提供的首帧图片，${finalPrompt}`;
                }
                console.log('[GenerateVideoTool] 有首帧图片，优化后的提示词:', finalPrompt.substring(0, 100));
            }
            if (firstFrameUrl) {
                console.log('[GenerateVideoTool] 处理用户上传的首帧图片:', firstFrameUrl.substring(0, 60));
                try {
                    if (firstFrameUrl.includes('tos-cn-') && firstFrameUrl.includes('volces.com')) {
                        console.log('[GenerateVideoTool] 图片已在TOS上，直接使用');
                        content.push({
                            type: 'image_url',
                            image_url: { url: firstFrameUrl },
                            role: 'first_frame'
                        });
                    }
                    else {
                        console.log('[GenerateVideoTool] 下载图片并上传到TOS...');
                        const imgResponse = await fetch(firstFrameUrl);
                        if (!imgResponse.ok) {
                            throw new Error(`下载图片失败: ${imgResponse.status}`);
                        }
                        const imgBuffer = Buffer.from(await imgResponse.arrayBuffer());
                        const timestamp = Date.now();
                        const imgKey = await this.storage.uploadFile({
                            fileContent: imgBuffer,
                            fileName: `video-first-frame/${timestamp}.jpg`,
                            contentType: 'image/jpeg'
                        });
                        const tosImgUrl = await this.storage.generatePresignedUrl({
                            key: imgKey,
                            expireTime: 86400 * 7
                        });
                        console.log('[GenerateVideoTool] 图片已上传到TOS:', tosImgUrl.substring(0, 60));
                        content.push({
                            type: 'image_url',
                            image_url: { url: tosImgUrl },
                            role: 'first_frame'
                        });
                    }
                }
                catch (imgError) {
                    console.error('[GenerateVideoTool] 处理首帧图片失败:', imgError.message);
                }
            }
            content.push({
                type: 'text',
                text: finalPrompt
            });
            await client
                .from('tasks')
                .update({ progress: 20 })
                .eq('id', taskId);
            const response = await videoClient.videoGeneration(content, {
                model: 'doubao-seedance-2-0-260128',
                duration,
                ratio: ratio,
                resolution: resolution,
                generateAudio,
                watermark: false
            });
            const originalUrl = response.videoUrl;
            if (!originalUrl) {
                throw new Error(response.response?.error_message || '视频生成失败');
            }
            console.log('[GenerateVideoTool] 视频生成成功:', originalUrl);
            await client
                .from('tasks')
                .update({
                progress: 70,
                logs: [{
                        tool: 'generate_video',
                        action: '正在上传到火山引擎CDN...',
                        timestamp: new Date().toISOString()
                    }]
            })
                .eq('id', taskId);
            const videoKey = await this.storage.uploadFromUrl({ url: originalUrl, timeout: 60000 });
            console.log('[GenerateVideoTool] 上传CDN成功, key:', videoKey);
            const cdnUrl = await this.storage.generatePresignedUrl({
                key: videoKey,
                expireTime: 86400 * 30
            });
            console.log('[GenerateVideoTool] CDN URL:', cdnUrl);
            const { data: videoRecord } = await client
                .from('generated_content')
                .insert({
                user_id: userId,
                avatar_id: avatarId,
                task_id: taskId,
                type: 'video',
                prompt: prompt,
                url: cdnUrl,
                storage_key: videoKey,
                metadata: {
                    duration,
                    ratio,
                    resolution,
                    hasAudio: generateAudio,
                    hasFirstFrame: !!firstFrameUrl,
                    firstFrameUrl: firstFrameUrl || null,
                    original_url: originalUrl
                }
            })
                .select()
                .single();
            await client
                .from('tasks')
                .update({
                progress: 100,
                result: {
                    type: 'video',
                    url: cdnUrl,
                    key: videoKey,
                    prompt,
                    duration,
                    ratio,
                    resolution,
                    hasAudio: generateAudio,
                    recordId: videoRecord?.id
                },
                status: 'completed',
                completed_at: new Date().toISOString()
            })
                .eq('id', taskId);
            return {
                success: true,
                data: {
                    url: cdnUrl,
                    key: videoKey,
                    prompt,
                    duration,
                    ratio,
                    resolution
                },
                message: `视频已生成成功！`,
                percentage: 100
            };
        }
        catch (error) {
            console.error('[GenerateVideoTool] 生成失败:', error);
            await client
                .from('tasks')
                .update({
                status: 'failed',
                result: { error: error.message }
            })
                .eq('id', taskId);
            return {
                success: false,
                error: error.message || '视频生成失败',
                message: `视频生成失败: ${error.message || '未知错误'}`
            };
        }
    }
}
exports.GenerateVideoTool = GenerateVideoTool;
//# sourceMappingURL=generate-video.tool.js.map