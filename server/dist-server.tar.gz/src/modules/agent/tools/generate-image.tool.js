"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenerateImageTool = void 0;
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const supabase_client_1 = require("../../../storage/database/supabase-client");
class GenerateImageTool {
    constructor() {
        this.name = 'generate_image';
        this.description = '根据文本描述生成高质量图片，支持2K/4K分辨率，可用于海报、插画、产品设计等场景';
        this.parameters = {
            type: 'object',
            properties: {
                prompt: {
                    type: 'string',
                    description: '图片描述，详细描述想要生成的图片内容、风格、色彩等'
                },
                size: {
                    type: 'string',
                    description: '图片尺寸：2K（默认）、4K，或自定义如 2560x1440',
                    default: '2K'
                },
                style: {
                    type: 'string',
                    description: '图片风格：realistic（写实）、anime（动漫）、oil_painting（油画）、watercolor（水彩）、sketch（素描）等',
                    default: 'realistic'
                }
            },
            required: ['prompt']
        };
        this.storage = new coze_coding_dev_sdk_1.S3Storage({
            endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL || 'https://tos-cn-guangzhou.volces.com',
            accessKey: process.env.VOLC_ACCESS_KEY || '',
            secretKey: process.env.VOLC_SECRET_KEY || '',
            bucketName: process.env.COZE_BUCKET_NAME || 'morena-ai',
            region: 'cn-guangzhou',
        });
    }
    async execute(params, context) {
        const { prompt, size = '2K', style = 'realistic' } = params;
        const { userId, avatarId, taskId, headers } = context;
        console.log('[GenerateImageTool] 开始生成图片:', { prompt, size, style });
        const client = (0, supabase_client_1.getSupabaseClient)();
        try {
            await client
                .from('tasks')
                .update({
                progress: 20,
                logs: client.rpc('array_append', {
                    arr: 'logs',
                    value: {
                        tool: 'generate_image',
                        action: '正在生成图片...',
                        timestamp: new Date().toISOString()
                    }
                })
            })
                .eq('id', taskId);
            const enhancedPrompt = this.buildEnhancedPrompt(prompt, style);
            const config = new coze_coding_dev_sdk_1.Config();
            const customHeaders = headers ? coze_coding_dev_sdk_1.HeaderUtils.extractForwardHeaders(headers) : undefined;
            const imageClient = new coze_coding_dev_sdk_1.ImageGenerationClient(config, customHeaders);
            const response = await imageClient.generate({
                prompt: enhancedPrompt,
                size: size,
                watermark: false
            });
            const helper = imageClient.getResponseHelper(response);
            if (!helper.success || helper.imageUrls.length === 0) {
                throw new Error(helper.errorMessages.join('; ') || '图片生成失败');
            }
            const originalUrl = helper.imageUrls[0];
            console.log('[GenerateImageTool] 图片生成成功:', originalUrl);
            await client
                .from('tasks')
                .update({
                progress: 60,
                logs: client.rpc('array_append', {
                    arr: 'logs',
                    value: {
                        tool: 'generate_image',
                        action: '正在上传到火山引擎CDN...',
                        timestamp: new Date().toISOString()
                    }
                })
            })
                .eq('id', taskId);
            const imageKey = await this.storage.uploadFromUrl({ url: originalUrl, timeout: 30000 });
            console.log('[GenerateImageTool] 上传CDN成功, key:', imageKey);
            const cdnUrl = await this.storage.generatePresignedUrl({
                key: imageKey,
                expireTime: 86400 * 30
            });
            console.log('[GenerateImageTool] CDN URL:', cdnUrl);
            const { data: imageRecord } = await client
                .from('generated_content')
                .insert({
                user_id: userId,
                avatar_id: avatarId,
                task_id: taskId,
                type: 'image',
                prompt: prompt,
                url: cdnUrl,
                storage_key: imageKey,
                metadata: {
                    size,
                    style,
                    model: response.model,
                    original_url: originalUrl
                }
            })
                .select()
                .single();
            await client
                .from('tasks')
                .update({
                progress: 100,
                result: {
                    type: 'image',
                    url: cdnUrl,
                    key: imageKey,
                    prompt,
                    style,
                    size,
                    recordId: imageRecord?.id
                },
                status: 'completed',
                completed_at: new Date().toISOString()
            })
                .eq('id', taskId);
            return {
                success: true,
                data: {
                    url: cdnUrl,
                    key: imageKey,
                    prompt,
                    style,
                    size
                },
                message: `图片已生成成功！`
            };
        }
        catch (error) {
            console.error('[GenerateImageTool] 生成失败:', error);
            await client
                .from('tasks')
                .update({
                status: 'failed',
                result: { error: error.message }
            })
                .eq('id', taskId);
            return {
                success: false,
                error: error.message || '图片生成失败',
                message: `图片生成失败: ${error.message || '未知错误'}`
            };
        }
    }
    buildEnhancedPrompt(prompt, style) {
        const styleEnhancements = {
            realistic: 'photorealistic, high detail, professional photography, 8k resolution',
            anime: 'anime style, vibrant colors, clean lines, Japanese animation aesthetic',
            oil_painting: 'oil painting style, rich textures, classical art, masterpiece',
            watercolor: 'watercolor painting, soft colors, artistic, dreamy atmosphere',
            sketch: 'pencil sketch, detailed linework, artistic drawing, monochrome',
            poster: 'poster design, bold typography, eye-catching, professional layout',
            logo: 'logo design, minimalist, clean, professional branding',
            '3d': '3D render, realistic lighting, detailed textures, high quality'
        };
        const enhancement = styleEnhancements[style] || styleEnhancements.realistic;
        return `${prompt}, ${enhancement}, high quality, detailed`;
    }
}
exports.GenerateImageTool = GenerateImageTool;
//# sourceMappingURL=generate-image.tool.js.map