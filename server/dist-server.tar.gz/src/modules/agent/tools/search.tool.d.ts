import { Tool, ToolExecutionContext, ToolResult } from '../tools.interface';
export declare class SearchTool implements Tool {
    name: string;
    description: string;
    parameters: {
        query: {
            type: string;
            description: string;
            required: boolean;
        };
        count: {
            type: string;
            description: string;
            required: boolean;
        };
    };
    execute(params: Record<string, any>, context: ToolExecutionContext): Promise<ToolResult>;
}
