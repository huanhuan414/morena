import { ToolResult, ToolCategory, PlatformType } from '../agent.types';
export interface ToolContext {
    userId: string;
    avatarId: string;
    taskId?: string;
    headers?: Record<string, string>;
    onProgress?: (message: string, step?: number, subStep?: string) => void;
    uploadedImages?: string[];
    uploadedVideos?: string[];
}
export interface ToolDefinition {
    name: string;
    displayName: string;
    description: string;
    category: ToolCategory;
    paramsSchema: Record<string, any>;
    requiresPlatform?: PlatformType;
}
export interface ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
    validateParams?(params: Record<string, any>): {
        valid: boolean;
        errors?: string[];
    };
    getConfigRequirements?(): {
        platform: string;
        fields: Array<{
            name: string;
            label: string;
            type: 'text' | 'password' | 'textarea';
            required: boolean;
            placeholder?: string;
        }>;
    };
}
