import { Tool, ToolExecutionContext, ToolResult } from '../tools.interface';
export declare class SendMessageTool implements Tool {
    name: string;
    description: string;
    parameters: {
        message: {
            type: string;
            description: string;
            required: boolean;
        };
        type: {
            type: string;
            description: string;
            required: boolean;
        };
    };
    execute(params: Record<string, any>, context: ToolExecutionContext): Promise<ToolResult>;
}
