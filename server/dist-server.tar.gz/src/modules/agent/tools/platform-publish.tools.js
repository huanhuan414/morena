"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishWechatVideoTool = exports.PublishDouyinTool = exports.PublishWeiboTool = exports.PublishBilibiliTool = exports.PublishXiaohongshuTool = exports.PublishWechatMpTool = exports.CheckPlatformConfigTool = exports.ListAvatarAccountsTool = void 0;
const common_1 = require("@nestjs/common");
const agent_types_1 = require("../agent.types");
const supabase_client_1 = require("../../../storage/database/supabase-client");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
let ListAvatarAccountsTool = class ListAvatarAccountsTool {
    constructor() {
        this.definition = {
            name: 'list_avatar_accounts',
            displayName: '查看分身绑定的平台账号',
            description: '查询分身已绑定的所有第三方平台账号列表（抖音、小红书、微信公众号、B站、微博等）',
            category: 'data_analysis',
            paramsSchema: {}
        };
    }
    async execute(params, context) {
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data, error } = await client
                .from('avatar_accounts')
                .select('*')
                .eq('avatar_id', context.avatarId)
                .order('created_at', { ascending: false });
            if (error) {
                return { success: false, error: `查询账号列表失败: ${error.message}` };
            }
            const platformNames = {
                'douyin': '抖音',
                'xiaohongshu': '小红书',
                'wechat': '微信公众号',
                'bilibili': 'B站',
                'weibo': '微博'
            };
            const accounts = data.map(account => ({
                platform: account.platform,
                platform_name: platformNames[account.platform] || account.platform,
                account_name: account.account_name || account.name || '未命名',
                followers: account.followers || account.extra_info?.follower_count || 0,
                total_works: account.total_works || account.extra_info?.aweme_count || account.extra_info?.notes_count || 0,
                total_favorited: account.extra_info?.total_favorited || 0,
                created_at: account.created_at,
                extra_info: account.extra_info ? {
                    nickname: account.extra_info.nickname,
                    avatar_url: account.extra_info.avatar_url,
                    signature: account.extra_info.signature,
                    aweme_count: account.extra_info.aweme_count,
                    notes_count: account.extra_info.notes_count,
                    follower_count: account.extra_info.follower_count,
                    total_favorited: account.extra_info.total_favorited
                } : undefined
            }));
            return {
                success: true,
                data: {
                    accounts,
                    total: accounts.length,
                    platforms: accounts.map(a => a.platform_name).join('、') || '暂无绑定平台'
                }
            };
        }
        catch (err) {
            return { success: false, error: err.message };
        }
    }
};
exports.ListAvatarAccountsTool = ListAvatarAccountsTool;
exports.ListAvatarAccountsTool = ListAvatarAccountsTool = __decorate([
    (0, common_1.Injectable)()
], ListAvatarAccountsTool);
let CheckPlatformConfigTool = class CheckPlatformConfigTool {
    constructor() {
        this.definition = {
            name: 'check_platform_config',
            displayName: '检查分身账号配置',
            description: '检查分身是否已绑定指定平台的账号（抖音、小红书、微信公众号等）',
            category: 'data_analysis',
            paramsSchema: {
                platform: {
                    type: 'string',
                    enum: ['wechat', 'xiaohongshu', 'bilibili', 'weibo', 'douyin'],
                    description: '平台类型',
                    required: true
                }
            }
        };
    }
    async execute(params, context) {
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const platform = params.platform;
            const platformNames = {
                'douyin': '抖音',
                'xiaohongshu': '小红书',
                'wechat': '微信公众号',
                'bilibili': 'B站',
                'weibo': '微博'
            };
            const { data, error } = await client
                .from('avatar_accounts')
                .select('*')
                .eq('avatar_id', context.avatarId)
                .eq('platform', platform)
                .maybeSingle();
            if (error) {
                return { success: false, error: `查询账号配置失败: ${error.message}` };
            }
            if (!data) {
                return {
                    success: true,
                    data: {
                        configured: false,
                        platform,
                        platform_name: platformNames[platform] || platform,
                        message: `分身尚未绑定${platformNames[platform] || platform}账号，请先在分身账号配置页面绑定账号`
                    },
                    requires_config: true,
                    config_platform: platform
                };
            }
            const accountInfo = {
                configured: true,
                platform,
                platform_name: platformNames[platform] || platform,
                account_name: data.account_name || data.name,
                followers: data.followers || data.extra_info?.follower_count || 0,
                total_works: data.total_works || data.extra_info?.aweme_count || data.extra_info?.notes_count || 0,
                created_at: data.created_at
            };
            if (data.extra_info) {
                accountInfo.extra_info = data.extra_info;
                if (data.extra_info.nickname) {
                    accountInfo.nickname = data.extra_info.nickname;
                }
                if (data.extra_info.avatar_url) {
                    accountInfo.avatar_url = data.extra_info.avatar_url;
                }
                if (data.extra_info.total_favorited !== undefined) {
                    accountInfo.total_favorited = data.extra_info.total_favorited;
                }
            }
            return {
                success: true,
                data: accountInfo
            };
        }
        catch (err) {
            return { success: false, error: err.message };
        }
    }
};
exports.CheckPlatformConfigTool = CheckPlatformConfigTool;
exports.CheckPlatformConfigTool = CheckPlatformConfigTool = __decorate([
    (0, common_1.Injectable)()
], CheckPlatformConfigTool);
let PublishWechatMpTool = class PublishWechatMpTool {
    constructor() {
        this.definition = {
            name: 'publish_wechat_mp',
            displayName: '发布公众号文章',
            description: '发布文章到微信公众号素材库，支持根据内容自动配图',
            category: 'platform_publish',
            paramsSchema: {
                title: { type: 'string', description: '文章标题', required: true },
                content: { type: 'string', description: '文章内容（Markdown或HTML格式）', required: true },
                cover_url: { type: 'string', description: '封面图片URL（可选，不传则根据标题自动生成）' },
                digest: { type: 'string', description: '摘要' },
                auto_image: { type: 'boolean', description: '是否自动配图（默认true）' }
            },
            requiresPlatform: 'wechat'
        };
    }
    async execute(params, context) {
        try {
            console.log('[publish_wechat_mp] 开始执行，参数:');
            console.log('  - title:', params.title);
            console.log('  - contentLength:', params.content?.length || 0);
            console.log('  - imageCount:', params.content ? (params.content.match(/!\[.*?\]\(.*?\)/g) || []).length : 0);
            console.log('  - cover_url:', params.cover_url);
            if (params.content) {
                console.log('  - 内容前800字符:', params.content.substring(0, 800));
            }
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data: account, error: accountError } = await client
                .from('avatar_accounts')
                .select('*')
                .eq('avatar_id', context.avatarId)
                .eq('platform', 'wechat')
                .maybeSingle();
            if (accountError || !account) {
                return {
                    success: false,
                    error: '未配置微信公众号账号，请先在分身账号配置页面绑定公众号账号',
                    requires_config: true,
                    config_platform: 'wechat'
                };
            }
            const appId = account.appid;
            const appSecret = account.appkey || account.app_secret;
            if (!appId || !appSecret) {
                return {
                    success: false,
                    error: '微信公众号账号配置不完整，缺少 AppID 或 AppSecret'
                };
            }
            console.log('Agent工具 - 发布公众号文章:', {
                title: params.title,
                cover_url: params.cover_url,
                app_id: appId,
                avatar_id: context.avatarId,
                content_length: params.content?.length || 0,
                content_preview: params.content?.substring(0, 200)
            });
            let accessToken;
            try {
                const accessTokenUrl = `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${appId}&secret=${appSecret}`;
                const tokenRes = await fetch(accessTokenUrl);
                const tokenData = await tokenRes.json();
                if (tokenData.errcode) {
                    const errorMsg = this.getWechatErrorMessage(tokenData.errcode);
                    return {
                        success: false,
                        data: { title: params.title, content: params.content },
                        error: `微信API错误: ${errorMsg}`
                    };
                }
                accessToken = tokenData.access_token;
                console.log('获取 access_token 成功');
            }
            catch (fetchError) {
                console.error('获取 access_token 失败:', fetchError);
                return {
                    success: false,
                    error: `获取access_token失败: ${fetchError.message}`
                };
            }
            let mediaId;
            let usedCoverUrl;
            try {
                if (params.cover_url && this.isValidImageUrl(params.cover_url)) {
                    console.log('正在上传封面图片:', params.cover_url.substring(0, 100));
                    for (let retry = 0; retry < 3; retry++) {
                        try {
                            mediaId = await this.uploadImage(accessToken, params.cover_url);
                            usedCoverUrl = params.cover_url;
                            console.log('封面图片上传成功, media_id:', mediaId);
                            break;
                        }
                        catch (uploadErr) {
                            console.log(`封面图上传第 ${retry + 1} 次失败:`, uploadErr.message);
                            if (retry < 2) {
                                await new Promise(resolve => setTimeout(resolve, 500));
                            }
                        }
                    }
                    if (!mediaId) {
                        console.error('封面图上传失败，使用用户指定的封面图');
                    }
                }
                if (!mediaId) {
                    console.log('正在根据标题生成封面图片...');
                    const generatedCoverUrl = await this.generateCoverImage(params.title);
                    if (generatedCoverUrl) {
                        mediaId = await this.uploadImage(accessToken, generatedCoverUrl);
                        usedCoverUrl = generatedCoverUrl;
                        console.log('自动生成封面上传成功, media_id:', mediaId);
                    }
                }
            }
            catch (coverError) {
                console.error('处理封面图片失败:', coverError.message || coverError);
            }
            if (!mediaId) {
                try {
                    console.log('生成默认封面作为最终备选...');
                    const defaultCoverUrl = await this.generateDefaultCover(params.title);
                    if (defaultCoverUrl) {
                        mediaId = await this.uploadImage(accessToken, defaultCoverUrl);
                        usedCoverUrl = defaultCoverUrl;
                        console.log('默认封面上传成功, media_id:', mediaId);
                    }
                }
                catch (finalError) {
                    console.error('生成默认封面也失败:', finalError.message || finalError);
                }
            }
            if (!mediaId) {
                return {
                    success: false,
                    error: '封面图片处理失败，无法创建草稿。请稍后重试或联系技术支持。'
                };
            }
            let contentWithImages = params.content;
            const autoImage = params.auto_image !== false;
            const existingImageCount = (params.content?.match(/!\[.*?\]\(.*?\)/g) || []).length;
            console.log('已有配图数量:', existingImageCount);
            if (autoImage && existingImageCount < 2) {
                try {
                    console.log('正在分析文章内容，生成配图...');
                    console.log('原始内容长度:', params.content?.length);
                    const result = await this.addImagesToContent(params.content, params.title);
                    contentWithImages = result.content;
                    console.log('文章配图完成，配图后内容长度:', contentWithImages?.length);
                    console.log('配图后内容预览:', contentWithImages?.substring(0, 500));
                }
                catch (imgError) {
                    console.error('文章配图失败，使用原始内容:', imgError.message || imgError);
                }
            }
            else if (existingImageCount >= 2) {
                console.log('文章已有足够的配图，跳过自动配图');
            }
            try {
                console.log('正在将图片上传到微信服务器...');
                const wechatContent = await this.replaceImagesForWechat(contentWithImages, accessToken);
                console.log('图片处理完成');
                const htmlContent = this.markdownToStyledHtml(wechatContent, params.title);
                console.log('HTML内容长度:', htmlContent?.length);
                console.log('HTML内容预览:', htmlContent?.substring(0, 500));
                const draftData = {
                    articles: [{
                            title: params.title,
                            author: '莫瑞娜AI助手',
                            digest: params.digest || this.generateDigest(params.content),
                            content: htmlContent,
                            thumb_media_id: mediaId,
                            need_open_comment: 0,
                            only_fans_can_comment: 0
                        }]
                };
                console.log('正在创建草稿...');
                const draftUrl = `https://api.weixin.qq.com/cgi-bin/draft/add?access_token=${accessToken}`;
                const draftRes = await fetch(draftUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(draftData)
                });
                const draftResult = await draftRes.json();
                if (draftResult.errcode) {
                    const errorMsg = this.getWechatErrorMessage(draftResult.errcode);
                    console.error('创建草稿失败:', draftResult);
                    return {
                        success: false,
                        error: `创建草稿失败: ${errorMsg}`
                    };
                }
                const draftMediaId = draftResult.media_id;
                console.log('草稿创建成功, media_id:', draftMediaId);
                return {
                    success: true,
                    data: {
                        media_id: draftMediaId,
                        published_title: params.title,
                        published_content: contentWithImages,
                        cover_url: usedCoverUrl,
                        word_count: params.content?.length || 0,
                        message: `✅ 文章已成功保存到公众号草稿箱！\n\n请前往微信公众平台 → 素材管理 → 草稿箱 查看《${params.title}》并进行发布。`
                    }
                };
            }
            catch (draftError) {
                console.error('创建草稿失败:', draftError);
                return {
                    success: false,
                    error: `创建草稿失败: ${draftError.message}`
                };
            }
        }
        catch (err) {
            return { success: false, error: `发布失败: ${err.message}` };
        }
    }
    isValidImageUrl(url) {
        if (!url)
            return false;
        const invalidPatterns = [
            'example.com',
            'placeholder.com',
            'via.placeholder.com',
            'dummyimage.com',
            'placehold.it',
            'lorempixel.com',
            'fake',
            'test-url',
        ];
        const lowerUrl = url.toLowerCase();
        for (const pattern of invalidPatterns) {
            if (lowerUrl.includes(pattern)) {
                console.log(`检测到无效的封面URL: ${url}`);
                return false;
            }
        }
        try {
            new URL(url);
            return true;
        }
        catch {
            return false;
        }
    }
    async generateCoverImage(title) {
        try {
            const config = new coze_coding_dev_sdk_1.Config();
            const imageClient = new coze_coding_dev_sdk_1.ImageGenerationClient(config);
            const prompt = `${title}，微信公众号封面，简约现代风格，清新配色，适合阅读，高质量，专业设计`;
            const response = await imageClient.generate({
                prompt: `${prompt}, social media cover style, clean layout, gradient background, professional`,
                size: '1K',
                watermark: false
            });
            const helper = imageClient.getResponseHelper(response);
            if (helper.success && helper.imageUrls.length > 0) {
                return helper.imageUrls[0];
            }
            return null;
        }
        catch (err) {
            console.error('生成封面图失败:', err);
            return null;
        }
    }
    async generateDefaultCover(title) {
        try {
            const config = new coze_coding_dev_sdk_1.Config();
            const imageClient = new coze_coding_dev_sdk_1.ImageGenerationClient(config);
            const response = await imageClient.generate({
                prompt: 'Abstract modern gradient background, blue and white colors, minimalist design, professional business style, no text, clean composition',
                size: '1K',
                watermark: false
            });
            const helper = imageClient.getResponseHelper(response);
            if (helper.success && helper.imageUrls.length > 0) {
                return helper.imageUrls[0];
            }
            return null;
        }
        catch (err) {
            console.error('生成默认封面失败:', err);
            return null;
        }
    }
    async addImagesToContent(content, title) {
        try {
            const config = new coze_coding_dev_sdk_1.Config();
            const imageClient = new coze_coding_dev_sdk_1.ImageGenerationClient(config);
            const images = [];
            console.log('生成文章开头配图...');
            const introImagePrompt = this.generateImagePrompt(title, 'intro');
            const introImageResponse = await imageClient.generate({
                prompt: introImagePrompt,
                size: '1K',
                watermark: false
            });
            const introHelper = imageClient.getResponseHelper(introImageResponse);
            const introImageUrl = introHelper.success && introHelper.imageUrls.length > 0
                ? introHelper.imageUrls[0]
                : null;
            const sections = this.parseArticleSections(content);
            console.log(`文章共发现 ${sections.length} 个章节`);
            const sectionImages = [];
            const maxImages = Math.min(sections.length, 3);
            for (let i = 0; i < maxImages; i++) {
                const section = sections[i];
                console.log(`生成章节 ${i + 1} 配图: ${section.title}`);
                try {
                    const sectionPrompt = this.generateImagePrompt(section.title, 'section', title);
                    const sectionResponse = await imageClient.generate({
                        prompt: sectionPrompt,
                        size: '1K',
                        watermark: false
                    });
                    const sectionHelper = imageClient.getResponseHelper(sectionResponse);
                    if (sectionHelper.success && sectionHelper.imageUrls.length > 0) {
                        const tosUrl = sectionHelper.imageUrls[0];
                        sectionImages.push({
                            position: section.position,
                            tosUrl: tosUrl,
                            title: section.title
                        });
                        images.push({ tosUrl });
                        console.log(`✅ 章节 ${i + 1} 配图生成成功`);
                        await new Promise(resolve => setTimeout(resolve, 500));
                    }
                }
                catch (sectionErr) {
                    console.error(`章节 ${i + 1} 配图生成失败:`, sectionErr);
                }
            }
            let result = content;
            if (introImageUrl) {
                console.log('✅ 开头配图插入到文章开头');
                result = `![${title}](${introImageUrl})\n\n${result}`;
                images.unshift({ tosUrl: introImageUrl });
            }
            else {
                console.log('❌ 开头配图生成失败');
            }
            for (let i = sectionImages.length - 1; i >= 0; i--) {
                const { position, tosUrl, title: sectionTitle } = sectionImages[i];
                const section = sections.find(s => s.position === position);
                if (section) {
                    const insertPosition = this.findInsertPosition(result, section);
                    console.log(`插入章节配图: 位置=${insertPosition}, 标题=${sectionTitle}`);
                    if (insertPosition !== -1) {
                        const before = result.substring(0, insertPosition);
                        const after = result.substring(insertPosition);
                        const imageMarkdown = `\n\n![${sectionTitle}](${tosUrl})\n`;
                        result = before + imageMarkdown + after;
                        console.log('✅ 章节配图插入成功');
                    }
                }
            }
            console.log('配图完成，最终内容长度:', result.length);
            console.log('共生成配图:', images.length, '张');
            return { content: result, images };
        }
        catch (err) {
            console.error('添加配图失败:', err);
            return { content, images: [] };
        }
    }
    async replaceImagesForWechat(content, accessToken) {
        console.log('[replaceImagesForWechat] 处理前的文章内容前500字符:', content.substring(0, 500));
        const imageRegex = /!\[([^\]]*)\]\(([^)]+)\)/g;
        const matches = [...content.matchAll(imageRegex)];
        console.log(`[replaceImagesForWechat] 找到 ${matches.length} 张 Markdown 图片`);
        matches.forEach((m, i) => {
            console.log(`[replaceImagesForWechat] 图片 ${i + 1}:`, m[2].substring(0, 60));
        });
        if (matches.length === 0) {
            console.log('文章中没有图片需要处理');
            return content;
        }
        console.log(`[replaceImagesForWechat] 文章中共有 ${matches.length} 张图片，正在上传到微信服务器...`);
        let result = content;
        const uploadedUrls = new Map();
        for (let i = matches.length - 1; i >= 0; i--) {
            const match = matches[i];
            const fullMatch = match[0];
            const alt = match[1];
            const tosUrl = match[2];
            try {
                console.log(`[replaceImagesForWechat] 处理图片 ${i + 1}/${matches.length}: ${tosUrl.substring(0, 60)}...`);
                let wechatUrl;
                if (uploadedUrls.has(tosUrl)) {
                    wechatUrl = uploadedUrls.get(tosUrl);
                    console.log(`[replaceImagesForWechat] 图片 ${i + 1} 已在上面的步骤中上传过，使用缓存 URL`);
                }
                else {
                    wechatUrl = await this.uploadArticleImage(accessToken, tosUrl);
                    uploadedUrls.set(tosUrl, wechatUrl);
                    console.log(`[replaceImagesForWechat] ✅ 图片 ${i + 1} 上传成功`);
                    await new Promise(resolve => setTimeout(resolve, 300));
                }
                const startIndex = result.lastIndexOf(fullMatch);
                if (startIndex === -1) {
                    console.error(`[replaceImagesForWechat] 警告：找不到图片 ${i + 1} 的匹配位置`);
                    continue;
                }
                const newImageMarkdown = `![${alt}](${wechatUrl})`;
                result = result.substring(0, startIndex) + newImageMarkdown + result.substring(startIndex + fullMatch.length);
            }
            catch (uploadErr) {
                console.error(`[replaceImagesForWechat] 图片 ${i + 1} 上传失败:`, uploadErr);
            }
        }
        console.log(`[replaceImagesForWechat] 图片处理完成，最终结果中的图片数量:`, (result.match(/!\[.*?\]\(.*?\)/g) || []).length);
        return result;
    }
    async uploadArticleImage(accessToken, imageUrl) {
        const imageRes = await fetch(imageUrl);
        if (!imageRes.ok) {
            throw new Error('下载图片失败');
        }
        const imageBuffer = await imageRes.arrayBuffer();
        const uploadUrl = `https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=${accessToken}&type=image`;
        const boundary = `----WebKitFormBoundary${Date.now().toString(16)}`;
        const formData = [];
        formData.push(`--${boundary}\r\n`);
        formData.push(`Content-Disposition: form-data; name="media"; filename="article-image.jpg"\r\n`);
        formData.push(`Content-Type: image/jpeg\r\n\r\n`);
        const formDataBuffer = Buffer.concat([
            Buffer.from(formData.join(''), 'utf-8'),
            Buffer.from(imageBuffer),
            Buffer.from(`\r\n--${boundary}--\r\n`, 'utf-8')
        ]);
        const uploadRes = await fetch(uploadUrl, {
            method: 'POST',
            headers: {
                'Content-Type': `multipart/form-data; boundary=${boundary}`
            },
            body: formDataBuffer
        });
        const uploadResult = await uploadRes.json();
        if (uploadResult.errcode) {
            throw new Error(this.getWechatErrorMessage(uploadResult.errcode));
        }
        return uploadResult.url || uploadResult.media_id;
    }
    parseArticleSections(content) {
        const sections = [];
        const lines = content.split('\n');
        let currentPosition = 0;
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const lineLength = line.length + 1;
            const h2Match = line.match(/^##\s+(.+)$/);
            if (h2Match) {
                sections.push({
                    title: h2Match[1].trim(),
                    position: currentPosition,
                    content: line
                });
            }
            const h3Match = line.match(/^###\s+(.+)$/);
            if (h3Match) {
                sections.push({
                    title: h3Match[1].trim(),
                    position: currentPosition,
                    content: line
                });
            }
            const h4Match = line.match(/^####\s+(.+)$/);
            if (h4Match) {
                sections.push({
                    title: h4Match[1].trim(),
                    position: currentPosition,
                    content: line
                });
            }
            currentPosition += lineLength;
        }
        if (sections.length === 0) {
            console.log('未发现标题格式，按段落分割生成配图...');
            const paragraphs = content.split(/\n\n+/);
            let pos = 0;
            const validParagraphs = paragraphs.filter(p => p.trim().length > 20);
            for (let i = 0; i < Math.min(validParagraphs.length, 3); i++) {
                const p = validParagraphs[i];
                const pseudoTitle = p.replace(/[#*`>\-\n]/g, '').trim().substring(0, 30);
                sections.push({
                    title: pseudoTitle + (p.length > 30 ? '...' : ''),
                    position: pos,
                    content: p
                });
                pos += p.length + 2;
            }
        }
        return sections;
    }
    findInsertPosition(content, section) {
        const sectionIndex = content.indexOf(section.content, section.position);
        if (sectionIndex === -1) {
            const paragraphEnd = content.indexOf('\n\n', section.position);
            return paragraphEnd !== -1 ? paragraphEnd : content.length;
        }
        let pos = sectionIndex + section.content.length;
        const nextNewline = content.indexOf('\n', pos);
        if (nextNewline !== -1) {
            pos = nextNewline + 1;
        }
        while (pos < content.length) {
            if (content[pos] === '\n') {
                if (pos + 1 < content.length && content[pos + 1] === '\n') {
                    return pos;
                }
                const remaining = content.substring(pos + 1);
                if (remaining.match(/^(#{1,6}\s)/)) {
                    return pos;
                }
            }
            pos++;
        }
        return content.length;
    }
    generateImagePrompt(content, type, mainTitle) {
        const cleanContent = content
            .replace(/[^\u4e00-\u9fa5a-zA-Z0-9\s]/g, '')
            .substring(0, 100);
        if (type === 'intro') {
            return `${cleanContent}，微信公众号文章配图，精美插画风格，现代简约，清新配色，高质量，专业设计，无文字，artistic illustration, clean composition, gradient colors`;
        }
        else {
            return `${cleanContent}，文章插图，简约插画风格，与"${mainTitle || ''}"主题相关，清新配色，高质量，无文字，thematic illustration, clean style, professional design`;
        }
    }
    async uploadImage(accessToken, imageUrl) {
        console.log('正在下载图片:', imageUrl.substring(0, 100));
        let imageRes;
        try {
            imageRes = await fetch(imageUrl, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
        }
        catch (fetchErr) {
            console.error('fetch 请求失败:', fetchErr.message);
            throw new Error(`下载图片失败: ${fetchErr.message}`);
        }
        if (!imageRes.ok) {
            console.error('下载图片响应失败:', imageRes.status, imageRes.statusText);
            throw new Error(`下载图片失败: HTTP ${imageRes.status}`);
        }
        const imageBuffer = await imageRes.arrayBuffer();
        console.log('图片下载成功，大小:', imageBuffer.byteLength, 'bytes');
        if (imageBuffer.byteLength < 100) {
            throw new Error('下载的图片太小，可能无效');
        }
        const uploadUrl = `https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=${accessToken}&type=image`;
        const boundary = `----WebKitFormBoundary${Date.now().toString(16)}`;
        const formData = [];
        formData.push(`--${boundary}\r\n`);
        formData.push(`Content-Disposition: form-data; name="media"; filename="cover.jpg"\r\n`);
        formData.push(`Content-Type: image/jpeg\r\n\r\n`);
        const formDataBuffer = Buffer.concat([
            Buffer.from(formData.join(''), 'utf-8'),
            Buffer.from(imageBuffer),
            Buffer.from(`\r\n--${boundary}--\r\n`, 'utf-8')
        ]);
        const uploadRes = await fetch(uploadUrl, {
            method: 'POST',
            headers: {
                'Content-Type': `multipart/form-data; boundary=${boundary}`
            },
            body: formDataBuffer
        });
        const uploadResult = await uploadRes.json();
        if (uploadResult.errcode) {
            console.error('微信上传失败:', uploadResult);
            throw new Error(this.getWechatErrorMessage(uploadResult.errcode));
        }
        console.log('上传成功, media_id:', uploadResult.media_id?.substring(0, 20));
        return uploadResult.media_id;
    }
    generateDigest(content) {
        const plainText = content
            .replace(/#{1,6}\s/g, '')
            .replace(/\*\*/g, '')
            .replace(/\*/g, '')
            .replace(/`/g, '')
            .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
            .replace(/!\[([^\]]*)\]\([^)]+\)/g, '')
            .replace(/>/g, '')
            .replace(/-/g, '')
            .replace(/\n/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
        return plainText.substring(0, 54) + (plainText.length > 54 ? '...' : '');
    }
    markdownToStyledHtml(markdown, title) {
        if (!markdown)
            return '';
        let html = markdown;
        const styles = {
            container: 'max-width: 100%; padding: 20px 16px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; font-size: 16px; line-height: 1.8; color: #333; background: #fff;',
            h1: 'font-size: 22px; font-weight: bold; color: #000; margin: 24px 0 16px; padding-bottom: 12px; border-bottom: 2px solid #eee;',
            h2: 'font-size: 20px; font-weight: bold; color: #000; margin: 20px 0 12px;',
            h3: 'font-size: 18px; font-weight: bold; color: #333; margin: 16px 0 10px;',
            h4: 'font-size: 16px; font-weight: bold; color: #333; margin: 14px 0 8px;',
            p: 'margin: 12px 0; text-align: justify; letter-spacing: 0.5px;',
            blockquote: 'margin: 16px 0; padding: 12px 16px; background: linear-gradient(135deg, #f8f9fa 0%, #fff 100%); border-left: 4px solid #1890ff; border-radius: 4px; color: #666; font-size: 15px;',
            ul: 'margin: 12px 0; padding-left: 24px;',
            ol: 'margin: 12px 0; padding-left: 24px;',
            li: 'margin: 6px 0; line-height: 1.8;',
            code: 'background: #f5f5f5; padding: 2px 6px; border-radius: 3px; font-family: Monaco, Consolas, monospace; font-size: 14px; color: #c7254e;',
            pre: 'background: #282c34; color: #abb2bf; padding: 16px; border-radius: 8px; overflow-x: auto; font-family: Monaco, Consolas, monospace; font-size: 14px; line-height: 1.6; margin: 16px 0;',
            img: 'max-width: 100%; height: auto; border-radius: 8px; margin: 16px 0; display: block;',
            strong: 'font-weight: bold; color: #000;',
            em: 'font-style: italic; color: #666;',
            a: 'color: #1890ff; text-decoration: none;',
            hr: 'border: none; height: 1px; background: linear-gradient(to right, transparent, #ddd, transparent); margin: 24px 0;',
            highlight: 'background: linear-gradient(to bottom, transparent 60%, #fff3cd 60%); padding: 0 4px;'
        };
        html = html.replace(/^#### (.+)$/gm, `<h4 style="${styles.h4}">$1</h4>`);
        html = html.replace(/^### (.+)$/gm, `<h3 style="${styles.h3}">$1</h3>`);
        html = html.replace(/^## (.+)$/gm, `<h2 style="${styles.h2}">$1</h2>`);
        html = html.replace(/^# (.+)$/gm, `<h1 style="${styles.h1}">$1</h1>`);
        html = html.replace(/```(\w+)?\n([\s\S]+?)```/g, (match, lang, code) => {
            return `<pre style="${styles.pre}"><code>${code.trim()}</code></pre>`;
        });
        html = html.replace(/`([^`]+)`/g, `<code style="${styles.code}">$1</code>`);
        html = html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, `<img src="$2" alt="$1" style="${styles.img}" />`);
        html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, `<a href="$2" style="${styles.a}">$1</a>`);
        html = html.replace(/\*\*(.+?)\*\*/g, `<strong style="${styles.strong}">$1</strong>`);
        html = html.replace(/\*(.+?)\*/g, `<em style="${styles.em}">$1</em>`);
        html = html.replace(/==(.+?)==/g, `<span style="${styles.highlight}">$1</span>`);
        html = html.replace(/^> 💡 (.+)$/gm, `<blockquote style="${styles.blockquote}"><span style="font-size: 18px;">💡</span> <strong>金句：</strong>$1</blockquote>`);
        html = html.replace(/^> ⚠️ (.+)$/gm, `<blockquote style="${styles.blockquote}; border-left-color: #ff9800;"><span style="font-size: 18px;">⚠️</span> $1</blockquote>`);
        html = html.replace(/^> ✨ (.+)$/gm, `<blockquote style="${styles.blockquote}; border-left-color: #9c27b0;"><span style="font-size: 18px;">✨</span> $1</blockquote>`);
        html = html.replace(/^> (.+)$/gm, `<blockquote style="${styles.blockquote}">$1</blockquote>`);
        html = html.replace(/^- (.+)$/gm, `<li style="${styles.li}">$1</li>`);
        html = html.replace(/(<li style="[^"]+">.*<\/li>\n?)+/g, `<ul style="${styles.ul}">$&</ul>`);
        html = html.replace(/^\d+\. (.+)$/gm, `<li style="${styles.li}">$1</li>`);
        html = html.replace(/^---$/gm, `<hr style="${styles.hr}" />`);
        html = html.replace(/^\*\*\*$/gm, `<hr style="${styles.hr}" />`);
        html = html.replace(/\n\n/g, '</p><p style="' + styles.p + '">');
        html = html.replace(/<p style="[^"]+">\s*<\/p>/g, '');
        html = `<section style="${styles.container}">
      ${title ? `<h1 style="${styles.h1}">${title}</h1>` : ''}
      <p style="${styles.p}">${html}</p>
    </section>`;
        html = html.replace(/<p style="[^"]+"><\/p>/g, '');
        html = html.replace(/<p style="[^"]+">\s*<h/g, '<h');
        html = html.replace(/<\/h(\d)>\s*<\/p>/g, '</h$1>');
        return html;
    }
    getWechatErrorMessage(errcode) {
        const errorMessages = {
            40001: 'AppSecret错误或不属于该公众号',
            40013: '不合法的AppID',
            40164: '服务器IP未加入白名单',
            41001: '缺少access_token参数',
            41004: '缺少AppSecret参数',
            42001: 'access_token已过期',
            45009: '接口调用超过限制',
            45011: 'API调用太频繁',
            45017: '标题不能为空',
            45018: '内容不能为空',
            45024: '素材数量超出限制',
            46003: '菜单不存在',
            47001: '解析JSON/XML内容错误',
            48001: 'api功能未授权（需要认证的服务号）',
            48004: '接口调用失败，请检查公众号权限',
            50002: '用户受限',
            50005: '用户未关注公众号',
            61004: 'access_token已过期或无效',
            87009: '账号安全问题',
            87010: '涉嫌违法内容',
            87011: '涉嫌营销内容',
            87012: '内容涉及敏感信息',
        };
        return errorMessages[errcode] || `微信API错误码：${errcode}`;
    }
};
exports.PublishWechatMpTool = PublishWechatMpTool;
exports.PublishWechatMpTool = PublishWechatMpTool = __decorate([
    (0, common_1.Injectable)()
], PublishWechatMpTool);
let PublishXiaohongshuTool = class PublishXiaohongshuTool {
    constructor() {
        this.definition = {
            name: 'publish_xiaohongshu',
            displayName: '发布小红书笔记',
            description: '准备发布笔记到小红书。注意：小红书暂无官方开放API，此工具仅用于生成内容，需要用户手动复制发布。',
            category: 'platform_publish',
            paramsSchema: {
                title: { type: 'string', description: '笔记标题', required: true },
                content: { type: 'string', description: '笔记内容', required: true },
                images: { type: 'array', items: { type: 'string' }, description: '图片URL列表' },
                tags: { type: 'array', items: { type: 'string' }, description: '话题标签' }
            },
            requiresPlatform: 'xiaohongshu'
        };
    }
    async execute(params, context) {
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data: config } = await client
                .from('platform_configs')
                .select('*')
                .eq('user_id', context.userId)
                .eq('platform_type', 'xiaohongshu')
                .maybeSingle();
            if (!config || config.status !== 'active') {
                const template = agent_types_1.PLATFORM_CONFIG_TEMPLATES['xiaohongshu'];
                return {
                    success: false,
                    error: '未配置小红书',
                    requires_config: true,
                    config_platform: 'xiaohongshu',
                    config_fields: template.fields
                };
            }
            console.log('Agent工具 - 准备小红书笔记内容:', params.title);
            return {
                success: true,
                data: {
                    title: params.title,
                    content: params.content,
                    images: params.images,
                    tags: params.tags,
                    manual_publish_required: true,
                    message: `⚠️ 重要提示：小红书暂无官方开放API，无法自动发布。\n\n请按以下步骤手动发布：\n1. 打开小红书APP\n2. 点击底部的"+"号\n3. 选择"图文"\n4. 复制下方内容发布\n\n📋 标题：\n${params.title}\n\n📝 内容：\n${params.content}\n\n${params.tags?.length ? `🏷️ 标签：${params.tags.join(' ')}` : ''}`
                }
            };
        }
        catch (err) {
            return { success: false, error: `发布失败: ${err.message}` };
        }
    }
};
exports.PublishXiaohongshuTool = PublishXiaohongshuTool;
exports.PublishXiaohongshuTool = PublishXiaohongshuTool = __decorate([
    (0, common_1.Injectable)()
], PublishXiaohongshuTool);
let PublishBilibiliTool = class PublishBilibiliTool {
    constructor() {
        this.definition = {
            name: 'publish_bilibili',
            displayName: '发布B站内容',
            description: '准备发布视频或文章到B站。注意：B站暂无官方开放API，此工具仅用于生成内容，需要用户手动发布。',
            category: 'platform_publish',
            paramsSchema: {
                type: { type: 'string', enum: ['video', 'article'], default: 'article' },
                title: { type: 'string', description: '标题', required: true },
                content: { type: 'string', description: '文章内容' },
                video_url: { type: 'string', description: '视频URL' },
                cover_url: { type: 'string', description: '封面URL' },
                tags: { type: 'array', items: { type: 'string' }, description: '标签' }
            },
            requiresPlatform: 'bilibili'
        };
    }
    async execute(params, context) {
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data: config } = await client
                .from('platform_configs')
                .select('*')
                .eq('user_id', context.userId)
                .eq('platform_type', 'bilibili')
                .maybeSingle();
            if (!config || config.status !== 'active') {
                const template = agent_types_1.PLATFORM_CONFIG_TEMPLATES['bilibili'];
                return {
                    success: false,
                    error: '未配置B站',
                    requires_config: true,
                    config_platform: 'bilibili',
                    config_fields: template.fields
                };
            }
            console.log('Agent工具 - 准备B站内容:', params.title);
            return {
                success: true,
                data: {
                    title: params.title,
                    content: params.content,
                    video_url: params.video_url,
                    cover_url: params.cover_url,
                    tags: params.tags,
                    manual_publish_required: true,
                    message: `⚠️ 重要提示：B站暂无官方开放API，无法自动发布。\n\n请按以下步骤手动发布：\n1. 打开B站创作中心 (member.bilibili.com)\n2. 选择"${params.type === 'video' ? '视频投稿' : '专栏投稿'}"\n3. 上传内容并填写信息\n\n📋 标题：${params.title}\n${params.content ? `\n📝 内容：\n${params.content.substring(0, 500)}${params.content.length > 500 ? '...' : ''}` : ''}${params.video_url ? `\n\n🎥 视频URL：${params.video_url}` : ''}`
                }
            };
        }
        catch (err) {
            return { success: false, error: `发布失败: ${err.message}` };
        }
    }
};
exports.PublishBilibiliTool = PublishBilibiliTool;
exports.PublishBilibiliTool = PublishBilibiliTool = __decorate([
    (0, common_1.Injectable)()
], PublishBilibiliTool);
let PublishWeiboTool = class PublishWeiboTool {
    constructor() {
        this.definition = {
            name: 'publish_weibo',
            displayName: '发布微博',
            description: '准备发布微博内容。注意：微博暂无官方开放API，此工具仅用于生成内容，需要用户手动发布。',
            category: 'platform_publish',
            paramsSchema: {
                content: { type: 'string', description: '微博内容', required: true },
                images: { type: 'array', items: { type: 'string' }, description: '图片URL列表' }
            },
            requiresPlatform: 'weibo'
        };
    }
    async execute(params, context) {
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data: config } = await client
                .from('platform_configs')
                .select('*')
                .eq('user_id', context.userId)
                .eq('platform_type', 'weibo')
                .maybeSingle();
            if (!config || config.status !== 'active') {
                const template = agent_types_1.PLATFORM_CONFIG_TEMPLATES['weibo'];
                return {
                    success: false,
                    error: '未配置微博',
                    requires_config: true,
                    config_platform: 'weibo',
                    config_fields: template.fields
                };
            }
            console.log('Agent工具 - 准备微博内容');
            return {
                success: true,
                data: {
                    content: params.content,
                    images: params.images,
                    manual_publish_required: true,
                    message: `⚠️ 重要提示：微博暂无官方开放API，无法自动发布。\n\n请复制以下内容手动发布到微博：\n\n📝 内容：\n${params.content}${params.images?.length ? `\n\n🖼️ 图片：${params.images.length}张` : ''}`
                }
            };
        }
        catch (err) {
            return { success: false, error: `发布失败: ${err.message}` };
        }
    }
};
exports.PublishWeiboTool = PublishWeiboTool;
exports.PublishWeiboTool = PublishWeiboTool = __decorate([
    (0, common_1.Injectable)()
], PublishWeiboTool);
let PublishDouyinTool = class PublishDouyinTool {
    constructor() {
        this.definition = {
            name: 'publish_douyin',
            displayName: '发布抖音视频',
            description: '准备发布视频到抖音。注意：抖音暂无官方开放API，此工具仅用于生成内容，需要用户手动发布。',
            category: 'platform_publish',
            paramsSchema: {
                title: { type: 'string', description: '视频标题', required: true },
                video_url: { type: 'string', description: '视频URL', required: true },
                cover_url: { type: 'string', description: '封面URL' },
                tags: { type: 'array', items: { type: 'string' }, description: '话题标签' }
            },
            requiresPlatform: 'douyin'
        };
    }
    async execute(params, context) {
        try {
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data: config } = await client
                .from('platform_configs')
                .select('*')
                .eq('user_id', context.userId)
                .eq('platform_type', 'douyin')
                .maybeSingle();
            if (!config || config.status !== 'active') {
                const template = agent_types_1.PLATFORM_CONFIG_TEMPLATES['douyin'];
                return {
                    success: false,
                    error: '未配置抖音',
                    requires_config: true,
                    config_platform: 'douyin',
                    config_fields: template.fields
                };
            }
            console.log('Agent工具 - 准备抖音视频:', params.title);
            return {
                success: true,
                data: {
                    title: params.title,
                    video_url: params.video_url,
                    cover_url: params.cover_url,
                    tags: params.tags,
                    manual_publish_required: true,
                    message: `⚠️ 重要提示：抖音暂无官方开放API，无法自动发布。\n\n请按以下步骤手动发布：\n1. 打开抖音APP或创作者中心 (creator.douyin.com)\n2. 点击上传视频\n3. 填写以下信息：\n\n📋 标题：${params.title}\n🎥 视频URL：${params.video_url}${params.tags?.length ? `\n🏷️ 标签：${params.tags.join(' ')}` : ''}`
                }
            };
        }
        catch (err) {
            return { success: false, error: `发布失败: ${err.message}` };
        }
    }
};
exports.PublishDouyinTool = PublishDouyinTool;
exports.PublishDouyinTool = PublishDouyinTool = __decorate([
    (0, common_1.Injectable)()
], PublishDouyinTool);
let PublishWechatVideoTool = class PublishWechatVideoTool {
    constructor() {
        this.definition = {
            name: 'publish_wechat_video',
            displayName: '发布视频号',
            description: '准备发布视频到微信视频号。注意：视频号暂无官方开放API，此工具仅用于生成内容，需要用户手动发布。',
            category: 'platform_publish',
            paramsSchema: {
                title: { type: 'string', description: '视频标题', required: true },
                video_url: { type: 'string', description: '视频URL', required: true },
                cover_url: { type: 'string', description: '封面URL' },
                description: { type: 'string', description: '视频描述' }
            }
        };
    }
    async execute(params, context) {
        try {
            return {
                success: true,
                data: {
                    title: params.title,
                    video_url: params.video_url,
                    cover_url: params.cover_url,
                    description: params.description,
                    message: '视频内容已准备完成。由于微信视频号暂无官方开放API，请手动前往微信视频号创作者平台发布视频。',
                    manual_action_required: true,
                    action_url: 'https://channels.weixin.qq.com'
                }
            };
        }
        catch (err) {
            return { success: false, error: err.message };
        }
    }
};
exports.PublishWechatVideoTool = PublishWechatVideoTool;
exports.PublishWechatVideoTool = PublishWechatVideoTool = __decorate([
    (0, common_1.Injectable)()
], PublishWechatVideoTool);
//# sourceMappingURL=platform-publish.tools.js.map