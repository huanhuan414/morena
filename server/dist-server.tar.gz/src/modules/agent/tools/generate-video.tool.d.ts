import { ITool, ToolExecutionContext, ToolResult } from '../tools.interface';
export declare class GenerateVideoTool implements ITool {
    name: string;
    description: string;
    private storage;
    constructor();
    parameters: {
        type: "object";
        properties: {
            prompt: {
                type: "string";
                description: string;
            };
            duration: {
                type: "number";
                description: string;
                default: number;
            };
            ratio: {
                type: "string";
                description: string;
                default: string;
            };
            resolution: {
                type: "string";
                description: string;
                default: string;
            };
            generateAudio: {
                type: "boolean";
                description: string;
                default: boolean;
            };
            firstFrameUrl: {
                type: "string";
                description: string;
            };
        };
        required: string[];
    };
    execute(params: Record<string, any>, context: ToolExecutionContext): Promise<ToolResult>;
}
