import { Tool, ToolExecutionContext, ToolResult } from '../tools.interface';
export declare class QueryDataTool implements Tool {
    name: string;
    description: string;
    parameters: {
        data_type: {
            type: string;
            description: string;
            required: boolean;
        };
        filter: {
            type: string;
            description: string;
            required: boolean;
        };
        limit: {
            type: string;
            description: string;
            required: boolean;
        };
    };
    execute(params: Record<string, any>, context: ToolExecutionContext): Promise<ToolResult>;
}
