"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateDocumentTool = void 0;
const common_1 = require("@nestjs/common");
const supabase_client_1 = require("../../../storage/database/supabase-client");
let CreateDocumentTool = class CreateDocumentTool {
    constructor() {
        this.name = 'create_document';
        this.description = '创建文档或笔记。当需要保存研究结果、生成报告、整理笔记时使用此工具。';
        this.parameters = {
            title: {
                type: 'string',
                description: '文档标题',
                required: true
            },
            content: {
                type: 'string',
                description: '文档内容，支持 Markdown 格式',
                required: true
            },
            type: {
                type: 'string',
                description: '文档类型：note(笔记), report(报告), article(文章)',
                required: false
            }
        };
    }
    async execute(params, context) {
        try {
            const { title, content, type = 'note' } = params;
            console.log(`[CreateDocumentTool] 创建文档: ${title}`);
            const client = (0, supabase_client_1.getSupabaseClient)();
            const { data, error } = await client
                .from('documents')
                .insert({
                user_id: context.userId,
                avatar_id: context.avatarId,
                title,
                content,
                type,
                created_at: new Date().toISOString()
            })
                .select()
                .single();
            if (error) {
                console.log('[CreateDocumentTool] 保存到任务记录');
                const { data: taskData } = await client
                    .from('tasks')
                    .insert({
                    user_id: context.userId,
                    avatar_id: context.avatarId,
                    title: `📄 ${title}`,
                    description: content,
                    task_type: 'document',
                    status: 'completed',
                    progress: 100,
                    result: { title, content, type },
                    logs: [{
                            timestamp: new Date().toISOString(),
                            action: 'document_created',
                            message: `文档已创建`
                        }]
                })
                    .select()
                    .single();
                return {
                    success: true,
                    data: {
                        id: taskData?.id,
                        title,
                        type,
                        contentPreview: content.substring(0, 200)
                    },
                    message: `文档已创建: ${title}`
                };
            }
            return {
                success: true,
                data: {
                    id: data?.id,
                    title,
                    type,
                    contentPreview: content.substring(0, 200)
                },
                message: `文档已创建: ${title}`
            };
        }
        catch (error) {
            console.error('[CreateDocumentTool] 创建失败:', error);
            return {
                success: false,
                error: error.message,
                message: `创建文档失败: ${error.message}`
            };
        }
    }
};
exports.CreateDocumentTool = CreateDocumentTool;
exports.CreateDocumentTool = CreateDocumentTool = __decorate([
    (0, common_1.Injectable)()
], CreateDocumentTool);
//# sourceMappingURL=create-document.tool.js.map