import { ITool, ToolContext, ToolDefinition } from './tool.interface';
import { ToolResult } from '../agent.types';
export declare class WriteArticleTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class WriteWechatMpArticleTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class WriteXiaohongshuNoteTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class GenerateImageTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class GenerateVideoTool implements ITool {
    readonly definition: ToolDefinition;
    private storage;
    constructor();
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
export declare class BatchGenerateTool implements ITool {
    readonly definition: ToolDefinition;
    execute(params: Record<string, any>, context: ToolContext): Promise<ToolResult>;
}
