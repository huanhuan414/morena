import { Tool, ToolResult, ToolCallRequest, ToolExecutionContext } from './tools.interface';
import { SearchTool } from './tools/search.tool';
import { SendMessageTool } from './tools/send-message.tool';
import { CreateDocumentTool } from './tools/create-document.tool';
import { QueryDataTool } from './tools/query-data.tool';
import { GenerateImageTool } from './tools/generate-image.tool';
import { GenerateVideoTool } from './tools/generate-video.tool';
export declare class ToolsRegistry {
    private readonly searchTool;
    private readonly sendMessageTool;
    private readonly createDocumentTool;
    private readonly queryDataTool;
    private readonly generateImageTool;
    private readonly generateVideoTool;
    private tools;
    constructor(searchTool: SearchTool, sendMessageTool: SendMessageTool, createDocumentTool: CreateDocumentTool, queryDataTool: QueryDataTool, generateImageTool: GenerateImageTool, generateVideoTool: GenerateVideoTool);
    private register;
    getToolsDefinition(): Array<{
        name: string;
        description: string;
        parameters: Record<string, any>;
    }>;
    executeTool(request: ToolCallRequest, context: ToolExecutionContext): Promise<ToolResult>;
    hasTool(name: string): boolean;
    getTool(name: string): Tool | undefined;
}
