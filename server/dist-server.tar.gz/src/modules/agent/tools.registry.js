"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolsRegistry = void 0;
const common_1 = require("@nestjs/common");
const search_tool_1 = require("./tools/search.tool");
const send_message_tool_1 = require("./tools/send-message.tool");
const create_document_tool_1 = require("./tools/create-document.tool");
const query_data_tool_1 = require("./tools/query-data.tool");
const generate_image_tool_1 = require("./tools/generate-image.tool");
const generate_video_tool_1 = require("./tools/generate-video.tool");
let ToolsRegistry = class ToolsRegistry {
    constructor(searchTool, sendMessageTool, createDocumentTool, queryDataTool, generateImageTool, generateVideoTool) {
        this.searchTool = searchTool;
        this.sendMessageTool = sendMessageTool;
        this.createDocumentTool = createDocumentTool;
        this.queryDataTool = queryDataTool;
        this.generateImageTool = generateImageTool;
        this.generateVideoTool = generateVideoTool;
        this.tools = new Map();
        this.register(searchTool);
        this.register(sendMessageTool);
        this.register(createDocumentTool);
        this.register(queryDataTool);
        this.register(generateImageTool);
        this.register(generateVideoTool);
    }
    register(tool) {
        this.tools.set(tool.name, tool);
        console.log(`[ToolsRegistry] 注册工具: ${tool.name}`);
    }
    getToolsDefinition() {
        return Array.from(this.tools.values()).map(tool => ({
            name: tool.name,
            description: tool.description,
            parameters: tool.parameters
        }));
    }
    async executeTool(request, context) {
        const tool = this.tools.get(request.tool);
        if (!tool) {
            return {
                success: false,
                error: `未知的工具: ${request.tool}`,
                message: `工具 "${request.tool}" 不存在`
            };
        }
        console.log(`[ToolsRegistry] 执行工具: ${request.tool}`, request.parameters);
        try {
            const result = await tool.execute(request.parameters || {}, context);
            console.log(`[ToolsRegistry] 工具执行结果:`, result.success ? '成功' : '失败');
            return result;
        }
        catch (error) {
            console.error(`[ToolsRegistry] 工具执行异常:`, error);
            return {
                success: false,
                error: error.message,
                message: `工具执行失败: ${error.message}`
            };
        }
    }
    hasTool(name) {
        return this.tools.has(name);
    }
    getTool(name) {
        return this.tools.get(name);
    }
};
exports.ToolsRegistry = ToolsRegistry;
exports.ToolsRegistry = ToolsRegistry = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [search_tool_1.SearchTool,
        send_message_tool_1.SendMessageTool,
        create_document_tool_1.CreateDocumentTool,
        query_data_tool_1.QueryDataTool,
        generate_image_tool_1.GenerateImageTool,
        generate_video_tool_1.GenerateVideoTool])
], ToolsRegistry);
//# sourceMappingURL=tools.registry.js.map