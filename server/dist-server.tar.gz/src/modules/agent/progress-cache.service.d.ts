export interface TaskProgress {
    taskId: string;
    userId: string;
    type: string;
    message: string;
    data?: any;
    timestamp: number;
    status?: 'pending' | 'running' | 'completed' | 'failed';
}
export interface TaskResult {
    taskId: string;
    userId: string;
    status: 'pending' | 'running' | 'completed' | 'failed';
    result?: any;
    error?: string;
    createdAt: number;
    completedAt?: number;
}
export declare class ProgressCacheService {
    private progressMap;
    private resultMap;
    private readonly MAX_PROGRESS_ITEMS;
    private readonly EXPIRE_TIME;
    createTask(userId: string, taskId: string): TaskResult;
    updateTaskStatus(userId: string, taskId: string, status: TaskResult['status'], result?: any, error?: string): void;
    getTaskResult(userId: string, taskId: string): TaskResult | null;
    getUserTasks(userId: string): TaskResult[];
    updateProgress(userId: string, progress: TaskProgress): void;
    addProgress(userId: string, progress: TaskProgress): void;
    getProgress(userId: string, taskId?: string): TaskProgress[];
    getLatestProgress(userId: string, taskId?: string): TaskProgress | null;
    clearProgress(userId: string, taskId?: string): void;
    cleanupExpired(): void;
}
