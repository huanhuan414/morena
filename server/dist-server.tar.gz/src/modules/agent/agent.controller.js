"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentController = void 0;
const common_1 = require("@nestjs/common");
const agent_service_1 = require("./agent.service");
const progress_cache_service_1 = require("./progress-cache.service");
let AgentController = class AgentController {
    constructor(agentService, progressCache) {
        this.agentService = agentService;
        this.progressCache = progressCache;
    }
    async getTools() {
        const tools = this.agentService.getAvailableTools();
        return {
            code: 200,
            data: tools,
            message: '获取成功'
        };
    }
    async getProgress(userId, taskId) {
        const progress = this.progressCache.getProgress(userId, taskId);
        const latestProgress = this.progressCache.getLatestProgress(userId, taskId);
        return {
            code: 200,
            data: {
                progress,
                latest: latestProgress,
                count: progress.length
            },
            message: '获取成功'
        };
    }
    async getTaskResult(userId, taskId) {
        const result = this.progressCache.getTaskResult(userId, taskId);
        if (!result) {
            return {
                code: 404,
                data: null,
                message: '任务不存在或已过期'
            };
        }
        return {
            code: 200,
            data: result,
            message: '获取成功'
        };
    }
    async executeTask(userId, body) {
        const taskId = body.task_id || `task-${Date.now()}`;
        this.progressCache.createTask(userId, taskId);
        this.agentService.executeTaskAsync(userId, body.avatar_id, body.task_description, {
            conversationId: body.conversation_id,
            taskId,
            conversationHistory: body.conversation_history,
            uploadedImages: body.attachments?.images || [],
            uploadedVideos: body.attachments?.videos || []
        }).catch(err => {
            console.error(`[AgentController] 任务执行失败: ${taskId}`, err);
            this.progressCache.updateTaskStatus(userId, taskId, 'failed', null, err.message);
        });
        return {
            code: 200,
            data: {
                taskId,
                status: 'pending'
            },
            message: '任务已提交，请通过轮询获取进度和结果'
        };
    }
    async checkPlatformConfig(userId, platform) {
        const result = await this.agentService.checkPlatformConfig(userId, platform);
        return {
            code: 200,
            data: result,
            message: '查询成功'
        };
    }
    async getUserPlatformConfigs(userId) {
        const configs = await this.agentService.getUserPlatformConfigs(userId);
        const safeConfigs = configs.map(config => ({
            ...config,
            config_data: Object.keys(config.config_data).reduce((acc, key) => {
                acc[key] = '******';
                return acc;
            }, {})
        }));
        return {
            code: 200,
            data: safeConfigs,
            message: '获取成功'
        };
    }
    async savePlatformConfig(userId, platform, configData) {
        const result = await this.agentService.savePlatformConfig(userId, platform, configData);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async validatePlatformConfig(platform, configData) {
        const result = await this.agentService.validatePlatformConfig(platform, configData);
        return {
            code: 200,
            data: result,
            message: result.valid ? '验证成功' : '验证失败'
        };
    }
    async deletePlatformConfig(userId, platform) {
        await this.agentService.deletePlatformConfig(userId, platform);
        return {
            code: 200,
            data: null,
            message: '删除成功'
        };
    }
    async getAvatarSkills(avatarId) {
        const skills = await this.agentService.getAvatarSkills(avatarId);
        return {
            code: 200,
            data: skills,
            message: '获取成功'
        };
    }
    async addAvatarSkill(avatarId, body) {
        const result = await this.agentService.addAvatarSkill(avatarId, body.skill_type, body.metadata);
        return {
            code: 200,
            data: null,
            message: '技能添加成功'
        };
    }
    async publishContent(userId, platform, body) {
        const result = await this.agentService.publishContent(userId, platform, body);
        return {
            code: result.success ? 200 : 400,
            data: result.data,
            message: result.message || (result.success ? '发布成功' : '发布失败')
        };
    }
    async generateImage(body) {
        try {
            const axios = require('axios');
            const apiUrl = 'https://ark.cn-beijing.volces.com/api/v3/images/generations';
            const apiKey = process.env.VOLC_VIDEO_API_KEY || '0a6405d5-b7ae-4afa-88e3-c707ae379a47';
            console.log('[AgentController] 生成图片:', {
                prompt_length: body.prompt?.length,
                size: body.size || '2K',
                style: body.style || 'realistic'
            });
            const response = await axios.post(apiUrl, {
                model: 'doubao-seedream-4-0-250828',
                prompt: body.prompt,
                sequential_image_generation: 'disabled',
                response_format: 'url',
                size: body.size || '2K',
                stream: false,
                watermark: false
            }, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${apiKey}`
                },
                timeout: 120000
            });
            console.log('[AgentController] 图片生成响应:', response.status, response.statusText);
            if (response.status !== 200) {
                const errorMsg = response.data?.error?.message || response.data?.message || '图片生成失败';
                return {
                    code: 400,
                    msg: errorMsg
                };
            }
            return {
                code: 200,
                data: {
                    url: response.data.data?.[0]?.url || response.data.url,
                    revised_prompt: response.data.data?.[0]?.revised_prompt
                }
            };
        }
        catch (error) {
            console.error('[AgentController] 图片生成失败:', error.message);
            return {
                code: 500,
                msg: `图片生成失败: ${error.message}`
            };
        }
    }
};
exports.AgentController = AgentController;
__decorate([
    (0, common_1.Get)('tools'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AgentController.prototype, "getTools", null);
__decorate([
    (0, common_1.Get)('progress'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('taskId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AgentController.prototype, "getProgress", null);
__decorate([
    (0, common_1.Get)('result/:taskId'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Param)('taskId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AgentController.prototype, "getTaskResult", null);
__decorate([
    (0, common_1.Post)('execute'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AgentController.prototype, "executeTask", null);
__decorate([
    (0, common_1.Get)('platform-config/:platform'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Param)('platform')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AgentController.prototype, "checkPlatformConfig", null);
__decorate([
    (0, common_1.Get)('platform-configs'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AgentController.prototype, "getUserPlatformConfigs", null);
__decorate([
    (0, common_1.Post)('platform-config/:platform'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Param)('platform')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AgentController.prototype, "savePlatformConfig", null);
__decorate([
    (0, common_1.Post)('platform-config/:platform/validate'),
    __param(0, (0, common_1.Param)('platform')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AgentController.prototype, "validatePlatformConfig", null);
__decorate([
    (0, common_1.Delete)('platform-config/:platform'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Param)('platform')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AgentController.prototype, "deletePlatformConfig", null);
__decorate([
    (0, common_1.Get)('skills/:avatarId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AgentController.prototype, "getAvatarSkills", null);
__decorate([
    (0, common_1.Post)('skills/:avatarId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AgentController.prototype, "addAvatarSkill", null);
__decorate([
    (0, common_1.Post)('publish/:platform'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Param)('platform')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AgentController.prototype, "publishContent", null);
__decorate([
    (0, common_1.Post)('images/generations'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AgentController.prototype, "generateImage", null);
exports.AgentController = AgentController = __decorate([
    (0, common_1.Controller)('agent'),
    __metadata("design:paramtypes", [agent_service_1.AgentService,
        progress_cache_service_1.ProgressCacheService])
], AgentController);
//# sourceMappingURL=agent.controller.js.map