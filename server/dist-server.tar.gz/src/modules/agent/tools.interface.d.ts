export type ToolParameters = Record<string, {
    type: string;
    description: string;
    required?: boolean;
}> | {
    type: 'object';
    properties: Record<string, {
        type: string;
        description: string;
        default?: any;
    }>;
    required: string[];
};
export interface ITool {
    name: string;
    description: string;
    parameters: ToolParameters;
    execute: (params: Record<string, any>, context: ToolExecutionContext) => Promise<ToolResult>;
}
export type Tool = ITool;
export interface ToolContext {
    userId: string;
    avatarId: string;
    conversationId: string;
    headers?: Record<string, string>;
}
export interface ToolExecutionContext extends ToolContext {
    taskId: string;
}
export interface ToolResult {
    success: boolean;
    data?: any;
    error?: string;
    message: string;
    percentage?: number;
}
export interface ToolCallRequest {
    tool: string;
    parameters: Record<string, any>;
    thought?: string;
}
export interface AgentStep {
    step: number;
    thought: string;
    action: string;
    tool?: string;
    parameters?: any;
    observation?: string;
    result?: ToolResult;
    timestamp: string;
}
export interface AgentExecutionResult {
    success: boolean;
    steps: AgentStep[];
    finalAnswer: string;
    toolsUsed: string[];
    duration: number;
    error?: string;
}
