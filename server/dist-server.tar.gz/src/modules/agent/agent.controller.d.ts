import { AgentService } from './agent.service';
import { PlatformType } from './agent.types';
import { ProgressCacheService } from './progress-cache.service';
export declare class AgentController {
    private readonly agentService;
    private readonly progressCache;
    constructor(agentService: AgentService, progressCache: ProgressCacheService);
    getTools(): Promise<{
        code: number;
        data: import("./agent.types").ToolDefinition[];
        message: string;
    }>;
    getProgress(userId: string, taskId?: string): Promise<{
        code: number;
        data: {
            progress: import("./progress-cache.service").TaskProgress[];
            latest: import("./progress-cache.service").TaskProgress | null;
            count: number;
        };
        message: string;
    }>;
    getTaskResult(userId: string, taskId: string): Promise<{
        code: number;
        data: null;
        message: string;
    } | {
        code: number;
        data: import("./progress-cache.service").TaskResult;
        message: string;
    }>;
    executeTask(userId: string, body: {
        avatar_id: string;
        task_description: string;
        conversation_id?: string;
        task_id?: string;
        conversation_history?: Array<{
            role: string;
            content: string;
        }>;
        attachments?: {
            images?: string[];
            videos?: string[];
        };
    }): Promise<{
        code: number;
        data: {
            taskId: string;
            status: string;
        };
        message: string;
    }>;
    checkPlatformConfig(userId: string, platform: PlatformType): Promise<{
        code: number;
        data: {
            configured: boolean;
            config?: import("./agent.types").PlatformConfig;
            requiredFields?: any[];
        };
        message: string;
    }>;
    getUserPlatformConfigs(userId: string): Promise<{
        code: number;
        data: {
            config_data: Record<string, string>;
            id: string;
            user_id: string;
            platform_type: PlatformType;
            status: import("./agent.types").PlatformConfigStatus;
            last_used_at?: string;
            created_at: string;
            updated_at: string;
        }[];
        message: string;
    }>;
    savePlatformConfig(userId: string, platform: PlatformType, configData: Record<string, any>): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    validatePlatformConfig(platform: PlatformType, configData: Record<string, any>): Promise<{
        code: number;
        data: {
            valid: boolean;
            message?: string;
            accountInfo?: any;
            serverIp?: string;
        };
        message: string;
    }>;
    deletePlatformConfig(userId: string, platform: PlatformType): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    getAvatarSkills(avatarId: string): Promise<{
        code: number;
        data: import("./agent.types").AvatarSkill[];
        message: string;
    }>;
    addAvatarSkill(avatarId: string, body: {
        skill_type: string;
        metadata?: Record<string, any>;
    }): Promise<{
        code: number;
        data: null;
        message: string;
    }>;
    publishContent(userId: string, platform: PlatformType, body: {
        title?: string;
        content?: string;
        cover_url?: string;
        images?: string[];
        tags?: string[];
    }): Promise<{
        code: number;
        data: any;
        message: string;
    }>;
    generateImage(body: {
        prompt: string;
        size?: string;
        style?: string;
    }): Promise<{
        code: number;
        msg: any;
        data?: undefined;
    } | {
        code: number;
        data: {
            url: any;
            revised_prompt: any;
        };
        msg?: undefined;
    }>;
}
