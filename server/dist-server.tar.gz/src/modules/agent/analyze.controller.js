"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnalyzeController = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
let AnalyzeController = class AnalyzeController {
    async analyzeLayout(body) {
        const { imageUrl } = body;
        const config = new coze_coding_dev_sdk_1.Config();
        const client = new coze_coding_dev_sdk_1.LLMClient(config);
        const messages = [
            {
                role: 'system',
                content: '你是一个专业的 UI/UX 设计师，擅长分析聊天应用的输入栏布局。请详细描述图片中输入栏的布局结构，包括按钮的位置、大小、间距、排列方式等。',
            },
            {
                role: 'user',
                content: [
                    {
                        type: 'text',
                        text: '请详细描述这个聊天页面底部输入栏的布局设计，包括：1. 所有按钮的位置和排列方式 2. 按钮的大小和样式 3. 输入框的位置和样式 4. 整体的布局结构',
                    },
                    {
                        type: 'image_url',
                        image_url: {
                            url: imageUrl,
                            detail: 'high',
                        },
                    },
                ],
            },
        ];
        const response = await client.invoke(messages, {
            model: 'doubao-seed-1-6-vision-250815',
            temperature: 0.3,
        });
        return {
            code: 200,
            msg: '分析成功',
            data: {
                analysis: response.content,
            },
        };
    }
};
exports.AnalyzeController = AnalyzeController;
__decorate([
    (0, common_1.Post)('layout'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AnalyzeController.prototype, "analyzeLayout", null);
exports.AnalyzeController = AnalyzeController = __decorate([
    (0, common_1.Controller)('analyze')
], AnalyzeController);
//# sourceMappingURL=analyze.controller.js.map