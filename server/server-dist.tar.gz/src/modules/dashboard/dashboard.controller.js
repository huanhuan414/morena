"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardController = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const TEST_USER_IDS = ['dev_user', 'test_user', 'guest-user-id', 'anonymous'];
let DashboardController = class DashboardController {
    async getDashboardStats(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        try {
            const isTestUser = userId && TEST_USER_IDS.includes(userId);
            const hasValidUserId = userId && userId.trim() && !isTestUser;
            let avatarCount = 0;
            try {
                if (!userId || !userId.trim() || userId.length < 10) {
                    const countResult = await db.query('SELECT COUNT(*) as count FROM avatars WHERE status = ?', ['active']);
                    avatarCount = countResult?.[0]?.count || 0;
                    console.log('[Dashboard] 无用户ID/测试用户，返回所有分身数量:', avatarCount);
                }
                else {
                    console.log('[Dashboard] 有效用户:', userId);
                    const avatarResult = await db.query('SELECT COUNT(*) as count FROM avatars WHERE user_id = ? AND status = ?', [userId, 'active']);
                    avatarCount = avatarResult?.[0]?.count || 0;
                    console.log('[Dashboard] 查询结果:', JSON.stringify(avatarResult));
                }
            }
            catch (err) {
                console.error('[Dashboard] 查询失败:', err);
            }
            let orderCount = 0;
            if (userId && userId.trim()) {
                const orderResult = await db.query('SELECT COUNT(*) as count FROM orders WHERE user_id = ?', [userId]);
                orderCount = orderResult?.[0]?.count || 0;
            }
            let totalEarnings = '0.00';
            if (userId && userId.trim()) {
                const earningResult = await db.query('SELECT SUM(amount) as total FROM earnings WHERE user_id = ?', [userId]);
                totalEarnings = earningResult?.[0]?.total || '0.00';
            }
            return {
                code: 200,
                msg: 'success',
                data: {
                    avatar_count: avatarCount,
                    order_count: orderCount,
                    total_earnings: totalEarnings,
                    user_avatar: null
                }
            };
        }
        catch (error) {
            console.error('获取仪表盘统计失败:', error);
            return {
                code: 200,
                msg: 'success',
                data: {
                    avatar_count: 0,
                    order_count: 0,
                    total_earnings: '0.00',
                    user_avatar: null
                }
            };
        }
    }
};
exports.DashboardController = DashboardController;
__decorate([
    (0, common_1.Get)('stats'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], DashboardController.prototype, "getDashboardStats", null);
exports.DashboardController = DashboardController = __decorate([
    (0, common_1.Controller)('dashboard')
], DashboardController);
