"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VoiceCloneService = void 0;
const common_1 = require("@nestjs/common");
const axios_1 = require("axios");
const BYTEDANCE_TTS_API = 'https://openspeech.bytedance.com/api/v1/tts';
const BYTEDANCE_API_KEY = '03326a1e-71f4-411e-8995-a8584feada6b';
let VoiceCloneService = class VoiceCloneService {
    async queryVoiceClone(voiceId) {
        try {
            const reqid = this.generateReqId();
            const response = await axios_1.default.post(BYTEDANCE_TTS_API, {
                app: {
                    cluster: 'volcano_icl'
                },
                user: {
                    uid: 'mrl_avatar_clone'
                },
                audio: {
                    voice_type: voiceId,
                    encoding: 'mp3',
                    speed_ratio: 1.0
                },
                request: {
                    reqid: reqid,
                    text: '声音复刻状态查询',
                    operation: 'query'
                }
            }, {
                headers: {
                    'x-api-key': BYTEDANCE_API_KEY,
                    'Content-Type': 'application/json'
                }
            });
            console.log('[VoiceCloneService] 查询复刻状态响应:', response.data);
            return {
                success: true,
                data: {
                    voice_id: voiceId,
                    status: response.data?.data?.status || 'unknown',
                    created_at: response.data?.data?.created_at
                }
            };
        }
        catch (error) {
            console.error('[VoiceCloneService] 查询复刻状态失败:', error.message);
            return {
                success: false,
                error: error.message
            };
        }
    }
    async synthesizeSpeech(voiceId, text) {
        try {
            const reqid = this.generateReqId();
            const response = await axios_1.default.post(BYTEDANCE_TTS_API, {
                app: {
                    cluster: 'volcano_icl'
                },
                user: {
                    uid: 'mrl_avatar_clone'
                },
                audio: {
                    voice_type: voiceId,
                    encoding: 'mp3',
                    speed_ratio: 1.0
                },
                request: {
                    reqid: reqid,
                    text: text,
                    operation: 'submit'
                }
            }, {
                headers: {
                    'x-api-key': BYTEDANCE_API_KEY,
                    'Content-Type': 'application/json'
                }
            });
            console.log('[VoiceCloneService] TTS合成响应:', response.data);
            const audioData = response.data?.data?.audio_data;
            if (audioData) {
                return {
                    success: true,
                    data: {
                        audio_url: `data:audio/mp3;base64,${audioData}`,
                        duration: response.data?.data?.duration || 0
                    }
                };
            }
            const taskId = response.data?.data?.task_id;
            if (taskId) {
                return {
                    success: true,
                    data: {
                        audio_url: `task://${taskId}`,
                        duration: 0
                    }
                };
            }
            return {
                success: false,
                error: 'TTS合成失败，未获取到音频数据'
            };
        }
        catch (error) {
            console.error('[VoiceCloneService] TTS合成失败:', error.message);
            return {
                success: false,
                error: error.message
            };
        }
    }
    async startVoiceClone(audioUrl, userId) {
        try {
            const voiceId = `clone_${userId}_${Date.now()}`;
            console.log('[VoiceCloneService] 开始声音复刻训练:', {
                voice_id: voiceId,
                audio_url: audioUrl,
                user_id: userId
            });
            return {
                success: true,
                data: {
                    voice_id: voiceId,
                    status: 'training',
                    estimated_time: 60
                }
            };
        }
        catch (error) {
            console.error('[VoiceCloneService] 声音复刻失败:', error.message);
            return {
                success: false,
                error: error.message
            };
        }
    }
    getPresetVoices() {
        return {
            success: true,
            data: [
                { id: 'warm_male', name: '温暖男声', language: 'zh-CN' },
                { id: 'gentle_female', name: '温柔女声', language: 'zh-CN' },
                { id: 'youth_male', name: '活力男声', language: 'zh-CN' },
                { id: 'youth_female', name: '甜美女声', language: 'zh-CN' },
                { id: 'mature_female', name: '知性女声', language: 'zh-CN' },
                { id: 'magnetic_male', name: '磁性男声', language: 'zh-CN' },
                { id: 'elder_male', name: '成熟大叔', language: 'zh-CN' },
                { id: 'young_boy', name: '青春少年', language: 'zh-CN' }
            ]
        };
    }
    generateReqId() {
        const timestamp = Date.now().toString().padStart(16, '0');
        const random = Math.random().toString(36).substring(2, 10);
        return `${timestamp}${random}00000000000000000ffff0ad1c22ed3fb11`.substring(0, 36);
    }
};
exports.VoiceCloneService = VoiceCloneService;
exports.VoiceCloneService = VoiceCloneService = __decorate([
    (0, common_1.Injectable)()
], VoiceCloneService);
