"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VoiceCloneModule = void 0;
const common_1 = require("@nestjs/common");
const voice_clone_controller_1 = require("./voice-clone.controller");
const voice_clone_service_1 = require("./voice-clone.service");
let VoiceCloneModule = class VoiceCloneModule {
};
exports.VoiceCloneModule = VoiceCloneModule;
exports.VoiceCloneModule = VoiceCloneModule = __decorate([
    (0, common_1.Module)({
        controllers: [voice_clone_controller_1.VoiceCloneController],
        providers: [voice_clone_service_1.VoiceCloneService],
        exports: [voice_clone_service_1.VoiceCloneService]
    })
], VoiceCloneModule);
