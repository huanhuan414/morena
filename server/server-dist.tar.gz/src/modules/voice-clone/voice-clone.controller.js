"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VoiceCloneController = void 0;
const common_1 = require("@nestjs/common");
const voice_clone_service_1 = require("./voice-clone.service");
let VoiceCloneController = class VoiceCloneController {
    constructor(voiceCloneService) {
        this.voiceCloneService = voiceCloneService;
    }
    async getPresetVoices() {
        const result = this.voiceCloneService.getPresetVoices();
        return { code: 200, msg: 'success', data: result.data };
    }
    async startVoiceClone(body) {
        console.log('[VoiceCloneController] 开始声音复刻:', body);
        if (!body.audio_url) {
            return { code: 400, msg: '音频文件不能为空', data: null };
        }
        const result = await this.voiceCloneService.startVoiceClone(body.audio_url, body.user_id || 'anonymous');
        if (result.success) {
            return { code: 200, msg: 'success', data: result.data };
        }
        else {
            return { code: 500, msg: result.error || '声音复刻失败', data: null };
        }
    }
    async getVoiceCloneStatus(voiceId) {
        console.log('[VoiceCloneController] 查询复刻状态:', voiceId);
        const result = await this.voiceCloneService.queryVoiceClone(voiceId);
        if (result.success) {
            return { code: 200, msg: 'success', data: result.data };
        }
        else {
            return { code: 500, msg: result.error || '查询失败', data: null };
        }
    }
    async synthesizeSpeech(body) {
        console.log('[VoiceCloneController] TTS合成:', body);
        if (!body.voice_id || !body.text) {
            return { code: 400, msg: 'voice_id 和 text 不能为空', data: null };
        }
        const result = await this.voiceCloneService.synthesizeSpeech(body.voice_id, body.text);
        if (result.success) {
            return { code: 200, msg: 'success', data: result.data };
        }
        else {
            return { code: 500, msg: result.error || 'TTS合成失败', data: null };
        }
    }
};
exports.VoiceCloneController = VoiceCloneController;
__decorate([
    (0, common_1.Get)('presets'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], VoiceCloneController.prototype, "getPresetVoices", null);
__decorate([
    (0, common_1.Post)('start'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], VoiceCloneController.prototype, "startVoiceClone", null);
__decorate([
    (0, common_1.Get)('status/:voiceId'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('voiceId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], VoiceCloneController.prototype, "getVoiceCloneStatus", null);
__decorate([
    (0, common_1.Post)('synthesize'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], VoiceCloneController.prototype, "synthesizeSpeech", null);
exports.VoiceCloneController = VoiceCloneController = __decorate([
    (0, common_1.Controller)('voice-clone'),
    __param(0, (0, common_1.Inject)(voice_clone_service_1.VoiceCloneService)),
    __metadata("design:paramtypes", [voice_clone_service_1.VoiceCloneService])
], VoiceCloneController);
