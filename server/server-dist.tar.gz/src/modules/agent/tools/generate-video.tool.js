"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenerateVideoTool = void 0;
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const mysql_client_1 = require("../../../storage/database/mysql-client");
const crypto = require("crypto");
class GenerateVideoTool {
    constructor() {
        this.name = 'generate_video';
        this.description = '根据文本描述生成高质量视频，支持4-12秒时长，可生成带音频的视频';
        this.parameters = {
            type: 'object',
            properties: {
                prompt: { type: 'string', description: '视频内容描述，详细描述视频场景、动作、镜头运动等' },
                duration: { type: 'number', description: '视频时长（秒），支持4-12秒，默认5秒', default: 5 },
                ratio: { type: 'string', description: '视频比例：16:9（横屏）、9:16（竖屏）、1:1（方形）', default: '16:9' },
                resolution: { type: 'string', description: '分辨率：480p、720p、1080p', default: '720p' },
                generateAudio: { type: 'boolean', description: '是否生成音频', default: true },
                firstFrameUrl: { type: 'string', description: '首帧图片URL（可选）' }
            },
            required: ['prompt']
        };
        this.storage = new coze_coding_dev_sdk_1.S3Storage({
            endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL || 'https://tos-cn-guangzhou.volces.com',
            accessKey: process.env.VOLC_ACCESS_KEY || '',
            secretKey: process.env.VOLC_SECRET_KEY || '',
            bucketName: process.env.COZE_BUCKET_NAME || 'morena-ai',
            region: 'cn-guangzhou',
        });
    }
    async execute(params, context) {
        const { prompt, duration = 5, ratio = '16:9', resolution = '720p', generateAudio = true, firstFrameUrl } = params;
        const { userId, avatarId, taskId, headers } = context;
        const db = (0, mysql_client_1.getMySQLClient)();
        try {
            await db.updateWhere('tasks', { id: taskId }, { progress: 10 });
            const config = new coze_coding_dev_sdk_1.Config();
            const customHeaders = headers ? coze_coding_dev_sdk_1.HeaderUtils.extractForwardHeaders(headers) : undefined;
            const videoClient = new coze_coding_dev_sdk_1.VideoGenerationClient(config, customHeaders);
            const content = [];
            let finalPrompt = prompt;
            if (firstFrameUrl) {
                if (!finalPrompt.includes('图片') && !finalPrompt.includes('参考')) {
                    finalPrompt = `基于提供的首帧图片，${finalPrompt}`;
                }
                if (firstFrameUrl.includes('tos-cn-') && firstFrameUrl.includes('volces.com')) {
                    content.push({ type: 'image_url', image_url: { url: firstFrameUrl }, role: 'first_frame' });
                }
                else {
                    try {
                        const imgResponse = await fetch(firstFrameUrl);
                        if (imgResponse.ok) {
                            const imgBuffer = Buffer.from(await imgResponse.arrayBuffer());
                            const imgKey = await this.storage.uploadFile({
                                fileContent: imgBuffer,
                                fileName: `video-first-frame/${Date.now()}.jpg`,
                                contentType: 'image/jpeg'
                            });
                            const tosImgUrl = await this.storage.generatePresignedUrl({ key: imgKey, expireTime: 86400 * 7 });
                            content.push({ type: 'image_url', image_url: { url: tosImgUrl }, role: 'first_frame' });
                        }
                    }
                    catch (e) { }
                }
            }
            content.push({ type: 'text', text: finalPrompt });
            await db.updateWhere('tasks', { id: taskId }, { progress: 20 });
            const response = await videoClient.videoGeneration(content, {
                model: 'doubao-seedance-2-0-260128',
                duration,
                ratio: ratio,
                resolution: resolution,
                generateAudio,
                watermark: false
            });
            const originalUrl = response.videoUrl;
            if (!originalUrl) {
                throw new Error(response.response?.error_message || '视频生成失败');
            }
            console.log('[GenerateVideoTool] 视频生成成功:', originalUrl);
            await db.updateWhere('tasks', { id: taskId }, { progress: 70 });
            const videoKey = await this.storage.uploadFromUrl({ url: originalUrl, timeout: 60000 });
            const cdnUrl = await this.storage.generatePresignedUrl({ key: videoKey, expireTime: 86400 * 30 });
            const recordId = crypto.randomUUID();
            await db.insert('generated_content', {
                id: recordId,
                user_id: userId,
                avatar_id: avatarId,
                task_id: taskId,
                type: 'video',
                prompt: prompt,
                url: cdnUrl,
                storage_key: videoKey,
                metadata: JSON.stringify({ duration, ratio, resolution, generateAudio, hasFirstFrame: !!firstFrameUrl }),
                created_at: new Date()
            });
            await db.updateWhere('tasks', { id: taskId }, {
                progress: 100,
                result: JSON.stringify({ type: 'video', url: cdnUrl, key: videoKey, prompt, duration, ratio, resolution }),
                status: 'completed',
                completed_at: new Date()
            });
            return {
                success: true,
                message: "操作成功",
                data: { url: cdnUrl, key: videoKey, prompt, duration, ratio, resolution }
            };
        }
        catch (error) {
            console.error('[GenerateVideoTool] 生成失败:', error);
            await db.updateWhere('tasks', { id: taskId }, {
                status: 'failed',
                result: JSON.stringify({ error: error.message })
            }).catch(() => { });
            return { success: false, error: error.message || '视频生成失败', message: '视频生成失败' };
        }
    }
}
exports.GenerateVideoTool = GenerateVideoTool;
