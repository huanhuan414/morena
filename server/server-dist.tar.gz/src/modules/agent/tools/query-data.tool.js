"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryDataTool = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../../storage/database/mysql-client");
let QueryDataTool = class QueryDataTool {
    constructor() {
        this.name = 'query_data';
        this.description = '查询用户的数据，包括任务、分身信息等。当需要了解用户的历史数据时使用此工具。';
        this.parameters = {
            data_type: { type: 'string', description: '数据类型：tasks, avatars, conversations', required: true },
            filter: { type: 'object', description: '筛选条件' },
            limit: { type: 'number', description: '返回数量限制，默认10' }
        };
    }
    async execute(params, context) {
        try {
            const { data_type, filter = {}, limit = 10 } = params;
            const db = (0, mysql_client_1.getMySQLClient)();
            let result = {};
            switch (data_type) {
                case 'tasks':
                    const tasksFilter = { user_id: context.userId };
                    if (filter.status)
                        tasksFilter.status = filter.status;
                    const tasks = await db.query('tasks', tasksFilter);
                    result = { tasks: (tasks?.data || []).slice(0, limit) };
                    break;
                case 'avatars':
                    const avatars = await db.query('avatars', { user_id: context.userId });
                    result = { avatars: avatars || [] };
                    break;
                case 'conversations':
                    const convFilter = { user_id: context.userId };
                    const conversations = await db.query('conversations', convFilter);
                    result = { conversations: (conversations?.data || []).slice(0, limit) };
                    break;
                default:
                    return { success: false, error: `不支持的数据类型: ${data_type}`, message: '不支持的数据类型' };
            }
            return { success: true, data: result, message: '查询成功' };
        }
        catch (err) {
            return { success: false, error: err.message, message: '查询失败' };
        }
    }
};
exports.QueryDataTool = QueryDataTool;
exports.QueryDataTool = QueryDataTool = __decorate([
    (0, common_1.Injectable)()
], QueryDataTool);
