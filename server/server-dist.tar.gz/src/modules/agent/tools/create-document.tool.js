"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateDocumentTool = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../../storage/database/mysql-client");
const crypto = require("crypto");
let CreateDocumentTool = class CreateDocumentTool {
    constructor() {
        this.name = 'create_document';
        this.description = '创建文档或笔记。当需要保存研究结果、生成报告、整理笔记时使用此工具。';
        this.parameters = {
            title: { type: 'string', description: '文档标题', required: true },
            content: { type: 'string', description: '文档内容，支持 Markdown 格式', required: true },
            type: { type: 'string', description: '文档类型：note(笔记), report(报告), article(文章)' }
        };
    }
    async execute(params, context) {
        try {
            const { title, content, type = 'note' } = params;
            const db = (0, mysql_client_1.getMySQLClient)();
            const id = crypto.randomUUID();
            await db.insert('tasks', {
                id,
                user_id: context.userId,
                avatar_id: context.avatarId,
                title: `📄 ${title}`,
                description: content,
                task_type: 'document',
                status: 'completed',
                progress: 100,
                result: JSON.stringify({ title, content, type }),
                created_at: new Date(),
                updated_at: new Date()
            });
            return {
                success: true,
                message: "操作成功",
                data: { id, title, type, message: '文档已创建' }
            };
        }
        catch (err) {
            return { success: false, error: err.message, message: "操作失败" };
        }
    }
};
exports.CreateDocumentTool = CreateDocumentTool;
exports.CreateDocumentTool = CreateDocumentTool = __decorate([
    (0, common_1.Injectable)()
], CreateDocumentTool);
