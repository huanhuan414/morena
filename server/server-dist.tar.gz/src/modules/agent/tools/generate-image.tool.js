"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenerateImageTool = void 0;
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const mysql_client_1 = require("../../../storage/database/mysql-client");
const crypto = require("crypto");
class GenerateImageTool {
    constructor() {
        this.name = 'generate_image';
        this.description = '根据文本描述生成高质量图片，支持2K/4K分辨率，可用于海报、插画、产品设计等场景';
        this.parameters = {
            type: 'object',
            properties: {
                prompt: { type: 'string', description: '图片描述，详细描述想要生成的图片内容、风格、色彩等' },
                size: { type: 'string', description: '图片尺寸：2K（默认）、4K', default: '2K' },
                style: { type: 'string', description: '图片风格：realistic、anime、oil_painting、watercolor等', default: 'realistic' }
            },
            required: ['prompt']
        };
        this.storage = new coze_coding_dev_sdk_1.S3Storage({
            endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL || 'https://tos-cn-guangzhou.volces.com',
            accessKey: process.env.VOLC_ACCESS_KEY || '',
            secretKey: process.env.VOLC_SECRET_KEY || '',
            bucketName: process.env.COZE_BUCKET_NAME || 'morena-ai',
            region: 'cn-guangzhou',
        });
    }
    async execute(params, context) {
        const { prompt, size = '2K', style = 'realistic' } = params;
        const { userId, avatarId, taskId, headers } = context;
        const db = (0, mysql_client_1.getMySQLClient)();
        try {
            await db.updateWhere('tasks', { id: taskId }, { progress: 20 });
            const enhancedPrompt = this.buildEnhancedPrompt(prompt, style);
            const config = new coze_coding_dev_sdk_1.Config();
            const customHeaders = headers ? coze_coding_dev_sdk_1.HeaderUtils.extractForwardHeaders(headers) : undefined;
            const imageClient = new coze_coding_dev_sdk_1.ImageGenerationClient(config, customHeaders);
            const response = await imageClient.generate({
                prompt: enhancedPrompt,
                size: size,
                watermark: false
            });
            const helper = imageClient.getResponseHelper(response);
            if (!helper.success || helper.imageUrls.length === 0) {
                throw new Error(helper.errorMessages.join('; ') || '图片生成失败');
            }
            const originalUrl = helper.imageUrls[0];
            console.log('[GenerateImageTool] 图片生成成功:', originalUrl);
            await db.updateWhere('tasks', { id: taskId }, { progress: 60 });
            const imageKey = await this.storage.uploadFromUrl({ url: originalUrl, timeout: 30000 });
            console.log('[GenerateImageTool] 上传CDN成功, key:', imageKey);
            const cdnUrl = await this.storage.generatePresignedUrl({ key: imageKey, expireTime: 86400 * 30 });
            const recordId = crypto.randomUUID();
            await db.insert('generated_content', {
                id: recordId,
                user_id: userId,
                avatar_id: avatarId,
                task_id: taskId,
                type: 'image',
                prompt: prompt,
                url: cdnUrl,
                storage_key: imageKey,
                metadata: JSON.stringify({ size, style, model: response.model }),
                created_at: new Date()
            });
            await db.updateWhere('tasks', { id: taskId }, {
                progress: 100,
                result: JSON.stringify({ type: 'image', url: cdnUrl, key: imageKey, prompt, style, size, recordId }),
                status: 'completed',
                completed_at: new Date()
            });
            return {
                success: true,
                message: "操作成功",
                data: { url: cdnUrl, key: imageKey, prompt, style, size }
            };
        }
        catch (error) {
            console.error('[GenerateImageTool] 生成失败:', error);
            await db.updateWhere('tasks', { id: taskId }, {
                status: 'failed',
                result: JSON.stringify({ error: error.message })
            }).catch(() => { });
            return { success: false, error: error.message || '图片生成失败', message: '图片生成失败' };
        }
    }
    buildEnhancedPrompt(prompt, style) {
        const styleEnhancements = {
            realistic: 'photorealistic, high detail, professional photography, 8k resolution',
            anime: 'anime style, vibrant colors, clean lines, Japanese animation aesthetic',
            oil_painting: 'oil painting style, rich textures, classical art, masterpiece',
            watercolor: 'watercolor painting, soft colors, artistic, dreamy atmosphere',
            sketch: 'pencil sketch, detailed linework, artistic drawing, monochrome',
            poster: 'poster design, bold typography, eye-catching, professional layout',
            logo: 'logo design, minimalist, clean, professional branding',
            '3d': '3D render, realistic lighting, detailed textures, high quality'
        };
        const enhancement = styleEnhancements[style] || styleEnhancements.realistic;
        return `${prompt}, ${enhancement}, high quality, detailed`;
    }
}
exports.GenerateImageTool = GenerateImageTool;
