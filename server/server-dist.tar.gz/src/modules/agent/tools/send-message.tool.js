"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SendMessageTool = void 0;
class SendMessageTool {
    constructor() {
        this.definition = {
            name: 'send_message',
            displayName: '发送消息',
            description: '向指定用户或分身发送消息',
            category: 'app_function',
            paramsSchema: {
                to: { type: 'string', description: '接收者ID', required: true },
                message: { type: 'string', description: '消息内容', required: true },
                type: { type: 'string', enum: ['text', 'image', 'voice', 'video'], default: 'text' }
            }
        };
    }
    async execute(params, context) {
        try {
            const { to, message, type = 'text' } = params;
            if (!to || !message) {
                return {
                    success: false,
                    error: '缺少必要参数',
                    message: '缺少必要参数'
                };
            }
            try {
                const { getMySQLClient } = await Promise.resolve().then(() => require('../../../storage/database/mysql-client'));
                const db = getMySQLClient();
                await db.insert('messages', {
                    sender_id: context.userId,
                    receiver_id: to,
                    content: message,
                    type: type,
                    status: 'sent'
                });
            }
            catch (e) {
                console.log('[SendMessageTool] 消息记录失败（忽略）:', e);
            }
            console.log('[SendMessageTool] 发送消息:', { to, message, type });
            return {
                success: true,
                data: { message, type, sentAt: new Date().toISOString() },
                message: '发送成功'
            };
        }
        catch (err) {
            return {
                success: false,
                error: err.message,
                message: '发送失败'
            };
        }
    }
}
exports.SendMessageTool = SendMessageTool;
