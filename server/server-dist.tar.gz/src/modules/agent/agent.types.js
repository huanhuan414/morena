"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PLATFORM_CONFIG_TEMPLATES = void 0;
exports.PLATFORM_CONFIG_TEMPLATES = {
    wechat: {
        platform: 'wechat',
        platform_name: '微信公众号',
        fields: [
            { name: 'app_id', label: 'AppID', type: 'text', required: true, placeholder: '请输入公众号AppID' },
            { name: 'app_secret', label: 'AppSecret', type: 'password', required: true, placeholder: '请输入公众号AppSecret' },
        ],
        instructions: '请前往分身账号配置页面绑定公众号账号',
        help_url: 'https://mp.weixin.qq.com'
    },
    xiaohongshu: {
        platform: 'xiaohongshu',
        platform_name: '小红书',
        fields: [
            { name: 'account_url', label: '分享链接', type: 'text', required: true, placeholder: '请输入小红书个人主页分享链接' },
        ],
        instructions: '请前往分身账号配置页面绑定小红书账号',
        help_url: 'https://www.xiaohongshu.com'
    },
    bilibili: {
        platform: 'bilibili',
        platform_name: 'B站',
        fields: [
            { name: 'account_name', label: '账号名称', type: 'text', required: true, placeholder: '请输入B站账号名称' },
        ],
        instructions: '请前往分身账号配置页面绑定B站账号',
        help_url: 'https://www.bilibili.com'
    },
    weibo: {
        platform: 'weibo',
        platform_name: '微博',
        fields: [
            { name: 'account_name', label: '账号名称', type: 'text', required: true, placeholder: '请输入微博账号名称' },
        ],
        instructions: '请前往分身账号配置页面绑定微博账号',
        help_url: 'https://weibo.com'
    },
    douyin: {
        platform: 'douyin',
        platform_name: '抖音',
        fields: [
            { name: 'unique_id', label: '抖音号', type: 'text', required: true, placeholder: '请输入抖音号' },
        ],
        instructions: '请前往分身账号配置页面绑定抖音账号',
        help_url: 'https://creator.douyin.com'
    }
};
