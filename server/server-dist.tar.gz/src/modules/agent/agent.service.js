"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentService = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const mysql_client_1 = require("../../storage/database/mysql-client");
const agent_types_1 = require("./agent.types");
const agent_gateway_1 = require("./agent.gateway");
const progress_cache_service_1 = require("./progress-cache.service");
const learning_service_1 = require("../avatar/learning.service");
const app_function_tools_1 = require("./tools/app-function.tools");
const content_creation_tools_1 = require("./tools/content-creation.tools");
const platform_publish_tools_1 = require("./tools/platform-publish.tools");
const shortdrama_tools_1 = require("./tools/shortdrama.tools");
const shortdrama_extended_tools_1 = require("./tools/shortdrama-extended.tools");
let AgentService = class AgentService {
    constructor(gateway, progressCache, learningService) {
        this.gateway = gateway;
        this.progressCache = progressCache;
        this.learningService = learningService;
        this.tools = new Map();
        this.currentTaskMap = new Map();
        const config = new coze_coding_dev_sdk_1.Config();
        this.llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
        this.registerTools();
    }
    emitProgress(userId, type, message, data, percentage) {
        const taskContext = this.currentTaskMap.get(userId);
        const taskId = taskContext?.taskId || `task-${Date.now()}`;
        const progress = {
            taskId,
            userId,
            type,
            action: type,
            message,
            status: data?.status || 'running',
            percentage: percentage || data?.percentage || 0,
            data,
            timestamp: Date.now()
        };
        if (this.gateway) {
            this.gateway.emitProgress(userId, progress);
        }
        this.progressCache.addProgress(userId, progress);
        if (taskContext?.conversationId) {
            this.updateAssistantMessageProgress(taskContext.conversationId, userId, taskId, message, percentage);
        }
    }
    registerTools() {
        this.tools.set('app_create_task', new app_function_tools_1.CreateTaskTool());
        this.tools.set('app_update_task', new app_function_tools_1.UpdateTaskTool());
        this.tools.set('app_delete_task', new app_function_tools_1.DeleteTaskTool());
        this.tools.set('app_list_tasks', new app_function_tools_1.ListTasksTool());
        this.tools.set('app_create_order', new app_function_tools_1.CreateOrderTool());
        this.tools.set('app_create_post', new app_function_tools_1.CreatePostTool());
        this.tools.set('app_update_avatar', new app_function_tools_1.UpdateAvatarTool());
        this.tools.set('app_list_avatars', new app_function_tools_1.ListAvatarsTool());
        this.tools.set('app_assign_order', new app_function_tools_1.AssignOrderTool());
        this.tools.set('app_add_friend', new app_function_tools_1.AddFriendTool());
        this.tools.set('app_list_user_friends', new app_function_tools_1.ListUserFriendsTool());
        this.tools.set('app_list_avatar_friends', new app_function_tools_1.ListFriendsTool());
        this.tools.set('app_get_subscription', new app_function_tools_1.GetSubscriptionTool());
        this.tools.set('app_subscribe', new app_function_tools_1.SubscribeTool());
        this.tools.set('write_article', new content_creation_tools_1.WriteArticleTool());
        this.tools.set('write_wechat_mp_article', new content_creation_tools_1.WriteWechatMpArticleTool());
        this.tools.set('write_xiaohongshu_note', new content_creation_tools_1.WriteXiaohongshuNoteTool());
        this.tools.set('generate_image', new content_creation_tools_1.GenerateImageTool());
        this.tools.set('generate_video', new content_creation_tools_1.GenerateVideoTool());
        this.tools.set('generate_shortdrama_script', new shortdrama_tools_1.GenerateShortDramaScriptTool());
        this.tools.set('generate_storyboard', new shortdrama_tools_1.GenerateStoryboardTool());
        this.tools.set('produce_shortdrama', new shortdrama_tools_1.ProduceShortDramaTool());
        this.tools.set('generate_multi_episode_drama', new shortdrama_extended_tools_1.GenerateMultiEpisodeDramaTool());
        this.tools.set('generate_drama_voiceover', new shortdrama_extended_tools_1.GenerateDramaVoiceoverTool());
        this.tools.set('edit_shortdrama_video', new shortdrama_extended_tools_1.EditShortDramaVideoTool());
        this.tools.set('generate_subtitle', new shortdrama_extended_tools_1.GenerateSubtitleTool());
        this.tools.set('recommend_bgm', new shortdrama_extended_tools_1.RecommendBGMTool());
        this.tools.set('list_avatar_accounts', new platform_publish_tools_1.ListAvatarAccountsTool());
        this.tools.set('check_platform_config', new platform_publish_tools_1.CheckPlatformConfigTool());
        this.tools.set('publish_wechat_mp', new platform_publish_tools_1.PublishWechatMpTool());
        this.tools.set('publish_xiaohongshu', new platform_publish_tools_1.PublishXiaohongshuTool());
        this.tools.set('publish_bilibili', new platform_publish_tools_1.PublishBilibiliTool());
        this.tools.set('publish_weibo', new platform_publish_tools_1.PublishWeiboTool());
        this.tools.set('publish_douyin', new platform_publish_tools_1.PublishDouyinTool());
        this.tools.set('publish_wechat_video', new platform_publish_tools_1.PublishWechatMpTool());
    }
    getAvailableTools() {
        return Array.from(this.tools.values()).map(tool => tool.definition);
    }
    async getAvatarTools(avatarId) {
        try {
            console.log(`[AgentService] 获取分身工具，分身ID: ${avatarId}`);
            const db = (0, mysql_client_1.getMySQLClient)();
            const avatarSkillsResult = await db.query('avatar_skills', { avatar_id: avatarId });
            const avatarSkills = avatarSkillsResult?.data || [];
            console.log(`[AgentService] 查询分身技能结果:`, {
                count: avatarSkills.length,
                skills: avatarSkills.map((s) => ({ skill_type: s.skill_type, metadata: s.metadata }))
            });
            const basicTools = [
                'app_create_task',
                'app_update_task',
                'app_delete_task',
                'app_list_tasks',
                'app_update_avatar',
                'app_list_avatars',
                'app_assign_order',
                'app_add_friend',
                'app_list_user_friends',
                'app_list_avatar_friends',
                'app_subscribe',
                'app_get_subscription',
                'check_platform_config',
                'write_article',
                'write_wechat_mp_article',
                'write_xiaohongshu_note',
                'generate_image',
                'generate_video',
                'produce_shortdrama',
                'generate_shortdrama_script',
                'generate_storyboard',
                'generate_multi_episode_drama',
                'generate_drama_voiceover',
                'edit_shortdrama_video',
                'generate_subtitle',
                'recommend_bgm'
            ];
            if (!avatarSkills || avatarSkills.length === 0) {
                console.log(`[AgentService] ⚠️ 分身没有技能，只返回基础工具`);
                return this.getToolsByNames(basicTools);
            }
            const toolNames = [];
            const skillIds = [];
            for (const item of avatarSkills) {
                if (item.skill_type) {
                    toolNames.push(item.skill_type);
                }
                if (item.metadata?.skill_id) {
                    skillIds.push(item.metadata.skill_id);
                }
            }
            console.log(`[AgentService] 提取的工具名称:`, toolNames);
            console.log(`[AgentService] 提取的技能ID:`, skillIds);
            if (skillIds.length > 0) {
                const db2 = (0, mysql_client_1.getMySQLClient)();
                const skillsResult = await db2.query('skills', { id: skillIds });
                const skills = skillsResult?.data || [];
                if (skills && skills.length > 0) {
                    for (const skill of skills) {
                        if (skill.tool_name) {
                            toolNames.push(skill.tool_name);
                        }
                    }
                }
            }
            if (toolNames.length === 0) {
                console.log(`[AgentService] ⚠️ 技能列表为空，只返回基础工具`);
                return this.getToolsByNames(basicTools);
            }
            const allToolNames = [...new Set([...basicTools, ...toolNames])];
            console.log(`[AgentService] 最终工具列表:`, allToolNames);
            const result = allToolNames
                .map(toolName => {
                const tool = this.tools.get(toolName);
                return tool ? tool.definition : null;
            })
                .filter((t) => t !== null);
            console.log(`[AgentService] 返回工具数量: ${result.length}`);
            return result;
        }
        catch (error) {
            console.error('[AgentService] 获取分身工具失败:', error);
            const basicTools = [
                'app_create_task',
                'app_update_task',
                'app_delete_task',
                'app_list_tasks',
                'app_update_avatar',
                'app_list_avatars',
                'app_assign_order',
                'app_add_friend',
                'app_list_user_friends',
                'app_list_avatar_friends',
                'app_subscribe',
                'app_get_subscription',
                'check_platform_config'
            ];
            return this.getToolsByNames(basicTools);
        }
    }
    getToolsByNames(toolNames) {
        return toolNames
            .map(toolName => {
            const tool = this.tools.get(toolName);
            return tool ? tool.definition : null;
        })
            .filter((t) => t !== null);
    }
    async *executeTaskWithProgress(userId, avatarId, taskDescription, options) {
        yield {
            type: 'start',
            message: '开始分析任务...',
            timestamp: Date.now()
        };
        yield { type: 'progress', message: '初始化执行环境...', step: 'init' };
        const context = await this.initContext(userId, avatarId, taskDescription, options);
        const steps = [];
        let finalAnswer = '';
        let requiresConfig = false;
        let configPlatform;
        let configFields = [];
        while (context.currentStep < context.maxSteps) {
            context.currentStep++;
            yield {
                type: 'thinking',
                message: `正在思考第 ${context.currentStep} 步...`,
                step: context.currentStep
            };
            const thought = await this.think(context, steps);
            if (thought.includes('Final Answer:') || thought.includes('最终答案:')) {
                finalAnswer = this.extractFinalAnswer(thought);
                yield {
                    type: 'complete',
                    message: '任务完成！',
                    thought: thought.substring(0, 200)
                };
                break;
            }
            const actionInfo = this.parseAction(thought);
            if (!actionInfo) {
                finalAnswer = await this.generateDirectAnswer(context);
                break;
            }
            const toolDef = this.tools.get(actionInfo.action)?.definition;
            const toolDisplayName = toolDef?.displayName || actionInfo.action;
            yield {
                type: 'action',
                action: actionInfo.action,
                displayName: toolDisplayName,
                message: `正在执行: ${toolDisplayName}`,
                params: actionInfo.action_input,
                step: context.currentStep
            };
            const step = {
                step_index: context.currentStep,
                thought,
                action: actionInfo.action,
                action_input: actionInfo.action_input
            };
            const toolResult = await this.executeTool(actionInfo.action, actionInfo.action_input, context);
            step.observation = toolResult;
            yield {
                type: 'observation',
                action: actionInfo.action,
                displayName: toolDisplayName,
                success: toolResult.success,
                message: toolResult.success
                    ? toolResult.data?.message || '执行成功'
                    : toolResult.error || '执行失败',
                data: toolResult.data,
                requires_config: toolResult.requires_config,
                config_platform: toolResult.config_platform,
                config_fields: toolResult.config_fields
            };
            if (toolResult.requires_config) {
                requiresConfig = true;
                configPlatform = toolResult.config_platform;
                configFields = toolResult.config_fields || agent_types_1.PLATFORM_CONFIG_TEMPLATES[toolResult.config_platform]?.fields || [];
                step.requires_config = true;
                step.config_platform = configPlatform;
                step.config_fields = configFields;
                steps.push(step);
                const generatedContent = steps.find(s => s.observation?.data?.content || s.observation?.data?.image_urls);
                let contentMessage = '';
                if (generatedContent?.observation?.data) {
                    const data = generatedContent.observation.data;
                    if (data.title) {
                        contentMessage = `\n\n📝 已生成内容：「${data.title}」${data.word_count ? `，共${data.word_count}字` : ''}${data.cover_image_url ? '，含封面图' : ''}`;
                    }
                }
                yield {
                    type: 'config_required',
                    platform: configPlatform,
                    platformName: agent_types_1.PLATFORM_CONFIG_TEMPLATES[configPlatform]?.platform_name,
                    fields: configFields,
                    message: `需要配置 ${agent_types_1.PLATFORM_CONFIG_TEMPLATES[configPlatform]?.platform_name || '平台'} 后才能发布${contentMessage}`,
                    generatedContent: generatedContent?.observation?.data
                };
                break;
            }
            steps.push(step);
            context.executionHistory = steps;
        }
        if (!finalAnswer) {
            if (requiresConfig) {
                const generatedContent = steps.find(s => s.observation?.data?.content || s.observation?.data?.image_urls);
                if (generatedContent?.observation?.data) {
                    const data = generatedContent.observation.data;
                    if (data.title && data.content) {
                        finalAnswer = `✅ ${data.title}`;
                    }
                    else if (data.image_urls?.length) {
                        finalAnswer = `✅ 图片已生成`;
                    }
                    else {
                        finalAnswer = `需要配置${agent_types_1.PLATFORM_CONFIG_TEMPLATES[configPlatform]?.platform_name || '平台'}后才能继续执行任务。`;
                    }
                }
                else {
                    finalAnswer = `需要配置${agent_types_1.PLATFORM_CONFIG_TEMPLATES[configPlatform]?.platform_name || '平台'}后才能继续执行任务。`;
                }
            }
            else {
                const mediaStep = steps.find(s => {
                    const data = s.observation?.data;
                    return data?.video_clips || data?.video_url || data?.image_urls || data?.characters || data?.scenes;
                });
                if (mediaStep?.observation?.data) {
                    const data = mediaStep.observation.data;
                    finalAnswer = JSON.stringify({
                        message: data.message || '内容已生成',
                        title: data.title || null,
                        script: data.script || null,
                        storyboard: data.storyboard || null,
                        characters: data.characters || [],
                        scenes: data.scenes || [],
                        video_clips: data.video_clips || [],
                        video_url: data.video_url || null,
                        image_urls: data.image_urls || [],
                        production_stats: data.production_stats || null
                    });
                    console.log('[Agent] 检测到媒体内容生成，保留完整数据:', Object.keys(data));
                }
                else {
                    finalAnswer = await this.summarizeExecution(context, steps);
                }
            }
        }
        if (options?.conversationId) {
            const cleanedFinalAnswer = this.cleanDebugInfo(finalAnswer);
            const taskContext = this.currentTaskMap.get(userId);
            const taskId = taskContext?.taskId || `task-${Date.now()}`;
            await this.createInitialAssistantMessage(options.conversationId, userId, avatarId, taskDescription, taskId);
            await this.updateAssistantMessage(options.conversationId, userId, avatarId, taskDescription, cleanedFinalAnswer, { success: !requiresConfig, finalAnswer, steps, requiresConfig, configPlatform, configFields }, taskId);
        }
        yield {
            type: 'result',
            success: !requiresConfig,
            finalAnswer,
            steps,
            requiresConfig,
            configPlatform,
            configFields
        };
    }
    async executeTask(userId, avatarId, taskDescription, options) {
        const taskId = options?.taskId || `task-${Date.now()}`;
        this.currentTaskMap.set(userId, {
            taskId,
            startTime: Date.now(),
            conversationId: options?.conversationId
        });
        this.progressCache.clearProgress(userId);
        if (options?.conversationId) {
            await this.createInitialAssistantMessage(options.conversationId, userId, avatarId, taskDescription, taskId);
        }
        try {
            this.emitProgress(userId, 'start', '开始分析任务...');
            this.emitProgress(userId, 'progress', '初始化执行环境...');
            const context = await this.initContext(userId, avatarId, taskDescription, options);
            const result = await this.runReActLoop(context, userId);
            this.emitProgress(userId, 'complete', '任务执行完成', {
                status: 'completed',
                success: result.success,
                requiresConfig: result.requiresConfig
            });
            if (options?.conversationId) {
                const cleanedFinalAnswer = this.cleanDebugInfo(result.finalAnswer);
                await this.updateAssistantMessage(options.conversationId, userId, avatarId, taskDescription, cleanedFinalAnswer, result, taskId);
            }
            try {
                await this.learningService.analyzeAndUpdate(avatarId, userId, taskDescription, result.finalAnswer || '');
                console.log(`[AgentService] 分身 ${avatarId} 学习数据已更新`);
            }
            catch (learningError) {
                console.error(`[AgentService] 分身学习更新失败:`, learningError);
            }
            return result;
        }
        finally {
            this.currentTaskMap.delete(userId);
        }
    }
    async executeTaskAsync(userId, avatarId, taskDescription, options) {
        const taskId = options?.taskId || `task-${Date.now()}`;
        this.progressCache.updateTaskStatus(userId, taskId, 'running');
        this.currentTaskMap.set(userId, {
            taskId,
            startTime: Date.now(),
            conversationId: options?.conversationId
        });
        if (options?.conversationId) {
            await this.createInitialAssistantMessage(options.conversationId, userId, avatarId, taskDescription, taskId, options?.uploadedImages, options?.uploadedVideos);
        }
        try {
            this.emitProgress(userId, 'start', '开始分析任务...');
            this.emitProgress(userId, 'progress', '初始化执行环境...');
            const context = await this.initContext(userId, avatarId, taskDescription, options);
            const result = await this.runReActLoop(context, userId);
            this.emitProgress(userId, 'complete', '任务执行完成', {
                status: 'completed',
                success: result.success,
                requiresConfig: result.requiresConfig
            });
            this.progressCache.updateTaskStatus(userId, taskId, 'completed', result);
            if (options?.conversationId) {
                await this.updateAssistantMessage(options.conversationId, userId, avatarId, taskDescription, result.finalAnswer, result, taskId);
            }
            try {
                await this.learningService.analyzeAndUpdate(avatarId, userId, taskDescription, result.finalAnswer || '');
                console.log(`[AgentService] 异步任务 - 分身 ${avatarId} 学习数据已更新`);
            }
            catch (learningError) {
                console.error(`[AgentService] 异步任务 - 分身学习更新失败:`, learningError);
            }
            return result;
        }
        catch (error) {
            this.progressCache.updateTaskStatus(userId, taskId, 'failed', null, error.message);
            this.emitProgress(userId, 'error', error.message, { status: 'failed' });
            if (options?.conversationId) {
                await this.updateAssistantMessage(options.conversationId, userId, avatarId, taskDescription, `任务执行失败: ${error.message}`, {
                    success: false,
                    finalAnswer: `任务执行失败: ${error.message}`,
                    steps: [],
                    requiresConfig: false
                }, taskId);
            }
            throw error;
        }
        finally {
            this.currentTaskMap.delete(userId);
        }
    }
    async createInitialAssistantMessage(conversationId, userId, avatarId, taskDescription, taskId, uploadedImages, uploadedVideos) {
        const db = (0, mysql_client_1.getMySQLClient)();
        await db.insert('messages', {
            conversation_id: conversationId,
            role: 'user',
            content: taskDescription,
            metadata: JSON.stringify({
                ...(uploadedImages && uploadedImages.length > 0 ? { uploaded_images: uploadedImages } : {}),
                ...(uploadedVideos && uploadedVideos.length > 0 ? { uploaded_videos: uploadedVideos } : {})
            }),
            created_at: new Date()
        });
        await db.insert('messages', {
            conversation_id: conversationId,
            role: 'assistant',
            content: '',
            metadata: JSON.stringify({
                task_state: {
                    taskId,
                    taskDescription,
                    status: 'running',
                    startTime: Date.now(),
                    endTime: null,
                    progressHistory: []
                }
            }),
            created_at: new Date()
        });
    }
    async updateAssistantMessageProgress(conversationId, userId, taskId, message, percentage) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const progressHistory = this.progressCache.getProgress(userId, taskId);
            const messagesResult = await db.query('messages', { conversation_id: conversationId, role: 'assistant' });
            const messages = messagesResult?.data || [];
            if (messages && messages.length > 0) {
                const lastMessage = messages.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
                await db.update('messages', { id: lastMessage.id }, {
                    metadata: JSON.stringify({
                        ...(lastMessage.metadata ? JSON.parse(lastMessage.metadata) : {}),
                        task_state: {
                            ...(lastMessage.metadata ? JSON.parse(lastMessage.metadata)?.task_state : {}),
                            status: 'running',
                            progressHistory: progressHistory.length > 0 ? progressHistory : undefined,
                            lastProgressMessage: message,
                            lastProgressPercentage: percentage
                        }
                    })
                });
            }
        }
        catch (error) {
            console.error('[AgentService] 更新 assistant 消息进度失败:', error);
        }
    }
    async updateAssistantMessage(conversationId, userId, avatarId, userMessage, aiMessage, agentResult, taskId) {
        const client = (0, mysql_client_1.getMySQLClient)();
        const media = [];
        const extractedFromFinalAnswer = new Set();
        try {
            if (aiMessage && typeof aiMessage === 'string' && aiMessage.trim().startsWith('{')) {
                const finalAnswerJson = JSON.parse(aiMessage.trim());
                if (finalAnswerJson.video_clips && Array.isArray(finalAnswerJson.video_clips)) {
                    console.log('[媒体提取] 从 finalAnswer JSON 中提取视频剪辑:', finalAnswerJson.video_clips.length);
                    finalAnswerJson.video_clips.forEach((clip) => {
                        if (clip.url) {
                            extractedFromFinalAnswer.add(clip.url);
                            media.push({
                                type: 'video',
                                url: clip.url,
                                key: clip.key || undefined,
                                title: `镜头 ${clip.clip_number || ''}`
                            });
                        }
                    });
                }
                if (finalAnswerJson.edited_video_url) {
                    console.log('[媒体提取] 从 finalAnswer JSON 中提取成品视频 URL:', finalAnswerJson.edited_video_url);
                    extractedFromFinalAnswer.add(finalAnswerJson.edited_video_url);
                    media.push({
                        type: 'video',
                        url: finalAnswerJson.edited_video_url,
                        key: 'edited_video',
                        title: '成品视频'
                    });
                }
                if (finalAnswerJson.video_url) {
                    console.log('[媒体提取] 从 finalAnswer JSON 中提取视频 URL:', finalAnswerJson.video_url);
                    extractedFromFinalAnswer.add(finalAnswerJson.video_url);
                    media.push({
                        type: 'video',
                        url: finalAnswerJson.video_url,
                        key: finalAnswerJson.video_key || undefined
                    });
                }
                if (finalAnswerJson.characters && Array.isArray(finalAnswerJson.characters)) {
                    console.log('[媒体提取] 从 finalAnswer JSON 中提取角色形象:', finalAnswerJson.characters.length);
                    finalAnswerJson.characters.forEach((char) => {
                        if (char.url) {
                            extractedFromFinalAnswer.add(char.url);
                            media.push({
                                type: 'image',
                                url: char.url,
                                key: char.key || undefined,
                                title: char.character || ''
                            });
                        }
                    });
                }
                if (finalAnswerJson.scenes && Array.isArray(finalAnswerJson.scenes)) {
                    console.log('[媒体提取] 从 finalAnswer JSON 中提取场景设计:', finalAnswerJson.scenes.length);
                    finalAnswerJson.scenes.forEach((scene) => {
                        if (scene.url) {
                            extractedFromFinalAnswer.add(scene.url);
                            media.push({
                                type: 'image',
                                url: scene.url,
                                key: scene.key || undefined,
                                title: scene.scene || ''
                            });
                        }
                    });
                }
                if (finalAnswerJson.image_urls && Array.isArray(finalAnswerJson.image_urls)) {
                    console.log('[媒体提取] 从 finalAnswer JSON 中提取图片数组:', finalAnswerJson.image_urls.length);
                    finalAnswerJson.image_urls.forEach((url) => {
                        if (url) {
                            extractedFromFinalAnswer.add(url);
                            media.push({ type: 'image', url });
                        }
                    });
                }
                if (finalAnswerJson.title || finalAnswerJson.script || finalAnswerJson.bgm_recommendations) {
                    console.log('[媒体提取] 插入短剧信息媒体项');
                    media.unshift({
                        type: 'shortdrama_info',
                        title: finalAnswerJson.title,
                        duration: finalAnswerJson.duration,
                        script: finalAnswerJson.script,
                        storyboard: finalAnswerJson.storyboard,
                        characters: finalAnswerJson.characters,
                        scenes: finalAnswerJson.scenes,
                        video_clips: finalAnswerJson.video_clips,
                        edited_video_url: finalAnswerJson.edited_video_url,
                        bgm_recommendations: finalAnswerJson.bgm_recommendations,
                        production_stats: finalAnswerJson.production_stats,
                        message: finalAnswerJson.message
                    });
                }
            }
        }
        catch (error) {
            console.log('[媒体提取] finalAnswer 不是 JSON 格式，使用常规提取方式');
        }
        agentResult.steps.forEach(step => {
            if (step.observation?.data) {
                const data = step.observation.data;
                if (data.url && typeof data.url === 'string') {
                    if (!extractedFromFinalAnswer.has(data.url)) {
                        console.log('[媒体提取] 提取单个图片 URL:', data.url, 'key:', data.key);
                        const mediaItem = { type: 'image', url: data.url };
                        if (data.key) {
                            mediaItem.key = data.key;
                        }
                        console.log('[媒体提取] 准备添加的 mediaItem:', mediaItem);
                        media.push(mediaItem);
                        extractedFromFinalAnswer.add(data.url);
                    }
                }
                if (data.image_urls && Array.isArray(data.image_urls)) {
                    console.log('[媒体提取] 提取图片数组:', data.image_urls);
                    data.image_urls.forEach((url) => {
                        if (url && typeof url === 'string' && !extractedFromFinalAnswer.has(url)) {
                            media.push({ type: 'image', url });
                            extractedFromFinalAnswer.add(url);
                        }
                    });
                }
                if (data.content && data.title) {
                    media.push({
                        type: 'article',
                        title: data.title,
                        content: data.content,
                        coverImage: data.cover_image_url
                    });
                }
                if (data.video_clips && Array.isArray(data.video_clips)) {
                    console.log('[媒体提取] 检查视频剪辑数组，已从 finalAnswer 提取:', extractedFromFinalAnswer.size);
                    data.video_clips.forEach((clip) => {
                        if (clip.url && !extractedFromFinalAnswer.has(clip.url)) {
                            console.log('[媒体提取] 从 steps 中提取视频剪辑:', clip.url);
                            media.push({
                                type: 'video',
                                url: clip.url,
                                key: clip.key || undefined,
                                title: clip.clip_number ? `镜头 ${clip.clip_number}` : undefined
                            });
                            extractedFromFinalAnswer.add(clip.url);
                        }
                    });
                }
                if (data.video_url && !extractedFromFinalAnswer.has(data.video_url)) {
                    console.log('[媒体提取] 从 steps 中提取视频 URL:', data.video_url, 'key:', data.video_key || data.key);
                    media.push({
                        type: 'video',
                        url: data.video_url,
                        key: data.video_key || data.key
                    });
                    extractedFromFinalAnswer.add(data.video_url);
                    console.log('[媒体提取] 已添加视频到 media 列表，当前 media 数量:', media.length);
                }
                if (data.cover_image_url && !data.content && !extractedFromFinalAnswer.has(data.cover_image_url)) {
                    console.log('[媒体提取] 提取封面图 URL:', data.cover_image_url);
                    media.push({ type: 'image', url: data.cover_image_url });
                    extractedFromFinalAnswer.add(data.cover_image_url);
                }
            }
        });
        console.log('[媒体提取] 最终提取的媒体列表:', media);
        const taskContext = this.currentTaskMap.get(userId);
        const progressHistory = this.progressCache.getProgress(userId, taskId);
        if (progressHistory && Array.isArray(progressHistory)) {
            console.log('[媒体提取] 从 progressHistory 中提取媒体，进度历史数量:', progressHistory.length);
            progressHistory.forEach((progress, idx) => {
                if (progress.action === 'generate_image') {
                    if (progress.image_urls && Array.isArray(progress.image_urls)) {
                        console.log(`[媒体提取] Progress ${idx}: 从 generate_image.image_urls 提取图片:`, progress.image_urls.length);
                        progress.image_urls.forEach((url) => {
                            if (url && typeof url === 'string' && !extractedFromFinalAnswer.has(url)) {
                                media.push({ type: 'image', url });
                                extractedFromFinalAnswer.add(url);
                            }
                        });
                    }
                    if (progress.cdn_urls && Array.isArray(progress.cdn_urls)) {
                        console.log(`[媒体提取] Progress ${idx}: 从 generate_image.cdn_urls 提取图片:`, progress.cdn_urls.length);
                        progress.cdn_urls.forEach((url) => {
                            if (url && typeof url === 'string' && !extractedFromFinalAnswer.has(url)) {
                                media.push({ type: 'image', url });
                                extractedFromFinalAnswer.add(url);
                            }
                        });
                    }
                }
                if (progress.action === 'observation' && progress.data?.data) {
                    const toolData = progress.data.data;
                    if (toolData.image_urls && Array.isArray(toolData.image_urls)) {
                        toolData.image_urls.forEach((url) => {
                            if (url && typeof url === 'string' && !extractedFromFinalAnswer.has(url)) {
                                media.push({ type: 'image', url });
                                extractedFromFinalAnswer.add(url);
                            }
                        });
                    }
                    if (toolData.url && typeof toolData.url === 'string' && !extractedFromFinalAnswer.has(toolData.url)) {
                        const mediaItem = { type: 'image', url: toolData.url };
                        if (toolData.key) {
                            mediaItem.key = toolData.key;
                        }
                        media.push(mediaItem);
                        extractedFromFinalAnswer.add(toolData.url);
                    }
                    if (toolData.cover_image_url && !extractedFromFinalAnswer.has(toolData.cover_image_url)) {
                        media.push({ type: 'image', url: toolData.cover_image_url });
                        extractedFromFinalAnswer.add(toolData.cover_image_url);
                    }
                }
            });
        }
        const { data: messages } = await client
            .from('messages')
            .select('id, metadata')
            .eq('conversation_id', conversationId)
            .eq('role', 'assistant')
            .order('created_at', { ascending: false })
            .limit(1);
        if (messages && messages.length > 0) {
            const lastMessage = messages[0];
            console.log('[AgentService updateAssistantMessage] 准备更新消息:', {
                messageId: lastMessage.id,
                原有metadata: lastMessage.metadata,
                新mediaCount: media.length,
                新media: media,
                新agentResultStepsCount: agentResult?.steps?.length || 0
            });
            const hasValidAgentResult = agentResult && agentResult.steps && agentResult.steps.length > 0;
            const hasValidMedia = media && media.length > 0;
            console.log('[AgentService updateAssistantMessage] 数据有效性检查:', {
                hasValidAgentResult,
                hasValidMedia,
                mediaList: media,
                mediaTypes: media.map(m => m.type),
                mediaCount: media.length
            });
            const updateData = {
                content: aiMessage
            };
            if (hasValidAgentResult || hasValidMedia) {
                const existingMetadata = lastMessage.metadata || {};
                updateData.metadata = {
                    ...existingMetadata,
                    ...(existingMetadata.task_state ? {} : {}),
                    agent_result: hasValidAgentResult ? agentResult : existingMetadata.agent_result,
                    media: hasValidMedia ? media : existingMetadata.media
                };
                if (updateData.metadata.task_state) {
                    delete updateData.metadata.task_state;
                }
                console.log('[AgentService updateAssistantMessage] 准备更新的 metadata.media:', {
                    mediaCount: updateData.metadata.media?.length || 0,
                    mediaTypes: updateData.metadata.media?.map(m => m.type) || [],
                    media: updateData.metadata.media
                });
                console.log('[AgentService updateAssistantMessage] 最终更新的 metadata:', updateData.metadata);
            }
            else {
                console.log('[AgentService updateAssistantMessage] 没有有效数据，只更新 content');
            }
            console.log('[AgentService updateAssistantMessage] 更新消息:', {
                messageId: lastMessage.id,
                hasValidAgentResult,
                hasValidMedia,
                stepsCount: agentResult?.steps?.length || 0,
                mediaCount: media?.length || 0
            });
            await client
                .from('messages')
                .update(updateData)
                .eq('id', lastMessage.id);
        }
        const { data: conversation } = await client
            .from('conversations')
            .select('context')
            .eq('id', conversationId)
            .single();
        let currentContext = [];
        if (conversation?.context) {
            const ctx = conversation.context;
            if (ctx && typeof ctx === 'object' && !Array.isArray(ctx)) {
                const keys = Object.keys(ctx);
                if (keys.length === 1 && keys[0].startsWith('friend_id:')) {
                    currentContext = [];
                }
                else {
                    currentContext = ctx;
                }
            }
            else if (Array.isArray(ctx)) {
                currentContext = ctx;
            }
        }
        if (!Array.isArray(currentContext)) {
            currentContext = [];
        }
        currentContext.push({ role: 'user', content: userMessage }, { role: 'assistant', content: aiMessage });
        if (currentContext.length > 20) {
            currentContext = currentContext.slice(-20);
        }
        await client
            .from('conversations')
            .update({ context: currentContext })
            .eq('id', conversationId);
    }
    cleanDebugInfo(content) {
        if (!content || typeof content !== 'string')
            return content;
        let cleaned = content;
        cleaned = cleaned.replace(/^Image[图片]?\s*[:：].*$/gim, '');
        cleaned = cleaned.replace(/^Video[视频]?\s*[:：].*$/gim, '');
        cleaned = cleaned.replace(/^图片\s*[:：].*$/gim, '');
        cleaned = cleaned.replace(/^视频\s*[:：].*$/gim, '');
        cleaned = cleaned.replace(/https?:\/\/code\.coze\.cn\/api\/sandbox\/[^\s\n]+/gi, '');
        cleaned = cleaned.replace(/https?:\/\/ark-content-generation-v2[\w-]+\.tos-cn-[\w-]+\.volces\.com\/[^\s\n]*/gi, '');
        cleaned = cleaned.replace(/已为您?生成.*?[，,]?\s*链接如下[::：][\s\S]*?(?=\n\n|\n[A-Z\u4e00-\u9fa5]|$)/gi, '');
        cleaned = cleaned.replace(/已为你生成.*?[，,]?\s*链接如下[::：][\s\S]*?(?=\n\n|\n[A-Z\u4e00-\u9fa5]|$)/gi, '');
        cleaned = cleaned.replace(/图片链接如下[::：]\s*\d*[\.、]?\s*https?:\/\/[^\s\n]+/gi, '');
        cleaned = cleaned.replace(/视频链接如下[::：]\s*\d*[\.、]?\s*https?:\/\/[^\s\n]+/gi, '');
        cleaned = cleaned.replace(/已为你生成.*配图[，,]\s*图片链接如下[::：]\s*https?:\/\/[^\s\n]+/gi, '');
        cleaned = cleaned.replace(/^\s*\d+[\.、]\s*https?:\/\/[^\s\n]+$/gm, '');
        cleaned = cleaned.replace(/链接如下[::：][\s\S]*?(?=\n\n|\n[A-Z\u4e00-\u9fa5]|$)/gi, '');
        cleaned = cleaned.replace(/\n\s*\n\s*\n/g, '\n\n');
        return cleaned.trim();
    }
    async initContext(userId, avatarId, taskDescription, options) {
        const client = (0, mysql_client_1.getMySQLClient)();
        const { data: platformConfigs } = await client
            .from('platform_configs')
            .select('*')
            .eq('user_id', userId);
        const platformMap = new Map();
        (platformConfigs || []).forEach(config => {
            platformMap.set(config.platform_type, config);
        });
        const { data: avatarInfo } = await client
            .from('avatars')
            .select('name, description, personality, level, avatar_url')
            .eq('id', avatarId)
            .single();
        console.log('[AgentService] 获取分身信息:', { avatarId, avatarInfo });
        const { data: avatarSkills } = await client
            .from('avatar_skills')
            .select('*')
            .eq('avatar_id', avatarId);
        let conversationHistory = options?.conversationHistory || [];
        if (options?.conversationId && conversationHistory.length === 0) {
            const { data: conversation } = await client
                .from('conversations')
                .select('context')
                .eq('id', options.conversationId)
                .single();
            if (conversation?.context) {
                const ctx = conversation.context;
                if (Array.isArray(ctx)) {
                    conversationHistory = ctx;
                }
                else if (typeof ctx === 'string') {
                    try {
                        conversationHistory = JSON.parse(ctx);
                    }
                    catch (e) {
                        console.error('[Agent] 解析对话历史失败:', e);
                        conversationHistory = [];
                    }
                }
                else {
                    console.warn('[Agent] conversation.context 格式不正确:', typeof ctx);
                    conversationHistory = [];
                }
            }
        }
        const availableTools = await this.getAvatarTools(avatarId);
        return {
            userId,
            avatarId,
            avatarInfo: avatarInfo || undefined,
            conversationId: options?.conversationId,
            taskId: options?.taskId,
            taskDescription,
            availableTools,
            platformConfigs: platformMap,
            avatarSkills: (avatarSkills || []),
            executionHistory: [],
            conversationHistory,
            uploadedImages: options?.uploadedImages || [],
            uploadedVideos: options?.uploadedVideos || [],
            maxSteps: 50,
            currentStep: 0
        };
    }
    async runReActLoop(context, userId) {
        const skillCheckResult = this.checkRequiredSkills(context.taskDescription, context.availableTools);
        if (skillCheckResult.missing.length > 0) {
            const missingSkillNames = skillCheckResult.missing.map(s => this.getToolDisplayNameChinese(s.toolName)).join('、');
            const finalAnswer = `检测到您的分身缺少以下技能：${missingSkillNames}

请前往技能广场添加这些技能后，再重新发送相同指令，我会帮您完成${context.taskDescription}主题短剧成品的生成任务。`;
            console.log(`[AgentService] 检测到缺少技能: ${missingSkillNames}，直接返回答案`);
            const taskId = context.taskId || `task-${Date.now()}`;
            this.progressCache.updateTaskStatus(userId, taskId, 'failed', null, finalAnswer);
            this.emitProgress(userId, 'error', finalAnswer, { status: 'failed' });
            return {
                success: false,
                finalAnswer,
                steps: [],
                requiresConfig: false
            };
        }
        const steps = [];
        let finalAnswer = '';
        let requiresConfig = false;
        let configPlatform;
        let configFields = [];
        while (context.currentStep < context.maxSteps) {
            context.currentStep++;
            const progressPercentage = Math.min(20 + ((context.currentStep - 1) / context.maxSteps) * 60, 80);
            this.emitProgress(userId, 'thinking', `正在思考第 ${context.currentStep} 步...`, {}, progressPercentage);
            const thought = await this.think(context, steps);
            if (thought.includes('Final Answer:') || thought.includes('最终答案:')) {
                const potentialFinalAnswer = this.extractFinalAnswer(thought);
                const hasDramaKeywords = /镜头|画面|场景|角色|视频|剧本|短剧/gi.test(potentialFinalAnswer);
                const hasMedia = this.hasMediaContent(potentialFinalAnswer);
                const hasVideo = this.hasVideoContent(potentialFinalAnswer);
                const isDramaTask = /短剧|制作视频|生成视频|视频成品|真人短剧/i.test(context.taskDescription);
                if (hasDramaKeywords && !hasVideo && isDramaTask) {
                    console.log('[AgentService] 警告：检测到短剧任务，但生成的内容没有视频数据，强制调用 produce_shortdrama...');
                    const toolInput = this.extractShortdramaParams(context.taskDescription, potentialFinalAnswer);
                    console.log('[AgentService] 强制调用 produce_shortdrama 工具:', toolInput);
                    const toolResult = await this.executeTool('produce_shortdrama', toolInput, context);
                    const observation = `Observation: ${JSON.stringify(toolResult)}`;
                    steps.push({
                        step_index: steps.length,
                        thought,
                        action: 'produce_shortdrama',
                        action_input: toolInput,
                        observation
                    });
                    if (toolResult.success && toolResult.data) {
                        finalAnswer = JSON.stringify(toolResult.data);
                        this.emitProgress(userId, 'complete', '思考完成，生成答案中...', {}, 90);
                        break;
                    }
                    else {
                        console.error('[AgentService] 工具执行失败:', toolResult.error);
                        finalAnswer = `抱歉，${toolResult.error || '短剧制作失败'}`;
                        this.emitProgress(userId, 'failed', '任务执行失败', {}, 100);
                        break;
                    }
                }
                else if (hasVideo) {
                    finalAnswer = potentialFinalAnswer;
                    this.emitProgress(userId, 'complete', '思考完成，生成答案中...', {}, 90);
                    break;
                }
                else {
                    const isWriteAndPublishTask = /写.*并.*发布|写.*然后.*发布|写.*再.*发布|写.*发布到|撰写.*并发布|生成.*并发布/i.test(context.taskDescription);
                    const hasWrittenArticle = steps.some(s => s.action === 'write_wechat_mp_article' || s.action === 'write_xiaohongshu_note');
                    const hasPublished = steps.some(s => s.action === 'publish_wechat_mp' || s.action === 'publish_xiaohongshu');
                    console.log('[AgentService] Final Answer 检测:', {
                        isWriteAndPublishTask,
                        hasWrittenArticle,
                        hasPublished,
                        taskDescription: context.taskDescription,
                        steps: steps.map(s => s.action)
                    });
                    if (isWriteAndPublishTask && hasWrittenArticle && !hasPublished) {
                        console.log('[AgentService] 检测到"写作并发布"任务，文章已写完但未发布，强制继续发布...');
                    }
                    else {
                        finalAnswer = potentialFinalAnswer;
                        this.emitProgress(userId, 'complete', '思考完成，生成答案中...', {}, 90);
                        break;
                    }
                }
            }
            const actionInfo = this.parseAction(thought);
            if (!actionInfo) {
                finalAnswer = await this.generateDirectAnswer(context);
                break;
            }
            const step = {
                step_index: context.currentStep,
                thought,
                action: actionInfo.action,
                action_input: actionInfo.action_input
            };
            const toolDef = this.tools.get(actionInfo.action)?.definition;
            const toolDisplayName = toolDef?.displayName || actionInfo.action;
            const actionProgress = Math.min(progressPercentage + 10, 80);
            this.emitProgress(userId, 'action', `正在执行: ${toolDisplayName}`, {
                action: actionInfo.action,
                displayName: toolDisplayName,
                params: actionInfo.action_input,
                status: 'running'
            }, actionProgress);
            const toolResult = await this.executeTool(actionInfo.action, actionInfo.action_input, context);
            step.observation = toolResult;
            const toolPercentage = toolResult.percentage || (actionProgress + 10);
            this.emitProgress(userId, 'observation', toolResult.success ? '执行成功' : '执行失败', {
                action: actionInfo.action,
                displayName: toolDisplayName,
                success: toolResult.success,
                status: toolResult.success ? 'completed' : 'failed',
                message: toolResult.data?.message || toolResult.error,
                data: toolResult.data
            }, toolPercentage);
            if (!toolResult.success) {
                console.error(`[AgentService] 工具执行失败，停止任务: ${actionInfo.action}`, toolResult.error);
                finalAnswer = toolResult.error || `工具执行失败: ${toolDisplayName}`;
                break;
            }
            if (toolResult.requires_config) {
                requiresConfig = true;
                configPlatform = toolResult.config_platform;
                configFields = toolResult.config_fields || agent_types_1.PLATFORM_CONFIG_TEMPLATES[toolResult.config_platform]?.fields || [];
                step.requires_config = true;
                step.config_platform = configPlatform;
                step.config_fields = configFields;
                steps.push(step);
                break;
            }
            steps.push(step);
            await this.logStep(context, step, toolResult);
            context.executionHistory = steps;
            if (!toolResult.success && toolResult.error?.includes('您的分身尚未添加该功能')) {
                finalAnswer = toolResult.error;
                console.log(`[Agent] 检测到技能缺失错误，直接返回: ${finalAnswer}`);
                break;
            }
        }
        if (!finalAnswer) {
            if (requiresConfig) {
                const generatedContent = steps.find(s => s.observation?.data?.content || s.observation?.data?.image_urls);
                if (generatedContent?.observation?.data) {
                    const data = generatedContent.observation.data;
                    if (data.title && data.content) {
                        finalAnswer = `✅ ${data.title}`;
                    }
                    else if (data.image_urls?.length) {
                        finalAnswer = `✅ 图片已生成`;
                    }
                    else {
                        finalAnswer = `需要配置${agent_types_1.PLATFORM_CONFIG_TEMPLATES[configPlatform]?.platform_name || '平台'}后才能继续执行任务。`;
                    }
                }
                else {
                    finalAnswer = `需要配置${agent_types_1.PLATFORM_CONFIG_TEMPLATES[configPlatform]?.platform_name || '平台'}后才能继续执行任务。`;
                }
            }
            else {
                const publishStep = steps.find(s => (s.action === 'publish_wechat_mp' || s.action === 'publish_xiaohongshu') &&
                    s.observation?.success);
                if (publishStep?.observation?.data?.message) {
                    finalAnswer = publishStep.observation.data.message;
                }
                else {
                    finalAnswer = await this.summarizeExecution(context, steps);
                }
            }
        }
        return {
            success: !requiresConfig,
            finalAnswer,
            steps,
            requiresConfig: requiresConfig,
            configPlatform,
            configFields,
            taskId: context.taskId
        };
    }
    async think(context, history) {
        const toolsDescription = this.formatToolsForPrompt(context.availableTools);
        const historyText = this.formatHistory(history);
        const conversationHistoryText = this.formatConversationHistory(context.conversationHistory);
        let avatarInfoText = '';
        if (context.avatarInfo) {
            avatarInfoText = `
【分身身份信息】
- 名字：${context.avatarInfo.name}
- 描述：${context.avatarInfo.description || '无'}
- 性格：${context.avatarInfo.personality || '无'}
- 等级：${context.avatarInfo.level || 1}
- 头像URL：${context.avatarInfo.avatar_url || '无'}

重要提示：你是一个AI分身，名字叫"${context.avatarInfo.name}"。用户正在与你进行对话。当用户询问你的身份或是否是分身时，请明确告知用户你的名字和身份，不要说"我没有创建任何分身"之类的错误回答。

【个人IP打造功能】
当用户要求生成视频（generate_video）或制作短剧（produce_shortdrama）时：
- 如果用户上传了图片：必须使用用户上传的图片作为首帧参考（first_frame参数）
- 如果用户没有上传图片：只使用文本描述生成视频，不传递图片参数
分身头像 URL：${context.avatarInfo.avatar_url || '未设置'}
`;
            console.log('[AgentService] 分身身份信息已生成:', avatarInfoText);
        }
        else {
            console.log('[AgentService] 警告：context.avatarInfo 为空，分身无法识别自己的身份');
        }
        let taskUnderstandingHint = this.getTaskUnderstandingHint(context.taskDescription, history, context);
        const isWriteAndPublishTask = /写.*并.*发布|写.*然后.*发布|写.*再.*发布|写.*发布到|撰写.*并发布|生成.*并发布/i.test(context.taskDescription);
        const hasWrittenArticle = history.some(s => s.action === 'write_wechat_mp_article' || s.action === 'write_xiaohongshu_note');
        const hasPublished = history.some(s => s.action === 'publish_wechat_mp' || s.action === 'publish_xiaohongshu');
        console.log('[AgentService] think() 方法 - 任务状态检测:', {
            isWriteAndPublishTask,
            hasWrittenArticle,
            hasPublished,
            taskDescription: context.taskDescription,
            historySteps: history.map(s => s.action)
        });
        if (isWriteAndPublishTask && hasWrittenArticle && !hasPublished) {
            console.log('[AgentService] 检测到"写作并发布"任务，文章已写完但未发布，添加强制发布提示');
            taskUnderstandingHint += `\n\n【🔴 强制任务提示 - 必须执行】\n用户要求"写作并发布"，文章已经写完，你现在必须：\n1. 立即调用 publish_wechat_mp 工具发布文章\n2. 使用 write_wechat_mp_article 返回的 title 和 content 作为参数\n3. 等待 publish_wechat_mp 执行完成后再返回结果\n4. 将 publish_wechat_mp 的结果（成功或失败）告知用户\n**严禁：直接返回 Final Answer 而不执行发布！**`;
        }
        let mediaInfoText = '';
        if (context.uploadedImages && context.uploadedImages.length > 0) {
            mediaInfoText += `
【用户上传的图片】
用户上传了 ${context.uploadedImages.length} 张图片：
${context.uploadedImages.map((url, index) => `${index + 1}. ${url}`).join('\n')}

【图片使用规则】
- 如果任务涉及"文章创作"、"公众号文章"、"小红书笔记"等，必须理解图片内容，并将图片插入到文章的合适位置
- 如果任务涉及"图片生成"，可以使用上传的图片作为参考
- 如果任务涉及"视频生成"，可以使用上传的图片作为首帧（first_frame）
- 在使用图片时，请分析图片内容，并在文章或生成内容中恰当地引用和描述图片
`;
        }
        if (context.uploadedVideos && context.uploadedVideos.length > 0) {
            mediaInfoText += `
【用户上传的视频】
用户上传了 ${context.uploadedVideos.length} 个视频：
${context.uploadedVideos.map((url, index) => `${index + 1}. ${url}`).join('\n')}
`;
        }
        const prompt = `你是一个智能Agent，能够使用工具完成任务。

${avatarInfoText}

可用工具：
${toolsDescription}

${conversationHistoryText ? `对话历史：\n${conversationHistoryText}\n` : ''}

${mediaInfoText}

当前任务：${context.taskDescription}

${taskUnderstandingHint}

${historyText ? `执行历史：\n${historyText}\n` : ''}

【重要规则】
1. **多步指令识别（CRITICAL）**：用户的指令可能包含多个子任务，使用"，"、"、"或"并"、"然后"等词分隔。
   - 示例："找50个分身，做50张海报" 包含两个任务：【找分身】和【做海报】
   - 示例："帮我生成海报，发布到小红书" 包含两个任务：【生成海报】和【发布小红书】
   - 示例："生成营销方案，并生成5张海报，然后找50个分身分发" 包含三个任务：【生成营销方案】、【生成5张海报】、【找50个分身分发】
   - **必须先分析指令中的所有子任务，然后按顺序逐个执行，不能遗漏任何子任务**
   - **执行完所有子任务后，才能返回 Final Answer**
   - **如果在执行过程中已经生成了部分内容，不要提前返回，必须继续执行剩余的子任务**
   - 如果包含"查看分身"、"找分身"、"添加好友"等内部功能操作，优先执行这些操作

2. 只有当用户明确要求"生成图片"、"画图"、"设计图片"、"生成视频"、"写文章"、"发布内容"、"生成短剧"、"制作短剧"等创作类任务时，才调用对应的工具。
3. 对于普通对话、问候、咨询、关注、点赞等社交互动，直接用Final Answer回复，不要调用任何工具。
4. 如果用户只是说"关注"、"点赞"、"分享"等，这是普通社交行为，不需要调用工具，直接回复即可。
5. 不要随意调用generate_image、generate_video或produce_shortdrama工具，除非用户明确要求创作图片、视频或短剧。
6. 【短剧工具使用规则】
   - 当用户要求"生成短剧"、"制作短剧"、"真人短剧"、"短剧成品"时，必须使用 produce_shortdrama 工具
   - 当用户要求"多集短剧"、"连续短剧"、"系列短剧"时，必须使用 generate_multi_episode_drama 工具
   - 当用户明确要求"只要剧本"、"剧本文字"时，才使用 generate_shortdrama_script 工具
   - 短剧工具会自动生成剧本、角色形象、场景设计和视频，不需要分步调用多个工具

7. 【公众号文章生成和发布规则（CRITICAL）】
   - **区分"写作"和"发布"**：
     - **写作**：用户说"写公众号文章"、"生成公众号图文" → 使用 write_wechat_mp_article 工具
     - **发布**：用户说"发布到公众号"、"发出去"、"推送"、"发一下" → **只**使用 publish_wechat_mp 工具
     - **写作+发布**：用户说"写一篇文章并发布" → 先用 write_wechat_mp_article，再用 publish_wechat_mp
   - 当使用 write_wechat_mp_article 工具生成公众号文章后：
     - **如果用户没有明确要求发布**：在 Final Answer 中明确告知"文章已生成，你可以在上方查看完整内容"，并提供如何发布的指引
     - **不要说"已成功保存到公众号草稿箱"**，因为实际上并没有调用发布接口
     - **明确告知用户**：
       1. 文章已生成（包含标题、正文、封面图）
       2. 文章显示在当前对话中（在上方）
       3. 如何发布到公众号：需要绑定微信公众号授权后，可以使用"发布到公众号"功能
     - **示例回复**："✅ 公众号文章已生成！你可以在上方查看完整内容（包含标题、正文和封面图）。如需发布到微信公众号，请先绑定公众号授权，然后发送'发布到公众号'即可。"
   - **如果用户明确要求"发布到公众号"或类似表述（"发出去"、"发一下"、"推送"）**：
     - **只使用 publish_wechat_mp 工具**，不要重新调用 write_wechat_mp_article
     - 如果 publish_wechat_mp 返回 requires_content=true，说明没有可发布的内容，才需要写文章
     - **不要说"我重新为你写了一篇文章"**，用户只是要发布现有内容！
   - **如果用户要求"写作并发布"（如"写公众号文章并发布"、"写一篇文章发布到公众号"）**：
     - **步骤1**：首先调用 write_wechat_mp_article 生成文章
     - **步骤2（必须）**：write_wechat_mp_article 成功后，**立即**调用 publish_wechat_mp 发布文章
     - **步骤3（必须）**：处理 publish_wechat_mp 的返回结果：
       * 成功(success=true)：告知用户"✅ 文章已成功保存到公众号草稿箱！"
       * 未配置账号(requires_config=true)：告知用户"文章已生成，但发布失败：未配置公众号账号，请先在设置中绑定公众号"
       * 失败(error)：告知用户"文章已生成，但发布失败：[具体错误信息]"
     - **禁止**：只写文章不发布，或发布失败不告知用户！

8. 【视频生成规则（CRITICAL）】
   - 当使用 generate_video 工具生成视频时：
     - **如果用户上传了图片**：使用用户上传的图片作为 firstFrameUrl 参数（role: 'first_frame'）
     - **如果用户没有上传图片**：只使用文本描述生成视频，不传递 firstFrameUrl 参数
     - 注意：豆包视频生成API不支持 'reference_image' 角色，必须使用 'first_frame'
     - 注意：只支持AI生成的图片，不支持真实人物照片（会导致"The request failed because the input image may contain real person"错误）
   - 当使用 produce_shortdrama 工具制作短剧时：
     - 如果用户上传了参考图片，使用用户上传的图片作为首帧（first_frame）
     - 如果没有上传参考图片，只使用文本描述生成视频

【多步指令执行规则】
- 当识别到多步指令时，必须按顺序执行所有子任务
- 每完成一个子任务后，继续思考下一步要做什么
- 不要在完成第一个子任务后就返回 Final Answer
- 不要因为已经生成了部分内容就认为任务完成
- 只有所有子任务都执行完成后，才能返回 Final Answer
- **特别重要**：对于"写作并发布"类任务，写作完成后**必须**执行发布操作，不能只写不发！
- **特别重要**：对于"发布"类任务，如果发布失败（requires_config、error等），**必须**将错误原因明确告知用户，不能假装成功！

【小程序内部功能】
当用户指令涉及以下关键词时，必须优先调用对应的小程序内部功能工具：
- "分配订单"、"派单"、"接单"（不包含"查看"或"寻找"时） → 使用 app_assign_order 工具
- "找分身"、"寻找分身"（作为独立任务时）→ 使用 app_list_avatars 工具查看分身列表
- **注意**：在多步指令中，"找X个分身"通常是任务的后续步骤，不要单独执行，要等待前面的任务完成后再执行
- "添加好友"、"交朋友"、"扩列" → 使用 app_add_friend 工具
- "我的好友"、"我有多少好友"、"查看好友"、"好友列表" → 使用 app_list_user_friends 工具（查询用户的好友）
- "分身的好友"、"分身有多少好友" → 使用 app_list_avatar_friends 工具（查询分身的好友）
- "订阅"、"升级"、"开通套餐" → 使用 app_subscribe 或 app_get_subscription 工具
- "创建任务"、"发布任务" → 使用 app_create_task 工具
- "查看订单"、"我的订单" → 使用 app_list_tasks 工具

请思考下一步应该做什么。
- 如果需要使用工具，按以下格式回复：
  Thought: [你的思考]
  Action: [工具名称]
  Action Input: [JSON格式的参数]

- 如果任务已完成或不需要调用工具，按以下格式回复：
  Thought: [你的思考]
  Final Answer: [最终答案]

只回复Thought、Action和Action Input（或Final Answer），不要有其他内容。`;
        const response = await this.llmClient.invoke([
            { role: 'user', content: prompt }
        ], {
            model: 'doubao-seed-1-8-251228',
            temperature: 0.3
        });
        return response.content.trim();
    }
    getTaskUnderstandingHint(task, history, context) {
        const hints = [];
        const lowerTask = task.toLowerCase();
        const hasMultiStepTask = /[，、,并然后接下来之后同时以及还有再]\s*(找|生成|做|画|创作|写|发布|添加|分配|发)/.test(task);
        if (hasMultiStepTask) {
            const subTasks = task.split(/[，、,并然后接下来之后同时以及还有再]/)
                .map(t => t.trim())
                .filter(t => t.length > 0);
            const hasFindAndDistribute = subTasks.some(t => /找.*分身.*分发|找.*人.*分发|分配.*分身|派.*分身/.test(t));
            let executionStrategy = `【执行策略】必须按顺序逐个执行每个子任务，不能遗漏任何子任务。`;
            if (hasFindAndDistribute) {
                executionStrategy += `
【关键提示】检测到"找分身分发"任务：
- 这应该使用 app_assign_order 工具（分配订单/找分身）
- 该工具会根据订单需求、分身等级、优先级等智能匹配最合适的分身
- 系统会自动为匹配的分身创建订单执行记录
- 不要使用 app_list_avatars 工具（那是查看分身列表）
- app_assign_order 工具参数示例：
  {
    "title": "订单标题（从前面任务中提取）",
    "description": "订单详细描述（结合营销方案内容）",
    "required_count": 50,
    "priority_level": "high"
  }`;
            }
            hints.push(`【多步指令识别】检测到 ${subTasks.length} 个子任务：\n${subTasks.map((t, i) => `${i + 1}. ${t}`).join('\n')}`);
            hints.push(executionStrategy);
            hints.push(`【重要提示】如果子任务中包含"找分身"、"寻找分身"，这是后续步骤，不要单独提前执行。`);
            return hints.join('\n\n');
        }
        if (lowerTask.match(/分配.*订单|派单|接单|分配任务|派任务/) && !lowerTask.match(/查看|寻找|找分身列表|我的分身/)) {
            hints.push(`【任务解析】这是一个订单分配/派单任务：
请使用 app_assign_order 工具为订单分配合适的分身。
参数示例：{ "title": "任务标题", "description": "任务描述", "required_count": 需要的分身数量 }
执行步骤：
1. 首先调用 app_assign_order 创建订单并分配分身
2. 如果还需要其他操作（如生成海报），继续执行后续步骤`);
            return hints.join('\n\n');
        }
        else if (lowerTask.match(/找.*分身|寻找.*分身|我的.*分身|分身.*列表|列表.*分身|分身.*信息|当前.*分身|分身.*详情/)) {
            hints.push(`【任务解析】这是一个查看分身列表任务：
请使用 app_list_avatars 工具获取用户的分身列表。
参数示例：{ "limit": 50, "filter_hosted": false }`);
            return hints.join('\n\n');
        }
        else if (lowerTask.match(/添加好友|交朋友|扩列/)) {
            hints.push(`【任务解析】这是一个添加好友任务：
请使用 app_add_friend 工具为分身添加好友。
参数示例：{ "avatar_id": "当前分身ID", "match_count": 需要添加的数量 }`);
            return hints.join('\n\n');
        }
        else if (lowerTask.match(/查看.*好友|我的.*好友|好友列表|好友.*信息/)) {
            hints.push(`【任务解析】这是一个查看好友列表任务：
请使用 app_list_friends 工具获取指定分身的好友列表。
参数示例：{ "limit": 50 }`);
            return hints.join('\n\n');
        }
        else if ((lowerTask.match(/订阅|升级|购买套餐/) || lowerTask.match(/^开通$/)) &&
            !lowerTask.includes('公众号') &&
            !lowerTask.includes('微信')) {
            hints.push(`【任务解析】这是一个订阅套餐任务：
请先使用 app_get_subscription 工具查看当前订阅状态，然后根据用户需求使用 app_subscribe 工具订阅套餐。
注意：如果用户想"写公众号文章"或"开通公众号"，这是内容创作任务，请使用 write_wechat_mp_article 工具，不要调用订阅相关工具。`);
            return hints.join('\n\n');
        }
        else if (lowerTask.match(/查看.*账号|我的.*账号|账号.*列表|账号.*配置|绑定.*账号|已绑定.*账号|配置.*平台/)) {
            hints.push(`【任务解析】这是一个查看已配置账号列表任务：
请使用 list_avatar_accounts 工具查询分身已绑定的所有第三方平台账号（抖音、小红书、微信公众号、B站、微博等）。
参数示例：{ }`);
            return hints.join('\n\n');
        }
        if (lowerTask.match(/生成.*图|画.*图|设计.*图|做.*图|创作.*图|生成图片|画张图|做个图|海报/)) {
            hints.push(`【任务解析】这是一个图片生成任务：
请直接使用 generate_image 工具生成图片，不要使用其他工具。
参数示例：{ "prompt": "图片详细描述", "style": "realistic" }
style 可选值：realistic（写实）、artistic（艺术）、anime（动漫）、3d（3D效果）、logo（Logo设计）`);
            return hints.join('\n\n');
        }
        else if (lowerTask.match(/生成.*视频|做.*视频|创作.*视频|生成视频|做个视频/)) {
            hints.push(`【任务解析】这是一个视频生成任务：
请直接使用 generate_video 工具生成视频，不要使用其他工具。
参数示例：{ "prompt": "视频内容描述", "duration": 5, "ratio": "9:16" }`);
            return hints.join('\n\n');
        }
        else if (lowerTask.match(/^关注|点赞|收藏|分享|转发|评论|回复|你好|在吗|嗨|hi|hello|谢谢|感谢|再见|拜拜/) ||
            lowerTask.match(/帮我关注|帮我点赞|帮我收藏|帮我分享/) ||
            lowerTask.match(/^.{0,20}$/) && !lowerTask.match(/生成|创作|设计|写|画|发布|找|分配|添加|订阅|升级|查看|分身|信息|好友/)) {
            hints.push(`【任务解析】这是一个普通对话或社交互动：
请直接用 Final Answer 回复用户，不要调用任何工具。
- 如果用户说"关注"，回复"好的，已为你关注该话题/用户"
- 如果用户说"点赞"，回复"好的，已为你点赞"
- 如果用户只是问候，友好地回复问候
- 不要调用 generate_image、generate_video 等工具`);
            return hints.join('\n\n');
        }
        else if (lowerTask.match(/发布|发一下|发出去|推送|publish|post/) &&
            (lowerTask.includes('公众号') || lowerTask.includes('微信')) &&
            !lowerTask.match(/写|创作|生成|制作|draft|草稿|编辑|修改|润色/)) {
            hints.push(`【任务解析】这是一个**纯发布任务**（用户已写好内容，只需发布）：
1. **只使用 publish_wechat_mp 工具**将内容发布到公众号
2. **不要**调用 write_wechat_mp_article 工具重新写文章
3. 如果 publish_wechat_mp 返回 requires_config=true，说明用户未配置公众号，需要提示用户配置
4. 如果返回 requires_content=true，说明没有可发布的内容，才需要写文章

**注意**：用户明确说"发布"而不是"写"，说明内容已经有了，直接发布即可！`);
            return hints.join('\n\n');
        }
        else if (lowerTask.includes('公众号') || lowerTask.includes('微信文章') || lowerTask.includes('微信图文')) {
            const requiresPublish = lowerTask.match(/并.*发布|然后.*发布|再.*发布|.*并.*推送|发布.*到|写.*发布|写.*然后.*发|写.*并.*发/);
            if (requiresPublish) {
                hints.push(`【任务解析】这是一个**微信公众号创作+发布任务**（写作后立即发布）：
**执行顺序（必须严格按此顺序）**：
1. 首先使用 write_wechat_mp_article 工具生成公众号爆款图文内容
2. **等待 write_wechat_mp_article 成功返回后**，立即使用 publish_wechat_mp 工具将文章发布到公众号
3. 调用 publish_wechat_mp 时，参数使用 write_wechat_mp_article 返回的内容
4. 如果 publish_wechat_mp 返回 requires_config=true，说明用户未配置公众号，需要提示用户配置
5. 如果 publish_wechat_mp 返回错误，必须将错误信息明确告知用户

**重要**：
- 用户明确要求"写...并发布"，你必须完成发布操作，不能只写文章不发布！
- 发布失败时必须告知用户具体错误原因（如：未配置账号、API错误等）`);
            }
            else {
                hints.push(`【任务解析】这是一个微信公众号内容创作任务（仅写作，不自动发布）：
1. 使用 write_wechat_mp_article 工具生成公众号爆款图文内容
2. **不要**自动调用 publish_wechat_mp，除非用户明确要求发布
3. 在最终回复中告知用户：如需发布，请发送"发布到公众号"`);
            }
            return hints.join('\n\n');
        }
        else if (lowerTask.match(/发布|发一下|发出去|推送|publish|post/) &&
            lowerTask.includes('小红书') &&
            !lowerTask.match(/写|创作|生成|制作|draft|草稿|编辑|修改|润色/)) {
            hints.push(`【任务解析】这是一个**小红书纯发布任务**（用户已写好内容，只需发布）：
1. **只使用 publish_xiaohongshu 工具**发布到小红书
2. **不要**调用 write_xiaohongshu_note 工具重新写笔记
3. 如果返回 requires_config=true，说明用户未配置小红书账号`);
            return hints.join('\n\n');
        }
        else if (lowerTask.includes('小红书') || lowerTask.includes('红书笔记')) {
            hints.push(`【任务解析】这是一个小红书内容创作任务：
1. 首先使用 write_xiaohongshu_note 工具生成小红书笔记内容
2. 然后使用 publish_xiaohongshu 工具尝试发布
3. 如果发布工具返回 requires_config=true，说明用户未配置小红书账号`);
            return hints.join('\n\n');
        }
        else if (lowerTask.includes('微博') && (lowerTask.includes('发') || lowerTask.includes('写') || lowerTask.includes('创作') || lowerTask.includes('生成'))) {
            hints.push(`【任务解析】这是一个微博内容创作任务：
1. 首先使用 write_article 工具生成微博内容（简短、话题性强）
2. 然后使用 publish_weibo 工具尝试发布
3. 如果发布工具返回 requires_config=true，说明用户未配置微博账号`);
            return hints.join('\n\n');
        }
        else if ((lowerTask.includes('抖音') || lowerTask.includes('tiktok')) && (lowerTask.includes('发') || lowerTask.includes('写') || lowerTask.includes('创作') || lowerTask.includes('生成'))) {
            hints.push(`【任务解析】这是一个抖音内容创作任务：
1. 首先生成视频内容（使用 generate_video 或提供视频脚本）
2. 然后使用 publish_douyin 工具尝试发布
3. 如果发布工具返回 requires_config=true，说明用户未配置抖音账号`);
            return hints.join('\n\n');
        }
        else if ((lowerTask.includes('b站') || lowerTask.includes('哔哩') || lowerTask.includes('bilibili')) && (lowerTask.includes('发') || lowerTask.includes('写') || lowerTask.includes('创作') || lowerTask.includes('生成'))) {
            hints.push(`【任务解析】这是一个B站内容创作任务：
1. 首先生成视频或文章内容
2. 然后使用 publish_bilibili 工具尝试发布
3. 如果发布工具返回 requires_config=true，说明用户未配置B站账号`);
            return hints.join('\n\n');
        }
        else if (lowerTask.includes('视频号') && (lowerTask.includes('发') || lowerTask.includes('写') || lowerTask.includes('创作') || lowerTask.includes('生成'))) {
            hints.push(`【任务解析】这是一个微信视频号内容创作任务：
1. 首先生成视频内容
2. 然后使用 publish_wechat_video 工具尝试发布
3. 如果发布工具返回 requires_config=true，说明用户未配置视频号`);
            return hints.join('\n\n');
        }
        else if ((lowerTask.includes('头条') || lowerTask.includes('今日头条')) && (lowerTask.includes('发') || lowerTask.includes('写') || lowerTask.includes('创作') || lowerTask.includes('生成'))) {
            hints.push(`【任务解析】这是一个今日头条内容创作任务：
1. 首先使用 write_article 工具生成头条文章内容
2. 注意：今日头条暂未集成，请告知用户当前支持的平台：微信公众号、小红书、微博、抖音、B站、微信视频号`);
            return hints.join('\n\n');
        }
        else if (lowerTask.match(/写.*文章|撰写.*文|生成.*文|创作.*文/) && !lowerTask.includes('公众号') && !lowerTask.includes('小红书')) {
            hints.push(`【任务解析】这是一个通用文章写作任务：
请使用 write_article 工具生成文章内容。`);
            return hints.join('\n\n');
        }
        if (history.length > 0) {
            const lastStep = history[history.length - 1];
            if (lastStep.observation?.next_action_hint) {
                hints.push(`【下一步建议】${lastStep.observation.next_action_hint}`);
            }
        }
        return hints.length > 0 ? hints.join('\n\n') : '';
    }
    formatConversationHistory(history) {
        if (!history || !Array.isArray(history) || history.length === 0)
            return '';
        return history
            .slice(-10)
            .map(msg => `${msg.role === 'user' ? '用户' : 'AI'}: ${msg.content}`)
            .join('\n');
    }
    async executeTool(toolName, params, context) {
        const isToolAvailable = context.availableTools.some(tool => tool.name === toolName);
        console.log(`[Agent] 执行工具检查 - 工具名: ${toolName}`);
        console.log(`[Agent] 可用工具列表:`, context.availableTools.map(t => t.name));
        console.log(`[Agent] 工具是否可用: ${isToolAvailable}`);
        if (!isToolAvailable) {
            console.warn(`[Agent] ⛔ 工具 ${toolName} 不在分身的可用工具列表中，拒绝执行`);
            const skillDisplayName = await this.getSkillDisplayName(toolName);
            return {
                success: false,
                error: `您的分身尚未添加该功能，请前往技能广场添加"${skillDisplayName}"技能`
            };
        }
        const tool = this.tools.get(toolName);
        if (!tool) {
            return { success: false, error: `工具 ${toolName} 不存在` };
        }
        const toolContext = {
            userId: context.userId,
            avatarId: context.avatarId,
            taskId: context.taskId,
            headers: undefined,
            uploadedImages: context.uploadedImages || [],
            uploadedVideos: context.uploadedVideos || [],
            onProgress: (message, step, subStep) => {
                if (!context.taskId) {
                    console.warn('[AgentService] taskId 为空，无法更新进度');
                    return;
                }
                const progress = {
                    taskId: context.taskId,
                    userId: context.userId,
                    type: 'substep',
                    message,
                    data: { step, subStep },
                    timestamp: Date.now(),
                    status: 'running'
                };
                this.progressCache.updateProgress(context.userId, progress);
                if (context.conversationId) {
                    this.updateAssistantMessageProgress(context.conversationId, context.userId, context.taskId, message).catch(err => {
                        console.error('[AgentService] 更新 assistant 消息进度失败:', err);
                    });
                }
            }
        };
        if (toolName.startsWith('publish_') && context.executionHistory?.length > 0) {
            const lastGeneratedContent = [...context.executionHistory].reverse().find(step => step.observation?.data?.content && step.observation?.data?.title);
            if (lastGeneratedContent?.observation?.data) {
                const generatedData = lastGeneratedContent.observation.data;
                if (!params.content || params.content.length < 100) {
                    console.log(`[Agent] 自动填充发布内容，原 content 长度: ${params.content?.length || 0}，新长度: ${generatedData.content?.length || 0}`);
                    params = {
                        ...params,
                        title: params.title || generatedData.title,
                        content: generatedData.content,
                        cover_url: params.cover_url || generatedData.cover_image_url
                    };
                }
            }
        }
        try {
            const result = await tool.execute(params || {}, toolContext);
            return result;
        }
        catch (err) {
            return { success: false, error: err.message };
        }
    }
    async getSkillDisplayName(toolName) {
        try {
            const { data } = await (0, mysql_client_1.getMySQLClient)()
                .from('skills')
                .select('name')
                .eq('tool_name', toolName)
                .single();
            return data?.name || toolName;
        }
        catch (error) {
            console.warn(`[Agent] 获取技能 ${toolName} 的中文名称失败:`, error);
            return toolName;
        }
    }
    parseAction(thought) {
        const actionMatch = thought.match(/Action:\s*(\w+)/i);
        const inputMatch = thought.match(/Action Input:\s*([\s\S]+?)(?=Thought:|Action:|Final Answer:|$)/i);
        if (actionMatch) {
            let actionInput = {};
            if (inputMatch) {
                try {
                    actionInput = JSON.parse(inputMatch[1].trim());
                }
                catch {
                    actionInput = { input: inputMatch[1].trim() };
                }
            }
            return {
                action: actionMatch[1],
                action_input: actionInput
            };
        }
        return null;
    }
    extractFinalAnswer(thought) {
        const match = thought.match(/Final Answer:\s*([\s\S]+)/i);
        return match ? match[1].trim() : thought;
    }
    hasMediaContent(finalAnswer) {
        try {
            const parsed = JSON.parse(finalAnswer);
            const mediaFields = ['video_clips', 'image_urls', 'video_url', 'edited_video_url', 'images', 'videos', 'characters', 'scenes'];
            return mediaFields.some(field => {
                const value = parsed[field];
                return Array.isArray(value) && value.length > 0;
            });
        }
        catch (e) {
            const urlPattern = /https?:\/\/[^\s]+\.(mp4|mov|avi|jpg|jpeg|png|gif)/gi;
            return urlPattern.test(finalAnswer);
        }
    }
    hasVideoContent(finalAnswer) {
        try {
            const parsed = JSON.parse(finalAnswer);
            const videoFields = ['video_clips', 'videos', 'video_url', 'edited_video_url'];
            const hasVideoArray = videoFields.some(field => {
                const value = parsed[field];
                if (Array.isArray(value) && value.length > 0) {
                    if (field === 'video_clips') {
                        return value.some((clip) => clip.url && typeof clip.url === 'string' && clip.url.length > 0);
                    }
                    return true;
                }
                return false;
            });
            const hasVideoString = videoFields.some(field => {
                const value = parsed[field];
                return typeof value === 'string' && value.length > 0;
            });
            return hasVideoArray || hasVideoString;
        }
        catch (e) {
            const videoUrlPattern = /https?:\/\/[^\s]+\.(mp4|mov|avi)/gi;
            return videoUrlPattern.test(finalAnswer);
        }
    }
    extractShortdramaParams(taskDescription, finalAnswer) {
        const params = {
            theme: taskDescription,
            duration: 1,
            include_video: true,
            key_scenes_count: 6,
            ratio: '16:9',
            generate_audio: true
        };
        const durationMatch = taskDescription.match(/(\d+)\s*分钟/);
        if (durationMatch) {
            params.duration = parseInt(durationMatch[1]);
        }
        if (taskDescription.includes('横屏') || taskDescription.includes('16:9')) {
            params.ratio = '16:9';
        }
        else if (taskDescription.includes('竖屏') || taskDescription.includes('9:16')) {
            params.ratio = '9:16';
        }
        const clipDurationMatch = taskDescription.match(/每镜头(\d+)\s*秒/);
        if (clipDurationMatch) {
            params.video_duration = parseInt(clipDurationMatch[1]);
        }
        const clipCountMatch = taskDescription.match(/(\d+)\s*个?镜头/);
        if (clipCountMatch) {
            params.key_scenes_count = parseInt(clipCountMatch[1]);
        }
        console.log('[AgentService] 提取短剧参数:', params);
        return params;
    }
    async generateDirectAnswer(context) {
        const response = await this.llmClient.invoke([
            {
                role: 'user',
                content: `请直接回答以下问题，不要使用工具：\n\n${context.taskDescription}`
            }
        ], {
            model: 'doubao-seed-1-8-251228',
            temperature: 0.7
        });
        return response.content.trim();
    }
    async summarizeExecution(context, steps) {
        const filteredSteps = steps.map(s => {
            const filteredObservation = s.observation ? { ...s.observation } : s.observation;
            if (filteredObservation?.data) {
                const { message, next_action_hint, ...businessData } = filteredObservation.data;
                filteredObservation.data = businessData;
            }
            return {
                step_index: s.step_index,
                thought: s.thought,
                action: s.action,
                observation: filteredObservation
            };
        });
        const stepsSummary = filteredSteps.map(s => `步骤${s.step_index}: ${s.thought}\n行动: ${s.action || '无'}\n结果: ${JSON.stringify(s.observation).substring(0, 200)}`).join('\n\n');
        const response = await this.llmClient.invoke([
            {
                role: 'user',
                content: `任务：${context.taskDescription}\n\n执行记录：\n${stepsSummary}\n\n请用简洁的语言总结任务执行结果。
要求：
1. 只总结最终生成的结果（如：文章、图片、视频等）
2. 不要提及中间过程、工具调用细节、数量统计等调试信息
3. 如果生成了图片，直接说"已生成图片"，不要说"已生成3张图片"
4. 如果生成了文章，直接说"文章已生成"，不要说"文章已生成，共1000字"
5. 使用简洁、自然的语言，就像一个普通人在回复朋友一样`
            }
        ], {
            model: 'doubao-seed-1-8-251228',
            temperature: 0.5
        });
        return response.content.trim();
    }
    formatToolsForPrompt(tools) {
        return tools.map(t => `- ${t.name}: ${t.description}\n  参数: ${JSON.stringify(t.paramsSchema)}`).join('\n');
    }
    formatHistory(history) {
        return history.map(h => {
            let resultStr;
            if (h.observation?.data) {
                const data = h.observation.data;
                if (data.title || data.content) {
                    resultStr = JSON.stringify({
                        success: h.observation.success,
                        data: {
                            title: data.title,
                            content: data.content,
                            content_length: data.content?.length || 0,
                            cover_image_url: data.cover_image_url,
                            word_count: data.word_count,
                            message: data.message,
                            next_action_hint: data.next_action_hint
                        }
                    });
                }
                else {
                    resultStr = JSON.stringify(h.observation);
                }
            }
            else {
                resultStr = JSON.stringify(h.observation);
            }
            return `步骤${h.step_index}:\n思考: ${h.thought}\n行动: ${h.action}\n结果: ${resultStr}`;
        }).join('\n\n');
    }
    async logStep(context, step, result) {
        if (!context.taskId)
            return;
        const client = (0, mysql_client_1.getMySQLClient)();
        await client.insert('agent_task_logs', {
            task_id: context.taskId,
            avatar_id: context.avatarId,
            step_index: step.step_index,
            step_type: 'action',
            content: step.thought,
            tool_name: step.action,
            tool_params: JSON.stringify(step.action_input),
            tool_result: JSON.stringify(result),
            requires_config: result.requires_config || false,
            config_platform: result.config_platform
        });
    }
    async checkPlatformConfig(userId, platform) {
        const client = (0, mysql_client_1.getMySQLClient)();
        const { data } = await client
            .from('platform_configs')
            .select('*')
            .eq('user_id', userId)
            .eq('platform_type', platform)
            .maybeSingle();
        if (!data || data.status !== 'active') {
            return {
                configured: false,
                requiredFields: agent_types_1.PLATFORM_CONFIG_TEMPLATES[platform]?.fields
            };
        }
        return {
            configured: true,
            config: data
        };
    }
    async validatePlatformConfig(platform, configData) {
        console.log(`验证平台配置: ${platform}`, Object.keys(configData));
        try {
            switch (platform) {
                case 'wechat':
                    return await this.validateWechatMpConfig(configData);
                case 'xiaohongshu':
                    return await this.validateXiaohongshuConfig(configData);
                case 'bilibili':
                    return await this.validateBilibiliConfig(configData);
                case 'weibo':
                    return await this.validateWeiboConfig(configData);
                case 'douyin':
                    return await this.validateDouyinConfig(configData);
                default:
                    return { valid: false, message: '不支持的平台类型' };
            }
        }
        catch (err) {
            console.error('验证配置失败:', err);
            return { valid: false, message: `验证失败: ${err.message}` };
        }
    }
    async validateWechatMpConfig(configData) {
        const { app_id, app_secret } = configData;
        if (!app_id || !app_secret) {
            return { valid: false, message: '请填写AppID和AppSecret' };
        }
        if (!app_id.startsWith('wx')) {
            return { valid: false, message: 'AppID格式错误，应以wx开头' };
        }
        if (app_secret.length !== 32) {
            return { valid: false, message: 'AppSecret格式错误，应为32位字符' };
        }
        try {
            const tokenUrl = `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${app_id}&secret=${app_secret}`;
            const res = await fetch(tokenUrl);
            const data = await res.json();
            if (data.errcode) {
                const errorMessages = {
                    40001: 'AppSecret错误或不属于该公众号，请检查AppSecret是否正确',
                    40013: 'AppID不合法，请检查AppID是否正确',
                    40164: '服务器IP未加入白名单，请在微信公众平台后台配置IP白名单：115.191.1.219（路径：设置与开发 -> 基本配置 -> IP白名单）',
                    41004: '缺少AppSecret参数',
                    48001: 'api功能未授权，请确认公众号已开通相关权限',
                };
                const msg = errorMessages[data.errcode] || `微信API错误: ${data.errmsg} (${data.errcode})`;
                let serverIp;
                if (data.errcode === 40164) {
                    serverIp = '115.191.1.219';
                }
                return { valid: false, message: msg, serverIp };
            }
            if (!data.access_token) {
                return { valid: false, message: '验证失败，请检查配置' };
            }
            const accessToken = data.access_token;
            let accountInfo = {};
            try {
                const accountInfoUrl = `https://api.weixin.qq.com/cgi-bin/account/getaccountbasicinfo?access_token=${accessToken}`;
                const accountInfoRes = await fetch(accountInfoUrl);
                const accountData = await accountInfoRes.json();
                console.log('公众号账号信息 API 响应:', accountData);
                if (accountData.errcode === 0) {
                    accountInfo = {
                        nickname: accountData.account_name,
                        account_name: accountData.account_name,
                        avatar_url: accountData.avatar_url || '',
                        signature: accountData.signature || '',
                        account_type: accountData.account_type,
                        service_type_info: accountData.service_type_info,
                        verify_type_info: accountData.verify_type_info,
                    };
                    console.log('获取公众号基本信息成功:', accountInfo);
                }
                else {
                    console.log('获取公众号基本信息失败，错误码:', accountData.errcode, '错误信息:', accountData.errmsg);
                    accountInfo = {
                        note: `无法获取公众号详细信息（${accountData.errmsg || '权限不足'}）`,
                        errcode: accountData.errcode,
                        errmsg: accountData.errmsg
                    };
                }
            }
            catch (err) {
                console.log('获取公众号基本信息异常:', err);
                accountInfo = {
                    note: '无法获取公众号详细信息（网络异常）',
                    error: err.message
                };
            }
            try {
                const userCountUrl = `https://api.weixin.qq.com/cgi-bin/user/get?access_token=${accessToken}`;
                const userCountRes = await fetch(userCountUrl);
                const userCountData = await userCountRes.json();
                console.log('粉丝数 API 响应:', userCountData);
                if (userCountData.errcode === 0 && userCountData.total !== undefined) {
                    accountInfo.follower_count = userCountData.total;
                    console.log('获取粉丝数成功:', accountInfo.follower_count);
                }
                else {
                    accountInfo.follower_count = 0;
                    accountInfo.follower_note = `无法获取粉丝数：${userCountData.errmsg || '可能需要认证的服务号权限'}`;
                    console.log('获取粉丝数失败:', userCountData);
                }
            }
            catch (err) {
                accountInfo.follower_count = 0;
                accountInfo.follower_note = `无法获取粉丝数：${err.message}`;
                console.log('获取粉丝数异常:', err);
            }
            try {
                const publishListUrl = `https://api.weixin.qq.com/cgi-bin/freepublish/batchget?access_token=${accessToken}&offset=0&count=1&no_content=1`;
                const publishRes = await fetch(publishListUrl);
                const publishData = await publishRes.json();
                console.log('作品数量 API 响应:', publishData);
                if (publishData.errcode === 0 && publishData.total_count !== undefined) {
                    accountInfo.total_works = publishData.total_count;
                    console.log('获取作品数量成功:', accountInfo.total_works);
                }
                else {
                    accountInfo.total_works = 0;
                    accountInfo.works_note = `无法获取作品数量：${publishData.errmsg || '可能需要更多权限'}`;
                    console.log('获取作品数量失败:', publishData);
                }
            }
            catch (err) {
                accountInfo.total_works = 0;
                accountInfo.works_note = `无法获取作品数量：${err.message}`;
                console.log('获取作品数量异常:', err);
            }
            let successMessage = '配置验证成功';
            const availableInfo = [];
            if (accountInfo.nickname)
                availableInfo.push(`公众号：${accountInfo.nickname}`);
            if (accountInfo.follower_count && accountInfo.follower_count > 0)
                availableInfo.push(`粉丝数：${accountInfo.follower_count}`);
            if (accountInfo.total_works && accountInfo.total_works > 0)
                availableInfo.push(`作品数：${accountInfo.total_works}`);
            if (availableInfo.length > 0) {
                successMessage = `配置验证成功！${availableInfo.join('，')}`;
            }
            else if (accountInfo.note) {
                successMessage = `配置验证成功！${accountInfo.note}`;
            }
            return {
                valid: true,
                message: successMessage,
                accountInfo
            };
        }
        catch (err) {
            return { valid: false, message: `API调用失败: ${err.message}` };
        }
    }
    async validateXiaohongshuConfig(configData) {
        const { cookie } = configData;
        if (!cookie || cookie.length < 50) {
            return { valid: false, message: 'Cookie格式不正确，请确保复制了完整的Cookie' };
        }
        if (!cookie.includes('web_session') && !cookie.includes('webId')) {
            return { valid: false, message: 'Cookie可能无效，请确保已登录小红书并正确复制Cookie' };
        }
        return { valid: true, message: 'Cookie格式验证通过（实际有效性需发布时验证）' };
    }
    async validateBilibiliConfig(configData) {
        const { sessdata, bili_jct } = configData;
        if (!sessdata) {
            return { valid: false, message: '请填写SESSDATA' };
        }
        if (!bili_jct) {
            return { valid: false, message: '请填写bili_jct' };
        }
        if (sessdata.length < 20) {
            return { valid: false, message: 'SESSDATA格式不正确' };
        }
        if (bili_jct.length !== 32) {
            return { valid: false, message: 'bili_jct格式不正确，应为32位' };
        }
        return { valid: true, message: '配置格式验证通过（实际有效性需发布时验证）' };
    }
    async validateWeiboConfig(configData) {
        const { cookie } = configData;
        if (!cookie || cookie.length < 50) {
            return { valid: false, message: 'Cookie格式不正确，请确保复制了完整的Cookie' };
        }
        if (!cookie.includes('SUB') && !cookie.includes('ALF')) {
            return { valid: false, message: 'Cookie可能无效，请确保已登录微博并正确复制Cookie' };
        }
        return { valid: true, message: 'Cookie格式验证通过（实际有效性需发布时验证）' };
    }
    async validateDouyinConfig(configData) {
        const { cookie } = configData;
        if (!cookie || cookie.length < 50) {
            return { valid: false, message: 'Cookie格式不正确，请确保复制了完整的Cookie' };
        }
        if (!cookie.includes('sessionid') && !cookie.includes('passport_csrf_token')) {
            return { valid: false, message: 'Cookie可能无效，请确保已登录抖音创作者平台并正确复制Cookie' };
        }
        return { valid: true, message: 'Cookie格式验证通过（实际有效性需发布时验证）' };
    }
    async validateWechatVideoConfig(configData) {
        const { app_id, app_secret } = configData;
        if (!app_id || !app_secret) {
            return { valid: false, message: '请填写AppID和AppSecret' };
        }
        return { valid: true, message: '配置格式验证通过。视频号API目前在内测阶段，需要申请开通后才能使用自动发布功能。' };
    }
    async savePlatformConfig(userId, platform, configData) {
        const client = (0, mysql_client_1.getMySQLClient)();
        const { error } = await client
            .from('platform_configs')
            .upsert({
            user_id: userId,
            platform_type: platform,
            config_data: configData,
            status: 'active',
            updated_at: new Date().toISOString()
        }, {
            onConflict: 'user_id,platform_type'
        });
        if (error) {
            return { success: false, message: `保存失败: ${error.message}` };
        }
        return { success: true, message: '配置保存成功' };
    }
    async getUserPlatformConfigs(userId) {
        const client = (0, mysql_client_1.getMySQLClient)();
        const { data } = await client
            .from('platform_configs')
            .select('*')
            .eq('user_id', userId);
        return (data || []);
    }
    async deletePlatformConfig(userId, platform) {
        const client = (0, mysql_client_1.getMySQLClient)();
        await client
            .from('platform_configs')
            .delete()
            .eq('user_id', userId)
            .eq('platform_type', platform);
        return { success: true };
    }
    async addAvatarSkill(avatarId, skillType, metadata) {
        const client = (0, mysql_client_1.getMySQLClient)();
        await client
            .from('avatar_skills')
            .upsert({
            avatar_id: avatarId,
            skill_type: skillType,
            skill_level: 1,
            usage_count: 0,
            metadata: metadata || {},
            created_at: new Date().toISOString()
        }, {
            onConflict: 'avatar_id,skill_type'
        });
        return { success: true };
    }
    async getAvatarSkills(avatarId) {
        const client = (0, mysql_client_1.getMySQLClient)();
        const { data } = await client
            .from('avatar_skills')
            .select('*')
            .eq('avatar_id', avatarId);
        return (data || []);
    }
    async publishContent(userId, platform, content) {
        const client = (0, mysql_client_1.getMySQLClient)();
        const { data: config, error: configError } = await client
            .from('platform_configs')
            .select('*')
            .eq('user_id', userId)
            .eq('platform_type', platform)
            .maybeSingle();
        if (configError || !config || config.status !== 'active') {
            const template = agent_types_1.PLATFORM_CONFIG_TEMPLATES[platform];
            return {
                success: false,
                message: `请先配置${template?.platform_name || platform}`
            };
        }
        let toolName;
        let params = {};
        switch (platform) {
            case 'wechat':
                toolName = 'publish_wechat_mp';
                params = {
                    title: content.title,
                    content: content.content,
                    cover_url: content.cover_url
                };
                break;
            case 'xiaohongshu':
                toolName = 'publish_xiaohongshu';
                params = {
                    title: content.title,
                    content: content.content,
                    images: content.images,
                    tags: content.tags
                };
                break;
            case 'weibo':
                toolName = 'publish_weibo';
                params = {
                    content: content.content,
                    images: content.images
                };
                break;
            case 'bilibili':
                toolName = 'publish_bilibili';
                params = {
                    type: 'article',
                    title: content.title,
                    content: content.content,
                    cover_url: content.cover_url,
                    tags: content.tags
                };
                break;
            case 'douyin':
                toolName = 'publish_douyin';
                params = {
                    title: content.title,
                    video_url: content.content,
                    cover_url: content.cover_url,
                    tags: content.tags
                };
                break;
            default:
                return { success: false, message: '不支持的平台' };
        }
        const tool = this.tools.get(toolName);
        if (!tool) {
            return { success: false, message: '发布工具不可用' };
        }
        const toolContext = {
            userId,
            avatarId: '',
            taskId: `publish-${Date.now()}`
        };
        try {
            console.log(`[AgentService] 发布到 ${platform}:`, params);
            const result = await tool.execute(params, toolContext);
            return {
                success: result.success,
                data: result.data,
                message: result.success
                    ? result.data?.message || '发布成功'
                    : result.error || '发布失败'
            };
        }
        catch (err) {
            console.error(`[AgentService] 发布失败:`, err);
            return { success: false, message: err.message || '发布失败' };
        }
    }
    checkRequiredSkills(task, availableTools) {
        const required = [];
        const missing = [];
        const lowerTask = task.toLowerCase();
        if (lowerTask.match(/短剧.*成品|真人短剧|短剧成品|制作短剧|生成短剧|短剧制作/)) {
            required.push({ toolName: 'produce_shortdrama', skillName: '完整短剧制作' });
        }
        else if (lowerTask.match(/多集.*短剧|连续短剧|系列短剧|短剧集/)) {
            required.push({ toolName: 'generate_multi_episode_drama', skillName: '多集连续短剧' });
        }
        else if (lowerTask.match(/短剧.*剧本|剧本.*短剧/)) {
            required.push({ toolName: 'generate_shortdrama_script', skillName: '短剧剧本生成' });
        }
        else if (lowerTask.match(/短剧.*配音|配音.*短剧/)) {
            required.push({ toolName: 'generate_drama_voiceover', skillName: '短剧配音' });
        }
        else if (lowerTask.match(/短剧.*剪辑|剪辑.*短剧/)) {
            required.push({ toolName: 'edit_shortdrama_video', skillName: '视频剪辑' });
        }
        else if (lowerTask.match(/短剧.*字幕|字幕.*短剧/)) {
            required.push({ toolName: 'generate_subtitle', skillName: '字幕生成' });
        }
        else if (lowerTask.match(/短剧.*配乐|配乐.*短剧|短剧.*背景音乐/)) {
            required.push({ toolName: 'recommend_bgm', skillName: '配乐推荐' });
        }
        else if (lowerTask.match(/生成.*视频|做.*视频|制作.*视频|视频生成/)) {
            required.push({ toolName: 'generate_video', skillName: '视频生成' });
        }
        if (lowerTask.match(/生成.*图|画.*图|设计.*图|做.*图|创作.*图|生成图片|画张图|做个图|海报/)) {
            required.push({ toolName: 'generate_image', skillName: '图像生成' });
        }
        if (lowerTask.match(/写.*文章|创作.*文章|写公众号|写内容/)) {
            required.push({ toolName: 'write_article', skillName: '文章创作' });
        }
        if (lowerTask.match(/写.*小红书|小红书.*笔记/)) {
            required.push({ toolName: 'write_xiaohongshu_note', skillName: '小红书笔记' });
        }
        if (lowerTask.match(/写.*公众号|公众号.*文章/)) {
            required.push({ toolName: 'write_wechat_mp_article', skillName: '公众号文章' });
        }
        if (lowerTask.match(/发.*公众号|发布.*公众号/)) {
            required.push({ toolName: 'publish_wechat_mp', skillName: '公众号发布' });
        }
        if (lowerTask.match(/发.*小红书|发布.*小红书/)) {
            required.push({ toolName: 'publish_xiaohongshu', skillName: '小红书发布' });
        }
        if (lowerTask.match(/发.*抖音|发布.*抖音/)) {
            required.push({ toolName: 'publish_douyin', skillName: '抖音发布' });
        }
        if (lowerTask.match(/发.*B站|发布.*B站|发.*Bilibili/)) {
            required.push({ toolName: 'publish_bilibili', skillName: 'B站发布' });
        }
        if (lowerTask.match(/发.*视频号|发布.*视频号/)) {
            required.push({ toolName: 'publish_wechat_video', skillName: '视频号发布' });
        }
        for (const skill of required) {
            const isAvailable = availableTools.some(tool => tool.name === skill.toolName);
            if (!isAvailable) {
                missing.push(skill);
            }
        }
        return { required, missing };
    }
    getToolDisplayNameChinese(toolName) {
        const toolNameMap = {
            'produce_shortdrama': '完整短剧制作',
            'generate_multi_episode_drama': '多集连续短剧',
            'generate_shortdrama_script': '短剧剧本生成',
            'generate_drama_voiceover': '短剧配音',
            'edit_shortdrama_video': '视频剪辑',
            'generate_subtitle': '字幕生成',
            'recommend_bgm': '配乐推荐',
            'generate_image': '图像生成',
            'generate_video': '视频生成',
            'write_article': '文章创作',
            'write_xiaohongshu_note': '小红书笔记',
            'write_wechat_mp_article': '公众号文章',
            'publish_wechat_mp': '公众号发布',
            'publish_xiaohongshu': '小红书发布',
            'publish_douyin': '抖音发布',
            'publish_bilibili': 'B站发布'
        };
        return toolNameMap[toolName] || toolName;
    }
    detectUnknownSkillRequirements(task, availableTools) {
        const lowerTask = task.toLowerCase();
        const availableToolNames = availableTools.map(t => t.name.toLowerCase());
        const unknownRequirements = [
            {
                pattern: /翻译|translate|中译英|英译中|日译中/,
                description: '翻译功能',
                suggestion: '目前技能广场暂未提供翻译功能。您可以：\n1. 使用其他翻译工具（如百度翻译、Google翻译）\n2. 或者尝试换一种方式描述您的需求'
            },
            {
                pattern: /写代码|编程|code|生成代码|开发|写程序|写脚本/,
                description: '代码生成功能',
                suggestion: '目前技能广场暂未提供代码生成功能。您可以：\n1. 描述具体的需求，看是否可以用其他方式实现\n2. 联系我们反馈需求'
            },
            {
                pattern: /分析.*数据|数据分析|统计.*数据|数据处理|数据挖掘/,
                description: '数据分析功能',
                suggestion: '目前技能广场暂未提供数据分析功能。您可以：\n1. 提供具体的数据和分析需求\n2. 使用专业数据分析工具'
            },
            {
                pattern: /聊天|对话|问答|咨询|问.*问题|解答/,
                description: 'AI 对话功能',
                suggestion: '我是专门用于内容创作和平台发布的 AI 分身。我可以帮您：\n1. 生成图片和视频\n2. 写文章、笔记\n3. 发布到各大平台\n4. 添加好友、管理订单'
            },
            {
                pattern: /音频|音乐|语音|配音|录音|TTS|ASR/,
                description: '音频处理功能',
                suggestion: '目前技能广场暂未提供音频处理功能。您可以：\n1. 描述具体需求\n2. 使用专业音频工具'
            },
            {
                pattern: /转换.*格式|格式转换|压缩.*文件|文件压缩|OCR|识别.*文字/,
                description: '文件处理功能',
                suggestion: '目前技能广场暂未提供文件处理功能。您可以：\n1. 使用在线转换工具\n2. 描述具体需求'
            },
            {
                pattern: /理财|投资|股票|基金|期货|外汇|财务分析|记账/,
                description: '财务理财功能',
                suggestion: '目前技能广场暂未提供财务理财功能。请您：\n1. 咨询专业理财顾问\n2. 使用专业理财工具'
            },
            {
                pattern: /医疗|健康|诊断|治疗|症状|疾病|看病|体检/,
                description: '医疗健康功能',
                suggestion: '我不是医疗助手，无法提供医疗建议。请您：\n1. 咨询专业医生\n2. 前往正规医疗机构'
            },
            {
                pattern: /法律|律师|合同|起诉|诉讼|维权|法律咨询/,
                description: '法律咨询功能',
                suggestion: '我不是法律助手，无法提供法律建议。请您：\n1. 咨询专业律师\n2. 寻求法律援助'
            }
        ];
        for (const req of unknownRequirements) {
            if (req.pattern.test(lowerTask)) {
                return `【功能暂未开放】检测到您需要使用${req.description}

${req.suggestion}

【我的能力范围】
我可以帮您完成以下任务：
- 🎨 生成图片、视频（图像生成、视频生成）
- 📝 创作内容（文章创作、小红书笔记、公众号文章）
- 📤 发布内容（小红书、公众号、抖音、B站、视频号）
- 👥 社交互动（添加好友、查看好友）
- 📋 订单管理（分配订单、查看订单）
- 🎁 订阅管理（查看订阅、升级套餐）

您可以尝试换个说法，或者告诉我更具体的需求。`;
            }
        }
        const actionVerbs = ['生成', '制作', '创建', '设计', '处理', '计算', '分析', '转换'];
        const hasActionVerb = actionVerbs.some(verb => lowerTask.includes(verb));
        if (hasActionVerb && !this.matchesAvailableTaskTypes(lowerTask)) {
            return `【无法识别的功能】抱歉，我暂时无法理解您的需求。

请尝试用更具体的方式描述您想要做的事情。

【我可以帮您】
- 生成图片："生成一张风景画"
- 生成视频："制作一个10秒的短视频"
- 写文章："写一篇关于XX的文章"
- 发布内容："发布这篇内容到小红书"
- 添加好友："帮我添加50个好友"
- 分配订单："分配订单给分身"

如果您的需求不在上述范围内，欢迎反馈给我们！`;
        }
        return null;
    }
    matchesAvailableTaskTypes(task) {
        const taskTypes = [
            /生成.*图|画.*图|设计.*图|海报/,
            /生成.*视频|制作.*视频|视频创作/,
            /写.*文章|创作.*文章|写内容/,
            /发布|发.*到|推送/,
            /添加好友|查看好友|分身列表/,
            /分配.*订单|派单|接单|查看订单/,
            /订阅|升级|开通套餐/,
            /你好|你是谁|介绍一下/
        ];
        return taskTypes.some(regex => regex.test(task));
    }
};
exports.AgentService = AgentService;
exports.AgentService = AgentService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)((0, common_1.forwardRef)(() => agent_gateway_1.AgentGateway))),
    __param(1, (0, common_1.Inject)(progress_cache_service_1.ProgressCacheService)),
    __param(2, (0, common_1.Inject)(learning_service_1.LearningService)),
    __metadata("design:paramtypes", [agent_gateway_1.AgentGateway,
        progress_cache_service_1.ProgressCacheService,
        learning_service_1.LearningService])
], AgentService);
