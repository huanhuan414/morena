"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProgressCacheService = void 0;
const common_1 = require("@nestjs/common");
let ProgressCacheService = class ProgressCacheService {
    constructor() {
        this.progressMap = new Map();
        this.resultMap = new Map();
        this.MAX_PROGRESS_ITEMS = 50;
        this.EXPIRE_TIME = 10 * 60 * 1000;
    }
    createTask(userId, taskId) {
        const result = {
            taskId,
            userId,
            status: 'pending',
            createdAt: Date.now()
        };
        const key = `${userId}:${taskId}`;
        this.resultMap.set(key, result);
        console.log(`[ProgressCache] 创建任务: ${key}`);
        return result;
    }
    updateTaskStatus(userId, taskId, status, result, error) {
        const key = `${userId}:${taskId}`;
        const taskResult = this.resultMap.get(key);
        if (taskResult) {
            taskResult.status = status;
            if (result !== undefined) {
                taskResult.result = result;
            }
            if (error) {
                taskResult.error = error;
            }
            if (status === 'completed' || status === 'failed') {
                taskResult.completedAt = Date.now();
            }
            console.log(`[ProgressCache] 更新任务状态: ${key} -> ${status}`);
        }
    }
    getTaskResult(userId, taskId) {
        const key = `${userId}:${taskId}`;
        return this.resultMap.get(key) || null;
    }
    getUserTasks(userId) {
        const tasks = [];
        this.resultMap.forEach((result, key) => {
            if (key.startsWith(`${userId}:`)) {
                tasks.push(result);
            }
        });
        return tasks.sort((a, b) => b.createdAt - a.createdAt);
    }
    updateProgress(userId, progress) {
        const key = `${userId}:${progress.taskId || 'default'}`;
        if (!this.progressMap.has(key)) {
            this.progressMap.set(key, []);
        }
        const progressList = this.progressMap.get(key);
        progressList.push(progress);
        if (progressList.length > this.MAX_PROGRESS_ITEMS) {
            progressList.shift();
        }
        console.log(`[ProgressCache] 更新进度: ${key}`, progress.type, progress.message);
    }
    addProgress(userId, progress) {
        const key = `${userId}:${progress.taskId || 'default'}`;
        if (!this.progressMap.has(key)) {
            this.progressMap.set(key, []);
        }
        const progressList = this.progressMap.get(key);
        progressList.push(progress);
        if (progressList.length > this.MAX_PROGRESS_ITEMS) {
            progressList.shift();
        }
        console.log(`[ProgressCache] 添加进度: ${key}`, progress.type, progress.message);
    }
    getProgress(userId, taskId) {
        if (taskId) {
            const key = `${userId}:${taskId}`;
            return this.progressMap.get(key) || [];
        }
        const allProgress = [];
        this.progressMap.forEach((progressList, key) => {
            if (key.startsWith(`${userId}:`)) {
                allProgress.push(...progressList);
            }
        });
        return allProgress.sort((a, b) => a.timestamp - b.timestamp);
    }
    getLatestProgress(userId, taskId) {
        if (taskId) {
            const key = `${userId}:${taskId}`;
            const progressList = this.progressMap.get(key);
            if (!progressList || progressList.length === 0) {
                return null;
            }
            return progressList[progressList.length - 1];
        }
        let latest = null;
        this.progressMap.forEach((progressList, key) => {
            if (key.startsWith(`${userId}:`) && progressList.length > 0) {
                const last = progressList[progressList.length - 1];
                if (!latest || last.timestamp > latest.timestamp) {
                    latest = last;
                }
            }
        });
        return latest;
    }
    clearProgress(userId, taskId) {
        if (taskId) {
            const key = `${userId}:${taskId}`;
            this.progressMap.delete(key);
            this.resultMap.delete(key);
        }
        else {
            const keysToDelete = [];
            this.progressMap.forEach((_, key) => {
                if (key.startsWith(`${userId}:`)) {
                    keysToDelete.push(key);
                }
            });
            keysToDelete.forEach(key => {
                this.progressMap.delete(key);
                this.resultMap.delete(key);
            });
            console.log(`[ProgressCache] 清除用户 ${userId} 的所有进度，共 ${keysToDelete.length} 个任务`);
        }
    }
    cleanupExpired() {
        const now = Date.now();
        this.progressMap.forEach((progressList, key) => {
            const latestProgress = progressList[progressList.length - 1];
            if (latestProgress && now - latestProgress.timestamp > this.EXPIRE_TIME) {
                this.progressMap.delete(key);
                this.resultMap.delete(key);
                console.log(`[ProgressCache] 清理过期进度: ${key}`);
            }
        });
    }
};
exports.ProgressCacheService = ProgressCacheService;
exports.ProgressCacheService = ProgressCacheService = __decorate([
    (0, common_1.Injectable)()
], ProgressCacheService);
