"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentGateway = void 0;
const websockets_1 = require("@nestjs/websockets");
const socket_io_1 = require("socket.io");
const common_1 = require("@nestjs/common");
let AgentGateway = class AgentGateway {
    constructor() {
        this.userSockets = new Map();
    }
    handleConnection(client) {
        const userId = client.handshake.query.userId;
        if (userId) {
            client.join(`user:${userId}`);
            if (!this.userSockets.has(userId)) {
                this.userSockets.set(userId, new Set());
            }
            this.userSockets.get(userId).add(client.id);
            console.log(`[WebSocket] 用户 ${userId} 已连接, socket: ${client.id}`);
        }
    }
    handleDisconnect(client) {
        const userId = client.handshake.query.userId;
        if (userId && this.userSockets.has(userId)) {
            this.userSockets.get(userId).delete(client.id);
            if (this.userSockets.get(userId).size === 0) {
                this.userSockets.delete(userId);
            }
        }
        console.log(`[WebSocket] Socket ${client.id} 已断开`);
    }
    emitProgress(userId, progress) {
        this.server.to(`user:${userId}`).emit('task-progress', progress);
    }
    handleSubscribeTask(client, payload) {
        client.join(`task:${payload.taskId}`);
        return { success: true, message: `已订阅任务 ${payload.taskId}` };
    }
    handleUnsubscribeTask(client, payload) {
        client.leave(`task:${payload.taskId}`);
        return { success: true, message: `已取消订阅任务 ${payload.taskId}` };
    }
    getOnlineUserCount() {
        return this.userSockets.size;
    }
};
exports.AgentGateway = AgentGateway;
__decorate([
    (0, websockets_1.WebSocketServer)(),
    __metadata("design:type", socket_io_1.Server)
], AgentGateway.prototype, "server", void 0);
__decorate([
    (0, websockets_1.SubscribeMessage)('subscribe-task'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", void 0)
], AgentGateway.prototype, "handleSubscribeTask", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('unsubscribe-task'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", void 0)
], AgentGateway.prototype, "handleUnsubscribeTask", null);
exports.AgentGateway = AgentGateway = __decorate([
    (0, common_1.Injectable)(),
    (0, websockets_1.WebSocketGateway)({
        cors: {
            origin: '*',
            credentials: true
        },
        namespace: '/agent'
    })
], AgentGateway);
