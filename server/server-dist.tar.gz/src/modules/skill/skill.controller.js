"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SkillController = void 0;
const common_1 = require("@nestjs/common");
const skill_service_1 = require("./skill.service");
const ai_service_1 = require("../ai/ai.service");
let SkillController = class SkillController {
    constructor(skillService, aiService) {
        this.skillService = skillService;
        this.aiService = aiService;
    }
    async list(category, keyword) {
        try {
            if (this.skillService) {
                const skills = await this.skillService.listSkills(category, keyword);
                return { code: 200, msg: 'success', data: skills };
            }
        }
        catch (e) {
            console.error('[SkillController] list error:', e.message);
        }
        return { code: 200, msg: 'success', data: [] };
    }
    async getAvatarSkills(avatarId) {
        try {
            if (this.skillService) {
                const skills = await this.skillService.getAvatarSkills(avatarId);
                return { code: 200, msg: 'success', data: skills };
            }
        }
        catch (e) {
            console.error('[SkillController] getAvatarSkills error:', e.message);
        }
        return { code: 200, msg: 'success', data: [] };
    }
    async addSkillToAvatar(avatarId, skillId) {
        try {
            if (this.skillService) {
                const result = await this.skillService.addSkillToAvatar(avatarId, skillId);
                return { code: 200, msg: '技能添加成功', data: result };
            }
        }
        catch (e) {
            console.error('[SkillController] addSkillToAvatar error:', e.message);
        }
        return { code: 500, msg: '服务暂不可用', data: null };
    }
    async removeSkillFromAvatar(avatarId, skillId) {
        try {
            if (this.skillService) {
                const result = await this.skillService.removeSkillFromAvatar(avatarId, skillId);
                return { code: 200, msg: '技能移除成功', data: result };
            }
        }
        catch (e) {
            console.error('[SkillController] removeSkillFromAvatar error:', e.message);
        }
        return { code: 500, msg: '服务暂不可用', data: null };
    }
    async batchAddSkills(avatarId, body) {
        try {
            if (this.skillService) {
                const result = await this.skillService.batchAddSkills(avatarId, body.skillIds);
                return { code: 200, msg: '技能批量添加成功', data: result };
            }
        }
        catch (e) {
            console.error('[SkillController] batchAddSkills error:', e.message);
        }
        return { code: 500, msg: '服务暂不可用', data: null };
    }
    async trySkill(skillId, body) {
        try {
            if (!this.skillService || !this.aiService) {
                return { code: 500, msg: '服务暂不可用', data: null };
            }
            const skill = await this.skillService.getSkillById(skillId);
            if (!skill)
                return { code: 404, msg: '技能不存在', data: null };
            const userInput = body.input || '';
            const category = skill.category;
            const skillName = skill.name;
            let prompt = '';
            let contentType = 'text';
            switch (category) {
                case 'life':
                    if (skillName.includes('手相')) {
                        prompt = `你是一位经验丰富的手相大师。${userInput ? `用户说：${userInput}` : '请为用户模拟一次看手相体验'}。请用轻松愉快的语气，给出一段完整的手相解读（200-300字）。`;
                    }
                    else if (skillName.includes('衣品')) {
                        prompt = `你是一位顶级时尚造型师。${userInput ? `用户说：${userInput}` : '请为用户模拟一次衣品改造体验'}。请给出完整的穿搭方案（200-300字）。`;
                    }
                    else {
                        prompt = `你是一位${skillName}领域的专家。${userInput ? `用户输入：${userInput}` : '请为用户做一次体验演示'}。请给出专业且有趣的体验结果（200-300字）。`;
                    }
                    break;
                case 'image':
                    prompt = `你是一位AI绘画创意大师。${userInput ? `用户想生成：${userInput}` : '请为用户模拟一次AI图片生成体验'}。请输出详细的画面描述（150字以上）。`;
                    contentType = 'image';
                    break;
                case 'video':
                    prompt = `你是一位AI视频创意导演。${userInput ? `用户想生成：${userInput}` : '请为用户模拟一次AI视频生成体验'}。请输出分镜头脚本。`;
                    contentType = 'video';
                    break;
                case 'content':
                    prompt = `你是一位顶级内容创作专家。${userInput ? `用户想创作：${userInput}` : '请为用户生成一篇示例内容'}。请输出优质文案（200字以上）。`;
                    contentType = 'content';
                    break;
                default:
                    prompt = `你是一位${skillName}领域的专家。${userInput ? `用户输入：${userInput}` : '请做一次体验演示'}。请给出专业且有趣的体验结果（200-300字）。`;
            }
            const result = await this.aiService.generateContent({
                prompt, platforms: ['通用'], contentType,
            });
            return { code: 200, msg: 'success', data: { skillId, skillName, category, contentType, content: result.content } };
        }
        catch (error) {
            return { code: 500, msg: error.message || '体验失败', data: null };
        }
    }
    async getCategories() {
        try {
            if (this.skillService) {
                const categories = await this.skillService.getCategories();
                return { code: 200, msg: 'success', data: categories };
            }
        }
        catch (e) {
            console.error('[SkillController] getCategories error:', e.message);
        }
        return { code: 200, msg: 'success', data: [] };
    }
};
exports.SkillController = SkillController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('category')),
    __param(1, (0, common_1.Query)('keyword')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], SkillController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('avatar/:avatarId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SkillController.prototype, "getAvatarSkills", null);
__decorate([
    (0, common_1.Post)('avatar/:avatarId/:skillId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Param)('skillId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], SkillController.prototype, "addSkillToAvatar", null);
__decorate([
    (0, common_1.Delete)('avatar/:avatarId/:skillId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Param)('skillId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], SkillController.prototype, "removeSkillFromAvatar", null);
__decorate([
    (0, common_1.Post)('avatar/:avatarId/batch'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SkillController.prototype, "batchAddSkills", null);
__decorate([
    (0, common_1.Post)(':id/try'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SkillController.prototype, "trySkill", null);
__decorate([
    (0, common_1.Get)('categories'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SkillController.prototype, "getCategories", null);
exports.SkillController = SkillController = __decorate([
    (0, common_1.Controller)('skills'),
    __param(0, (0, common_1.Inject)(skill_service_1.SkillService)),
    __param(1, (0, common_1.Inject)(ai_service_1.AiService)),
    __metadata("design:paramtypes", [skill_service_1.SkillService,
        ai_service_1.AiService])
], SkillController);
