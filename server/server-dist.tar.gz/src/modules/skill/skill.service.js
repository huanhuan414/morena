"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SkillService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const uuid_1 = require("uuid");
const CATEGORY_NAMES = {
    content: '内容创作',
    video: '视频制作',
    audio: '音频处理',
    image: '图片生成',
    music: '音乐推荐',
    life: '生活服务',
    marketing: '营销推广',
    social: '社交互动',
    education: '教育学习',
    tool: '实用工具',
    service: '生活服务',
    growth: '成长提升',
    community: '社区互动',
    knowledge: '知识百科',
};
let SkillService = class SkillService {
    async listSkills(category, keyword) {
        const db = (0, mysql_client_1.getMySQLClient)();
        let sql = 'SELECT * FROM skills WHERE is_active = 1';
        const params = [];
        if (category && category !== 'all') {
            sql += ' AND category = ?';
            params.push(category);
        }
        if (keyword) {
            sql += ' AND (name LIKE ? OR description LIKE ?)';
            params.push(`%${keyword}%`, `%${keyword}%`);
        }
        sql += ' ORDER BY sort_order ASC, usage_count DESC';
        const rows = await db.query(sql, params);
        return rows;
    }
    async getAvatarSkills(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const rows = await db.query(`SELECT s.id as skillId, s.name as skillName, s.description, s.category, s.icon, s.rating, s.usage_count, s.price, s.tags,
              ast.level, ast.experience, ast.unlocked, ast.created_at as assignedAt
       FROM skills s 
       INNER JOIN avatar_skills ast ON s.id = ast.skill_id 
       WHERE ast.avatar_id = ? AND s.is_active = 1
       ORDER BY s.sort_order ASC`, [avatarId]);
        return rows;
    }
    async addSkillToAvatar(avatarId, skillId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const skillRows = await db.query('SELECT id FROM skills WHERE id = ? AND is_active = 1', [skillId]);
        if (!skillRows || (Array.isArray(skillRows) && skillRows.length === 0)) {
            throw new Error('技能不存在');
        }
        const existing = await db.query('SELECT id FROM avatar_skills WHERE avatar_id = ? AND skill_id = ?', [avatarId, skillId]);
        if (existing && Array.isArray(existing) && existing.length > 0) {
            return { alreadyOwned: true };
        }
        const id = (0, uuid_1.v4)();
        await db.query('INSERT INTO avatar_skills (id, avatar_id, skill_id, level, experience, unlocked) VALUES (?, ?, ?, 1, 0, 1)', [id, avatarId, skillId]);
        await db.query('UPDATE skills SET usage_count = usage_count + 1 WHERE id = ?', [skillId]);
        return { success: true };
    }
    async removeSkillFromAvatar(avatarId, skillId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        await db.query('DELETE FROM avatar_skills WHERE avatar_id = ? AND skill_id = ?', [avatarId, skillId]);
        return { success: true };
    }
    async batchAddSkills(avatarId, skillIds) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const results = [];
        for (const skillId of skillIds) {
            try {
                const skillRows = await db.query('SELECT id FROM skills WHERE id = ? AND is_active = 1', [skillId]);
                if (!skillRows || (Array.isArray(skillRows) && skillRows.length === 0)) {
                    results.push({ skillId, status: 'not_found' });
                    continue;
                }
                const existing = await db.query('SELECT id FROM avatar_skills WHERE avatar_id = ? AND skill_id = ?', [avatarId, skillId]);
                if (existing && Array.isArray(existing) && existing.length > 0) {
                    results.push({ skillId, status: 'already_owned' });
                    continue;
                }
                const id = (0, uuid_1.v4)();
                await db.query('INSERT INTO avatar_skills (id, avatar_id, skill_id, level, experience, unlocked) VALUES (?, ?, ?, 1, 0, 1)', [id, avatarId, skillId]);
                await db.query('UPDATE skills SET usage_count = usage_count + 1 WHERE id = ?', [skillId]);
                results.push({ skillId, status: 'added' });
            }
            catch (e) {
                results.push({ skillId, status: 'error', message: e.message });
            }
        }
        return results;
    }
    async getSkillById(id) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const rows = await db.query('SELECT * FROM skills WHERE id = ?', [id]);
        return rows[0] || null;
    }
    async getCategories() {
        const db = (0, mysql_client_1.getMySQLClient)();
        const rows = await db.query('SELECT category, COUNT(*) as count FROM skills WHERE is_active = 1 GROUP BY category ORDER BY count DESC');
        return (rows || []).map((row) => ({
            key: row.category,
            name: CATEGORY_NAMES[row.category] || row.category,
            count: Number(row.count),
        }));
    }
};
exports.SkillService = SkillService;
exports.SkillService = SkillService = __decorate([
    (0, common_1.Injectable)()
], SkillService);
