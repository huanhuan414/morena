"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const crypto = require("crypto");
let ChatService = class ChatService {
    async createConversation(userId, avatarId, title) {
        const db = (0, mysql_client_1.getMySQLClient)();
        if (!avatarId) {
            avatarId = 'default-avatar';
        }
        const id = crypto.randomUUID();
        await db.insert('conversations', {
            id,
            user_id: userId,
            avatar_id: avatarId,
            title: title || '新对话',
            context: JSON.stringify([]),
            updated_at: new Date(),
            created_at: new Date()
        });
        return await db.queryOne('conversations', { id });
    }
    async getConversations(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.query('conversations', { user_id: userId }, {
            orderBy: 'updated_at',
            orderDirection: 'desc'
        });
        return result?.data || [];
    }
    async getMessages(conversationId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.query('messages', { conversation_id: conversationId }, {
            orderBy: 'created_at',
            orderDirection: 'asc'
        });
        return result?.data || [];
    }
    async addMessage(conversationId, message) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const id = crypto.randomUUID();
        await db.insert('messages', {
            id,
            conversation_id: conversationId,
            role: message.role,
            content: message.content,
            metadata: message.metadata ? JSON.stringify(message.metadata) : null,
            created_at: new Date()
        });
        await db.updateWhere('conversations', { id: conversationId }, {
            updated_at: new Date()
        });
        return await db.queryOne('conversations', { id });
    }
    async deleteConversation(userId, conversationId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const conversation = await db.queryOne('conversations', {
            id: conversationId,
            user_id: userId
        });
        if (!conversation) {
            throw new Error('对话不存在或无权删除');
        }
        await (0, mysql_client_1.deleteRow)('messages', { conversation_id: conversationId });
        await (0, mysql_client_1.deleteRow)('conversations', { id: conversationId });
        return { success: true };
    }
    async updateConversationTitle(userId, conversationId, title) {
        const db = (0, mysql_client_1.getMySQLClient)();
        await db.updateWhere('conversations', { id: conversationId, user_id: userId }, {
            title,
            updated_at: new Date()
        });
        return await db.queryOne('conversations', { id: conversationId });
    }
    async clearConversation(conversationId) {
        await (0, mysql_client_1.deleteRow)('messages', { conversation_id: conversationId });
        return { success: true };
    }
};
exports.ChatService = ChatService;
exports.ChatService = ChatService = __decorate([
    (0, common_1.Injectable)()
], ChatService);
