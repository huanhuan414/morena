"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AiSkillController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const multer_1 = require("multer");
const ai_skill_service_1 = require("./ai-skill.service");
const storage_service_1 = require("../storage/storage.service");
let AiSkillController = class AiSkillController {
    constructor(aiSkillService, storageService) {
        this.aiSkillService = aiSkillService;
        this.storageService = storageService;
    }
    async generate(body, req) {
        const userId = req.headers['x-user-id'];
        if (!userId) {
            return { code: 401, msg: '请先登录', data: null };
        }
        if (!body.skillType) {
            return { code: 400, msg: '请选择技能类型', data: null };
        }
        let imageUrl = body.inputImageUrl;
        if (body.inputImageUrls && body.inputImageUrls.length > 0) {
            imageUrl = body.inputImageUrls.join(',');
        }
        console.log(`[AiSkillController] generate: userId=${userId}, skillType=${body.skillType}, hasImage=${!!imageUrl}, imageCount=${body.inputImageUrls?.length || 0}, hasText=${!!body.inputText}`);
        try {
            const limitCheck = await this.aiSkillService.checkDailyLimit(userId, body.skillType);
            if (limitCheck.remaining <= 0) {
                return { code: 429, msg: `今日使用次数已达上限（${limitCheck.limit}次/天）`, data: { remaining: 0, limit: limitCheck.limit, used: limitCheck.used } };
            }
            const result = await this.aiSkillService.startGenerate(userId, body.skillType, imageUrl, body.inputText);
            return { code: 200, msg: '已提交生成任务', data: result };
        }
        catch (error) {
            console.error('[AiSkillController] generate error:', error.message);
            return { code: 500, msg: error.message || '提交失败', data: null };
        }
    }
    async getHistory(skillType, page, pageSize, req) {
        const userId = req.headers['x-user-id'];
        if (!userId) {
            return { code: 401, msg: '请先登录', data: null };
        }
        const result = await this.aiSkillService.getHistory(userId, skillType || undefined, page ? parseInt(page) : 1, pageSize ? parseInt(pageSize) : 20);
        return { code: 200, msg: 'ok', data: result };
    }
    async getUsageLimit(skillType, req) {
        const userId = req.headers['x-user-id'];
        if (!userId) {
            return { code: 401, msg: '请先登录', data: null };
        }
        if (skillType) {
            const result = await this.aiSkillService.checkDailyLimit(userId, skillType);
            return { code: 200, msg: 'ok', data: result };
        }
        const allLimits = await this.aiSkillService.getAllUsageLimits(userId);
        return { code: 200, msg: 'ok', data: allLimits };
    }
    async getRecord(id, req) {
        const userId = req.headers['x-user-id'];
        if (!userId) {
            return { code: 401, msg: '请先登录', data: null };
        }
        const record = await this.aiSkillService.getRecord(userId, id);
        if (!record) {
            return { code: 404, msg: '记录不存在', data: null };
        }
        return { code: 200, msg: 'ok', data: record };
    }
    async uploadImage(file) {
        if (!file) {
            return { code: 400, msg: '请选择图片', data: null };
        }
        console.log('[AiSkill] 上传图片:', file.originalname, file.mimetype, file.size, 'bytes');
        const imageUrl = await this.storageService.uploadImage(file);
        console.log('[AiSkill] 图片URL:', imageUrl);
        return { code: 200, msg: 'ok', data: { imageUrl } };
    }
    async deleteRecord(id, req) {
        const userId = req.headers['x-user-id'];
        if (!userId) {
            return { code: 401, msg: '请先登录', data: null };
        }
        try {
            const result = await this.aiSkillService.deleteRecords(userId, [id]);
            return { code: 200, msg: '删除成功', data: result };
        }
        catch (error) {
            return { code: 400, msg: error.message || '删除失败', data: null };
        }
    }
    async deleteRecords(body, req) {
        const userId = req.headers['x-user-id'];
        if (!userId) {
            return { code: 401, msg: '请先登录', data: null };
        }
        if (!body.ids || !Array.isArray(body.ids) || body.ids.length === 0) {
            return { code: 400, msg: '请选择要删除的记录', data: null };
        }
        try {
            const result = await this.aiSkillService.deleteRecords(userId, body.ids);
            return { code: 200, msg: '删除成功', data: result };
        }
        catch (error) {
            return { code: 400, msg: error.message || '删除失败', data: null };
        }
    }
};
exports.AiSkillController = AiSkillController;
__decorate([
    (0, common_1.Post)('generate'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AiSkillController.prototype, "generate", null);
__decorate([
    (0, common_1.Get)('history'),
    __param(0, (0, common_1.Query)('skillType')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('pageSize')),
    __param(3, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", Promise)
], AiSkillController.prototype, "getHistory", null);
__decorate([
    (0, common_1.Get)('usage-limit'),
    __param(0, (0, common_1.Query)('skillType')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AiSkillController.prototype, "getUsageLimit", null);
__decorate([
    (0, common_1.Get)('record/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AiSkillController.prototype, "getRecord", null);
__decorate([
    (0, common_1.Post)('upload'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { storage: (0, multer_1.memoryStorage)(), limits: { fileSize: 10 * 1024 * 1024 } })),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AiSkillController.prototype, "uploadImage", null);
__decorate([
    (0, common_1.Delete)('record/:id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AiSkillController.prototype, "deleteRecord", null);
__decorate([
    (0, common_1.Post)('records/delete'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AiSkillController.prototype, "deleteRecords", null);
exports.AiSkillController = AiSkillController = __decorate([
    (0, common_1.Controller)('ai-skill'),
    __param(0, (0, common_1.Inject)(ai_skill_service_1.AiSkillService)),
    __param(1, (0, common_1.Inject)(storage_service_1.StorageService)),
    __metadata("design:paramtypes", [ai_skill_service_1.AiSkillService,
        storage_service_1.StorageService])
], AiSkillController);
