"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AiSkillModule = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const multer_1 = require("multer");
const ai_skill_controller_1 = require("./ai-skill.controller");
const ai_skill_service_1 = require("./ai-skill.service");
const volcengine_service_1 = require("../upload/volcengine.service");
const storage_service_1 = require("../storage/storage.service");
let AiSkillModule = class AiSkillModule {
};
exports.AiSkillModule = AiSkillModule;
exports.AiSkillModule = AiSkillModule = __decorate([
    (0, common_1.Module)({
        imports: [
            platform_express_1.MulterModule.register({
                storage: (0, multer_1.memoryStorage)(),
                limits: { fileSize: 10 * 1024 * 1024 },
            }),
        ],
        controllers: [ai_skill_controller_1.AiSkillController],
        providers: [ai_skill_service_1.AiSkillService, volcengine_service_1.VolcengineService, storage_service_1.StorageService],
        exports: [ai_skill_service_1.AiSkillService],
    })
], AiSkillModule);
