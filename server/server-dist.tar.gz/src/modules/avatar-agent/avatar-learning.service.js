"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarLearningService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
let AvatarLearningService = class AvatarLearningService {
    async learnFromInteraction(avatarId, interactionData) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.insert('avatar_learning', {
            avatar_id: avatarId,
            interaction_type: interactionData.type || 'general',
            content: interactionData.content || '',
            learned_patterns: JSON.stringify(interactionData.patterns || {}),
            created_at: new Date()
        });
        return { success: result.affectedRows > 0 };
    }
    async getLearnedPatterns(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.select('avatar_learning', { avatar_id: avatarId });
        return result.data?.map((item) => ({
            type: item.interaction_type,
            content: item.content,
            patterns: JSON.parse(item.learned_patterns || '{}')
        })) || [];
    }
    async learnFromResult(avatarId, resultData) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.insert('avatar_learning', {
            avatar_id: avatarId,
            interaction_type: 'result_feedback',
            content: JSON.stringify(resultData),
            learned_patterns: '{}',
            created_at: new Date()
        });
        return { success: result.affectedRows > 0 };
    }
    async updateSkillLevel(avatarId, skillId, level) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.updateWhere('avatar_skills', { id: skillId, avatar_id: avatarId }, {
            level,
            updated_at: new Date()
        });
        return { success: result.affectedRows > 0 };
    }
};
exports.AvatarLearningService = AvatarLearningService;
exports.AvatarLearningService = AvatarLearningService = __decorate([
    (0, common_1.Injectable)()
], AvatarLearningService);
