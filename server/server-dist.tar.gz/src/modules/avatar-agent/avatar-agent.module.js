"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarAgentModule = void 0;
const common_1 = require("@nestjs/common");
const avatar_agent_controller_1 = require("./avatar-agent.controller");
const avatar_agent_service_1 = require("./avatar-agent.service");
const avatar_memory_service_1 = require("./avatar-memory.service");
const avatar_learning_service_1 = require("./avatar-learning.service");
const tool_registry_1 = require("./tools/tool-registry");
const content_tools_1 = require("./tools/content-tools");
const content_creation_tools_1 = require("./tools/content-creation-tools");
const content_generation_tools_1 = require("./tools/content-generation-tools");
const platform_publish_tools_1 = require("./tools/platform-publish-tools");
const data_tools_1 = require("./tools/data-tools");
const social_tools_1 = require("./tools/social-tools");
const task_tools_1 = require("./tools/task-tools");
const user_management_tools_1 = require("./tools/user-management-tools");
const avatar_management_tools_1 = require("./tools/avatar-management-tools");
let AvatarAgentModule = class AvatarAgentModule {
};
exports.AvatarAgentModule = AvatarAgentModule;
exports.AvatarAgentModule = AvatarAgentModule = __decorate([
    (0, common_1.Module)({
        controllers: [avatar_agent_controller_1.AvatarAgentController],
        providers: [
            avatar_agent_service_1.AvatarAgentService,
            avatar_memory_service_1.AvatarMemoryService,
            avatar_learning_service_1.AvatarLearningService,
            tool_registry_1.AvatarToolRegistry,
            content_tools_1.WriteArticleTool,
            content_tools_1.GenerateImageTool,
            content_tools_1.SummarizeTool,
            content_creation_tools_1.WriteWechatMpArticleTool,
            content_creation_tools_1.WriteXiaohongshuNoteTool,
            content_creation_tools_1.WriteWechatMomentsTool,
            content_generation_tools_1.GenerateImageTool,
            content_generation_tools_1.GenerateVideoTool,
            platform_publish_tools_1.PublishWechatMpTool,
            data_tools_1.QueryUserProfileTool,
            data_tools_1.QueryOrdersTool,
            social_tools_1.AvatarSendMessageTool,
            social_tools_1.AvatarCreateMomentTool,
            task_tools_1.CreateTaskTool,
            task_tools_1.UpdateTaskTool,
            task_tools_1.QueryTasksTool,
            user_management_tools_1.ChangePasswordTool,
            avatar_management_tools_1.QueryAvatarFriendsTool,
            avatar_management_tools_1.AddAvatarFriendTool,
            avatar_management_tools_1.RemoveAvatarFriendTool,
        ],
        exports: [avatar_agent_service_1.AvatarAgentService]
    })
], AvatarAgentModule);
