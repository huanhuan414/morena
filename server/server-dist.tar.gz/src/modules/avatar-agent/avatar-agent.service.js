"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AvatarAgentService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarAgentService = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const mysql_client_1 = require("../../storage/database/mysql-client");
const avatar_memory_service_1 = require("./avatar-memory.service");
const avatar_learning_service_1 = require("./avatar-learning.service");
const tool_registry_1 = require("./tools/tool-registry");
let AvatarAgentService = AvatarAgentService_1 = class AvatarAgentService {
    constructor(memoryService, learningService, toolRegistry) {
        this.memoryService = memoryService;
        this.learningService = learningService;
        this.toolRegistry = toolRegistry;
        this.logger = new common_1.Logger(AvatarAgentService_1.name);
        const config = new coze_coding_dev_sdk_1.Config();
        this.llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
    }
    async think(avatarId, userMessage, context) {
        try {
            const config = await this.loadAvatarConfig(avatarId);
            const relevantMemories = await this.memoryService.retrieveRelevantMemories(avatarId, userMessage, 10);
            const reasoningContext = await this.buildReasoningContext(avatarId, userMessage, context, relevantMemories, config);
            const thought = await this.executeReasoning(avatarId, reasoningContext, config);
            await this.memoryService.storeThought(avatarId, thought);
            return thought;
        }
        catch (error) {
            this.logger.error('Error in think method:', error);
            return {
                id: `thought-${Date.now()}`,
                avatarId,
                content: '推理过程中发生错误',
                intent: {
                    type: 'error',
                    confidence: 0
                },
                requiresTool: false,
                createdAt: new Date().toISOString()
            };
        }
    }
    async loadAvatarConfig(avatarId) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const agentConfig = await db.queryOne('avatar_agent_configs', { avatar_id: avatarId });
            const avatar = await db.queryOne('avatars', { id: avatarId });
            if (!agentConfig?.data) {
                return this.getDefaultConfig(avatarId, avatar?.data);
            }
            return {
                id: agentConfig.data.id,
                avatarId: agentConfig.data.avatar_id,
                name: avatar?.data?.name || '分身',
                personality: avatar?.data?.personality || '友好开朗',
                memoryConfig: agentConfig.data.memory_config ? JSON.parse(agentConfig.data.memory_config) : {},
                toolConfig: agentConfig.data.tool_config ? JSON.parse(agentConfig.data.tool_config) : {}
            };
        }
        catch (error) {
            this.logger.error('Error loading avatar config:', error);
            return this.getDefaultConfig(avatarId, null);
        }
    }
    getDefaultConfig(avatarId, avatar) {
        return {
            id: `default-${avatarId}`,
            avatarId,
            name: avatar?.name || '分身',
            personality: avatar?.personality || '友好开朗',
            memoryConfig: {
                maxMemories: 100,
                relevanceThreshold: 0.7
            },
            toolConfig: {}
        };
    }
    async buildReasoningContext(avatarId, userMessage, context, relevantMemories, config) {
        const memoryContext = relevantMemories.length > 0
            ? `\n相关记忆:\n${relevantMemories.map(m => `- ${m.content}`).join('\n')}`
            : '';
        const historyContext = context?.history
            ? `\n对话历史:\n${context.history.map((h) => `${h.role}: ${h.content}`).join('\n')}`
            : '';
        return `
你是${config.name}，一个AI分身。
性格: ${config.personality}
${memoryContext}
${historyContext}
用户: ${userMessage}
`.trim();
    }
    async executeReasoning(avatarId, reasoningContext, config) {
        try {
            const response = await this.llmClient.invoke([
                { role: 'system', content: '你是一个智能AI分身。请分析用户消息并给出回应。' },
                { role: 'user', content: reasoningContext }
            ], {
                model: 'doubao-seed-1-8-251228',
                temperature: 0.8
            });
            return {
                id: `thought-${Date.now()}`,
                avatarId,
                content: response.content,
                intent: {
                    type: 'chat',
                    confidence: 0.9
                },
                requiresTool: false,
                createdAt: new Date().toISOString()
            };
        }
        catch (error) {
            this.logger.error('Error executing reasoning:', error);
            return {
                id: `thought-${Date.now()}`,
                avatarId,
                content: '抱歉，我遇到了一些问题。',
                intent: {
                    type: 'error',
                    confidence: 0
                },
                requiresTool: false,
                createdAt: new Date().toISOString()
            };
        }
    }
    async generateResponse(avatarId, thought, actionResult) {
        let content = thought.content;
        if (actionResult?.data) {
            content = `已完成操作: ${JSON.stringify(actionResult.data)}`;
        }
        return {
            content,
            metadata: {
                thought,
                confidence: thought.intent.confidence
            }
        };
    }
    async chat(avatarId, userId, message, conversationHistory) {
        try {
            const thought = await this.think(avatarId, message, {
                userId,
                history: conversationHistory
            });
            let response;
            if (thought.requiresTool && thought.intent.toolName) {
                const actionResult = await this.act(avatarId, thought, {
                    userId,
                    history: conversationHistory
                });
                response = await this.generateResponse(avatarId, thought, actionResult);
                if (actionResult.success) {
                    await this.learningService.learnFromResult(avatarId, thought, actionResult);
                }
            }
            else {
                response = await this.generateResponse(avatarId, thought);
                await this.learningService.learnFromResult(avatarId, thought, {
                    success: true,
                    toolName: 'none',
                    data: { message: response.content }
                });
            }
            await this.memoryService.storeConversation(avatarId, userId, {
                userMessage: message,
                assistantResponse: response.content,
                thought
            });
            await this.learningService.updateSkillLevel(avatarId, thought, response);
            return response;
        }
        catch (error) {
            this.logger.error('Error in chat method:', error);
            return {
                content: '抱歉，我遇到了一些问题，请稍后再试。',
                metadata: {
                    thought: {
                        id: 'error',
                        avatarId,
                        content: '',
                        intent: { type: 'error', confidence: 0 },
                        requiresTool: false,
                        createdAt: new Date().toISOString()
                    },
                    confidence: 0
                }
            };
        }
    }
    async act(avatarId, thought, context) {
        try {
            if (!thought.requiresTool || !thought.intent.toolName) {
                return {
                    success: true,
                    toolName: 'none',
                    data: { message: '无需执行工具' }
                };
            }
            const toolName = thought.intent.toolName;
            const params = thought.intent.params || {};
            this.logger.log(`Executing tool ${toolName} for avatar ${avatarId}`);
            return {
                success: true,
                toolName,
                data: { message: '工具执行成功' }
            };
        }
        catch (error) {
            this.logger.error('Error in act method:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
};
exports.AvatarAgentService = AvatarAgentService;
exports.AvatarAgentService = AvatarAgentService = AvatarAgentService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(avatar_memory_service_1.AvatarMemoryService)),
    __param(1, (0, common_1.Inject)((0, common_1.forwardRef)(() => avatar_learning_service_1.AvatarLearningService))),
    __param(2, (0, common_1.Inject)(tool_registry_1.AvatarToolRegistry)),
    __metadata("design:paramtypes", [avatar_memory_service_1.AvatarMemoryService,
        avatar_learning_service_1.AvatarLearningService,
        tool_registry_1.AvatarToolRegistry])
], AvatarAgentService);
