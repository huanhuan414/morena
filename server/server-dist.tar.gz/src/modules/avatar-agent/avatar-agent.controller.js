"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarAgentController = void 0;
const common_1 = require("@nestjs/common");
const avatar_agent_service_1 = require("./avatar-agent.service");
const avatar_memory_service_1 = require("./avatar-memory.service");
const avatar_learning_service_1 = require("./avatar-learning.service");
const mysql_client_1 = require("../../storage/database/mysql-client");
let AvatarAgentController = class AvatarAgentController {
    constructor(agentService, memoryService, learningService) {
        this.agentService = agentService;
        this.memoryService = memoryService;
        this.learningService = learningService;
    }
    async chat(avatarId, userId, body) {
        try {
            const response = await this.agentService.chat(avatarId, userId, body.message, body.conversationHistory);
            return {
                code: 200,
                data: response,
                message: '成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '对话失败'
            };
        }
    }
    async think(avatarId, body) {
        try {
            const thought = await this.agentService.think(avatarId, body.message, {
                userId: body.userId,
                conversationId: body.conversationId,
                history: body.conversationHistory
            });
            return {
                code: 200,
                data: thought,
                message: '推理成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '推理失败'
            };
        }
    }
    async getConfig(avatarId) {
        try {
            const config = await this.agentService['loadAvatarConfig'](avatarId);
            return {
                code: 200,
                data: config,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '获取配置失败'
            };
        }
    }
    async updateConfig(avatarId, body) {
        try {
            await this.agentService.updateAvatarConfig(avatarId, body);
            return {
                code: 200,
                data: null,
                message: '配置更新成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '配置更新失败'
            };
        }
    }
    async initializeConfig(avatarId, body) {
        try {
            await this.agentService.initializeAvatarConfig(avatarId, body);
            return {
                code: 200,
                data: null,
                message: '配置初始化成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '配置初始化失败'
            };
        }
    }
    async getMemories(avatarId, type, limit, userId) {
        try {
            const memories = await this.memoryService.retrieveRelevantMemories(avatarId, '', {
                maxRetrieval: limit ? parseInt(limit) : 10,
                allowedTypes: type ? [type] : undefined
            });
            return {
                code: 200,
                data: {
                    memories,
                    count: memories.length
                },
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '获取记忆失败'
            };
        }
    }
    async getUserPreferences(avatarId, userId) {
        try {
            const preferences = await this.memoryService.getUserPreferences(avatarId, userId);
            return {
                code: 200,
                data: preferences,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '获取用户偏好失败'
            };
        }
    }
    async getExperiences(avatarId, taskType, limit) {
        try {
            const experiences = await this.memoryService.getAvatarExperiences(avatarId, {
                taskType,
                limit: limit ? parseInt(limit) : 10
            });
            return {
                code: 200,
                data: experiences,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '获取经验失败'
            };
        }
    }
    async recordFeedback(avatarId, userId, body) {
        try {
            await this.learningService.recordFeedback(avatarId, userId, body.messageId, body.feedbackScore, body.feedbackText);
            return {
                code: 200,
                data: null,
                message: '反馈记录成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '反馈记录失败'
            };
        }
    }
    async getLearningStats(avatarId) {
        try {
            const stats = await this.learningService.getLearningStats(avatarId);
            return {
                code: 200,
                data: stats,
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '获取学习统计失败'
            };
        }
    }
    async getCapabilities(avatarId) {
        try {
            const memories = await this.memoryService.retrieveRelevantMemories(avatarId, '', { maxRetrieval: 50 });
            const memoryByType = memories.reduce((acc, m) => {
                acc[m.type] = (acc[m.type] || 0) + 1;
                return acc;
            }, {});
            const skillsResult = await (0, mysql_client_1.getMySQLClient)().query('avatar_skills', undefined, {
                conditions: { avatar_id: avatarId },
                orderBy: 'skill_level',
                ascending: false,
                limit: 10
            });
            const skills = skillsResult?.data || [];
            const learningStats = await this.learningService.getLearningStats(avatarId);
            const memoriesResult = await (0, mysql_client_1.getMySQLClient)().query('avatar_memories', undefined, {
                columns: 'id, content, metadata, created_at',
                conditions: { avatar_id: avatarId, memory_type: 'learning' },
                orderBy: 'created_at',
                ascending: false,
                limit: 5
            });
            const recentThoughts = memoriesResult?.data || [];
            const formattedThoughts = recentThoughts?.map((thought) => ({
                id: thought.id,
                action: thought.content || '思考中...',
                intent: thought.metadata?.intent?.type || 'unknown',
                createdAt: thought.created_at
            })) || [];
            return {
                code: 200,
                data: {
                    memory: {
                        total: memories.length,
                        byType: memoryByType,
                        recentMemories: memories.slice(0, 5)
                    },
                    skills: skills || [],
                    learning: learningStats,
                    thoughts: formattedThoughts
                },
                message: '获取成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '获取能力概览失败'
            };
        }
    }
    async knowledgeDistillation(avatarId, sourceAvatarId) {
        try {
            await this.learningService.knowledgeDistillation(sourceAvatarId, avatarId);
            return {
                code: 200,
                data: null,
                message: '知识蒸馏成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '知识蒸馏失败'
            };
        }
    }
    async personalize(avatarId, userId, body) {
        try {
            await this.learningService.personalize(avatarId, userId, body.interactions);
            return {
                code: 200,
                data: null,
                message: '个性化学习成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '个性化学习失败'
            };
        }
    }
};
exports.AvatarAgentController = AvatarAgentController;
__decorate([
    (0, common_1.Post)(':avatarId/chat'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AvatarAgentController.prototype, "chat", null);
__decorate([
    (0, common_1.Post)(':avatarId/think'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarAgentController.prototype, "think", null);
__decorate([
    (0, common_1.Get)(':avatarId/config'),
    __param(0, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarAgentController.prototype, "getConfig", null);
__decorate([
    (0, common_1.Put)(':avatarId/config'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarAgentController.prototype, "updateConfig", null);
__decorate([
    (0, common_1.Post)(':avatarId/initialize'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarAgentController.prototype, "initializeConfig", null);
__decorate([
    (0, common_1.Get)(':avatarId/memories'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Query)('type')),
    __param(2, (0, common_1.Query)('limit')),
    __param(3, (0, common_1.Query)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], AvatarAgentController.prototype, "getMemories", null);
__decorate([
    (0, common_1.Get)(':avatarId/preferences/:userId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Param)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AvatarAgentController.prototype, "getUserPreferences", null);
__decorate([
    (0, common_1.Get)(':avatarId/experiences'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Query)('taskType')),
    __param(2, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], AvatarAgentController.prototype, "getExperiences", null);
__decorate([
    (0, common_1.Post)(':avatarId/feedback'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AvatarAgentController.prototype, "recordFeedback", null);
__decorate([
    (0, common_1.Get)(':avatarId/learning-stats'),
    __param(0, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarAgentController.prototype, "getLearningStats", null);
__decorate([
    (0, common_1.Get)(':avatarId/capabilities'),
    __param(0, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarAgentController.prototype, "getCapabilities", null);
__decorate([
    (0, common_1.Post)(':avatarId/distill/:sourceAvatarId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Param)('sourceAvatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AvatarAgentController.prototype, "knowledgeDistillation", null);
__decorate([
    (0, common_1.Post)(':avatarId/personalize/:userId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Param)('userId')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AvatarAgentController.prototype, "personalize", null);
exports.AvatarAgentController = AvatarAgentController = __decorate([
    (0, common_1.Controller)('avatar-agent'),
    __param(0, (0, common_1.Inject)(avatar_agent_service_1.AvatarAgentService)),
    __param(1, (0, common_1.Inject)(avatar_memory_service_1.AvatarMemoryService)),
    __param(2, (0, common_1.Inject)(avatar_learning_service_1.AvatarLearningService)),
    __metadata("design:paramtypes", [avatar_agent_service_1.AvatarAgentService,
        avatar_memory_service_1.AvatarMemoryService,
        avatar_learning_service_1.AvatarLearningService])
], AvatarAgentController);
