"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishWechatMpTool = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../../storage/database/mysql-client");
let PublishWechatMpTool = class PublishWechatMpTool {
    constructor() {
        this.name = 'publish_wechat_mp';
        this.displayName = '发布公众号文章';
        this.description = '发布文章到微信公众号素材库';
        this.category = 'platform_publish';
        this.paramsSchema = {
            title: { type: 'string', description: '文章标题', required: true },
            content: { type: 'string', description: '文章内容', required: true },
            cover_url: { type: 'string', description: '封面图片URL' }
        };
    }
    async execute(params, context) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const configs = await db.query('platform_configs', { user_id: context.userId, platform_type: 'wechat_mp' });
            if (!configs?.data || configs.data.length === 0) {
                return { success: false, toolName: this.name, error: '未配置微信公众号', requires_config: true };
            }
            const config = configs.data[0];
            const appId = config.config?.app_id;
            const appSecret = config.config?.app_secret;
            if (!appId || !appSecret) {
                return { success: false, toolName: this.name, error: '微信公众号配置不完整' };
            }
            const tokenRes = await fetch(`https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${appId}&secret=${appSecret}`);
            const tokenData = await tokenRes.json();
            if (tokenData.errcode) {
                return { success: false, toolName: this.name, error: `微信API错误: ${tokenData.errmsg}` };
            }
            const htmlContent = params.content.replace(/\n/g, '<br/>');
            const draftData = {
                articles: [{
                        title: params.title,
                        content: htmlContent,
                        thumb_media_id: ''
                    }]
            };
            const draftRes = await fetch(`https://api.weixin.qq.com/cgi-bin/draft/add?access_token=${tokenData.access_token}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(draftData)
            });
            const result = await draftRes.json();
            if (result.errcode) {
                return { success: false, toolName: this.name, error: `创建草稿失败: ${result.errmsg}` };
            }
            return { success: true, toolName: this.name, data: { media_id: result.media_id } };
        }
        catch (error) {
            return { success: false, toolName: this.name, error: error.message };
        }
    }
};
exports.PublishWechatMpTool = PublishWechatMpTool;
exports.PublishWechatMpTool = PublishWechatMpTool = __decorate([
    (0, common_1.Injectable)()
], PublishWechatMpTool);
