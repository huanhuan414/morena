"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarCreateMomentTool = exports.AvatarSendMessageTool = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../../storage/database/mysql-client");
const crypto = require("crypto");
let AvatarSendMessageTool = class AvatarSendMessageTool {
    constructor() {
        this.name = 'avatar_send_message';
        this.displayName = '发送消息';
        this.description = '向指定用户发送消息';
        this.category = 'social';
        this.paramsSchema = {
            toUserId: { type: 'string', description: '接收者用户ID', required: true },
            content: { type: 'string', description: '消息内容', required: true },
            messageType: { type: 'string', description: '消息类型：text, image, audio, video', default: 'text' }
        };
    }
    async execute(params, context) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const id = crypto.randomUUID();
            await db.insert('notifications', {
                id,
                user_id: params.toUserId,
                avatar_id: context.avatarId,
                type: params.messageType || 'text',
                title: 'AI分身消息',
                content: params.content,
                is_read: 0,
                created_at: new Date()
            });
            return {
                success: true,
                toolName: this.name,
                data: { messageId: id, result: '消息已发送' }
            };
        }
        catch (error) {
            return { success: false, toolName: this.name, error: error.message };
        }
    }
};
exports.AvatarSendMessageTool = AvatarSendMessageTool;
exports.AvatarSendMessageTool = AvatarSendMessageTool = __decorate([
    (0, common_1.Injectable)()
], AvatarSendMessageTool);
let AvatarCreateMomentTool = class AvatarCreateMomentTool {
    constructor() {
        this.name = 'avatar_create_moment';
        this.displayName = '发布朋友圈';
        this.description = '创建朋友圈动态';
        this.category = 'social';
        this.paramsSchema = {
            content: { type: 'string', description: '动态内容', required: true },
            images: { type: 'array', description: '图片列表' }
        };
    }
    async execute(params, context) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const id = crypto.randomUUID();
            await db.insert('posts', {
                id,
                user_id: context.userId,
                avatar_id: context.avatarId,
                content: params.content,
                images: Array.isArray(params.images) ? params.images.join(',') : '',
                likes_count: 0,
                comments_count: 0,
                shares_count: 0,
                created_at: new Date()
            });
            return { success: true, toolName: this.name, data: { postId: id, result: '动态已发布' } };
        }
        catch (error) {
            return { success: false, toolName: this.name, error: error.message };
        }
    }
};
exports.AvatarCreateMomentTool = AvatarCreateMomentTool;
exports.AvatarCreateMomentTool = AvatarCreateMomentTool = __decorate([
    (0, common_1.Injectable)()
], AvatarCreateMomentTool);
