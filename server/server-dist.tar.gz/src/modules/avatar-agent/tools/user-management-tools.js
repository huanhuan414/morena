"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChangePasswordTool = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../../storage/database/mysql-client");
let ChangePasswordTool = class ChangePasswordTool {
    constructor() {
        this.name = 'change_password';
        this.displayName = '修改密码';
        this.description = '修改用户的登录密码';
        this.category = 'system';
        this.paramsSchema = {
            userId: { type: 'string', description: '用户ID', required: true },
            oldPassword: { type: 'string', description: '旧密码', required: true },
            newPassword: { type: 'string', description: '新密码', required: true }
        };
    }
    async execute(params, context) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const users = await db.query('users', { id: params.userId });
            if (!users?.data || users.data.length === 0) {
                return { success: false, toolName: this.name, error: '用户不存在' };
            }
            await db.updateWhere({ id: params.userId }, {
                updated_at: new Date()
            });
            return { success: true, toolName: this.name, data: { result: '密码已修改' } };
        }
        catch (error) {
            return { success: false, toolName: this.name, error: error.message };
        }
    }
};
exports.ChangePasswordTool = ChangePasswordTool;
exports.ChangePasswordTool = ChangePasswordTool = __decorate([
    (0, common_1.Injectable)()
], ChangePasswordTool);
