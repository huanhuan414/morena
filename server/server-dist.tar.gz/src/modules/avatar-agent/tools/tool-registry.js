"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AvatarToolRegistry_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarToolRegistry = void 0;
const common_1 = require("@nestjs/common");
const content_tools_1 = require("./content-tools");
const content_creation_tools_1 = require("./content-creation-tools");
const content_generation_tools_1 = require("./content-generation-tools");
const platform_publish_tools_1 = require("./platform-publish-tools");
const data_tools_1 = require("./data-tools");
const social_tools_1 = require("./social-tools");
const task_tools_1 = require("./task-tools");
const user_management_tools_1 = require("./user-management-tools");
const avatar_management_tools_1 = require("./avatar-management-tools");
let AvatarToolRegistry = AvatarToolRegistry_1 = class AvatarToolRegistry {
    constructor(writeArticleTool, generateImageTool, summarizeTool, writeWechatMpArticleTool, writeXiaohongshuNoteTool, writeWechatMomentsTool, contentGenerateImageTool, generateVideoTool, publishWechatMpTool, queryUserProfileTool, queryOrdersTool, sendMessageTool, createMomentTool, createTaskTool, updateTaskTool, queryTasksTool, changePasswordTool, queryAvatarFriendsTool, addAvatarFriendTool, removeAvatarFriendTool) {
        this.writeArticleTool = writeArticleTool;
        this.generateImageTool = generateImageTool;
        this.summarizeTool = summarizeTool;
        this.writeWechatMpArticleTool = writeWechatMpArticleTool;
        this.writeXiaohongshuNoteTool = writeXiaohongshuNoteTool;
        this.writeWechatMomentsTool = writeWechatMomentsTool;
        this.contentGenerateImageTool = contentGenerateImageTool;
        this.generateVideoTool = generateVideoTool;
        this.publishWechatMpTool = publishWechatMpTool;
        this.queryUserProfileTool = queryUserProfileTool;
        this.queryOrdersTool = queryOrdersTool;
        this.sendMessageTool = sendMessageTool;
        this.createMomentTool = createMomentTool;
        this.createTaskTool = createTaskTool;
        this.updateTaskTool = updateTaskTool;
        this.queryTasksTool = queryTasksTool;
        this.changePasswordTool = changePasswordTool;
        this.queryAvatarFriendsTool = queryAvatarFriendsTool;
        this.addAvatarFriendTool = addAvatarFriendTool;
        this.removeAvatarFriendTool = removeAvatarFriendTool;
        this.logger = new common_1.Logger(AvatarToolRegistry_1.name);
        this.tools = new Map();
        this.registerAllTools();
    }
    registerAllTools() {
        this.registerTool(this.writeArticleTool, 'WriteArticleTool');
        this.registerTool(this.generateImageTool, 'GenerateImageTool');
        this.registerTool(this.summarizeTool, 'SummarizeTool');
        this.registerTool(this.writeWechatMpArticleTool, 'WriteWechatMpArticleTool');
        this.registerTool(this.writeXiaohongshuNoteTool, 'WriteXiaohongshuNoteTool');
        this.registerTool(this.writeWechatMomentsTool, 'WriteWechatMomentsTool');
        this.registerTool(this.contentGenerateImageTool, 'ContentGenerateImageTool');
        this.registerTool(this.generateVideoTool, 'GenerateVideoTool');
        this.registerTool(this.publishWechatMpTool, 'PublishWechatMpTool');
        this.registerTool(this.queryUserProfileTool, 'QueryUserProfileTool');
        this.registerTool(this.queryOrdersTool, 'QueryOrdersTool');
        this.registerTool(this.sendMessageTool, 'AvatarSendMessageTool');
        this.registerTool(this.createMomentTool, 'AvatarCreateMomentTool');
        this.registerTool(this.createTaskTool, 'CreateTaskTool');
        this.registerTool(this.updateTaskTool, 'UpdateTaskTool');
        this.registerTool(this.queryTasksTool, 'QueryTasksTool');
        this.registerTool(this.changePasswordTool, 'ChangePasswordTool');
        this.registerTool(this.queryAvatarFriendsTool, 'QueryAvatarFriendsTool');
        this.registerTool(this.addAvatarFriendTool, 'AddAvatarFriendTool');
        this.registerTool(this.removeAvatarFriendTool, 'RemoveAvatarFriendTool');
        this.logger.log(`已注册 ${this.tools.size} 个工具`);
    }
    registerTool(tool, toolName = 'unknown') {
        if (!tool) {
            this.logger.warn(`工具 ${toolName} 未定义或未注入，跳过注册`);
            return;
        }
        if (this.tools.has(tool.name)) {
            this.logger.warn(`工具 ${tool.name} 已存在，将被覆盖`);
        }
        this.tools.set(tool.name, tool);
    }
    getAllTools() {
        return Array.from(this.tools.values());
    }
    getTool(name) {
        return this.tools.get(name);
    }
    async executeTool(name, params, context) {
        const tool = this.tools.get(name);
        if (!tool) {
            return { success: false, error: `工具 ${name} 不存在` };
        }
        try {
            return await tool.execute(params, context);
        }
        catch (error) {
            this.logger.error(`执行工具 ${name} 失败`, error);
            return { success: false, error: error.message };
        }
    }
    getToolsByCategory(category) {
        return this.getAllTools().filter(tool => tool.category === category);
    }
    getToolSchema(name) {
        const tool = this.tools.get(name);
        if (!tool)
            return null;
        return {
            name: tool.name,
            displayName: tool.displayName,
            description: tool.description,
            params: tool.paramsSchema
        };
    }
};
exports.AvatarToolRegistry = AvatarToolRegistry;
exports.AvatarToolRegistry = AvatarToolRegistry = AvatarToolRegistry_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [content_tools_1.WriteArticleTool,
        content_tools_1.GenerateImageTool,
        content_tools_1.SummarizeTool,
        content_creation_tools_1.WriteWechatMpArticleTool,
        content_creation_tools_1.WriteXiaohongshuNoteTool,
        content_creation_tools_1.WriteWechatMomentsTool,
        content_generation_tools_1.GenerateImageTool,
        content_generation_tools_1.GenerateVideoTool,
        platform_publish_tools_1.PublishWechatMpTool,
        data_tools_1.QueryUserProfileTool,
        data_tools_1.QueryOrdersTool,
        social_tools_1.AvatarSendMessageTool,
        social_tools_1.AvatarCreateMomentTool,
        task_tools_1.CreateTaskTool,
        task_tools_1.UpdateTaskTool,
        task_tools_1.QueryTasksTool,
        user_management_tools_1.ChangePasswordTool,
        avatar_management_tools_1.QueryAvatarFriendsTool,
        avatar_management_tools_1.AddAvatarFriendTool,
        avatar_management_tools_1.RemoveAvatarFriendTool])
], AvatarToolRegistry);
