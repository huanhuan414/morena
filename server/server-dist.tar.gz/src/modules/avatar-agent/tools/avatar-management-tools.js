"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RemoveAvatarFriendTool = exports.AddAvatarFriendTool = exports.QueryAvatarFriendsTool = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../../storage/database/mysql-client");
const crypto = require("crypto");
let QueryAvatarFriendsTool = class QueryAvatarFriendsTool {
    constructor() {
        this.name = 'query_avatar_friends';
        this.displayName = '查询分身好友';
        this.description = '查询指定分身的好友列表';
        this.category = 'data';
        this.paramsSchema = {
            avatarId: { type: 'string', description: '分身ID', required: true },
            status: { type: 'string', description: '好友状态', default: 'active' }
        };
    }
    async execute(params, context) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const friendships = await db.query('avatar_friends', {
                avatar_id: params.avatarId,
                status: params.status || 'active'
            });
            const friends = (friendships?.data || []).map((f) => ({
                id: f.friend_avatar_id,
                friendshipId: f.id,
                matchReason: f.match_reason,
                compatibilityScore: f.compatibility_score
            }));
            return { success: true, toolName: this.name, data: { friends, total: friends.length } };
        }
        catch (error) {
            return { success: false, toolName: this.name, error: error.message };
        }
    }
};
exports.QueryAvatarFriendsTool = QueryAvatarFriendsTool;
exports.QueryAvatarFriendsTool = QueryAvatarFriendsTool = __decorate([
    (0, common_1.Injectable)()
], QueryAvatarFriendsTool);
let AddAvatarFriendTool = class AddAvatarFriendTool {
    constructor() {
        this.name = 'add_avatar_friend';
        this.displayName = '添加分身好友';
        this.description = '为分身添加新的好友';
        this.category = 'social';
        this.paramsSchema = {
            avatarId: { type: 'string', description: '当前分身ID', required: true },
            friendAvatarId: { type: 'string', description: '要添加的好友分身ID', required: true }
        };
    }
    async execute(params, context) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const id = crypto.randomUUID();
            const existing = await db.query('avatar_friends', {
                avatar_id: params.avatarId,
                friend_avatar_id: params.friendAvatarId,
                status: 'active'
            });
            if (existing?.data && existing.data.length > 0) {
                return { success: false, toolName: this.name, error: '已经是好友关系' };
            }
            await db.insert('avatar_friends', {
                id,
                avatar_id: params.avatarId,
                friend_avatar_id: params.friendAvatarId,
                match_reason: '手动添加',
                compatibility_score: Math.floor(Math.random() * 40) + 60,
                status: 'active',
                created_at: new Date()
            });
            return { success: true, toolName: this.name, data: { message: '好友添加成功' } };
        }
        catch (error) {
            return { success: false, toolName: this.name, error: error.message };
        }
    }
};
exports.AddAvatarFriendTool = AddAvatarFriendTool;
exports.AddAvatarFriendTool = AddAvatarFriendTool = __decorate([
    (0, common_1.Injectable)()
], AddAvatarFriendTool);
let RemoveAvatarFriendTool = class RemoveAvatarFriendTool {
    constructor() {
        this.name = 'remove_avatar_friend';
        this.displayName = '移除分身好友';
        this.description = '移除分身的好友';
        this.category = 'social';
        this.paramsSchema = {
            avatarId: { type: 'string', description: '当前分身ID', required: true },
            friendAvatarId: { type: 'string', description: '要移除的好友分身ID', required: true }
        };
    }
    async execute(params, context) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            await (0, mysql_client_1.deleteRow)('avatar_friends', {
                avatar_id: params.avatarId,
                friend_avatar_id: params.friendAvatarId
            });
            return { success: true, toolName: this.name, data: { message: '好友已移除' } };
        }
        catch (error) {
            return { success: false, toolName: this.name, error: error.message };
        }
    }
};
exports.RemoveAvatarFriendTool = RemoveAvatarFriendTool;
exports.RemoveAvatarFriendTool = RemoveAvatarFriendTool = __decorate([
    (0, common_1.Injectable)()
], RemoveAvatarFriendTool);
