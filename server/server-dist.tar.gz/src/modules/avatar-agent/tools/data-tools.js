"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryOrdersTool = exports.QueryUserProfileTool = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../../storage/database/mysql-client");
let QueryUserProfileTool = class QueryUserProfileTool {
    constructor() {
        this.name = 'query_user_profile';
        this.displayName = '查询用户信息';
        this.description = '查询用户的基本信息、偏好设置等';
        this.category = 'data';
        this.paramsSchema = {
            userId: { type: 'string', description: '用户ID', required: true },
            fields: { type: 'array', description: '要查询的字段', default: [] }
        };
    }
    async execute(params, context) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const profiles = await db.query('users', { id: params.userId });
            if (!profiles?.data || profiles.data.length === 0) {
                return { success: false, toolName: this.name, error: '用户不存在' };
            }
            const data = profiles.data[0];
            const result = params.fields && params.fields.length > 0
                ? params.fields.reduce((acc, field) => { acc[field] = data[field]; return acc; }, {})
                : data;
            return { success: true, toolName: this.name, data: result };
        }
        catch (error) {
            return { success: false, toolName: this.name, error: error.message };
        }
    }
};
exports.QueryUserProfileTool = QueryUserProfileTool;
exports.QueryUserProfileTool = QueryUserProfileTool = __decorate([
    (0, common_1.Injectable)()
], QueryUserProfileTool);
let QueryOrdersTool = class QueryOrdersTool {
    constructor() {
        this.name = 'query_orders';
        this.displayName = '查询订单';
        this.description = '查询用户的订单列表';
        this.category = 'data';
        this.paramsSchema = {
            userId: { type: 'string', description: '用户ID', required: true },
            status: { type: 'string', description: '订单状态' }
        };
    }
    async execute(params, context) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const filter = { user_id: params.userId };
            if (params.status)
                filter.status = params.status;
            const orders = await db.query('orders', filter);
            return { success: true, toolName: this.name, data: { orders: orders?.data || [] } };
        }
        catch (error) {
            return { success: false, toolName: this.name, error: error.message };
        }
    }
};
exports.QueryOrdersTool = QueryOrdersTool;
exports.QueryOrdersTool = QueryOrdersTool = __decorate([
    (0, common_1.Injectable)()
], QueryOrdersTool);
