"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateTaskTool = exports.QueryTasksTool = exports.CreateTaskTool = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../../storage/database/mysql-client");
const crypto = require("crypto");
let CreateTaskTool = class CreateTaskTool {
    constructor() {
        this.name = 'create_task';
        this.displayName = '创建任务';
        this.description = '创建一个新任务';
        this.category = 'task';
        this.paramsSchema = {
            title: { type: 'string', description: '任务标题', required: true },
            description: { type: 'string', description: '任务描述', default: '' },
            priority: { type: 'string', description: '优先级：low, medium, high, urgent', default: 'medium' },
            dueDate: { type: 'string', description: '截止日期' }
        };
    }
    async execute(params, context) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const id = crypto.randomUUID();
            await db.insert('tasks', {
                id,
                user_id: context.userId,
                avatar_id: params.assignedToAvatarId || context.avatarId,
                title: params.title,
                description: params.description || '',
                priority: params.priority || 'medium',
                status: 'pending',
                progress: 0,
                due_date: params.dueDate,
                created_at: new Date(),
                updated_at: new Date()
            });
            return {
                success: true,
                toolName: this.name,
                data: { taskId: id, result: '任务已创建' }
            };
        }
        catch (error) {
            return { success: false, toolName: this.name, error: error.message };
        }
    }
};
exports.CreateTaskTool = CreateTaskTool;
exports.CreateTaskTool = CreateTaskTool = __decorate([
    (0, common_1.Injectable)()
], CreateTaskTool);
let QueryTasksTool = class QueryTasksTool {
    constructor() {
        this.name = 'query_tasks';
        this.displayName = '查询任务';
        this.description = '查询用户的任务列表';
        this.category = 'task';
        this.paramsSchema = {
            status: { type: 'string', description: '任务状态' }
        };
    }
    async execute(params, context) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const filter = { user_id: context.userId };
            if (params.status)
                filter.status = params.status;
            const tasks = await db.query('tasks', filter);
            return { success: true, toolName: this.name, data: { tasks: tasks || [] } };
        }
        catch (error) {
            return { success: false, toolName: this.name, error: error.message };
        }
    }
};
exports.QueryTasksTool = QueryTasksTool;
exports.QueryTasksTool = QueryTasksTool = __decorate([
    (0, common_1.Injectable)()
], QueryTasksTool);
let UpdateTaskTool = class UpdateTaskTool {
    constructor() {
        this.name = 'update_task';
        this.displayName = '更新任务';
        this.description = '更新任务状态或进度';
        this.category = 'task';
        this.paramsSchema = {
            taskId: { type: 'string', description: '任务ID', required: true },
            status: { type: 'string', description: '任务状态' },
            progress: { type: 'number', description: '进度' }
        };
    }
    async execute(params, context) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const updateData = { updated_at: new Date() };
            if (params.status)
                updateData.status = params.status;
            if (params.progress !== undefined)
                updateData.progress = params.progress;
            await db.updateWhere({ id: params.taskId, user_id: context.userId }, updateData);
            return { success: true, toolName: this.name, data: { result: '任务已更新' } };
        }
        catch (error) {
            return { success: false, toolName: this.name, error: error.message };
        }
    }
};
exports.UpdateTaskTool = UpdateTaskTool;
exports.UpdateTaskTool = UpdateTaskTool = __decorate([
    (0, common_1.Injectable)()
], UpdateTaskTool);
