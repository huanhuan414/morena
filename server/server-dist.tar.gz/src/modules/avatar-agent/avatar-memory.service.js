"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarMemoryService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
let AvatarMemoryService = class AvatarMemoryService {
    async addMemory(avatarId, memoryData) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const id = Date.now().toString();
        const result = await db.insert('avatar_memories', {
            id,
            avatar_id: avatarId,
            memory_type: memoryData.type || 'general',
            memory_content: memoryData.content || '',
            importance: memoryData.importance || 5,
            created_at: new Date()
        });
        return { success: result.affectedRows > 0, id };
    }
    async getMemories(avatarId, options) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const filter = { avatar_id: avatarId };
        if (options?.type) {
            filter.memory_type = options.type;
        }
        const result = await db.select('avatar_memories', filter, {
            limit: options?.limit || 100
        });
        return result.data || [];
    }
    async deleteMemory(memoryId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.delete('avatar_memories', { id: memoryId });
        return { success: result.affectedRows > 0 };
    }
    async updateMemory(memoryId, updateData) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.updateWhere('avatar_memories', { id: memoryId }, updateData);
        return { success: result.affectedRows > 0 };
    }
    async retrieveRelevantMemories(avatarId, query) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.select('avatar_memories', { avatar_id: avatarId }, { limit: 10 });
        return result.data || [];
    }
    async storeConversation(avatarId, conversationData) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.insert('avatar_conversations', {
            id: Date.now().toString(),
            avatar_id: avatarId,
            user_id: conversationData.userId,
            message: conversationData.message,
            response: conversationData.response,
            created_at: new Date()
        });
        return { success: result.affectedRows > 0 };
    }
    async storeThought(avatarId, thoughtData) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.insert('avatar_thoughts', {
            id: Date.now().toString(),
            avatar_id: avatarId,
            thought_content: thoughtData.content,
            thought_type: thoughtData.type || 'general',
            created_at: new Date()
        });
        return { success: result.affectedRows > 0 };
    }
};
exports.AvatarMemoryService = AvatarMemoryService;
exports.AvatarMemoryService = AvatarMemoryService = __decorate([
    (0, common_1.Injectable)()
], AvatarMemoryService);
