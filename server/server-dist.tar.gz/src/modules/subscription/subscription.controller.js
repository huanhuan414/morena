"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionController = void 0;
const common_1 = require("@nestjs/common");
const subscription_service_1 = require("./subscription.service");
const wechat_pay_service_1 = require("../payment/wechat-pay.service");
let SubscriptionController = class SubscriptionController {
    constructor(subscriptionService, wechatPayService) {
        this.subscriptionService = subscriptionService;
        this.wechatPayService = wechatPayService;
    }
    async getPlans() {
        try {
            if (this.subscriptionService) {
                const plans = await this.subscriptionService.getPlans();
                return { code: 200, data: plans, message: '获取成功' };
            }
        }
        catch (e) {
            console.error('[SubscriptionController] getPlans error:', e.message);
        }
        return { code: 200, data: [], message: '获取成功' };
    }
    async getStatus(userId) {
        if (!userId)
            return { code: 401, data: null, message: '未登录' };
        try {
            if (this.subscriptionService) {
                const status = await this.subscriptionService.getUserSubscription(userId);
                return { code: 200, data: status, message: '获取成功' };
            }
        }
        catch (e) {
            console.error('[SubscriptionController] getStatus error:', e.message);
        }
        return { code: 200, data: { plan: 'free', features: {} }, message: '获取成功' };
    }
    async checkPermission(userId, type, currentCount) {
        if (!userId || !type)
            return { code: 400, data: null, message: '缺少参数' };
        try {
            if (this.subscriptionService) {
                const result = await this.subscriptionService.checkPermission(userId, type, currentCount ? Number(currentCount) : 0);
                return { code: 200, data: result, message: '校验成功' };
            }
        }
        catch (e) {
            console.error('[SubscriptionController] checkPermission error:', e.message);
        }
        return { code: 200, data: { allowed: true, remaining: 999 }, message: '校验成功' };
    }
    async createOrder(planId, userId, openid) {
        if (!planId || !userId || !openid)
            return { code: 400, data: null, message: '缺少必要参数' };
        try {
            if (this.subscriptionService && this.wechatPayService) {
                const plan = await this.subscriptionService.getPlanByPlanId(planId);
                if (!plan)
                    return { code: 404, data: null, message: '套餐不存在' };
                if (Number(plan.price) === 0)
                    return { code: 400, data: null, message: '免费计划无需支付' };
                const orderResult = await this.wechatPayService.createOrder({
                    planId: plan.id, userId, openid,
                    amount: Number(plan.price),
                    description: `Morena AI - ${plan.name}`,
                });
                return { code: 200, data: orderResult, message: '下单成功' };
            }
        }
        catch (error) {
            console.error('[Subscription] 创建订单失败:', error);
            return { code: 500, data: null, message: error.message || '创建订单失败' };
        }
        return { code: 500, data: null, message: '服务暂不可用' };
    }
};
exports.SubscriptionController = SubscriptionController;
__decorate([
    (0, common_1.Get)('plans'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SubscriptionController.prototype, "getPlans", null);
__decorate([
    (0, common_1.Get)('status'),
    __param(0, (0, common_1.Query)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SubscriptionController.prototype, "getStatus", null);
__decorate([
    (0, common_1.Get)('check'),
    __param(0, (0, common_1.Query)('userId')),
    __param(1, (0, common_1.Query)('type')),
    __param(2, (0, common_1.Query)('currentCount')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], SubscriptionController.prototype, "checkPermission", null);
__decorate([
    (0, common_1.Post)('order'),
    __param(0, (0, common_1.Body)('planId')),
    __param(1, (0, common_1.Body)('userId')),
    __param(2, (0, common_1.Body)('openid')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], SubscriptionController.prototype, "createOrder", null);
exports.SubscriptionController = SubscriptionController = __decorate([
    (0, common_1.Controller)('subscription'),
    __param(0, (0, common_1.Inject)(subscription_service_1.SubscriptionService)),
    __param(1, (0, common_1.Inject)(wechat_pay_service_1.WechatPayService)),
    __metadata("design:paramtypes", [subscription_service_1.SubscriptionService,
        wechat_pay_service_1.WechatPayService])
], SubscriptionController);
