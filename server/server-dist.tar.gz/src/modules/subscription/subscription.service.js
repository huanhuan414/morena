"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const crypto = require("crypto");
let SubscriptionService = class SubscriptionService {
    async getPlans() {
        const db = (0, mysql_client_1.getMySQLClient)();
        const plans = await db.query('SELECT * FROM subscription_plans WHERE is_active = 1 ORDER BY price ASC');
        return plans;
    }
    async getPlanByPlanId(planId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const plans = await db.query('SELECT * FROM subscription_plans WHERE id = ?', [planId]);
        return plans?.[0] || null;
    }
    async getPlanById(id) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const plans = await db.query('SELECT * FROM subscription_plans WHERE id = ?', [id]);
        return plans?.[0] || null;
    }
    async getUserSubscription(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const subscriptions = await db.query('SELECT us.id, us.status, us.start_date, us.end_date, us.plan_id, ' +
            'sp.name as plan_name, sp.price as plan_price, sp.duration_days, sp.max_avatars, sp.can_receive_orders ' +
            'FROM user_subscriptions us ' +
            'LEFT JOIN subscription_plans sp ON us.plan_id = sp.id ' +
            'WHERE us.user_id = ? ORDER BY us.created_at DESC LIMIT 1', [userId]);
        if (!subscriptions || subscriptions.length === 0) {
            return null;
        }
        const sub = subscriptions[0];
        return {
            id: sub.id,
            status: sub.status,
            startDate: sub.startDate || sub.start_date,
            endDate: sub.endDate || sub.end_date,
            maxAvatars: sub.maxAvatars || sub.max_avatars,
            canReceiveOrders: sub.canReceiveOrders || sub.can_receive_orders,
            plan: {
                id: sub.planId || sub.plan_id,
                name: sub.planName || sub.plan_name,
                price: sub.planPrice || sub.plan_price,
                durationDays: sub.durationDays || sub.duration_days,
                maxAvatars: sub.maxAvatars || sub.max_avatars,
                canReceiveOrders: sub.canReceiveOrders || sub.can_receive_orders,
            }
        };
    }
    async activateSubscription(userId, planId, paymentOrderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const plan = await this.getPlanById(planId);
        if (!plan) {
            throw new Error('订阅计划不存在');
        }
        const durationDays = Number(plan.durationDays || plan.duration_days || 30);
        const maxAvatars = Number(plan.maxAvatars || plan.max_avatars || 1);
        const canReceiveOrders = Number(plan.canReceiveOrders || plan.can_receive_orders || 0);
        const existing = await db.query('SELECT * FROM user_subscriptions WHERE user_id = ? AND status = ? LIMIT 1', [userId, 'active']);
        const startDate = new Date();
        const endDate = new Date();
        endDate.setDate(endDate.getDate() + durationDays);
        if (existing && existing.length > 0) {
            await db.query('UPDATE user_subscriptions SET plan_id = ?, status = ?, start_date = ?, end_date = ?, max_avatars = ?, can_receive_orders = ?, updated_at = NOW() WHERE id = ?', [plan.id, 'active', startDate, endDate, maxAvatars, canReceiveOrders, existing[0].id]);
            return { id: existing[0].id, planId: plan.id, endDate };
        }
        const id = crypto.randomUUID();
        await db.query('INSERT INTO user_subscriptions (id, user_id, plan_id, status, start_date, end_date, max_avatars, can_receive_orders, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())', [id, userId, plan.id, 'active', startDate, endDate, maxAvatars, canReceiveOrders]);
        return { id, planId: plan.id, endDate };
    }
    async cancelSubscription(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        await db.query('UPDATE user_subscriptions SET status = ?, updated_at = NOW() WHERE user_id = ? AND status = ?', ['cancelled', userId, 'active']);
        return { success: true };
    }
    async checkSubscriptionStatus(userId) {
        const subscription = await this.getUserSubscription(userId);
        if (!subscription) {
            return { is_active: false };
        }
        const now = new Date();
        const endDate = new Date(subscription.end_date);
        return {
            is_active: subscription.status === 'active' && endDate > now,
            plan: subscription.plan?.plan_id,
            expires_at: endDate
        };
    }
    async checkPermission(userId, type, currentCount = 0) {
        const subscription = await this.getUserSubscription(userId);
        console.log('[Subscription] getUserSubscription result:', JSON.stringify(subscription, null, 2));
        let features = {};
        let planId = 'plan_free';
        if (subscription && subscription.status === 'active') {
            planId = subscription.plan?.id || 'plan_free';
            console.log('[Subscription] planId from subscription:', planId);
            const plan = await this.getPlanById(planId);
            console.log('[Subscription] plan from getPlanById:', JSON.stringify(plan, null, 2));
            if (plan) {
                features = typeof plan.features === 'string' ? JSON.parse(plan.features) : (plan.features || {});
            }
        }
        else {
            console.log('[Subscription] No active subscription, using free plan');
            const freePlan = await this.getPlanById('plan_free');
            if (freePlan) {
                features = typeof freePlan.features === 'string' ? JSON.parse(freePlan.features) : (freePlan.features || {});
            }
        }
        console.log('[Subscription] features:', JSON.stringify(features, null, 2));
        switch (type) {
            case 'check_avatars': {
                return {
                    allowed: true,
                    limit: 999,
                    current: currentCount,
                    reason: undefined,
                };
            }
            case 'check_orders': {
                return {
                    allowed: true,
                    reason: undefined,
                };
            }
            case 'check_skills': {
                const skillUses = features.skillUsesPerDay || features.skill_uses_per_day || 3;
                return {
                    allowed: true,
                    limit: skillUses,
                    current: currentCount,
                    reason: currentCount >= skillUses ? `今日技能使用已达上限(${skillUses}次)，请升级套餐` : undefined,
                };
            }
            case 'check_feature': {
                return {
                    allowed: true,
                    limit: 0,
                    current: 0,
                };
            }
            default:
                return { allowed: false, reason: '未知校验类型' };
        }
    }
};
exports.SubscriptionService = SubscriptionService;
exports.SubscriptionService = SubscriptionService = __decorate([
    (0, common_1.Injectable)()
], SubscriptionService);
