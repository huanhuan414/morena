"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TikHubController = void 0;
const common_1 = require("@nestjs/common");
const tikhub_service_1 = require("./tikhub.service");
let TikHubController = class TikHubController {
    constructor(tikhubService) {
        this.tikhubService = tikhubService;
    }
    async verifyPost(body) {
        const { platform, postUrl, keywords } = body;
        if (!platform) {
            return { code: 400, message: '请指定平台', data: null };
        }
        if (!postUrl) {
            return { code: 400, message: '请输入发布链接', data: null };
        }
        const result = await this.tikhubService.verifyPost(platform, postUrl, keywords || []);
        return {
            code: result.success ? 200 : 400,
            message: result.message,
            data: result.data || null,
        };
    }
    async getDouyinUserInfo(body) {
        const { douyinId } = body;
        if (!douyinId) {
            return {
                code: 400,
                message: '请输入抖音号',
                data: null,
            };
        }
        const result = await this.tikhubService.getDouyinUserInfo(douyinId);
        if (result.success) {
            return {
                code: 200,
                message: '获取成功',
                data: result.data,
            };
        }
        else {
            return {
                code: 400,
                message: result.message,
                data: null,
            };
        }
    }
    async getXiaohongshuUserInfo(body) {
        const { shareUrl } = body;
        if (!shareUrl) {
            return {
                code: 400,
                message: '请输入小红书分享链接',
                data: null,
            };
        }
        const result = await this.tikhubService.getXiaohongshuUserInfo(shareUrl);
        if (result.success) {
            return {
                code: 200,
                message: '获取成功',
                data: result.data,
            };
        }
        else {
            return {
                code: 400,
                message: result.message,
                data: null,
            };
        }
    }
};
exports.TikHubController = TikHubController;
__decorate([
    (0, common_1.Post)('verify-post'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], TikHubController.prototype, "verifyPost", null);
__decorate([
    (0, common_1.Post)('douyin/user-info'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], TikHubController.prototype, "getDouyinUserInfo", null);
__decorate([
    (0, common_1.Post)('xiaohongshu/user-info'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], TikHubController.prototype, "getXiaohongshuUserInfo", null);
exports.TikHubController = TikHubController = __decorate([
    (0, common_1.Controller)('tikhub'),
    __param(0, (0, common_1.Inject)(tikhub_service_1.TikHubService)),
    __metadata("design:paramtypes", [tikhub_service_1.TikHubService])
], TikHubController);
