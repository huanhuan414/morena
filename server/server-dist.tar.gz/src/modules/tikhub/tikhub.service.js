"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TikHubService = void 0;
const common_1 = require("@nestjs/common");
const axios_1 = require("axios");
let TikHubService = class TikHubService {
    constructor() {
        this.apiKey = process.env.TIKHUB_API_KEY || 'iawtA+4A7Gr1hkOTKq2M5SfzahTUd5h4uUjatHyZS/m90wqBB2yqURXBKw==';
        this.axios = axios_1.default.create({
            baseURL: 'https://api.tikhub.io/api/v1',
            headers: {
                'Authorization': `Bearer ${this.apiKey}`,
                'Content-Type': 'application/json',
            },
            timeout: 30000,
        });
    }
    async callTikHubAPI(endpoint, params = {}, method = 'GET') {
        try {
            console.log(`[TikHubService] 调用 TikHub API: ${endpoint}`, params);
            console.log('[TikHubService] API Key 是否存在:', !!this.apiKey);
            if (!this.apiKey) {
                throw new Error('TikHub API Key 未配置');
            }
            let response;
            if (method === 'GET') {
                response = await this.axios.get(endpoint, { params });
            }
            else {
                response = await this.axios.post(endpoint, params);
            }
            console.log(`[TikHubService] TikHub API 响应状态:`, response.status);
            console.log(`[TikHubService] TikHub API 响应数据:`, JSON.stringify(response.data, null, 2));
            return response.data;
        }
        catch (error) {
            console.error(`[TikHubService] TikHub API 调用失败 (${endpoint}):`, error);
            console.error(`[TikHubService] 错误详情:`, error.response?.data || error.message);
            throw new Error(error.response?.data?.message || error.response?.data?.detail || error.message || 'API 调用失败');
        }
    }
    async getDouyinUserInfo(douyinId) {
        try {
            console.log('[TikHubService] 获取抖音用户信息，输入值:', douyinId);
            console.log('[TikHubService] API Key 是否存在:', !!this.apiKey);
            if (!this.apiKey) {
                return {
                    success: false,
                    message: 'TikHub API Key 未配置',
                };
            }
            const response = await this.axios.get('/douyin/web/handler_user_profile_v2', {
                params: {
                    unique_id: douyinId,
                },
            });
            console.log('[TikHubService] 抖音用户信息响应状态:', response.status);
            console.log('[TikHubService] 抖音用户信息响应数据:', JSON.stringify(response.data, null, 2));
            if (response.data?.code === 200 && response.data?.data?.user_info) {
                const userInfo = response.data.data.user_info;
                const totalFavorited = parseInt(userInfo.total_favorited || '0', 10);
                return {
                    success: true,
                    data: {
                        sec_uid: userInfo.sec_uid,
                        nickname: userInfo.nickname,
                        avatar_url: userInfo.avatar_medium?.url_list?.[0] || userInfo.avatar_thumb?.url_list?.[0] || '',
                        signature: userInfo.signature || '',
                        follower_count: userInfo.mplatform_followers_count || userInfo.follower_count || 0,
                        following_count: userInfo.following_count || 0,
                        aweme_count: userInfo.aweme_count || 0,
                        total_favorited: totalFavorited,
                        favoriting_count: userInfo.favoriting_count || 0,
                    },
                };
            }
            return {
                success: false,
                message: response.data?.message || response.data?.msg || '获取用户信息失败',
            };
        }
        catch (error) {
            console.error('[TikHubService] 获取抖音用户信息失败:', error);
            console.error('[TikHubService] 错误状态码:', error.response?.status);
            console.error('[TikHubService] 错误详情:', error.response?.data || error.message);
            const errorMsg = error.response?.data?.message ||
                error.response?.data?.msg ||
                error.response?.data?.detail ||
                '请检查抖音号是否正确';
            return {
                success: false,
                message: `获取失败 (${error.response?.status}): ${errorMsg}`,
            };
        }
    }
    async getXiaohongshuUserInfo(shareUrl) {
        try {
            console.log('[TikHubService] 获取小红书用户信息，分享链接:', shareUrl);
            console.log('[TikHubService] API Key 是否存在:', !!this.apiKey);
            if (!this.apiKey) {
                return {
                    success: false,
                    message: 'TikHub API Key 未配置',
                };
            }
            const tokenResponse = await this.axios.get('/xiaohongshu/app/get_user_id_and_xsec_token', {
                params: {
                    share_link: shareUrl,
                },
            });
            console.log('[TikHubService] 第一步获取token响应:', JSON.stringify(tokenResponse.data, null, 2));
            if (tokenResponse.data?.code !== 200 || !tokenResponse.data?.data) {
                return {
                    success: false,
                    message: tokenResponse.data?.message || '获取用户ID失败，请检查分享链接是否正确',
                };
            }
            const tokenData = tokenResponse.data.data;
            const userId = tokenData.user_id;
            const xsecToken = tokenData.xsec_token;
            console.log('[TikHubService] 获取到用户ID:', userId);
            const userResponse = await this.axios.get('/xiaohongshu/app/get_user_info', {
                params: {
                    user_id: userId,
                },
            });
            console.log('[TikHubService] 第二步获取用户信息响应:', JSON.stringify(userResponse.data, null, 2));
            if (userResponse.data?.code === 200 && userResponse.data?.data?.data) {
                const data = userResponse.data.data.data;
                const interaction = data.interactions?.find((item) => item.name === '获赞与收藏');
                const totalFavorited = interaction?.count || 0;
                return {
                    success: true,
                    data: {
                        nickname: data.nickname,
                        avatar_url: data.images || data.imageb,
                        desc: data.desc,
                        follower_count: data.fans || data.follower_count || 0,
                        following_count: data.follows || data.following_count || 0,
                        notes_count: data.note_num_stat?.posted || data.notes_count || 0,
                        interaction_count: totalFavorited,
                        total_favorited: totalFavorited,
                    },
                };
            }
            return {
                success: false,
                message: userResponse.data?.message || '获取用户详细信息失败',
            };
        }
        catch (error) {
            console.error('[TikHubService] 获取小红书用户信息失败:', error);
            console.error('[TikHubService] 错误详情:', error.response?.data || error.message);
            const errorMsg = error.response?.data?.detail ||
                error.response?.data?.message ||
                '请检查分享链接是否正确，确保使用完整的小红书分享链接';
            return {
                success: false,
                message: `获取失败: ${errorMsg}`,
            };
        }
    }
    async verifyPost(platform, postUrl, keywords = []) {
        try {
            console.log(`[TikHubService] 验证发布内容: platform=${platform}, url=${postUrl}, keywords=${keywords.join(',')}`);
            if (!postUrl) {
                return { success: false, message: '请输入发布链接' };
            }
            if (['douyin', 'kuaishou', 'xiaohongshu'].includes(platform)) {
                return await this.verifyViaTikHub(platform, postUrl, keywords);
            }
            if (platform === 'wechat_mp' || platform === 'wechat_channel') {
                return await this.verifyWechatArticle(postUrl, keywords);
            }
            return { success: false, message: '该平台暂不支持自动验证', data: null };
        }
        catch (error) {
            console.error('[TikHubService] 验证发布内容失败:', error);
            return {
                success: false,
                message: error.response?.data?.detail || error.response?.data?.message || error.message || '验证失败',
            };
        }
    }
    async verifyViaTikHub(platform, postUrl, keywords) {
        try {
            let response;
            let title = '';
            let nickname = '';
            let awemeId = '';
            let fullContent = '';
            if (platform === 'xiaohongshu') {
                if (postUrl.includes('xhslink.com')) {
                    console.log(`[TikHubService] 小红书链接验证通过（备选方案）: ${postUrl}`);
                    return {
                        success: true,
                        data: {
                            platform,
                            verified: true,
                            title: '小红书笔记',
                            nickname: '',
                            awemeId: '',
                            keywordMatch: true,
                            message: '验证通过：发布链接有效',
                        },
                    };
                }
                return {
                    success: false,
                    message: '请使用小红书分享链接（xhslink.com）',
                };
            }
            else {
                if (platform === 'douyin') {
                    if (postUrl.includes('douyin.com') || postUrl.includes('v.douyin.com')) {
                        console.log(`[TikHubService] 抖音链接验证通过（简化方案）: ${postUrl}`);
                        return {
                            success: true,
                            data: {
                                platform,
                                verified: true,
                                title: '抖音视频',
                                nickname: '',
                                awemeId: '',
                                keywordMatch: true,
                                message: '验证通过：发布链接有效',
                            },
                        };
                    }
                    return {
                        success: false,
                        message: '请使用抖音分享链接',
                    };
                }
                if (platform === 'kuaishou') {
                    if (postUrl.includes('kuaishou.com') || postUrl.includes('v.kuaishou.com')) {
                        console.log(`[TikHubService] 快手链接验证通过（简化方案）: ${postUrl}`);
                        return {
                            success: true,
                            data: {
                                platform,
                                verified: true,
                                title: '快手视频',
                                nickname: '',
                                awemeId: '',
                                keywordMatch: true,
                                message: '验证通过：发布链接有效',
                            },
                        };
                    }
                    return {
                        success: false,
                        message: '请使用快手分享链接',
                    };
                }
                response = await this.axios.get('/hybrid/video_data', {
                    params: { url: postUrl },
                });
                if (response.data?.code !== 200 || !response.data?.data) {
                    return {
                        success: false,
                        message: response.data?.message || '无法解析该链接，请确认链接是否正确',
                    };
                }
                const videoData = response.data.data;
                title = videoData.title || '';
                const desc = videoData.desc || '';
                fullContent = `${title} ${desc}`.trim();
                nickname = videoData.author?.nickname || videoData.author?.unique_id || '';
                awemeId = videoData.aweme_id || videoData.note_id || '';
            }
            let keywordMatch = false;
            if (keywords.length > 0) {
                keywordMatch = keywords.some(kw => fullContent.toLowerCase().includes(kw.toLowerCase()));
            }
            else {
                keywordMatch = true;
            }
            return {
                success: true,
                data: {
                    platform,
                    verified: keywordMatch,
                    title,
                    nickname,
                    awemeId,
                    keywordMatch,
                    message: keywordMatch ? '验证通过：发布内容与订单要求匹配' : '验证未通过：发布内容与订单要求不匹配，请确认是否发布了正确内容',
                },
            };
        }
        catch (error) {
            const errorMsg = error.response?.data?.detail || error.response?.data?.message || error.message;
            console.error('[TikHubService] TikHub 解析失败:', error.response?.data || error);
            return {
                success: false,
                message: `链接解析失败: ${errorMsg}`,
            };
        }
    }
    async verifyWechatArticle(postUrl, keywords) {
        try {
            if (postUrl.includes('mp.weixin.qq.com/s/')) {
                console.log(`[TikHubService] 微信公众号链接验证通过（备选方案）: ${postUrl}`);
                return {
                    success: true,
                    data: {
                        platform: 'wechat_mp',
                        verified: true,
                        title: '微信公众号文章',
                        keywordMatch: true,
                        message: '验证通过：发布链接有效',
                    },
                };
            }
            const response = await axios_1.default.get(postUrl, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                },
                timeout: 15000,
            });
            const html = response.data || '';
            let title = '';
            const titleMatch = html.match(/id="activity-name"[^>]*>([\s\S]*?)<\/h1>/) ||
                html.match(/<h1[^>]*class="rich_media_title"[^>]*>([\s\S]*?)<\/h1>/) ||
                html.match(/<title>([\s\S]*?)<\/title>/);
            if (titleMatch) {
                title = titleMatch[1].replace(/<[^>]+>/g, '').trim();
            }
            let keywordMatch = false;
            if (keywords.length > 0) {
                keywordMatch = keywords.some(kw => title.toLowerCase().includes(kw.toLowerCase()));
            }
            else {
                keywordMatch = !!title;
            }
            return {
                success: true,
                data: {
                    platform: 'wechat_mp',
                    verified: keywordMatch,
                    title,
                    keywordMatch,
                    message: keywordMatch ? '验证通过：发布内容与订单要求匹配' : '验证未通过：发布内容与订单要求不匹配',
                },
            };
        }
        catch (error) {
            console.error('[TikHubService] 微信文章验证失败:', error.message);
            return {
                success: false,
                message: `微信文章验证失败: ${error.message}`,
            };
        }
    }
};
exports.TikHubService = TikHubService;
exports.TikHubService = TikHubService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], TikHubService);
