"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReferralService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const earning_service_1 = require("../earning/earning.service");
const crypto = require("crypto");
let ReferralService = class ReferralService {
    constructor(earningService) {
        this.earningService = earningService;
    }
    async generateReferralCode(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const user = await db.queryOne('users', { id: userId });
        console.log('[ReferralService] generateReferralCode - userId:', userId);
        console.log('[ReferralService] user data:', {
            referral_code: user?.referral_code,
            referralCode: user?.referralCode
        });
        if (user?.referral_code || user?.referralCode) {
            const existingCode = user.referral_code || user.referralCode;
            console.log('[ReferralService] returning existing code:', existingCode);
            return existingCode;
        }
        const code = this.generateUniqueCode();
        console.log('[ReferralService] generating new code:', code);
        await db.updateWhere('users', { id: userId }, {
            referral_code: code,
            updated_at: new Date()
        });
        return code;
    }
    generateUniqueCode() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let code = '';
        for (let i = 0; i < 6; i++) {
            code += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return code;
    }
    async useReferralCode(inviteeId, code) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const inviter = await db.queryOne('users', { referral_code: code });
        if (!inviter) {
            throw new Error('邀请码无效');
        }
        if (inviter.id === inviteeId) {
            throw new Error('不能使用自己的邀请码');
        }
        const existingReferral = await db.queryOne('referrals', { referred_id: inviteeId });
        if (existingReferral) {
            throw new Error('您已被邀请过');
        }
        const INVITER_REWARD = 5;
        const INVITEE_REWARD = 5;
        const id = crypto.randomUUID();
        await db.insert('referrals', {
            id,
            referrer_id: inviter.id,
            referred_id: inviteeId,
            status: 'pending',
            reward_amount: INVITER_REWARD,
            created_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
        });
        const inviterRecord = await db.queryOne('users', { id: inviter.id });
        await db.updateWhere('users', { id: inviter.id }, {
            referral_count: (inviterRecord?.referral_count || 0) + 1,
            updated_at: new Date()
        });
        return {
            success: true,
            inviterReward: INVITER_REWARD,
            inviteeReward: INVITEE_REWARD
        };
    }
    async getReferralStats(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const referralCode = await this.generateReferralCode(userId);
        const referrals = await db.query('referrals', { referrer_id: userId });
        const completedReferrals = referrals?.filter((r) => r.status === 'completed') || [];
        const pendingCount = (referrals?.length || 0) - completedReferrals.length;
        const totalReward = completedReferrals.reduce((sum, r) => sum + Number(r.reward_amount || 0), 0);
        return {
            referralCode,
            totalInvited: referrals?.length || 0,
            totalReward,
            pendingReward: pendingCount * 5,
            totalInvites: referrals?.length || 0,
            pendingInvites: pendingCount,
            completedInvites: completedReferrals.length,
            inviterReward: 5,
            inviteeReward: 5,
            totalEarned: totalReward
        };
    }
    async settleReferralOnFirstAvatar(inviteeId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const pending = await db.queryOne('referrals', { referred_id: inviteeId, status: 'pending' });
        const referral = pending?.data;
        if (!referral)
            return { skipped: true };
        const inviterId = referral.referrer_id || referral.referrerId;
        if (!inviterId)
            return { skipped: true };
        const INVITER_REWARD = 5;
        const INVITEE_REWARD = 5;
        const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
        await db.updateWhere('referrals', { id: referral.id }, {
            status: 'completed',
            reward_amount: INVITER_REWARD,
        });
        await db.insert('earnings', {
            id: crypto.randomUUID(),
            user_id: inviterId,
            type: 'referral_bonus',
            amount: INVITER_REWARD,
            description: '邀请好友奖励',
            status: 'completed',
            created_at: now,
        });
        await db.insert('earnings', {
            id: crypto.randomUUID(),
            user_id: inviteeId,
            type: 'referral_bonus',
            amount: INVITEE_REWARD,
            description: '受邀创建分身奖励',
            status: 'completed',
            created_at: now,
        });
        await db.query('UPDATE users SET balance = balance + ?, total_earnings = total_earnings + ?, updated_at = ? WHERE id = ?', [INVITER_REWARD, INVITER_REWARD, now, inviterId]);
        await db.query('UPDATE users SET balance = balance + ?, total_earnings = total_earnings + ?, updated_at = ? WHERE id = ?', [INVITEE_REWARD, INVITEE_REWARD, now, inviteeId]);
        return { completed: true, inviterId };
    }
    async getReferralList(userId, page = 1, pageSize = 10) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const offset = (page - 1) * pageSize;
        const referrals = await db.query('referrals', { referrer_id: userId });
        const total = referrals?.length || 0;
        const paginatedReferrals = referrals?.slice(offset, offset + pageSize) || [];
        const list = await Promise.all(paginatedReferrals.map(async (ref) => {
            const inviteeId = ref.referred_id || ref.referredId;
            let inviteeNickname = '未知用户';
            let inviteeAvatar = '';
            if (inviteeId) {
                try {
                    const invitee = await db.queryOne('users', { id: inviteeId });
                    if (invitee) {
                        inviteeNickname = invitee.nickname || inviteeNickname;
                        inviteeAvatar = invitee.avatar || '';
                    }
                }
                catch (e) {
                    console.error('[ReferralService] 获取被邀请人信息失败:', e);
                }
            }
            return {
                invitee_id: inviteeId,
                invitee_nickname: inviteeNickname,
                invitee_avatar: inviteeAvatar,
                status: ref.status,
                reward_amount: ref.reward_amount || ref.rewardAmount || 0,
                created_at: ref.created_at || ref.createdAt
            };
        }));
        return {
            list,
            total,
            page,
            pageSize
        };
    }
};
exports.ReferralService = ReferralService;
exports.ReferralService = ReferralService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(earning_service_1.EarningService)),
    __metadata("design:paramtypes", [earning_service_1.EarningService])
], ReferralService);
