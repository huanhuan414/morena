"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReferralController = void 0;
const common_1 = require("@nestjs/common");
const referral_service_1 = require("./referral.service");
let ReferralController = class ReferralController {
    constructor(referralService) {
        this.referralService = referralService;
    }
    async getReferralCode(userId) {
        try {
            if (this.referralService) {
                const code = await this.referralService.generateReferralCode(userId);
                return { code: 200, data: { referralCode: code }, message: '获取成功' };
            }
        }
        catch (e) {
            console.error('[ReferralController] getReferralCode error:', e.message);
        }
        return { code: 200, data: { referralCode: '' }, message: '获取成功' };
    }
    async postReferralCode(userId) {
        try {
            if (this.referralService) {
                const code = await this.referralService.generateReferralCode(userId);
                return { code: 200, data: { referralCode: code }, message: '获取成功' };
            }
        }
        catch (e) {
            console.error('[ReferralController] postReferralCode error:', e.message);
        }
        return { code: 200, data: { referralCode: '' }, message: '获取成功' };
    }
    async useReferralCode(userId, code) {
        try {
            if (this.referralService) {
                const result = await this.referralService.useReferralCode(userId, code);
                return { code: 200, data: result, message: '邀请码使用成功' };
            }
        }
        catch (e) {
            console.error('[ReferralController] useReferralCode error:', e.message);
        }
        return { code: 500, data: null, message: '服务暂不可用' };
    }
    async getStats(userId) {
        try {
            if (this.referralService) {
                const stats = await this.referralService.getReferralStats(userId);
                return { code: 200, data: stats, message: '获取成功' };
            }
        }
        catch (e) {
            console.error('[ReferralController] getStats error:', e.message);
        }
        return { code: 200, data: { totalReferred: 0, totalEarned: 0 }, message: '获取成功' };
    }
    async getList(userId, page, pageSize) {
        try {
            if (this.referralService) {
                const result = await this.referralService.getReferralList(userId, page ? parseInt(page) : 1, pageSize ? parseInt(pageSize) : 20);
                return { code: 200, data: result, message: '获取成功' };
            }
        }
        catch (e) {
            console.error('[ReferralController] getList error:', e.message);
        }
        return { code: 200, data: { list: [], total: 0 }, message: '获取成功' };
    }
};
exports.ReferralController = ReferralController;
__decorate([
    (0, common_1.Get)('code'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ReferralController.prototype, "getReferralCode", null);
__decorate([
    (0, common_1.Post)('code'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ReferralController.prototype, "postReferralCode", null);
__decorate([
    (0, common_1.Post)('use'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)('code')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], ReferralController.prototype, "useReferralCode", null);
__decorate([
    (0, common_1.Get)('stats'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ReferralController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)('list'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], ReferralController.prototype, "getList", null);
exports.ReferralController = ReferralController = __decorate([
    (0, common_1.Controller)('referral'),
    __param(0, (0, common_1.Inject)(referral_service_1.ReferralService)),
    __metadata("design:paramtypes", [referral_service_1.ReferralService])
], ReferralController);
