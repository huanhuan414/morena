"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PalmReadingService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const crypto = require("crypto");
let PalmReadingService = class PalmReadingService {
    constructor() {
        this.imageApiUrl = 'https://api.aaigc.top/v1/images/edits';
        this.imageApiKey = 'sk-z1CFQbVdKI6x7ciJLwQkp1vPJPp8P9lQWW0jJGQWUdkSuQsK';
    }
    async createTask(imageUrl, avatarId, userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const id = crypto.randomUUID();
        await db.insert('palm_reading_records', {
            id,
            avatar_id: avatarId || null,
            user_id: userId || null,
            palm_image_url: imageUrl,
            status: 'pending',
            progress: '任务已创建',
            generated_image_url: null,
            error_message: null,
            created_at: new Date(),
            updated_at: new Date()
        });
        const record = await db.queryOne('palm_reading_records', { id });
        this.executeTask(record.id, imageUrl).catch((err) => {
            console.error('[PalmReadingService] 异步任务执行失败:', err.message);
        });
        return record;
    }
    async executeTask(taskId, imageUrl) {
        const db = (0, mysql_client_1.getMySQLClient)();
        try {
            await this.updateTask(taskId, { status: 'processing', progress: '正在处理图片...' });
            await this.updateTask(taskId, { progress: '图片已就绪，正在生成掌相阅读指南...' });
            await this.updateTask(taskId, {
                status: 'completed',
                progress: '处理完成',
                generated_image_url: imageUrl
            });
        }
        catch (error) {
            await this.updateTask(taskId, {
                status: 'failed',
                error_message: error.message
            });
        }
    }
    async updateTask(taskId, updates) {
        const db = (0, mysql_client_1.getMySQLClient)();
        await db.update('palm_reading_records', { id: taskId }, {
            ...updates,
            updated_at: new Date()
        });
    }
    async getTask(taskId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const record = await db.queryOne('palm_reading_records', { id: taskId });
        return record;
    }
    async getUserTasks(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const tasks = await db.query('palm_reading_records', { user_id: userId });
        return (tasks || []);
    }
};
exports.PalmReadingService = PalmReadingService;
exports.PalmReadingService = PalmReadingService = __decorate([
    (0, common_1.Injectable)()
], PalmReadingService);
