"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var AiService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AiService = void 0;
const common_1 = require("@nestjs/common");
const ARK_API_KEY = '0a6405d5-b7ae-4afa-88e3-c707ae379a47';
const ARK_BASE_URL = 'https://ark.cn-beijing.volces.com/api/v3';
const ARK_MODEL = 'doubao-seed-2-0-pro-260215';
let AiService = AiService_1 = class AiService {
    constructor() {
        this.logger = new common_1.Logger(AiService_1.name);
        this.tasks = new Map();
    }
    startGenerate(params) {
        const requestId = `${Date.now()}_${Math.random().toString(16).slice(2)}`;
        this.tasks.set(requestId, { status: 'processing', content: '', createdAt: Date.now() });
        this.generateContentStreaming(params, requestId)
            .then((fullContent) => {
            this.tasks.set(requestId, { status: 'completed', content: fullContent, createdAt: Date.now() });
            this.logger.log(`AI帮写完成, 内容长度: ${fullContent.length}`);
        })
            .catch((err) => {
            const msg = err?.message || '生成失败';
            this.tasks.set(requestId, { status: 'failed', error: msg, createdAt: Date.now() });
            this.logger.error(`AI帮写失败: ${msg}`);
        });
        return { requestId, status: 'processing' };
    }
    getTask(requestId) {
        const task = this.tasks.get(requestId);
        if (!task) {
            return null;
        }
        return {
            requestId,
            status: task.status,
            content: task.content,
            error: task.error,
        };
    }
    async generateContentStreaming(params, requestId) {
        const { prompt } = params;
        const systemPrompt = '你是一位资深内容策划与社交媒体运营专家，擅长为不同平台产出结构化、可执行、可落地的爆款内容任务描述。';
        this.logger.log('调用火山引擎豆包API(流式)生成内容...');
        const response = await fetch(`${ARK_BASE_URL}/chat/completions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${ARK_API_KEY}`,
            },
            body: JSON.stringify({
                model: ARK_MODEL,
                stream: true,
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: prompt },
                ],
            }),
        });
        if (!response.ok) {
            const errText = await response.text();
            this.logger.error(`ARK API 请求失败: status=${response.status}, body=${errText}`);
            throw new Error(`ARK API 请求失败: ${response.status}`);
        }
        const reader = response.body?.getReader();
        if (!reader) {
            throw new Error('无法获取响应流');
        }
        const decoder = new TextDecoder();
        let fullContent = '';
        let buffer = '';
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';
            for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed || !trimmed.startsWith('data: '))
                    continue;
                const dataStr = trimmed.slice(6);
                if (dataStr === '[DONE]')
                    continue;
                try {
                    const chunk = JSON.parse(dataStr);
                    const delta = chunk.choices?.[0]?.delta;
                    if (delta?.content) {
                        fullContent += delta.content;
                        const task = this.tasks.get(requestId);
                        if (task && task.status === 'processing') {
                            this.tasks.set(requestId, { ...task, content: fullContent });
                        }
                    }
                }
                catch {
                }
            }
        }
        if (!fullContent) {
            throw new Error('模型返回内容为空');
        }
        return fullContent;
    }
    static async invokeLlmSync(messages) {
        const response = await fetch(`${ARK_BASE_URL}/chat/completions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${ARK_API_KEY}`,
            },
            body: JSON.stringify({
                model: ARK_MODEL,
                messages,
            }),
        });
        if (!response.ok) {
            const errText = await response.text();
            throw new Error(`ARK API 请求失败: ${response.status} - ${errText.slice(0, 200)}`);
        }
        const result = (await response.json());
        const content = result?.choices?.[0]?.message?.content;
        if (!content) {
            throw new Error('模型返回内容为空');
        }
        return content;
    }
    async generateContent(params) {
        const { prompt } = params;
        const systemPrompt = '你是一位资深内容策划与社交媒体运营专家，擅长为不同平台产出结构化、可执行、可落地的爆款内容任务描述。';
        const content = await AiService_1.invokeLlmSync([
            { role: 'system', content: systemPrompt },
            { role: 'user', content: prompt },
        ]);
        return { content };
    }
};
exports.AiService = AiService;
exports.AiService = AiService = AiService_1 = __decorate([
    (0, common_1.Injectable)()
], AiService);
