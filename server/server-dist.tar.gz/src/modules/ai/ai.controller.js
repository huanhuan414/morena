"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AiController = void 0;
const common_1 = require("@nestjs/common");
const ai_service_1 = require("./ai.service");
let AiController = class AiController {
    constructor(aiService) {
        this.aiService = aiService;
    }
    async generateContent(body) {
        try {
            const result = this.aiService.startGenerate(body);
            return {
                code: 200,
                message: 'success',
                data: result
            };
        }
        catch (error) {
            return {
                code: 500,
                message: error.message || '生成失败',
                data: null
            };
        }
    }
    async getStatus(requestId) {
        const task = this.aiService.getTask(requestId);
        if (!task) {
            return {
                code: 404,
                message: 'not_found',
                data: null,
            };
        }
        return {
            code: 200,
            message: 'success',
            data: task,
        };
    }
};
exports.AiController = AiController;
__decorate([
    (0, common_1.Post)('generate'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AiController.prototype, "generateContent", null);
__decorate([
    (0, common_1.Get)('status/:requestId'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('requestId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AiController.prototype, "getStatus", null);
exports.AiController = AiController = __decorate([
    (0, common_1.Controller)('ai'),
    __param(0, (0, common_1.Inject)(ai_service_1.AiService)),
    __metadata("design:paramtypes", [ai_service_1.AiService])
], AiController);
