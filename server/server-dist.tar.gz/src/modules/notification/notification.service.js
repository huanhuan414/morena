"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationService = void 0;
const common_1 = require("@nestjs/common");
const crypto = require("crypto");
const sharedMemoryNotifications = new Map();
const sharedMemoryNotificationOrder = [];
const MEMORY_MAX_USERS = Number(process.env?.NOTIFY_MEMORY_MAX_USERS || 200);
const MEMORY_MAX_TOTAL = Number(process.env?.NOTIFY_MEMORY_MAX_TOTAL || 2000);
const MEMORY_MAX_PER_USER = Number(process.env?.NOTIFY_MEMORY_MAX_PER_USER || 50);
const TEMPLATE_DEFS = {
    first_order_guide: {
        envKey: 'NOTIFY_TPL_FIRST_ORDER_ENABLED',
        type: 'growth_first_order_guide',
        title: '首单完成引导',
        content: '你已完成首单支付，订单「{orderTitle}」正在分配分身。你可以在订单页查看进度与时间线。',
    },
    acceptance_overdue: {
        envKey: 'NOTIFY_TPL_ACCEPTANCE_OVERDUE_ENABLED',
        type: 'order_acceptance_overdue',
        title: '验收超时提醒',
        content: '你的订单「{orderTitle}」已超过6小时未验收，请尽快处理。',
    }
};
let NotificationService = class NotificationService {
    constructor() {
        this.notificationColumns = null;
    }
    async getNotificationColumns() {
        if (this.notificationColumns)
            return this.notificationColumns;
        try {
            const { getMySQLClient } = await Promise.resolve().then(() => require('../../storage/database/mysql-client'));
            const db = getMySQLClient();
            const rows = await db.query(`SELECT COLUMN_NAME as column_name
         FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = 'notifications'`);
            const list = Array.isArray(rows) ? rows : (rows?.data || []);
            this.notificationColumns = new Set((list || []).map((r) => String(r.columnName ?? r.column_name ?? '').toLowerCase()).filter(Boolean));
        }
        catch {
            this.notificationColumns = new Set(['id', 'user_id', 'type', 'title', 'content', 'is_read', 'data', 'created_at']);
        }
        return this.notificationColumns;
    }
    pickNotificationPayload(columns, payload) {
        const picked = {};
        for (const [key, value] of Object.entries(payload || {})) {
            if (columns.has(key.toLowerCase())) {
                picked[key] = value;
            }
        }
        return picked;
    }
    removeFromMemoryOrder(userId, ids) {
        if (!ids || ids.length === 0)
            return;
        const idSet = new Set(ids);
        for (let i = sharedMemoryNotificationOrder.length - 1; i >= 0; i--) {
            const item = sharedMemoryNotificationOrder[i];
            if (item.userId === userId && idSet.has(item.id)) {
                sharedMemoryNotificationOrder.splice(i, 1);
            }
        }
    }
    removeMemoryNotification(userId, notificationId) {
        const notifications = sharedMemoryNotifications.get(userId) || [];
        const filtered = notifications.filter((n) => n.id !== notificationId);
        if (filtered.length === 0) {
            sharedMemoryNotifications.delete(userId);
        }
        else {
            sharedMemoryNotifications.set(userId, filtered);
        }
        this.removeFromMemoryOrder(userId, [notificationId]);
    }
    enforceMemoryLimits() {
        if (MEMORY_MAX_PER_USER > 0) {
            for (const [userId, list] of sharedMemoryNotifications.entries()) {
                if (list.length > MEMORY_MAX_PER_USER) {
                    const removed = list.slice(MEMORY_MAX_PER_USER);
                    const removedIds = removed.map((n) => n.id);
                    list.length = MEMORY_MAX_PER_USER;
                    this.removeFromMemoryOrder(userId, removedIds);
                }
            }
        }
        while ((MEMORY_MAX_TOTAL > 0 && sharedMemoryNotificationOrder.length > MEMORY_MAX_TOTAL)
            || (MEMORY_MAX_USERS > 0 && sharedMemoryNotifications.size > MEMORY_MAX_USERS)) {
            const item = sharedMemoryNotificationOrder.pop();
            if (!item)
                break;
            this.removeMemoryNotification(item.userId, item.id);
        }
    }
    addMemoryNotification(userId, notification) {
        const userNotifications = sharedMemoryNotifications.get(userId) || [];
        userNotifications.unshift(notification);
        sharedMemoryNotifications.set(userId, userNotifications);
        sharedMemoryNotificationOrder.unshift({ userId, id: notification.id });
        this.enforceMemoryLimits();
    }
    async flushMemoryNotificationsToDb(userId) {
        const notifications = sharedMemoryNotifications.get(userId) || [];
        if (notifications.length === 0)
            return { flushed: 0 };
        let flushed = 0;
        try {
            const { getMySQLClient } = await Promise.resolve().then(() => require('../../storage/database/mysql-client'));
            const db = getMySQLClient();
            const columns = await this.getNotificationColumns();
            const remaining = [];
            for (let i = notifications.length - 1; i >= 0; i--) {
                const n = notifications[i];
                try {
                    const base = {
                        id: n.id,
                        user_id: n.user_id || userId,
                        type: n.type,
                        title: n.title,
                        content: n.content,
                        is_read: Boolean(n.is_read),
                        created_at: n.created_at ? new Date(n.created_at) : new Date(),
                    };
                    const metadataJson = JSON.stringify(n.metadata || {});
                    if (columns.has('metadata'))
                        base.metadata = metadataJson;
                    if (columns.has('data'))
                        base.data = metadataJson;
                    if (columns.has('updated_at'))
                        base.updated_at = n.updated_at ? new Date(n.updated_at) : new Date();
                    await db.insert('notifications', this.pickNotificationPayload(columns, base));
                    flushed += 1;
                }
                catch {
                    remaining.unshift(n);
                }
            }
            if (remaining.length === 0) {
                sharedMemoryNotifications.delete(userId);
            }
            else {
                sharedMemoryNotifications.set(userId, remaining);
            }
            const remainingIds = new Set(remaining.map((n) => n.id));
            for (let i = sharedMemoryNotificationOrder.length - 1; i >= 0; i--) {
                const item = sharedMemoryNotificationOrder[i];
                if (item.userId === userId && !remainingIds.has(item.id)) {
                    sharedMemoryNotificationOrder.splice(i, 1);
                }
            }
        }
        catch { }
        this.enforceMemoryLimits();
        return { flushed };
    }
    normalizeReadFlag(value) {
        if (value === true)
            return true;
        if (value === false)
            return false;
        if (typeof value === 'number')
            return value === 1;
        if (typeof value === 'string') {
            const normalized = value.trim().toLowerCase();
            return normalized === '1' || normalized === 'true' || normalized === 'yes';
        }
        return false;
    }
    safeParseJson(value, fallback) {
        if (value === null || value === undefined)
            return fallback;
        if (typeof value === 'object')
            return value;
        if (typeof value !== 'string')
            return fallback;
        try {
            return JSON.parse(value);
        }
        catch {
            return fallback;
        }
    }
    normalizeNotificationRow(row) {
        const isRead = this.normalizeReadFlag(row?.isRead ?? row?.is_read);
        const createdAt = row?.createdAt || row?.created_at;
        const updatedAt = row?.updatedAt || row?.updated_at;
        const metadataSource = row?.metadata ?? row?.data;
        const metadata = this.safeParseJson(metadataSource, metadataSource || {});
        return {
            ...row,
            metadata,
            is_read: isRead,
            isRead,
            created_at: createdAt,
            createdAt,
            updated_at: updatedAt,
            updatedAt,
        };
    }
    renderTemplate(input, params = {}) {
        if (!input)
            return input;
        return String(input).replace(/\{(\w+)\}/g, (_, key) => {
            const value = params[key];
            if (value === undefined || value === null)
                return '';
            return String(value);
        });
    }
    async createTemplateNotification(userId, templateKey, params = {}, metadata) {
        const def = TEMPLATE_DEFS[templateKey];
        if (!def) {
            throw new Error('未知通知模板');
        }
        if (def.envKey && process.env?.[def.envKey] === '0') {
            return { skipped: true };
        }
        const title = this.renderTemplate(def.title, params);
        const content = this.renderTemplate(def.content, params);
        return await this.createNotification({
            user_id: userId,
            type: def.type,
            title,
            content,
            metadata: { ...(metadata || {}), templateKey }
        });
    }
    async createNotification(data) {
        const id = crypto.randomUUID();
        const notification = {
            id,
            user_id: data.user_id,
            type: data.type,
            title: data.title,
            content: data.content,
            metadata: data.metadata || {},
            is_read: false,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };
        try {
            const { getMySQLClient } = await Promise.resolve().then(() => require('../../storage/database/mysql-client'));
            const db = getMySQLClient();
            const columns = await this.getNotificationColumns();
            const base = {
                id,
                user_id: data.user_id,
                type: data.type,
                title: data.title,
                content: data.content,
                is_read: false,
                created_at: new Date(),
            };
            const metadataJson = JSON.stringify(data.metadata || {});
            if (columns.has('metadata'))
                base.metadata = metadataJson;
            if (columns.has('data'))
                base.data = metadataJson;
            if (columns.has('updated_at'))
                base.updated_at = new Date();
            await db.insert('notifications', this.pickNotificationPayload(columns, base));
            await this.flushMemoryNotificationsToDb(data.user_id);
        }
        catch (dbError) {
            this.addMemoryNotification(data.user_id, notification);
        }
        return { id };
    }
    async getNotifications(userId, page = 1, pageSize = 20) {
        let notifications = [];
        try {
            const { getMySQLClient } = await Promise.resolve().then(() => require('../../storage/database/mysql-client'));
            const db = getMySQLClient();
            await this.flushMemoryNotificationsToDb(userId);
            const result = (await db.query('notifications', { user_id: userId }));
            notifications = Array.isArray(result) ? result : (result?.data || []);
        }
        catch (dbError) {
            notifications = sharedMemoryNotifications.get(userId) || [];
        }
        const total = notifications.length;
        const offset = (page - 1) * pageSize;
        return {
            list: notifications.slice(offset, offset + pageSize).map((n) => this.normalizeNotificationRow(n)),
            total,
            page,
            pageSize
        };
    }
    async markAsRead(notificationId, userId) {
        try {
            const { getMySQLClient } = await Promise.resolve().then(() => require('../../storage/database/mysql-client'));
            const db = getMySQLClient();
            await this.flushMemoryNotificationsToDb(userId);
            const columns = await this.getNotificationColumns();
            const base = { is_read: true };
            if (columns.has('updated_at'))
                base.updated_at = new Date();
            await db.updateWhere('notifications', { id: notificationId, user_id: userId }, this.pickNotificationPayload(columns, base));
        }
        catch (dbError) {
            const notifications = sharedMemoryNotifications.get(userId) || [];
            const notification = notifications.find(n => n.id === notificationId);
            if (notification) {
                notification.is_read = true;
                notification.updated_at = new Date().toISOString();
            }
        }
        return { success: true };
    }
    async markAllAsRead(userId) {
        try {
            const { getMySQLClient } = await Promise.resolve().then(() => require('../../storage/database/mysql-client'));
            const db = getMySQLClient();
            await this.flushMemoryNotificationsToDb(userId);
            const notifications = await db.query('notifications', { user_id: userId, is_read: false });
            const columns = await this.getNotificationColumns();
            for (const n of notifications || []) {
                const base = { is_read: true };
                if (columns.has('updated_at'))
                    base.updated_at = new Date();
                await db.updateWhere('notifications', { id: n.id }, this.pickNotificationPayload(columns, base));
            }
        }
        catch (dbError) {
            const notifications = sharedMemoryNotifications.get(userId) || [];
            notifications.forEach(n => {
                n.is_read = true;
                n.updated_at = new Date().toISOString();
            });
        }
        return { success: true };
    }
    async deleteNotification(notificationId, userId) {
        try {
            const { getMySQLClient } = await Promise.resolve().then(() => require('../../storage/database/mysql-client'));
            const db = getMySQLClient();
            await this.flushMemoryNotificationsToDb(userId);
            await db.delete('notifications', { id: notificationId, user_id: userId });
        }
        catch (dbError) {
            this.removeMemoryNotification(userId, notificationId);
        }
        return { success: true };
    }
    async getUnreadCount(userId) {
        let count = 0;
        try {
            const { getMySQLClient } = await Promise.resolve().then(() => require('../../storage/database/mysql-client'));
            const db = getMySQLClient();
            await this.flushMemoryNotificationsToDb(userId);
            const notifications = await db.query('notifications', { user_id: userId, is_read: false });
            count = notifications?.length || 0;
        }
        catch (dbError) {
            const notifications = sharedMemoryNotifications.get(userId) || [];
            count = notifications.filter(n => !n.is_read).length;
        }
        return { count };
    }
    async getNotificationSettings(userId) {
        try {
            const { getMySQLClient } = await Promise.resolve().then(() => require('../../storage/database/mysql-client'));
            const db = getMySQLClient();
            const settings = await db.query('notification_settings', { user_id: userId });
            if (settings && settings.length > 0) {
                return settings[0];
            }
        }
        catch (dbError) {
        }
        return {
            message: true,
            like: true,
            follow: true,
            system: true
        };
    }
    async updateNotificationSettings(userId, settings) {
        try {
            const { getMySQLClient } = await Promise.resolve().then(() => require('../../storage/database/mysql-client'));
            const db = getMySQLClient();
            const existing = await db.query('notification_settings', { user_id: userId });
            if (existing && existing.length > 0) {
                await db.updateWhere('notification_settings', { user_id: userId }, {
                    ...settings,
                    updated_at: new Date()
                });
            }
            else {
                await db.insert('notification_settings', {
                    user_id: userId,
                    ...settings,
                    created_at: new Date(),
                    updated_at: new Date()
                });
            }
        }
        catch (dbError) {
        }
        return { success: true, ...settings };
    }
};
exports.NotificationService = NotificationService;
exports.NotificationService = NotificationService = __decorate([
    (0, common_1.Injectable)()
], NotificationService);
