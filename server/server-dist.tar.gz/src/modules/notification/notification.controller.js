"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationController = void 0;
const common_1 = require("@nestjs/common");
const notification_service_1 = require("./notification.service");
let NotificationController = class NotificationController {
    constructor(notificationService) {
        this.notificationService = notificationService;
    }
    async getNotifications(userId) {
        if (!userId)
            return { code: 401, data: null, message: '未登录' };
        try {
            if (this.notificationService) {
                const notifications = await this.notificationService.getNotifications(userId);
                return { code: 200, data: notifications, message: '获取成功' };
            }
        }
        catch (e) {
            console.error('[NotificationController] getNotifications error:', e.message);
        }
        return { code: 200, data: { list: [], total: 0, page: 1, pageSize: 20 }, message: '获取成功' };
    }
    async getUnreadCount(userId) {
        if (!userId)
            return { code: 200, data: { count: 0 }, message: '获取成功' };
        try {
            if (this.notificationService) {
                const count = await this.notificationService.getUnreadCount(userId);
                return { code: 200, data: count, message: '获取成功' };
            }
        }
        catch (e) {
            console.error('[NotificationController] getUnreadCount error:', e.message);
        }
        return { code: 200, data: { count: 0 }, message: '获取成功' };
    }
    async getSettings(userId) {
        if (!userId)
            return { code: 401, data: null, message: '未登录' };
        try {
            if (this.notificationService) {
                const settings = await this.notificationService.getNotificationSettings(userId);
                return { code: 200, data: settings, message: '获取成功' };
            }
        }
        catch (e) {
            console.error('[NotificationController] getSettings error:', e.message);
        }
        return { code: 200, data: { message: true, like: true, follow: true, system: true }, message: '获取成功' };
    }
    async updateSettings(userId, settings) {
        if (!userId)
            return { code: 401, data: null, message: '未登录' };
        try {
            if (this.notificationService) {
                const result = await this.notificationService.updateNotificationSettings(userId, settings);
                return { code: 200, data: result, message: '设置已更新' };
            }
        }
        catch (e) {
            console.error('[NotificationController] updateSettings error:', e.message);
        }
        return { code: 200, data: { success: true, ...settings }, message: '设置已更新' };
    }
    async markAsRead(notificationId, userId) {
        try {
            if (this.notificationService) {
                await this.notificationService.markAsRead(notificationId, userId);
            }
        }
        catch (e) {
            console.error('[NotificationController] markAsRead error:', e.message);
        }
        return { code: 200, data: null, message: '已标记已读' };
    }
    async urgeReview(userId, body) {
        try {
            if (this.notificationService && body?.orderId) {
                await this.notificationService.createNotification({
                    user_id: userId,
                    type: 'urge_review',
                    title: '催验收提醒',
                    content: `分身已完成内容"${body.contentTitle || '内容'}"的发布，请尽快验收`,
                    metadata: { orderId: body.orderId, triggeredBy: userId }
                });
            }
            return { code: 200, data: null, message: '催验收提醒已发送' };
        }
        catch (error) {
            return { code: 500, data: null, message: '发送失败：' + error.message };
        }
    }
    async markAllAsRead(userId) {
        try {
            if (this.notificationService) {
                await this.notificationService.markAllAsRead(userId);
            }
        }
        catch (e) {
            console.error('[NotificationController] markAllAsRead error:', e.message);
        }
        return { code: 200, data: null, message: '已全部标记已读' };
    }
    async createNotification(userId, body) {
        try {
            if (this.notificationService) {
                const notification = await this.notificationService.createNotification(userId, body);
                return { code: 200, data: notification, message: '创建成功' };
            }
        }
        catch (e) {
            console.error('[NotificationController] createNotification error:', e.message);
        }
        return { code: 500, data: null, message: '服务暂不可用' };
    }
};
exports.NotificationController = NotificationController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], NotificationController.prototype, "getNotifications", null);
__decorate([
    (0, common_1.Get)('unread-count'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], NotificationController.prototype, "getUnreadCount", null);
__decorate([
    (0, common_1.Get)('settings'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], NotificationController.prototype, "getSettings", null);
__decorate([
    (0, common_1.Put)('settings'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], NotificationController.prototype, "updateSettings", null);
__decorate([
    (0, common_1.Put)(':id/read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], NotificationController.prototype, "markAsRead", null);
__decorate([
    (0, common_1.Post)('urge-review'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], NotificationController.prototype, "urgeReview", null);
__decorate([
    (0, common_1.Put)('read-all'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], NotificationController.prototype, "markAllAsRead", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], NotificationController.prototype, "createNotification", null);
exports.NotificationController = NotificationController = __decorate([
    (0, common_1.Controller)('notifications'),
    __param(0, (0, common_1.Inject)(notification_service_1.NotificationService)),
    __metadata("design:paramtypes", [notification_service_1.NotificationService])
], NotificationController);
