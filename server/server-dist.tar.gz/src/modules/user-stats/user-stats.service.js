"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserStatsService = exports.sharedMemoryStats = exports.sharedMemoryAvatars = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const shared_cache_1 = require("../../common/shared-cache");
exports.sharedMemoryAvatars = new Map();
exports.sharedMemoryStats = new Map();
let UserStatsService = class UserStatsService {
    async getUserStatsOverview(userId) {
        let avatarList = [];
        let avatarCount = 0;
        let pendingOrders = 0;
        let generatedContents = 0;
        let totalEarnings = 0;
        let referralCode = '';
        let invitedCount = 0;
        let totalWorkHours = 0;
        let userResult = null;
        const syncFromSharedCache = () => {
            try {
                const sharedCache = (0, shared_cache_1.getSharedCache)();
                const cacheKey = `avatars_${userId}`;
                const cachedAvatars = sharedCache.get(cacheKey) || [];
                if (cachedAvatars.length > 0) {
                    const existingIds = new Set(avatarList.map(a => a.id));
                    const newAvatars = cachedAvatars.filter((a) => !existingIds.has(a.id));
                    if (newAvatars.length > 0) {
                        avatarList = [...avatarList, ...newAvatars];
                        avatarCount = avatarList.length;
                        console.log('[UserStats] 从共享缓存同步 AvatarService 数据:', newAvatars.length);
                    }
                }
            }
            catch (e) {
                console.warn('[UserStats] 同步共享缓存失败:', e.message);
            }
        };
        let db = null;
        try {
            db = (0, mysql_client_1.getMySQLClient)();
            const dbAvatars = await db.query('avatars', { user_id: userId, status: 'active' });
            console.log('[UserStats] DB avatars for', userId, ':', dbAvatars?.length || 0);
            avatarList = dbAvatars || [];
            syncFromSharedCache();
            const avatarIds = avatarList.map((a) => a.id);
            avatarCount = avatarList.length;
            if (avatarIds.length > 0) {
                const avatarIdList = avatarIds.map((id) => `'${id}'`).join(',');
                try {
                    const pendingResult = await db.query(`SELECT COUNT(*) as cnt FROM order_dispatch_requests r
             INNER JOIN orders o ON r.order_id = o.id
               AND o.status IN ('pending', 'pending_payment', 'awaiting_acceptance', 'pending_acceptance', 'accepted', 'in_progress')
             WHERE r.avatar_id IN (${avatarIdList}) AND r.status = 'pending'`);
                    pendingOrders = pendingResult?.[0]?.cnt || 0;
                }
                catch (e) {
                    console.error('[UserStats] 查询待接订单失败:', e.message);
                    pendingOrders = 0;
                }
            }
            if (avatarIds.length > 0) {
                const avatarIdList = avatarIds.map((id) => `'${id}'`).join(',');
                try {
                    const contentResult = await db.query(`SELECT COUNT(*) as cnt FROM content_generation_requests
             WHERE avatar_id IN (${avatarIdList})
               AND status NOT IN ('pending', 'failed', 'cancelled')`);
                    generatedContents = contentResult?.[0]?.cnt || 0;
                }
                catch (e) {
                    generatedContents = 0;
                }
            }
            userResult = await db.queryOne('users', { id: userId });
            const earningsResult = await db.queryWhere('earnings', `user_id = '${userId}' AND status IN ('settled', 'completed')`);
            totalEarnings = earningsResult?.reduce((sum, e) => sum + Number(e.amount || 0), 0) || 0;
            try {
                const referralResult = await db.queryWhere('referrals', `referrer_id = '${userId}' AND status = 'completed'`);
                invitedCount = referralResult?.length || 0;
                if (userResult?.referral_code || userResult?.referralCode) {
                    referralCode = userResult.referral_code || userResult.referralCode;
                }
                else {
                    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
                    referralCode = '';
                    for (let i = 0; i < 6; i++) {
                        referralCode += chars.charAt(Math.floor(Math.random() * chars.length));
                    }
                    await db.updateWhere('users', { id: userId }, {
                        referral_code: referralCode,
                        updated_at: new Date()
                    });
                }
            }
            catch (e) { }
            if (avatarIds.length > 0) {
                const avatarIdList = avatarIds.map((id) => `'${id}'`).join(',');
                try {
                    const contentResult = await db.query(`SELECT COUNT(*) as cnt FROM content_generation_requests
             WHERE avatar_id IN (${avatarIdList})
               AND status IN ('completed', 'approved', 'published', 'awaiting_acceptance', 'settled', 'done')`);
                    const completedCount = contentResult?.[0]?.cnt || 0;
                    totalWorkHours = Math.round(completedCount * 0.5 * 10) / 10;
                }
                catch (e) { }
            }
            exports.sharedMemoryAvatars.set(userId, avatarList);
            exports.sharedMemoryStats.set(userId, { pendingOrders, generatedContents, totalEarnings });
        }
        catch (error) {
            avatarList = exports.sharedMemoryAvatars.get(userId) || [];
            avatarCount = avatarList.length;
            const cachedStats = exports.sharedMemoryStats.get(userId) || {};
            pendingOrders = cachedStats.pendingOrders || 0;
            generatedContents = cachedStats.generatedContents || 0;
            totalEarnings = cachedStats.totalEarnings || 0;
        }
        let avatarStatsResult = [];
        if (db) {
            try {
                for (const a of avatarList) {
                    let avatarTotalOrders = 0;
                    let avatarCompletedOrders = 0;
                    let avatarEarnings = 0;
                    try {
                        const statsResult = await db.query(`SELECT
                 COUNT(DISTINCT cgr.order_id) as total_orders,
                 COUNT(DISTINCT CASE WHEN cgr.status IN ('completed','approved','published','awaiting_acceptance','settled','done','preview') THEN cgr.order_id END) as completed_orders
               FROM content_generation_requests cgr
               WHERE cgr.avatar_id = ?
                 AND cgr.status NOT IN ('pending', 'cancelled')`, [a.id]);
                        avatarTotalOrders = statsResult?.[0]?.totalOrders || statsResult?.[0]?.total_orders || 0;
                        avatarCompletedOrders = statsResult?.[0]?.completedOrders || statsResult?.[0]?.completed_orders || 0;
                    }
                    catch (e) {
                        console.error(`[user-stats] avatar stats error for ${a.id}:`, e.message);
                    }
                    try {
                        const earnResult = await db.query(`SELECT COALESCE(SUM(amount), 0) as total FROM earnings
               WHERE avatar_id = ? AND status IN ('settled', 'completed')`, [a.id]);
                        avatarEarnings = Number(earnResult?.[0]?.total || 0);
                    }
                    catch (e) { }
                    avatarStatsResult.push({
                        id: a.id,
                        totalOrders: avatarTotalOrders,
                        completedOrders: avatarCompletedOrders,
                        totalEarnings: avatarEarnings,
                    });
                }
            }
            catch (e) {
                console.error('[user-stats] avatar stats error:', e.message);
            }
        }
        const avatarStatsMap = new Map(avatarStatsResult.map((s) => [s.id, s]));
        const allHostingEnabled = avatarCount > 0 && avatarList.every((a) => a.isHosted === 1 || a.hostingEnabled === 1);
        return {
            avatarCount,
            pendingOrders,
            generatedContents,
            totalEarnings,
            allHostingEnabled,
            avatars: avatarList.map((a) => {
                const stats = avatarStatsMap.get(a.id);
                return {
                    id: a.id,
                    name: a.name || a.nickname || '分身',
                    avatar: a.avatar_url || a.avatarUrl || '',
                    status: a.status || 'active',
                    totalOrders: stats?.totalOrders || 0,
                    completedOrders: stats?.completedOrders || 0,
                    totalEarnings: stats?.totalEarnings || 0,
                };
            }),
            nickname: userResult?.nickname || '',
            avatar: userResult?.avatar || '',
            referralCode,
            invitedCount,
            totalWorkHours
        };
    }
    async getAvatarOrders(userId, avatarId) {
        let avatarList = [];
        let orders = [];
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const avatars = await db.query('avatars', { user_id: userId, status: 'active' });
            avatarList = avatars || [];
            const avatarIds = avatarList.map((a) => a.id);
            let where = '';
            if (avatarId) {
                where = `avatar_id = '${avatarId}'`;
            }
            else if (avatarIds.length > 0) {
                const avatarIdList = avatarIds.map((id) => `'${id}'`).join(',');
                where = `avatar_id IN (${avatarIdList})`;
            }
            else {
                return { orders: [], avatars: [] };
            }
            const ordersResult = await db.queryWhere('orders', where, {
                orderBy: 'created_at',
                orderDirection: 'desc',
                limit: 50
            });
            orders = ordersResult?.data || [];
            exports.sharedMemoryAvatars.set(userId, avatarList);
        }
        catch (error) {
            avatarList = exports.sharedMemoryAvatars.get(userId) || [];
        }
        const ordersWithAvatar = orders.map((order) => {
            const avatar = avatarList.find((a) => a.id === order.avatar_id);
            return {
                ...order,
                avatar_name: avatar?.name || '未知分身',
                avatar_url: avatar?.avatar_url || ''
            };
        });
        return {
            orders: ordersWithAvatar,
            avatars: avatarList.map((a) => ({
                id: a.id,
                name: a.name,
                avatarUrl: a.avatar_url || ''
            }))
        };
    }
    async getAvatarContents(userId, avatarId) {
        let avatarList = [];
        let contents = [];
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const avatars = await db.query('avatars', { user_id: userId, status: 'active' });
            avatarList = avatars || [];
            const avatarIds = avatarList.map((a) => a.id);
            let where = '';
            if (avatarId) {
                where = `avatar_id = '${avatarId}'`;
            }
            else if (avatarIds.length > 0) {
                const avatarIdList = avatarIds.map((id) => `'${id}'`).join(',');
                where = `avatar_id IN (${avatarIdList})`;
            }
            else {
                return { contents: [], avatars: [] };
            }
            try {
                const avatarIdParams = avatarIds.map(() => '?').join(',');
                const sql = `SELECT id, order_id, avatar_id, content_type, platform, platforms, status, created_at, updated_at, video_url, images, publish_feedback, SUBSTRING(content, 1, 200) as content, CASE WHEN images IS NOT NULL AND images != '' AND images != '[]' THEN JSON_LENGTH(images) ELSE 0 END as image_count FROM content_generation_requests WHERE avatar_id IN (${avatarIdParams}) ORDER BY created_at DESC LIMIT 50`;
                const t0 = Date.now();
                const result = await db.query(sql, avatarIds);
                console.log(`[getAvatarContents] SQL query took ${Date.now() - t0}ms`);
                contents = Array.isArray(result) ? result : (result?.data || []);
            }
            catch (e) {
                contents = [];
            }
            exports.sharedMemoryAvatars.set(userId, avatarList);
        }
        catch (error) {
            avatarList = exports.sharedMemoryAvatars.get(userId) || [];
        }
        const contentsWithAvatar = contents.map((content) => {
            const aid = content.avatarId || content.avatar_id;
            const avatar = avatarList.find((a) => a.id === aid);
            let platforms = content.platforms || content.platform;
            if (typeof platforms === 'string') {
                try {
                    platforms = JSON.parse(platforms);
                }
                catch {
                    platforms = [platforms];
                }
            }
            if (!Array.isArray(platforms)) {
                platforms = platforms ? [String(platforms)] : [];
            }
            let images = content.images;
            if (typeof images === 'string') {
                try {
                    images = JSON.parse(images);
                }
                catch {
                    images = [];
                }
            }
            if (!Array.isArray(images))
                images = images ? [String(images)] : [];
            images = images.filter((img) => typeof img === 'string' && img.startsWith('http'));
            return {
                ...content,
                orderId: content.orderId || content.order_id || '',
                avatarId: aid,
                avatarName: avatar?.name || avatar?.userName || '未知分身',
                avatar_name: avatar?.name || avatar?.userName || '未知分身',
                avatarUrl: avatar?.avatarUrl || avatar?.avatar_url || '',
                avatar_url: avatar?.avatarUrl || avatar?.avatar_url || '',
                contentType: content.contentType || content.content_type || 'image_text',
                content_type: content.contentType || content.content_type || 'image_text',
                platform: content.platform || (Array.isArray(platforms) ? platforms[0] : '') || '',
                platforms,
                images,
                status: content.status,
                createdAt: content.createdAt || content.created_at || '',
            };
        });
        return {
            contents: contentsWithAvatar,
            avatars: avatarList.map((a) => ({
                id: a.id,
                name: a.name,
                avatarUrl: a.avatar_url || ''
            }))
        };
    }
};
exports.UserStatsService = UserStatsService;
exports.UserStatsService = UserStatsService = __decorate([
    (0, common_1.Injectable)()
], UserStatsService);
