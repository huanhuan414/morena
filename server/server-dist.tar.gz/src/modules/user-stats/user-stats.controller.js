"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserStatsController = void 0;
const common_1 = require("@nestjs/common");
const user_stats_service_1 = require("./user-stats.service");
let UserStatsController = class UserStatsController {
    constructor(userStatsService) {
        this.userStatsService = userStatsService;
    }
    async getOverview(userId) {
        if (!userId)
            return { code: 401, data: null, message: '未登录' };
        try {
            if (this.userStatsService) {
                const stats = await this.userStatsService.getUserStatsOverview(userId);
                return { code: 200, data: stats, message: '获取成功' };
            }
        }
        catch (e) {
            console.error('[UserStatsController] getOverview error:', e.message);
        }
        return { code: 200, data: { avatarCount: 0, pendingOrders: 0, generatedContents: 0, totalEarnings: 0, totalWorkHours: 0 }, message: '获取成功' };
    }
    async getOrders(userId, avatarId) {
        if (!userId)
            return { code: 401, data: null, message: '未登录' };
        try {
            if (this.userStatsService) {
                const result = await this.userStatsService.getAvatarOrders(userId, avatarId);
                return { code: 200, data: result, message: '获取成功' };
            }
        }
        catch (e) {
            console.error('[UserStatsController] getOrders error:', e.message);
        }
        return { code: 200, data: { list: [], total: 0 }, message: '获取成功' };
    }
    async getContents(userId, avatarId) {
        if (!userId)
            return { code: 401, data: null, message: '未登录' };
        try {
            if (this.userStatsService) {
                const result = await this.userStatsService.getAvatarContents(userId, avatarId);
                return { code: 200, data: result, message: '获取成功' };
            }
        }
        catch (e) {
            console.error('[UserStatsController] getContents error:', e.message);
        }
        return { code: 200, data: { list: [], total: 0 }, message: '获取成功' };
    }
};
exports.UserStatsController = UserStatsController;
__decorate([
    (0, common_1.Get)('overview'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UserStatsController.prototype, "getOverview", null);
__decorate([
    (0, common_1.Get)('orders'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], UserStatsController.prototype, "getOrders", null);
__decorate([
    (0, common_1.Get)('contents'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], UserStatsController.prototype, "getContents", null);
exports.UserStatsController = UserStatsController = __decorate([
    (0, common_1.Controller)('user-stats'),
    __param(0, (0, common_1.Inject)(user_stats_service_1.UserStatsService)),
    __metadata("design:paramtypes", [user_stats_service_1.UserStatsService])
], UserStatsController);
