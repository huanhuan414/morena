"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EarningsService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const crypto = require("crypto");
let EarningsService = class EarningsService {
    async createEarning(userId, data) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const id = crypto.randomUUID();
        const insertResult = await db.insert('earnings', {
            id,
            user_id: userId,
            order_id: data.order_id || data.reference_id || null,
            order_title: data.order_title || '',
            avatar_id: data.avatar_id || null,
            avatar_name: data.avatar_name || '',
            type: data.type,
            amount: data.amount,
            description: data.description || '',
            status: 'pending',
            created_at: new Date(),
        });
        if (insertResult.error) {
            console.error('[EarningsService] createEarning 失败:', insertResult.error);
        }
        return { id };
    }
    async getEarnings(userId, page = 1, pageSize = 20) {
        const pool = (0, mysql_client_1.getPool)();
        const limit = Math.max(1, Number(pageSize) || 20);
        const offset = (Math.max(1, Number(page) || 1) - 1) * limit;
        const [rows] = await pool.query(`SELECT * FROM earnings WHERE user_id = ? ORDER BY created_at DESC LIMIT ${limit} OFFSET ${offset}`, [userId]);
        const [countRows] = await pool.query('SELECT COUNT(*) as total FROM earnings WHERE user_id = ?', [userId]);
        return {
            list: rows || [],
            total: countRows[0]?.total || 0,
            page,
            pageSize
        };
    }
    async getEarningStats(userId) {
        const pool = (0, mysql_client_1.getPool)();
        const [rows] = await pool.query('SELECT status, SUM(amount) as total_amount FROM earnings WHERE user_id = ? GROUP BY status', [userId]);
        let totalEarnings = 0;
        let pendingAmount = 0;
        let settledAmount = 0;
        for (const row of rows) {
            const amount = Number(row.total_amount) || 0;
            if (row.status === 'settled' || row.status === 'completed') {
                settledAmount += amount;
                totalEarnings += amount;
            }
            else if (row.status === 'pending') {
                pendingAmount += amount;
            }
        }
        const [userRows] = await pool.query('SELECT balance, frozen_balance FROM users WHERE id = ?', [userId]);
        const availableBalance = Number(userRows[0]?.balance) || 0;
        const frozenBalance = Number(userRows[0]?.frozen_balance) || 0;
        return {
            total_earnings: totalEarnings,
            pending_earnings: pendingAmount,
            available_earnings: availableBalance,
            frozen_balance: frozenBalance,
        };
    }
    async getLeaderboard() {
        const pool = (0, mysql_client_1.getPool)();
        const [rows] = await pool.query(`SELECT e.user_id, u.nickname, u.phone, SUM(e.amount) as total
       FROM earnings e
       LEFT JOIN users u ON e.user_id = u.id
       WHERE e.status = 'settled'
       GROUP BY e.user_id, u.nickname, u.phone
       ORDER BY total DESC
       LIMIT 50`);
        return {
            items: rows || [],
            total: rows?.length || 0
        };
    }
    async updateEarningStatus(earningId, status) {
        const pool = (0, mysql_client_1.getPool)();
        if (status === 'settled' || status === 'completed') {
            const [rows] = await pool.query('SELECT user_id, amount FROM earnings WHERE id = ?', [earningId]);
            const earning = rows[0];
            if (earning) {
                await pool.query('UPDATE users SET balance = balance + ? WHERE id = ?', [earning.amount, earning.user_id]);
            }
        }
        await pool.query('UPDATE earnings SET status = ? WHERE id = ?', [status, earningId]);
        return { success: true };
    }
    async requestWithdrawal(userId, amount, paymentMethod, paymentAccount) {
        const pool = (0, mysql_client_1.getPool)();
        const [userRows] = await pool.query('SELECT balance, frozen_balance FROM users WHERE id = ?', [userId]);
        const balance = Number(userRows[0]?.balance) || 0;
        if (amount <= 0) {
            throw new Error('提现金额必须大于0');
        }
        if (amount > balance) {
            throw new Error(`余额不足，当前可用余额: ${balance}`);
        }
        await pool.query('UPDATE users SET balance = balance - ?, frozen_balance = frozen_balance + ? WHERE id = ?', [amount, amount, userId]);
        const id = crypto.randomUUID();
        await pool.query(`INSERT INTO withdrawals (id, user_id, amount, bank_name, bank_account, bank_holder, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)`, [id, userId, amount, paymentMethod === 'wechat' ? '微信' : '银行卡', paymentAccount, '', new Date()]);
        return { id, amount, status: 'pending' };
    }
};
exports.EarningsService = EarningsService;
exports.EarningsService = EarningsService = __decorate([
    (0, common_1.Injectable)()
], EarningsService);
