"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EarningsController = void 0;
const common_1 = require("@nestjs/common");
const earnings_service_1 = require("./earnings.service");
let EarningsController = class EarningsController {
    constructor(earningsService) {
        this.earningsService = earningsService;
    }
    async getLeaderboard(limit) {
        const limitNum = limit ? parseInt(limit, 10) : 50;
        const result = await this.earningsService.getLeaderboard(limitNum);
        return {
            code: 200,
            msg: 'success',
            data: result
        };
    }
    async getOverview(userId) {
        if (!userId) {
            return {
                code: 401,
                msg: '未登录',
                data: { total_earnings: 0, pending_earnings: 0, available_earnings: 0 }
            };
        }
        const result = await this.earningsService.getEarningStats(userId);
        return {
            code: 200,
            msg: 'success',
            data: result
        };
    }
    async getEarnings(userId, page, pageSize) {
        if (!userId) {
            return { code: 401, msg: '未登录', data: { list: [], total: 0, page: 1, pageSize: 20 } };
        }
        const result = await this.earningsService.getEarnings(userId, parseInt(page) || 1, parseInt(pageSize) || 20);
        return { code: 200, msg: 'success', data: result };
    }
    async requestWithdrawal(userId, body) {
        if (!userId) {
            return { code: 401, msg: '未登录', data: null };
        }
        try {
            const result = await this.earningsService.requestWithdrawal(userId, body.amount, body.paymentMethod || 'wechat', body.paymentAccount || '');
            return { code: 200, msg: '提现申请已提交', data: result };
        }
        catch (e) {
            return { code: 400, msg: e.message, data: null };
        }
    }
};
exports.EarningsController = EarningsController;
__decorate([
    (0, common_1.Get)('leaderboard'),
    __param(0, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EarningsController.prototype, "getLeaderboard", null);
__decorate([
    (0, common_1.Get)('overview'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EarningsController.prototype, "getOverview", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], EarningsController.prototype, "getEarnings", null);
__decorate([
    (0, common_1.Post)('withdraw'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], EarningsController.prototype, "requestWithdrawal", null);
exports.EarningsController = EarningsController = __decorate([
    (0, common_1.Controller)('earnings'),
    __param(0, (0, common_1.Inject)('EARNINGS_SERVICE')),
    __metadata("design:paramtypes", [earnings_service_1.EarningsService])
], EarningsController);
