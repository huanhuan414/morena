"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminController = void 0;
const common_1 = require("@nestjs/common");
const admin_service_1 = require("./admin.service");
let AdminController = class AdminController {
    constructor(adminService) {
        this.adminService = adminService;
    }
    getAdminAuthHeader(headers) {
        const authorization = headers.authorization ?? headers.Authorization;
        const adminToken = headers['admin_token'] ?? headers['admin-token'] ?? headers['Admin-Token'];
        const firstValue = (value) => Array.isArray(value) ? value[0] : value;
        return firstValue(authorization) ?? firstValue(adminToken);
    }
    async login(username, password) {
        const result = await this.adminService.login(username, password);
        return {
            code: result.success ? 200 : 401,
            data: result.data,
            message: result.message
        };
    }
    async getDashboardStats(headers) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const stats = await this.adminService.getDashboardStats();
        return {
            code: 200,
            data: stats,
            message: 'success'
        };
    }
    async getUsers(headers, page = 1, limit = 20, keyword) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getUsers(page, limit, keyword);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async getUserDetail(headers, userId) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const user = await this.adminService.getUserDetail(userId);
        return {
            code: user ? 200 : 404,
            data: user,
            message: user ? 'success' : '用户不存在'
        };
    }
    async getUserStats(headers, userId) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const stats = await this.adminService.getUserStats(userId);
        return {
            code: 200,
            data: stats,
            message: 'success'
        };
    }
    async banUser(headers, userId, action) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.banUser(userId, action === 'ban');
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message || '操作完成'
        };
    }
    async getAvatars(headers, page = 1, limit = 20, keyword, status) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getAvatars(page, limit);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async toggleAvatarStatus(headers, avatarId, status) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.updateAvatarStatus(avatarId, status);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getOrders(headers, page = 1, limit = 20, keyword, status) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getOrders(page, limit, status);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async getAcceptanceOverdueOrders(headers, hours = 6, limit = 50) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getAcceptanceOverdueOrders(Number(hours) || 6, Number(limit) || 50);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async getSupplyQueue(headers, queue, limit = 20) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getSupplyQueue(queue, Number(limit) || 20);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async updateOrderStatus(headers, orderId, status) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.updateOrderStatus(orderId, status);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getSkills(headers) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getSkills(1, 100);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async createSkill(headers, data) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.createSkill(data);
        return {
            code: result.success ? 200 : 400,
            data: result.data,
            message: result.message
        };
    }
    async updateSkill(headers, id, data) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.updateSkill(id, data);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async deleteSkill(headers, id) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.deleteSkill(id);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async toggleSkillStatus(headers, id, status) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.updateSkillStatus(id, status);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getPosts(headers, status, search) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const page = parseInt(search || '1', 10);
        const result = await this.adminService.getPosts(page, 20, status);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async reviewPost(headers, id, status) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.reviewPost(id, status);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async deletePost(headers, id) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.deletePost(id);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getFinanceStats(headers) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const stats = await this.adminService.getFinanceStats();
        return {
            code: 200,
            data: stats,
            message: 'success'
        };
    }
    async getTransactions(headers, type, pageStr) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const page = parseInt(pageStr || '1', 10);
        const result = await this.adminService.getTransactions(page, 20, type);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async approveWithdraw(headers, id) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.approveWithdraw(id);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async rejectWithdraw(headers, id, reason) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.rejectWithdraw(id, reason);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getReferralStats(headers, days) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const stats = await this.adminService.getReferralStats(Number(days) || 14);
        return {
            code: 200,
            data: stats,
            message: 'success'
        };
    }
    async getReferrers(headers) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getReferrers(1, 100);
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async updateReferralSettings(headers, rate) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.updateCommissionRate(rate);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async getGrowthCampaign(headers) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const config = await this.adminService.getGrowthCampaignConfig();
        return {
            code: 200,
            data: config,
            message: 'success'
        };
    }
    async updateGrowthCampaign(headers, payload) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.updateGrowthCampaignConfig(payload);
        return {
            code: result.success ? 200 : 400,
            data: result.data,
            message: result.success ? '配置更新成功' : '配置更新失败'
        };
    }
    async getGrowthCampaignStats(headers, days) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const stats = await this.adminService.getGrowthCampaignStats(Number(days) || 7);
        return {
            code: 200,
            data: stats,
            message: 'success'
        };
    }
    async getAdmins(headers) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.getAdmins();
        return {
            code: 200,
            data: result,
            message: 'success'
        };
    }
    async addAdmin(headers, username, password) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.addAdmin(username, password);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async deleteAdmin(headers, id) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.deleteAdmin(id);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message
        };
    }
    async changePassword(headers, oldPassword, newPassword) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.changePassword(admin.id, newPassword);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.message || '密码修改成功'
        };
    }
    async getConfig(headers) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const config = await this.adminService.getSystemConfig();
        return {
            code: 200,
            data: config,
            message: 'success'
        };
    }
    async updateConfig(headers, config) {
        const admin = await this.adminService.verifyToken(this.getAdminAuthHeader(headers));
        if (!admin) {
            return { code: 401, data: null, message: '未授权' };
        }
        const result = await this.adminService.updateSystemConfig(config);
        return {
            code: result.success ? 200 : 400,
            data: null,
            message: result.success ? '配置更新成功' : '配置更新失败'
        };
    }
};
exports.AdminController = AdminController;
__decorate([
    (0, common_1.Post)('login'),
    __param(0, (0, common_1.Body)('username')),
    __param(1, (0, common_1.Body)('password')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "login", null);
__decorate([
    (0, common_1.Get)('dashboard/stats'),
    __param(0, (0, common_1.Headers)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getDashboardStats", null);
__decorate([
    (0, common_1.Get)('users'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('limit')),
    __param(3, (0, common_1.Query)('keyword')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Number, Number, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getUsers", null);
__decorate([
    (0, common_1.Get)('users/:id'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getUserDetail", null);
__decorate([
    (0, common_1.Get)('users/:id/stats'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getUserStats", null);
__decorate([
    (0, common_1.Post)('users/ban'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Body)('user_id')),
    __param(2, (0, common_1.Body)('action')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "banUser", null);
__decorate([
    (0, common_1.Get)('avatars'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('limit')),
    __param(3, (0, common_1.Query)('keyword')),
    __param(4, (0, common_1.Query)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Number, Number, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getAvatars", null);
__decorate([
    (0, common_1.Post)('avatars/toggle-status'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Body)('avatar_id')),
    __param(2, (0, common_1.Body)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "toggleAvatarStatus", null);
__decorate([
    (0, common_1.Get)('orders'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('limit')),
    __param(3, (0, common_1.Query)('keyword')),
    __param(4, (0, common_1.Query)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Number, Number, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getOrders", null);
__decorate([
    (0, common_1.Get)('orders/acceptance-overdue'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Query)('hours')),
    __param(2, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Number, Number]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getAcceptanceOverdueOrders", null);
__decorate([
    (0, common_1.Get)('queues/supply'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Query)('queue')),
    __param(2, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Number]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getSupplyQueue", null);
__decorate([
    (0, common_1.Post)('orders/update-status'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Body)('order_id')),
    __param(2, (0, common_1.Body)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "updateOrderStatus", null);
__decorate([
    (0, common_1.Get)('skills'),
    __param(0, (0, common_1.Headers)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getSkills", null);
__decorate([
    (0, common_1.Post)('skills'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "createSkill", null);
__decorate([
    (0, common_1.Put)('skills/:id'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "updateSkill", null);
__decorate([
    (0, common_1.Delete)('skills/:id'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "deleteSkill", null);
__decorate([
    (0, common_1.Put)('skills/:id/status'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "toggleSkillStatus", null);
__decorate([
    (0, common_1.Get)('posts'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Query)('status')),
    __param(2, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getPosts", null);
__decorate([
    (0, common_1.Put)('posts/:id/review'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "reviewPost", null);
__decorate([
    (0, common_1.Delete)('posts/:id'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "deletePost", null);
__decorate([
    (0, common_1.Get)('finance/stats'),
    __param(0, (0, common_1.Headers)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getFinanceStats", null);
__decorate([
    (0, common_1.Get)('finance/transactions'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Query)('type')),
    __param(2, (0, common_1.Query)('page')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getTransactions", null);
__decorate([
    (0, common_1.Post)('finance/withdraw/:id/approve'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "approveWithdraw", null);
__decorate([
    (0, common_1.Post)('finance/withdraw/:id/reject'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)('reason')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "rejectWithdraw", null);
__decorate([
    (0, common_1.Get)('referral/stats'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Query)('days')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getReferralStats", null);
__decorate([
    (0, common_1.Get)('referral/list'),
    __param(0, (0, common_1.Headers)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getReferrers", null);
__decorate([
    (0, common_1.Put)('referral/settings'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Body)('commissionRate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Number]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "updateReferralSettings", null);
__decorate([
    (0, common_1.Get)('activities/campaign'),
    __param(0, (0, common_1.Headers)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getGrowthCampaign", null);
__decorate([
    (0, common_1.Put)('activities/campaign'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "updateGrowthCampaign", null);
__decorate([
    (0, common_1.Get)('activities/campaign/stats'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Query)('days')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getGrowthCampaignStats", null);
__decorate([
    (0, common_1.Get)('settings/admins'),
    __param(0, (0, common_1.Headers)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getAdmins", null);
__decorate([
    (0, common_1.Post)('settings/admins'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Body)('username')),
    __param(2, (0, common_1.Body)('password')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "addAdmin", null);
__decorate([
    (0, common_1.Delete)('settings/admins/:id'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "deleteAdmin", null);
__decorate([
    (0, common_1.Put)('settings/password'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Body)('oldPassword')),
    __param(2, (0, common_1.Body)('newPassword')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "changePassword", null);
__decorate([
    (0, common_1.Get)('settings/config'),
    __param(0, (0, common_1.Headers)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "getConfig", null);
__decorate([
    (0, common_1.Put)('settings/config'),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AdminController.prototype, "updateConfig", null);
exports.AdminController = AdminController = __decorate([
    (0, common_1.Controller)('admin'),
    __param(0, (0, common_1.Inject)(admin_service_1.AdminService)),
    __metadata("design:paramtypes", [admin_service_1.AdminService])
], AdminController);
