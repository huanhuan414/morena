"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActivitiesController = void 0;
const common_1 = require("@nestjs/common");
const activities_service_1 = require("./activities.service");
let ActivitiesController = class ActivitiesController {
    constructor(activitiesService) {
        this.activitiesService = activitiesService;
    }
    async getRecentActivities(req, limit) {
        const userId = req.headers['x-user-id'] || req.query.userId || 'dev_user';
        const limitNum = limit ? parseInt(limit, 10) : 10;
        try {
            if (this.activitiesService) {
                const activities = await this.activitiesService.getRecentActivities(userId, limitNum);
                return { code: 200, msg: 'success', data: activities };
            }
        }
        catch (e) {
            console.error('[ActivitiesController] getRecentActivities error:', e.message);
        }
        return { code: 200, msg: 'success', data: [] };
    }
    async getActiveCampaign() {
        try {
            const campaign = await this.activitiesService.getActiveCampaign();
            return { code: 200, msg: 'success', data: campaign };
        }
        catch (e) {
            console.error('[ActivitiesController] getActiveCampaign error:', e.message);
            return { code: 200, msg: 'success', data: null };
        }
    }
    async trackCampaign(req, eventType) {
        const userId = req.headers['x-user-id'] || req.body?.userId || req.query?.userId;
        const normalizedEventType = String(eventType || '').trim();
        if (!normalizedEventType) {
            return { code: 200, msg: 'success', data: { skipped: true } };
        }
        try {
            const result = await this.activitiesService.trackCampaignEvent(userId, normalizedEventType);
            return { code: 200, msg: 'success', data: result };
        }
        catch (e) {
            console.error('[ActivitiesController] trackCampaign error:', e.message);
            return { code: 200, msg: 'success', data: { skipped: true } };
        }
    }
};
exports.ActivitiesController = ActivitiesController;
__decorate([
    (0, common_1.Get)('recent'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], ActivitiesController.prototype, "getRecentActivities", null);
__decorate([
    (0, common_1.Get)('campaign/active'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ActivitiesController.prototype, "getActiveCampaign", null);
__decorate([
    (0, common_1.Post)('campaign/track'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)('eventType')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], ActivitiesController.prototype, "trackCampaign", null);
exports.ActivitiesController = ActivitiesController = __decorate([
    (0, common_1.Controller)('activities'),
    __param(0, (0, common_1.Inject)(activities_service_1.ActivitiesService)),
    __metadata("design:paramtypes", [activities_service_1.ActivitiesService])
], ActivitiesController);
