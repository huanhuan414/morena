"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
let TaskService = class TaskService {
    async createTask(userId, data) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const id = crypto.randomUUID();
        await db.insert('tasks', {
            id,
            user_id: userId,
            avatar_id: data.avatar_id || null,
            type: data.type,
            status: 'pending',
            config: JSON.stringify(data.config || {}),
            created_at: new Date(),
            updated_at: new Date()
        });
        return { id };
    }
    async getTasks(userId, status) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const filters = { user_id: userId };
        if (status) {
            filters.status = status;
        }
        return await db.query('tasks', filters);
    }
    async getTask(taskId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        return await db.queryOne('tasks', { id: taskId });
    }
    async updateTaskStatus(taskId, status, result) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const updateData = {
            status,
            updated_at: new Date()
        };
        if (result) {
            updateData.result = JSON.stringify(result);
        }
        await db.updateWhere('tasks', { id: taskId }, updateData);
        return { success: true };
    }
    async getTaskStats(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const tasks = await db.query('tasks', { user_id: userId });
        const stats = {
            total: tasks?.length || 0,
            pending: 0,
            processing: 0,
            completed: 0,
            failed: 0
        };
        if (tasks) {
            tasks.forEach((task) => {
                if (task.status === 'pending')
                    stats.pending++;
                else if (task.status === 'processing')
                    stats.processing++;
                else if (task.status === 'completed')
                    stats.completed++;
                else if (task.status === 'failed')
                    stats.failed++;
            });
        }
        return stats;
    }
};
exports.TaskService = TaskService;
exports.TaskService = TaskService = __decorate([
    (0, common_1.Injectable)()
], TaskService);
const crypto = require("crypto");
