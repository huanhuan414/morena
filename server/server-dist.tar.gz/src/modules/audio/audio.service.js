"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AudioService = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
let AudioService = class AudioService {
    constructor() {
        this.config = new coze_coding_dev_sdk_1.Config();
        this.asrClient = new coze_coding_dev_sdk_1.ASRClient(this.config);
    }
    async recognizeSpeech(file) {
        console.log('[AudioService] 开始语音识别');
        console.log('[AudioService] 文件大小:', file.size, 'bytes');
        console.log('[AudioService] 文件类型:', file.mimetype);
        try {
            let audioUrl;
            let audioBase64;
            if (file.path) {
                console.log('[AudioService] 使用文件路径:', file.path);
                const fs = await Promise.resolve().then(() => require('fs'));
                const buffer = fs.readFileSync(file.path);
                audioBase64 = buffer.toString('base64');
            }
            else if (file.buffer) {
                console.log('[AudioService] 使用文件buffer');
                audioBase64 = file.buffer.toString('base64');
            }
            else {
                throw new Error('无法读取音频文件');
            }
            console.log('[AudioService] Base64长度:', audioBase64.length);
            const result = await this.asrClient.recognize({
                uid: 'user-' + Date.now(),
                base64Data: audioBase64,
            });
            console.log('[AudioService] ASR识别成功:', result.text);
            return {
                text: result.text,
                duration: result.duration,
            };
        }
        catch (error) {
            console.error('[AudioService] 语音识别错误:', error);
            throw error;
        }
    }
    async recognizeFromUrl(url) {
        console.log('[AudioService] 从URL识别:', url);
        try {
            const result = await this.asrClient.recognize({
                uid: 'user-' + Date.now(),
                url: url,
            });
            console.log('[AudioService] ASR识别成功:', result.text);
            return {
                text: result.text,
                duration: result.duration,
            };
        }
        catch (error) {
            console.error('[AudioService] 语音识别错误:', error);
            throw error;
        }
    }
};
exports.AudioService = AudioService;
exports.AudioService = AudioService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], AudioService);
