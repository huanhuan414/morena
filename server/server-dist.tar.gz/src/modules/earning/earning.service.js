"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EarningService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const crypto = require("crypto");
let EarningService = class EarningService {
    async getEarningsOverview(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const user = await db.queryOne('users', { id: userId });
        const completedEarnings = await db.queryWhere('earnings', `user_id = '${userId}' AND status IN ('settled', 'completed')`);
        const totalEarnings = completedEarnings?.reduce((sum, e) => sum + Number(e.amount), 0) || 0;
        const pendingEarnings = await db.queryWhere('earnings', `user_id = '${userId}' AND status = 'pending'`);
        const pendingAmount = pendingEarnings?.reduce((sum, e) => sum + Number(e.amount), 0) || 0;
        const now = new Date();
        const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
        const monthlyEarnings = await db.queryWhere('earnings', `user_id = '${userId}' AND status IN ('settled', 'completed') AND created_at >= '${monthStart.toISOString()}'`);
        const monthlyAmount = monthlyEarnings?.reduce((sum, e) => sum + Number(e.amount), 0) || 0;
        const totalOrders = await db.countWhere('earnings', `user_id = '${userId}' AND type = 'order_reward'`);
        const totalReferrals = await db.countWhere('earnings', `user_id = '${userId}' AND type = 'referral_bonus'`);
        return {
            balance: user?.balance || 0,
            totalEarnings,
            pendingAmount,
            monthlyAmount,
            totalOrders: totalOrders || 0,
            totalReferrals: totalReferrals || 0
        };
    }
    async getEarningsList(userId, options) {
        const pool = (0, mysql_client_1.getPool)();
        const page = options?.page || 1;
        const pageSize = options?.pageSize || 20;
        const offset = (page - 1) * pageSize;
        let where = 'user_id = ?';
        const params = [userId];
        if (options?.type) {
            where += ' AND type = ?';
            params.push(options.type);
        }
        if (options?.status) {
            where += ' AND status = ?';
            params.push(options.status);
        }
        const [list] = await pool.query(`SELECT * FROM earnings WHERE ${where} ORDER BY created_at DESC LIMIT ${Number(pageSize)} OFFSET ${Number(offset)}`, params);
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM earnings WHERE ${where}`, params);
        return {
            list: Array.isArray(list) ? list : [],
            total: countResult?.[0]?.total || 0,
            page,
            pageSize
        };
    }
    async createEarning(userId, earningData) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const id = crypto.randomUUID();
        await db.insert('earnings', {
            id,
            user_id: userId,
            type: earningData.type,
            amount: earningData.amount,
            status: 'pending',
            description: earningData.description || '',
            avatar_id: earningData.avatar_id || null,
            order_id: earningData.order_id || null,
            created_at: new Date()
        });
        return await db.queryOne('users', { id });
    }
    async createOrderEarnings(orderId, participants) {
        const pool = (0, mysql_client_1.getPool)();
        const [existingEarnings] = await pool.query('SELECT id FROM earnings WHERE order_id = ?', [orderId]);
        if (existingEarnings && existingEarnings.length > 0) {
            console.log(`[EarningService] 订单 ${orderId} 已创建收益记录，跳过重复创建`);
            return [];
        }
        const results = [];
        for (const participant of participants) {
            const id = crypto.randomUUID();
            try {
                await pool.query(`INSERT INTO earnings (id, user_id, type, amount, status, description, avatar_id, order_id, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, [id, participant.user_id, 'order_reward', participant.amount, 'pending', '订单收益', participant.avatar_id, orderId, new Date()]);
                results.push({ id, ...participant });
            }
            catch (e) {
                console.error('[EarningService] createOrderEarnings 写入失败:', e.message);
            }
        }
        return results;
    }
    async settleOrderEarnings(orderId) {
        const pool = (0, mysql_client_1.getPool)();
        const [earnings] = await pool.query('SELECT * FROM earnings WHERE order_id = ? AND status = ?', [orderId, 'pending']);
        for (const earning of earnings) {
            await pool.query('UPDATE earnings SET status = ? WHERE id = ?', ['settled', earning.id]);
            await pool.query('UPDATE users SET balance = balance + ?, total_earnings = total_earnings + ? WHERE id = ?', [earning.amount, earning.amount, earning.user_id]);
        }
        return { count: earnings.length };
    }
    async getOrderEarnings(orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const earnings = await db.query('SELECT * FROM earnings WHERE order_id = ? ORDER BY created_at DESC', [orderId]);
        return earnings;
    }
    async confirmWithdrawal(withdrawalId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const withdrawal = await db.queryOne('withdrawals', { id: withdrawalId });
        if (!withdrawal || withdrawal.status !== 'pending') {
            throw new Error('提现申请不存在或已处理');
        }
        await db.updateWhere('withdrawals', { id: withdrawalId }, {
            status: 'completed',
            updated_at: new Date()
        });
        await db.query('UPDATE users SET frozen_balance = frozen_balance - ?, updated_at = ? WHERE id = ?', [withdrawal.amount, new Date(), withdrawal.user_id]);
        return await db.queryOne('withdrawals', { id: withdrawalId });
    }
    async rejectWithdrawal(withdrawalId, reason) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const withdrawal = await db.queryOne('withdrawals', { id: withdrawalId });
        if (!withdrawal || withdrawal.status !== 'pending') {
            throw new Error('提现申请不存在或已处理');
        }
        await db.updateWhere('withdrawals', { id: withdrawalId }, {
            status: 'rejected',
            rejected_reason: reason || '',
            updated_at: new Date()
        });
        await db.query('UPDATE users SET balance = balance + ?, frozen_balance = frozen_balance - ?, updated_at = ? WHERE id = ?', [withdrawal.amount, withdrawal.amount, new Date(), withdrawal.user_id]);
        return await db.queryOne('withdrawals', { id: withdrawalId });
    }
    async updateEarningStatus(earningId, status) {
        const db = (0, mysql_client_1.getMySQLClient)();
        await db.updateWhere('earnings', { id: earningId }, {
            status,
            updated_at: new Date()
        });
        return await db.queryOne('earnings', { id: earningId });
    }
    async getTransactions(userId, page = 1, pageSize = 20) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const offset = (page - 1) * pageSize;
        const list = await db.query('transactions', { user_id: userId }, {
            orderBy: 'created_at',
            orderDirection: 'desc',
            limit: pageSize,
            offset: offset
        });
        const total = await db.count('transactions', { user_id: userId });
        return { list: list?.data || [], total: total || 0 };
    }
    async createWithdrawal(userId, withdrawalData) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const user = await db.queryOne('users', { id: userId });
        if (!user || (user.balance || 0) < withdrawalData.amount) {
            throw new Error('余额不足');
        }
        const id = crypto.randomUUID();
        await db.insert('withdrawals', {
            id,
            user_id: userId,
            amount: withdrawalData.amount,
            method: withdrawalData.method,
            account: withdrawalData.account,
            status: 'pending',
            created_at: new Date(),
            updated_at: new Date()
        });
        await db.updateWhere('users', { id: userId }, {
            frozen_balance: (user.frozen_balance || 0) + withdrawalData.amount,
            updated_at: new Date()
        });
        return await db.queryOne('withdrawals', { id });
    }
    async getWithdrawals(userId, page = 1, pageSize = 20) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const offset = (page - 1) * pageSize;
        const list = await db.query('withdrawals', { user_id: userId }, {
            orderBy: 'created_at',
            orderDirection: 'desc',
            limit: pageSize,
            offset: offset
        });
        const total = await db.count('withdrawals', { user_id: userId });
        return { list: list?.data || [], total: total || 0 };
    }
};
exports.EarningService = EarningService;
exports.EarningService = EarningService = __decorate([
    (0, common_1.Injectable)()
], EarningService);
