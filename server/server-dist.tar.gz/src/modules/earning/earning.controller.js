"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EarningController = void 0;
const common_1 = require("@nestjs/common");
const earning_service_1 = require("./earning.service");
let EarningController = class EarningController {
    constructor(earningService) {
        this.earningService = earningService;
    }
    async getOverview(userId) {
        const overview = await this.earningService.getEarningsOverview(userId);
        return {
            code: 200,
            data: overview,
            message: '获取成功'
        };
    }
    async getList(userId, type, status, page, pageSize) {
        const result = await this.earningService.getEarningsList(userId, {
            type,
            status,
            page: page ? parseInt(page) : 1,
            pageSize: pageSize ? parseInt(pageSize) : 20
        });
        return {
            code: 200,
            data: result,
            message: '获取成功'
        };
    }
    async createWithdrawal(userId, body) {
        const withdrawal = await this.earningService.createWithdrawal(userId, body);
        return {
            code: 200,
            data: withdrawal,
            message: '提现申请已提交'
        };
    }
};
exports.EarningController = EarningController;
__decorate([
    (0, common_1.Get)('overview'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EarningController.prototype, "getOverview", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('type')),
    __param(2, (0, common_1.Query)('status')),
    __param(3, (0, common_1.Query)('page')),
    __param(4, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String]),
    __metadata("design:returntype", Promise)
], EarningController.prototype, "getList", null);
__decorate([
    (0, common_1.Post)('withdraw'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], EarningController.prototype, "createWithdrawal", null);
exports.EarningController = EarningController = __decorate([
    (0, common_1.Controller)('earnings'),
    __param(0, (0, common_1.Inject)('EARNING_SERVICE')),
    __metadata("design:paramtypes", [earning_service_1.EarningService])
], EarningController);
