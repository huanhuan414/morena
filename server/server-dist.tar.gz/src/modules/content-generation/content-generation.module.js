"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentGenerationModule = void 0;
const common_1 = require("@nestjs/common");
const content_generation_service_1 = require("./content-generation.service");
const content_generation_controller_1 = require("./content-generation.controller");
const avatar_agent_module_1 = require("../avatar-agent/avatar-agent.module");
const order_module_1 = require("../order/order.module");
const volcengine_service_1 = require("../upload/volcengine.service");
const storage_service_1 = require("../storage/storage.service");
let ContentGenerationModule = class ContentGenerationModule {
};
exports.ContentGenerationModule = ContentGenerationModule;
exports.ContentGenerationModule = ContentGenerationModule = __decorate([
    (0, common_1.Module)({
        imports: [avatar_agent_module_1.AvatarAgentModule, (0, common_1.forwardRef)(() => order_module_1.OrderModule)],
        controllers: [content_generation_controller_1.ContentGenerationController],
        providers: [content_generation_service_1.ContentGenerationService, volcengine_service_1.VolcengineService, storage_service_1.StorageService],
        exports: [content_generation_service_1.ContentGenerationService]
    })
], ContentGenerationModule);
