"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentGenerationController = void 0;
const common_1 = require("@nestjs/common");
const content_generation_service_1 = require("./content-generation.service");
const mysql_client_1 = require("../../storage/database/mysql-client");
const order_service_1 = require("../order/order.service");
let ContentGenerationController = class ContentGenerationController {
    constructor(contentGenerationService, orderService) {
        this.contentGenerationService = contentGenerationService;
        this.orderService = orderService;
        this.contentGenerationColumns = null;
    }
    async getContentGenerationColumns(db) {
        if (this.contentGenerationColumns)
            return this.contentGenerationColumns;
        try {
            const [rows] = await db.query(`SELECT COLUMN_NAME as column_name
         FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = 'content_generation_requests'`);
            this.contentGenerationColumns = new Set((rows || []).map((r) => String(r.column_name || r.columnName || '').toLowerCase()).filter(Boolean));
        }
        catch {
            this.contentGenerationColumns = new Set();
        }
        return this.contentGenerationColumns;
    }
    pickPayload(columns, payload) {
        const picked = {};
        for (const [key, value] of Object.entries(payload || {})) {
            if (columns.has(key.toLowerCase())) {
                picked[key] = value;
            }
        }
        return picked;
    }
    async generateContent(body) {
        try {
            const payload = {
                ...body,
                targetAudience: body.targetAudience || '通用用户'
            };
            const result = await this.contentGenerationService.generateContent(payload);
            return {
                code: 200,
                message: '内容生成成功',
                data: result
            };
        }
        catch (error) {
            return {
                code: 500,
                message: '内容生成失败',
                error: error.message
            };
        }
    }
    async retryGeneration(requestId) {
        try {
            const db = await (0, mysql_client_1.getMySQLClient)();
            const [records] = await db.query('SELECT * FROM content_generation_requests WHERE id = ?', [requestId]);
            if (!records || records.length === 0) {
                return { code: 404, message: '记录不存在' };
            }
            const record = records[0];
            await db.query('UPDATE content_generation_requests SET status = ?, updated_at = NOW() WHERE id = ?', ['processing', requestId]);
            const payload = {
                orderId: record.order_id,
                requestId: record.id,
                avatarId: record.avatar_id,
                orderTitle: record.order_title || '',
                orderDescription: record.order_description || '',
                platforms: record.platforms ? JSON.parse(record.platforms) : [],
                contentType: record.content_type || 'image',
                targetAudience: record.target_audience || '通用用户',
                contentQuantity: record.content_quantity || 1,
            };
            this.contentGenerationService.generateContent(payload).catch((err) => {
                console.error('[ContentGeneration] retry generation error:', err.message);
            });
            return { code: 200, message: '已开始重新生成', data: { requestId, status: 'processing' } };
        }
        catch (error) {
            return { code: 500, message: '重试失败', error: error.message };
        }
    }
    async getGeneratedContent(requestId, avatarId) {
        try {
            const pool = await (0, mysql_client_1.getMySQLClient)();
            const [rows] = await pool.query('SELECT * FROM content_generation_requests WHERE id = ? AND avatar_id = ? LIMIT 1', [requestId, avatarId]);
            if (!rows || rows.length === 0) {
                return { code: 404, message: '内容不存在', data: null };
            }
            const record = rows[0];
            let images = [];
            let video = null;
            try {
                images = record.images ? JSON.parse(record.images) : [];
            }
            catch {
                images = [];
            }
            try {
                video = record.video_url ? JSON.parse(record.video_url) : null;
            }
            catch {
                video = record.video_url || null;
            }
            return {
                code: 200,
                message: '获取成功',
                data: {
                    id: record.id,
                    content: record.content,
                    images,
                    video,
                    status: record.status,
                    createdAt: record.created_at
                }
            };
        }
        catch (error) {
            return { code: 500, message: '获取失败', error: error.message };
        }
    }
    async getContentImages(contentId) {
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const results = await db.query('SELECT images FROM content_generation_requests WHERE id = ? LIMIT 1', [contentId]);
            const rows = Array.isArray(results) ? results : [];
            if (!rows || rows.length === 0) {
                return { code: 404, message: '内容不存在', data: { images: [] } };
            }
            let images = [];
            const raw = rows[0]?.images;
            if (typeof raw === 'string') {
                try {
                    images = JSON.parse(raw);
                }
                catch {
                    images = [];
                }
            }
            else if (Array.isArray(raw)) {
                images = raw;
            }
            const urlImages = [];
            const base64Images = [];
            images.forEach((img, idx) => {
                if (typeof img === 'string' && img.startsWith('http')) {
                    urlImages.push(img);
                }
                else if (typeof img === 'string' && img.startsWith('data:image/')) {
                    base64Images.push({ index: idx, data: img });
                }
            });
            if (base64Images.length > 0) {
                this.contentGenerationService.migrateBase64ImagesToTos(contentId, images).catch(() => { });
            }
            return { code: 200, message: '获取成功', data: { images: urlImages } };
        }
        catch (error) {
            return { code: 500, message: '获取失败', data: { images: [] } };
        }
    }
    async getContentById(contentId) {
        try {
            const db = await (0, mysql_client_1.getMySQLClient)();
            const results = await db.query('SELECT * FROM content_generation_requests WHERE id = ? LIMIT 1', [contentId]);
            const rows = Array.isArray(results) ? results : [];
            if (rows.length === 0) {
                return { code: 404, message: '内容不存在', data: null };
            }
            const record = rows[0];
            let images = [];
            try {
                images = record.images ? (Array.isArray(record.images) ? record.images : JSON.parse(record.images)) : [];
            }
            catch {
                images = [];
            }
            let videos = [];
            try {
                const rawVideoUrl = record.videoUrl;
                if (rawVideoUrl) {
                    if (Array.isArray(rawVideoUrl)) {
                        videos = rawVideoUrl;
                    }
                    else if (typeof rawVideoUrl === 'string') {
                        const trimmed = rawVideoUrl.trim();
                        if (trimmed.startsWith('[')) {
                            const parsed = JSON.parse(trimmed);
                            videos = Array.isArray(parsed) ? parsed : [];
                        }
                        else if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
                            videos = [trimmed];
                        }
                    }
                }
            }
            catch {
                videos = [];
            }
            let parsedPlatforms = [];
            try {
                const p = record.platforms;
                if (Array.isArray(p) && p.length > 0) {
                    parsedPlatforms = p;
                }
                else if (typeof p === 'string' && p.trim()) {
                    const parsed = JSON.parse(p);
                    parsedPlatforms = Array.isArray(parsed) ? parsed : [String(parsed)];
                }
            }
            catch {
                if (record.platforms)
                    parsedPlatforms = [String(record.platforms)];
            }
            if (parsedPlatforms.length === 0 && record.platform) {
                parsedPlatforms = [record.platform];
            }
            return {
                code: 200,
                message: '获取成功',
                data: {
                    id: record.id,
                    avatarId: record.avatarId,
                    orderId: record.orderId,
                    content: record.content || '',
                    images,
                    videos,
                    videoUrl: videos.length > 0 ? videos[0] : null,
                    platform: record.platform,
                    platforms: parsedPlatforms,
                    status: record.status,
                    contentType: record.contentType || 'image_text',
                    createdAt: record.createdAt,
                }
            };
        }
        catch (error) {
            return { code: 500, message: '获取失败', error: error.message };
        }
    }
    async updateContentStatus(contentId, body) {
        try {
            const pool = await (0, mysql_client_1.getMySQLClient)();
            await pool.query('UPDATE content_generation_requests SET status = ? WHERE id = ?', [body.status, contentId]);
            return { code: 200, message: '状态更新成功' };
        }
        catch (error) {
            return { code: 500, message: '状态更新失败', error: error.message };
        }
    }
    async getHistory(avatarId, orderId) {
        try {
            const pool = await (0, mysql_client_1.getMySQLClient)();
            let sql = 'SELECT * FROM content_generation_requests WHERE avatar_id = ?';
            const params = [avatarId];
            if (orderId) {
                sql += ' AND order_id = ?';
                params.push(orderId);
            }
            sql += ' ORDER BY created_at DESC LIMIT 50';
            const [rows] = await pool.query(sql, params);
            return {
                code: 200,
                message: '获取成功',
                data: rows
            };
        }
        catch (error) {
            return { code: 500, message: '获取失败', error: error.message };
        }
    }
    async submitPublishProof(contentId, body) {
        try {
            const db = await (0, mysql_client_1.getMySQLClient)();
            const columns = await this.getContentGenerationColumns(db);
            const payload = {
                publish_url: body.publishUrl || null,
                publish_screenshot: body.publishScreenshot || null,
                verification_status: 'pending',
                verified_at: null,
                updated_at: new Date(),
            };
            const picked = this.pickPayload(columns, payload);
            const setClause = Object.keys(picked).map((k) => `${k} = ?`).join(', ');
            if (setClause) {
                await db.query(`UPDATE content_generation_requests SET ${setClause} WHERE id = ?`, [...Object.values(picked), contentId]);
            }
            const [contents] = await db.query('SELECT order_id FROM content_generation_requests WHERE id = ?', [contentId]);
            if (contents && contents.length > 0 && contents[0].orderId) {
                await db.query(`UPDATE orders SET publish_proof_url = ?, publish_verified = 0 WHERE id = ?`, [body.publishScreenshot || body.publishUrl || null, contents[0].orderId]);
            }
            console.log(`[发布凭证] contentId=${contentId}, publishUrl=${body.publishUrl}`);
            return { code: 200, message: '发布凭证提交成功，等待验证' };
        }
        catch (error) {
            return { code: 500, message: '提交失败', error: error.message };
        }
    }
    async verifyPublish(contentId, body) {
        try {
            const db = await (0, mysql_client_1.getMySQLClient)();
            const columns = await this.getContentGenerationColumns(db);
            const verificationStatus = body.verified ? 'verified' : 'failed';
            const payload = {
                verification_status: verificationStatus,
                verified_at: new Date(),
                updated_at: new Date(),
            };
            const picked = this.pickPayload(columns, payload);
            const setClause = Object.keys(picked).map((k) => `${k} = ?`).join(', ');
            if (setClause) {
                await db.query(`UPDATE content_generation_requests SET ${setClause} WHERE id = ?`, [...Object.values(picked), contentId]);
            }
            const [contents] = await db.query('SELECT order_id FROM content_generation_requests WHERE id = ?', [contentId]);
            if (contents && contents.length > 0 && contents[0].orderId) {
                if (body.verified) {
                    await db.query(`UPDATE orders SET publish_verified = 1, status = 'completed' WHERE id = ?`, [contents[0].orderId]);
                }
                else {
                    await db.query(`UPDATE orders SET publish_verified = 0, status = 'publish_failed' WHERE id = ?`, [contents[0].orderId]);
                    try {
                        await db.query(`INSERT INTO order_timeout_logs (id, order_id, event_type, old_status, new_status, notes)
               VALUES (UUID(), ?, 'publish_timeout', 'published', 'publish_failed', ?)`, [contents[0].orderId, body.reason || '发布验证失败']);
                    }
                    catch { }
                }
            }
            console.log(`[发布验证] contentId=${contentId}, verified=${body.verified}`);
            return { code: 200, message: body.verified ? '验证通过' : '验证失败，需重新发布' };
        }
        catch (error) {
            return { code: 500, message: '验证失败', error: error.message };
        }
    }
    async retryPublish(orderId) {
        try {
            const db = await (0, mysql_client_1.getMySQLClient)();
            const columns = await this.getContentGenerationColumns(db);
            const rows = await db.query('SELECT id, status FROM orders WHERE id = ? LIMIT 1', [orderId]);
            const order = rows?.[0] || rows?.data?.[0];
            if (!order) {
                return { code: 404, message: '订单不存在', data: null };
            }
            const currentStatus = String(order.status || '');
            if (!['publish_failed', 'publish_timeout'].includes(currentStatus)) {
                return { code: 400, message: '当前订单状态不可重试', data: { status: currentStatus } };
            }
            const orderUpdateResult = await db.query(`UPDATE orders SET publish_verified = 0, status = 'submitted', updated_at = NOW() WHERE id = ?`, [orderId]);
            let contentUpdateResult = null;
            if (columns.has('verification_status') && columns.has('verified_at')) {
                contentUpdateResult = await db.query(`UPDATE content_generation_requests
           SET verification_status = 'pending', verified_at = NULL
           WHERE order_id = ? AND verification_status = 'failed'`, [orderId]);
            }
            else {
                const payload = { updated_at: new Date() };
                const picked = this.pickPayload(columns, payload);
                const setClause = Object.keys(picked).map((k) => `${k} = ?`).join(', ');
                if (setClause) {
                    contentUpdateResult = await db.query(`UPDATE content_generation_requests SET ${setClause} WHERE order_id = ?`, [...Object.values(picked), orderId]);
                }
            }
            await this.orderService.syncOrderStatusByContent(orderId);
            return {
                code: 200,
                message: '已触发重试',
                data: {
                    orderId,
                    status: 'submitted',
                    updatedOrders: orderUpdateResult?.affectedRows ?? null,
                    resetContents: contentUpdateResult?.affectedRows ?? null,
                }
            };
        }
        catch (error) {
            return { code: 500, message: '重试失败', error: error.message };
        }
    }
    async clearGeneration(orderId) {
        try {
            const pool = await (0, mysql_client_1.getMySQLClient)();
            await pool.query('DELETE FROM content_generation_requests WHERE order_id = ?', [orderId]);
            return {
                code: 200,
                message: '清除成功'
            };
        }
        catch (error) {
            return { code: 500, message: '清除失败', error: error.message };
        }
    }
};
exports.ContentGenerationController = ContentGenerationController;
__decorate([
    (0, common_1.Post)('generate'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "generateContent", null);
__decorate([
    (0, common_1.Post)('retry/:requestId'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('requestId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "retryGeneration", null);
__decorate([
    (0, common_1.Get)('request/:requestId/avatar/:avatarId'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "getGeneratedContent", null);
__decorate([
    (0, common_1.Get)('content-images/:contentId'),
    __param(0, (0, common_1.Param)('contentId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "getContentImages", null);
__decorate([
    (0, common_1.Get)('content/:contentId'),
    __param(0, (0, common_1.Param)('contentId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "getContentById", null);
__decorate([
    (0, common_1.Post)('content/:contentId/status'),
    __param(0, (0, common_1.Param)('contentId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "updateContentStatus", null);
__decorate([
    (0, common_1.Get)('history/avatar/:avatarId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Query)('orderId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "getHistory", null);
__decorate([
    (0, common_1.Post)('content/:contentId/publish-proof'),
    __param(0, (0, common_1.Param)('contentId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "submitPublishProof", null);
__decorate([
    (0, common_1.Post)('content/:contentId/verify'),
    __param(0, (0, common_1.Param)('contentId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "verifyPublish", null);
__decorate([
    (0, common_1.Post)('order/:orderId/retry-publish'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('orderId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "retryPublish", null);
__decorate([
    (0, common_1.Delete)('clear/:orderId'),
    __param(0, (0, common_1.Param)('orderId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ContentGenerationController.prototype, "clearGeneration", null);
exports.ContentGenerationController = ContentGenerationController = __decorate([
    (0, common_1.Controller)('content-generation'),
    __param(0, (0, common_1.Inject)(content_generation_service_1.ContentGenerationService)),
    __param(1, (0, common_1.Inject)((0, common_1.forwardRef)(() => order_service_1.OrderService))),
    __metadata("design:paramtypes", [content_generation_service_1.ContentGenerationService,
        order_service_1.OrderService])
], ContentGenerationController);
