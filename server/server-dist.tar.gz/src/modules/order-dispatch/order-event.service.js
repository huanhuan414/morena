"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var OrderEventService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderEventService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
let OrderEventService = OrderEventService_1 = class OrderEventService {
    constructor() {
        this.logger = new common_1.Logger(OrderEventService_1.name);
        this.EVENT_CONFIG = {
            created: {
                titleTpl: '订单已创建',
                icon: 'FileText',
                color: '#3b82f6',
                defaultVisibility: 'both'
            },
            dispatched: {
                titleTpl: '已派单给 {avatarName}',
                icon: 'Send',
                color: '#8b5cf6',
                defaultVisibility: 'both'
            },
            accepted: {
                titleTpl: '{avatarName} 已接单',
                icon: 'CircleCheck',
                color: '#22c55e',
                defaultVisibility: 'both'
            },
            rejected: {
                titleTpl: '{avatarName} 婉拒了订单',
                icon: 'CircleX',
                color: '#9ca3af',
                defaultVisibility: 'both'
            },
            expired: {
                titleTpl: '{avatarName} 超时未接单',
                icon: 'Clock',
                color: '#f59e0b',
                defaultVisibility: 'both'
            },
            content_started: {
                titleTpl: '{avatarName} 开始生成内容',
                icon: 'Loader',
                color: '#6366f1',
                defaultVisibility: 'both'
            },
            content_completed: {
                titleTpl: '{avatarName} 内容已生成',
                icon: 'FileCheck',
                color: '#22c55e',
                defaultVisibility: 'both'
            },
            content_failed: {
                titleTpl: '{avatarName} 内容生成失败',
                icon: 'AlertTriangle',
                color: '#ef4444',
                defaultVisibility: 'both'
            },
            publish_started: {
                titleTpl: '{avatarName} 开始发布',
                icon: 'Upload',
                color: '#06b6d4',
                defaultVisibility: 'both'
            },
            publish_completed: {
                titleTpl: '{avatarName} 已发布到 {platformName}',
                icon: 'Globe',
                color: '#22c55e',
                defaultVisibility: 'both'
            },
            publish_failed: {
                titleTpl: '{avatarName} 发布失败',
                icon: 'AlertTriangle',
                color: '#ef4444',
                defaultVisibility: 'both'
            },
            publish_verified: {
                titleTpl: '发布已验证通过',
                icon: 'ShieldCheck',
                color: '#22c55e',
                defaultVisibility: 'both'
            },
            revision_requested: {
                titleTpl: '发单方要求修改',
                icon: 'RefreshCw',
                color: '#f59e0b',
                defaultVisibility: 'both'
            },
            reassign: {
                titleTpl: '订单已转派给其他分身',
                icon: 'Repeat',
                color: '#f59e0b',
                defaultVisibility: 'both'
            },
            timeout_warning: {
                titleTpl: '{avatarName} 即将超时',
                icon: 'AlertTriangle',
                color: '#f59e0b',
                defaultVisibility: 'both'
            },
            auto_cancel: {
                titleTpl: '订单已自动取消',
                icon: 'Ban',
                color: '#ef4444',
                defaultVisibility: 'both'
            },
            cancel: {
                titleTpl: '订单已取消',
                icon: 'Ban',
                color: '#ef4444',
                defaultVisibility: 'both'
            },
            completed: {
                titleTpl: '订单已完成',
                icon: 'PartyPopper',
                color: '#22c55e',
                defaultVisibility: 'both'
            },
            accepted_by_publisher: {
                titleTpl: '发单方验收通过',
                icon: 'CircleCheckBig',
                color: '#22c55e',
                defaultVisibility: 'both'
            }
        };
    }
    async recordEvent(params) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const id = `evt_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
        const config = this.EVENT_CONFIG[params.eventType] || {};
        let title = params.title || config.titleTpl || params.eventType;
        title = title
            .replace(/\{avatarName\}/g, params.avatarName || '分身')
            .replace(/\{platformName\}/g, params.platformName || '平台');
        const eventData = {
            ...(params.eventData || {}),
            ...(params.avatarName ? { avatarName: params.avatarName } : {}),
            ...(params.platformName ? { platformName: params.platformName } : {}),
        };
        try {
            await db.query(`INSERT INTO order_events (id, order_id, dispatch_id, avatar_id, user_id, event_type, source, visibility, title, content, event_data, icon, color, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`, [
                id,
                params.orderId,
                params.dispatchId || null,
                params.avatarId || null,
                params.userId || null,
                params.eventType,
                params.source || 'system',
                params.visibility || config.defaultVisibility || 'both',
                title,
                params.content || null,
                JSON.stringify(eventData),
                config.icon || 'Activity',
                config.color || '#6b7280',
            ]);
            this.logger.log(`事件记录: [${params.eventType}] ${title} (order=${params.orderId})`);
            this.triggerNotifications(params, title).catch(err => {
                this.logger.warn(`通知触发失败: ${err.message}`);
            });
            return { id, title };
        }
        catch (error) {
            this.logger.error(`记录事件失败: ${error.message}`);
            return { id: null, title: '' };
        }
    }
    async getPublisherTimeline(orderId, limit = 50) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const rows = await db.query(`SELECT id, order_id, dispatch_id, avatar_id, event_type, source, 
              title, content, event_data, icon, color, created_at
       FROM order_events 
       WHERE order_id = ? AND visibility IN ('both', 'publisher')
       ORDER BY created_at ASC
       LIMIT ?`, [orderId, limit]);
        return this.formatTimeline(rows || []);
    }
    async getAvatarTimeline(orderId, avatarId, limit = 50) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const rows = await db.query(`SELECT id, order_id, dispatch_id, avatar_id, event_type, source,
              title, content, event_data, icon, color, created_at
       FROM order_events 
       WHERE order_id = ? 
       AND (
         visibility IN ('both', 'avatar') 
         OR (visibility = 'publisher' AND avatar_id = ?)
       )
       ORDER BY created_at ASC
       LIMIT ?`, [orderId, avatarId, limit]);
        return this.formatTimeline(rows || []);
    }
    async getPublisherTimelineSummary(orderId, limit = 50) {
        const timeline = await this.getPublisherTimeline(orderId, limit);
        return {
            timeline,
            durations: this.computeDurations(timeline)
        };
    }
    computeDurations(timeline) {
        const firstTimeOf = (eventType) => {
            const found = (timeline || []).find((item) => item?.eventType === eventType);
            if (!found?.createdAt)
                return null;
            const ts = new Date(found.createdAt).getTime();
            return Number.isNaN(ts) ? null : ts;
        };
        const createdAt = firstTimeOf('created');
        const acceptedAt = firstTimeOf('accepted');
        const contentCompletedAt = firstTimeOf('content_completed');
        const publishCompletedAt = firstTimeOf('publish_completed');
        const publisherAcceptedAt = firstTimeOf('accepted_by_publisher');
        const completedAt = firstTimeOf('completed');
        const duration = (from, to) => typeof from === 'number' && typeof to === 'number' && to >= from ? (to - from) : null;
        return {
            createdToAcceptedMs: duration(createdAt, acceptedAt),
            acceptedToContentCompletedMs: duration(acceptedAt, contentCompletedAt),
            contentCompletedToPublishCompletedMs: duration(contentCompletedAt, publishCompletedAt),
            publishCompletedToPublisherAcceptedMs: duration(publishCompletedAt, publisherAcceptedAt),
            publishCompletedToCompletedMs: duration(publishCompletedAt, completedAt),
            createdToCompletedMs: duration(createdAt, completedAt)
        };
    }
    async getAvatarEvents(userId, limit = 20) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const avatars = await db.query(`SELECT id FROM avatars WHERE user_id = ? AND status = 'active'`, [userId]);
        const avatarIds = (avatars || []).map((a) => a.id);
        if (avatarIds.length === 0)
            return [];
        const placeholders = avatarIds.map(() => '?').join(',');
        const rows = await db.query(`SELECT e.id, e.order_id, e.dispatch_id, e.avatar_id, e.event_type, e.source,
              e.title, e.content, e.event_data, e.icon, e.color, e.created_at,
              o.title as order_title
       FROM order_events e
       LEFT JOIN orders o ON e.order_id = o.id
       WHERE e.avatar_id IN (${placeholders})
       AND e.visibility IN ('both', 'avatar')
       ORDER BY e.created_at DESC
       LIMIT ?`, [...avatarIds, limit]);
        return this.formatTimeline(rows || []);
    }
    async getUnreadCount(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const rows = await db.query(`SELECT COUNT(*) as cnt FROM order_events e
       JOIN orders o ON e.order_id = o.id
       WHERE o.user_id = ? 
       AND e.visibility IN ('both', 'publisher')
       AND e.created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)`, [userId]);
        return rows?.[0]?.cnt || 0;
    }
    formatTimeline(rows) {
        return rows.map((row) => {
            let eventData = row.eventData || row.event_data;
            if (typeof eventData === 'string') {
                try {
                    eventData = JSON.parse(eventData);
                }
                catch {
                    eventData = {};
                }
            }
            const createdAt = row.createdAt || row.created_at;
            return {
                id: row.id,
                orderId: row.orderId || row.order_id,
                dispatchId: row.dispatchId || row.dispatch_id,
                avatarId: row.avatarId || row.avatar_id,
                eventType: row.eventType || row.event_type,
                source: row.source,
                title: row.title,
                content: row.content,
                eventData,
                icon: row.icon,
                color: row.color,
                orderTitle: row.orderTitle || row.order_title || null,
                createdAt: createdAt instanceof Date
                    ? createdAt.toISOString()
                    : String(createdAt),
            };
        });
    }
    async triggerNotifications(params, title) {
        try {
            const { NotificationService } = await Promise.resolve().then(() => require('../notification/notification.service'));
            const { getMySQLClient: getMySQLClientLazy } = await Promise.resolve().then(() => require('../../storage/database/mysql-client'));
            const db = getMySQLClientLazy();
            const orders = await db.query('SELECT user_id, title FROM orders WHERE id = ?', [params.orderId]);
            const order = orders?.[0];
            if (!order)
                return;
            let avatarUserId = null;
            if (params.avatarId) {
                const avatars = await db.query('SELECT user_id FROM avatars WHERE id = ?', [params.avatarId]);
                avatarUserId = avatars?.[0]?.userId;
            }
            const notificationService = new NotificationService();
            const notifyPublisher = ['accepted', 'rejected', 'content_completed', 'content_failed',
                'publish_completed', 'publish_failed', 'timeout_warning', 'expired', 'completed'].includes(params.eventType);
            const notifyAvatar = ['dispatched', 'revision_requested', 'reassign', 'auto_cancel', 'cancel',
                'accepted_by_publisher'].includes(params.eventType);
            if (notifyPublisher && order.userId) {
                await notificationService.createNotification({
                    user_id: order.userId,
                    type: `order_${params.eventType}`,
                    title: '订单动态',
                    content: title,
                    metadata: { orderId: params.orderId, eventType: params.eventType }
                });
            }
            if (notifyAvatar && avatarUserId) {
                await notificationService.createNotification({
                    user_id: avatarUserId,
                    type: `order_${params.eventType}`,
                    title: '任务动态',
                    content: title,
                    metadata: { orderId: params.orderId, eventType: params.eventType, avatarId: params.avatarId }
                });
            }
        }
        catch (err) {
            this.logger.warn(`通知触发异常: ${err.message}`);
        }
    }
};
exports.OrderEventService = OrderEventService;
exports.OrderEventService = OrderEventService = OrderEventService_1 = __decorate([
    (0, common_1.Injectable)()
], OrderEventService);
