"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var OrderDispatchService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderDispatchService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const sms_service_1 = require("../sms/sms.service");
const notification_service_1 = require("../notification/notification.service");
const order_service_1 = require("../order/order.service");
const content_generation_service_1 = require("../content-generation/content-generation.service");
const order_event_service_1 = require("./order-event.service");
let OrderDispatchService = OrderDispatchService_1 = class OrderDispatchService {
    constructor(smsService, notificationService, contentGenerationService, orderService, eventService) {
        this.smsService = smsService;
        this.notificationService = notificationService;
        this.contentGenerationService = contentGenerationService;
        this.orderService = orderService;
        this.eventService = eventService;
        this.logger = new common_1.Logger(OrderDispatchService_1.name);
        this.avatarColumnsCache = null;
    }
    normalizeDispatchStatus(status) {
        if (status === 'confirmed') {
            return 'accepted';
        }
        return status || 'pending';
    }
    async getAvatarTableColumns() {
        if (this.avatarColumnsCache) {
            return this.avatarColumnsCache;
        }
        const db = (0, mysql_client_1.getMySQLClient)();
        const colRows = await db.query(`
      SELECT COLUMN_NAME
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'avatars'
    `);
        this.avatarColumnsCache = new Set((colRows || [])
            .map((row) => String(row.columnName || row.COLUMN_NAME || row.column_name || '').toLowerCase())
            .filter(Boolean));
        return this.avatarColumnsCache;
    }
    buildHostedColumnChecks(columnExpression) {
        return [
            `${columnExpression} = 1`,
            `${columnExpression} = true`,
            `${columnExpression} = '1'`,
            `${columnExpression} = 'true'`
        ];
    }
    async buildHostedWhereClause(alias) {
        const columns = await this.getAvatarTableColumns();
        const prefix = alias ? `${alias}.` : '';
        const conditions = [];
        if (columns.has('is_hosted')) {
            conditions.push(...this.buildHostedColumnChecks(`${prefix}is_hosted`));
        }
        if (columns.has('trust_enabled')) {
            conditions.push(...this.buildHostedColumnChecks(`${prefix}trust_enabled`));
        }
        if (columns.has('hosting_enabled')) {
            conditions.push(...this.buildHostedColumnChecks(`${prefix}hosting_enabled`));
        }
        if (conditions.length === 0) {
            this.logger.warn('avatars 表缺少 is_hosted / trust_enabled 字段，自动派单将返回空结果');
            return '1 = 0';
        }
        return `(${conditions.join(' OR ')})`;
    }
    async createDispatchRequest(data) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const id = crypto.randomUUID();
        const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
        await db.insert('order_dispatch_requests', {
            id,
            order_id: data.order_id,
            avatar_id: data.avatar_id,
            user_id: data.user_id,
            platform: data.platform,
            status: 'pending',
            expires_at: expiresAt,
            created_at: new Date(),
            updated_at: new Date()
        });
        return { id };
    }
    async getDispatchRequests(orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        return await db.query('order_dispatch_requests', { order_id: orderId });
    }
    async updateDispatchStatus(dispatchId, status, rejectReason) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const updateData = {
            status,
            updated_at: new Date()
        };
        if (status === 'accepted' || status === 'rejected') {
            updateData.responded_at = new Date();
        }
        if (rejectReason) {
            updateData.reject_reason = rejectReason;
        }
        await db.updateWhere('order_dispatch_requests', { id: dispatchId }, updateData);
        return { success: true };
    }
    async getUserPendingRequests(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const requestRows = await db.query(`SELECT r.id as dispatch_id, r.order_id, r.avatar_id, r.status as dispatch_status,
              r.expires_at, r.created_at as dispatch_created_at,
              o.title, o.description, o.content_type, o.platforms, o.budget,
              o.status as order_status, o.quantity_per_avatar, o.expected_quantity,
              o.created_at as order_created_at, o.target_audience, o.deadline,
              o.priority, o.requirements,
              o.preferred_styles, o.industry_tags,
              a.name as avatar_name, a.content_styles, a.niche_tags, a.skills
       FROM order_dispatch_requests r
       INNER JOIN avatars a ON r.avatar_id = a.id AND a.status = 'active'
       INNER JOIN orders o ON r.order_id = o.id AND o.status IN ('pending', 'pending_payment', 'awaiting_acceptance', 'pending_acceptance', 'accepted', 'in_progress')
       WHERE r.user_id = ? AND r.status = 'pending'
       ORDER BY r.created_at DESC`, [userId]);
        const requests = requestRows || [];
        const avatarIds = [...new Set(requests.map((r) => r.avatar_id).filter(Boolean))];
        const skillsMap = new Map();
        if (avatarIds.length > 0) {
            const skillRows = await db.query(`SELECT s.avatar_id, s.skill_id FROM avatar_skills s WHERE s.avatar_id IN (?)`, [avatarIds]);
            for (const sr of (skillRows || [])) {
                const aid = sr.avatarId;
                if (!skillsMap.has(aid))
                    skillsMap.set(aid, []);
                skillsMap.get(aid).push(sr.skill_id);
            }
        }
        return requests.map(req => {
            req._skillsFromTable = skillsMap.get(req.avatarId) || [];
            const { score, details } = this.calculateMatchScore(req, req);
            const budget = Number(req.budget || 0);
            const expectedQuantity = Number(req.expectedQuantity || req.expected_quantity || 1);
            const expectedEarnings = expectedQuantity > 0 ? Math.round(budget / expectedQuantity * 100) / 100 : budget;
            return {
                ...req,
                matchScore: score,
                matchDetails: details,
                expectedEarnings,
            };
        });
    }
    calculateMatchScore(avatar, order) {
        const details = { skillScore: 0, styleScore: 0, nicheScore: 0 };
        const avatarStyles = this.safeParseJson(avatar.contentStyles, []);
        const avatarNiches = this.safeParseJson(avatar.nicheTags, []);
        const avatarSkills = (avatar._skillsFromTable && avatar._skillsFromTable.length > 0)
            ? avatar._skillsFromTable
            : this.safeParseJson(avatar.skills, []);
        const orderStyles = this.safeParseJson(order.preferredStyles, []);
        const orderNiches = this.safeParseJson(order.industryTags, []);
        const orderContentType = (order.content_type || order.contentType || '').toLowerCase();
        const orderPlatforms = this.safeParseJson(order.platforms, []);
        const requiredSkills = [];
        if (orderContentType.includes('text') || orderContentType.includes('文案'))
            requiredSkills.push('content_writing');
        if (orderContentType.includes('image') || orderContentType.includes('图文'))
            requiredSkills.push('image_generation');
        if (orderContentType.includes('video') || orderContentType.includes('视频'))
            requiredSkills.push('video_generation');
        if (orderPlatforms.some(p => p.includes('douyin') || p.includes('tiktok')))
            requiredSkills.push('video_generation', 'content_writing');
        if (orderPlatforms.some(p => p.includes('xiaohongshu') || p.includes('redbook')))
            requiredSkills.push('image_generation', 'content_writing');
        if (orderPlatforms.some(p => p.includes('wechat') || p.includes('朋友圈')))
            requiredSkills.push('content_writing');
        if (requiredSkills.length > 0) {
            const matchedSkills = requiredSkills.filter(s => avatarSkills.includes(s));
            details.skillScore = Math.round((matchedSkills.length / requiredSkills.length) * 40);
        }
        else {
            details.skillScore = avatarSkills.length > 0 ? 20 : 10;
        }
        if (orderStyles.length > 0 && avatarStyles.length > 0) {
            const matchedStyles = orderStyles.filter(s => avatarStyles.includes(s));
            details.styleScore = Math.round((matchedStyles.length / orderStyles.length) * 30);
        }
        else if (orderStyles.length > 0) {
            details.styleScore = 15;
        }
        else {
            details.styleScore = 30;
        }
        if (orderNiches.length > 0 && avatarNiches.length > 0) {
            const matchedNiches = orderNiches.filter(n => avatarNiches.includes(n));
            details.nicheScore = Math.round((matchedNiches.length / orderNiches.length) * 30);
        }
        else if (orderNiches.length > 0) {
            details.nicheScore = 15;
        }
        else {
            details.nicheScore = 30;
        }
        const score = Math.min(100, details.skillScore + details.styleScore + details.nicheScore);
        return { score, details };
    }
    safeParseJson(value, fallback) {
        if (value === null || value === undefined)
            return fallback;
        if (Array.isArray(value))
            return value;
        if (typeof value === 'object') {
            if (Array.isArray(fallback) && !Array.isArray(value))
                return fallback;
            return value;
        }
        if (typeof value === 'string') {
            try {
                const parsed = JSON.parse(value);
                if (Array.isArray(fallback) && !Array.isArray(parsed))
                    return fallback;
                return parsed;
            }
            catch {
                return fallback;
            }
        }
        return fallback;
    }
    async getRecommendedAvatars(orderId, limit = 0) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const hostedWhereClause = await this.buildHostedWhereClause();
        let sql = `SELECT * FROM avatars WHERE ${hostedWhereClause} AND status = 'active' ORDER BY updated_at DESC`;
        if (limit > 0) {
            sql += ` LIMIT ${parseInt(String(limit)) * 3}`;
        }
        const resultRows = await db.query(sql);
        const avatars = resultRows || [];
        const avatarIds = [...new Set(avatars.map((a) => a.id).filter(Boolean))];
        const skillsMap = new Map();
        if (avatarIds.length > 0) {
            try {
                const skillRows = await db.query(`SELECT s.avatar_id, s.skill_id FROM avatar_skills s WHERE s.avatar_id IN (?)`, [avatarIds]);
                for (const sr of (skillRows || [])) {
                    const aid = sr.avatarId || sr.avatar_id;
                    if (!aid)
                        continue;
                    if (!skillsMap.has(aid))
                        skillsMap.set(aid, []);
                    skillsMap.get(aid).push(sr.skillId || sr.skill_id);
                }
            }
            catch (err) {
                this.logger.warn('读取 avatar_skills 失败，回退使用 avatars.skills 字段:', err);
            }
        }
        const readyAvatars = avatars.map((avatar) => {
            avatar._skillsFromTable = skillsMap.get(avatar.id) || [];
            return avatar;
        });
        const dispatchStatsMap = new Map();
        const readyAvatarIds = [...new Set(readyAvatars.map((a) => a.id).filter(Boolean))];
        if (readyAvatarIds.length > 0) {
            try {
                const rows = await db.query(`SELECT COALESCE(od.avatar_id, od.target_avatar_id) as avatar_id,
                  COUNT(*) as total,
                  SUM(CASE WHEN od.status IN ('accepted', 'confirmed') THEN 1 ELSE 0 END) as accepted,
                  SUM(CASE WHEN od.status = 'expired' THEN 1 ELSE 0 END) as expired
           FROM order_dispatch_requests od
           WHERE COALESCE(od.avatar_id, od.target_avatar_id) IN (?)
             AND od.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
           GROUP BY COALESCE(od.avatar_id, od.target_avatar_id)`, [readyAvatarIds]);
                for (const r of (rows || [])) {
                    const id = r.avatarId || r.avatar_id;
                    if (!id)
                        continue;
                    dispatchStatsMap.set(id, {
                        total: Number(r.total || 0),
                        accepted: Number(r.accepted || 0),
                        expired: Number(r.expired || 0),
                    });
                }
            }
            catch (err) {
                this.logger.warn('读取派单统计失败，跳过派单权重:', err);
            }
        }
        if (orderId) {
            try {
                const orderRows2 = await db.query('SELECT * FROM orders WHERE id = ?', [orderId]);
                const order = orderRows2?.[0];
                if (order) {
                    const scoredAvatars = readyAvatars.map(avatar => {
                        const { score, details } = this.calculateMatchScore(avatar, order);
                        const stats = dispatchStatsMap.get(avatar.id) || { total: 0, accepted: 0, expired: 0 };
                        const rate = stats.total > 0 ? stats.accepted / stats.total : 0;
                        const baseScore = score;
                        let bonus = 0;
                        if (stats.total >= 5 && rate >= 0.8)
                            bonus = 5;
                        if (stats.total >= 5 && rate <= 0.3)
                            bonus = -10;
                        const finalScore = Math.max(0, Math.min(100, baseScore + bonus));
                        return {
                            ...avatar,
                            matchScoreBase: baseScore,
                            matchScore: finalScore,
                            matchDetails: details,
                            dispatchStats: { ...stats, acceptanceRate: rate }
                        };
                    });
                    scoredAvatars.sort((a, b) => b.matchScore - a.matchScore);
                    return limit > 0 ? scoredAvatars.slice(0, limit) : scoredAvatars;
                }
            }
            catch (err) {
                this.logger.warn('匹配排序失败，使用默认排序:', err);
            }
        }
        return readyAvatars;
    }
    async dispatchOrder(orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const avatars = await this.getRecommendedAvatars(orderId, 1);
        if (avatars.length === 0) {
            return null;
        }
        const avatar = avatars[0];
        const id = crypto.randomUUID();
        await db.insert('order_dispatch_requests', {
            id,
            order_id: orderId,
            avatar_id: avatar.id,
            user_id: avatar.userId,
            platform: 'auto',
            status: 'pending',
            created_at: new Date(),
            updated_at: new Date()
        });
        return { avatar_id: avatar.id, avatar_name: avatar.name };
    }
    async getExecutionProgress(orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const requests = await db.query('order_dispatch_requests', { order_id: orderId });
        return requests;
    }
    async getDispatchStatus(orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const requests = await db.query('order_dispatch_requests', { order_id: orderId });
        const normalizedStatuses = requests.map((request) => this.normalizeDispatchStatus(request.status));
        const acceptedCount = normalizedStatuses.filter((status) => status === 'accepted').length;
        return {
            total: requests.length,
            pending: normalizedStatuses.filter((status) => status === 'pending').length,
            accepted: acceptedCount,
            confirmed: acceptedCount,
            completed: normalizedStatuses.filter((status) => status === 'completed').length,
            rejected: normalizedStatuses.filter((status) => status === 'rejected').length
        };
    }
    async dispatchToAvatar(orderId, avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const avatars = await db.query('SELECT * FROM avatars WHERE id = ? AND status = \'active\'', [avatarId]);
        if (avatars.length === 0) {
            throw new Error('分身不存在或已失效');
        }
        const avatar = avatars[0];
        const id = crypto.randomUUID();
        await db.insert('order_dispatch_requests', {
            id,
            order_id: orderId,
            avatar_id: avatarId,
            user_id: avatar.userId,
            platform: 'manual',
            status: 'pending',
            created_at: new Date(),
            updated_at: new Date()
        });
        return { avatar_id: avatarId };
    }
    async getRequestById(requestId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const requests = await db.query('order_dispatch_requests', { id: requestId });
        return requests[0] || null;
    }
    async confirmDispatch(requestId, avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        await db.updateWhere('order_dispatch_requests', { id: requestId }, {
            status: 'accepted',
            updated_at: new Date()
        });
        return { success: true };
    }
    async rejectDispatch(requestId, avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        await db.update('order_dispatch_requests', { status: 'rejected' }, { id: requestId });
        return { success: true };
    }
    async dispatchToAllAvatars(orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const orderRows = await db.query('SELECT * FROM orders WHERE id = ?', [orderId]);
        const order = orderRows?.[0];
        if (!order) {
            return { count: 0, avatarIds: [], smsSentCount: 0 };
        }
        const requiredCount = order.expectedQuantity || order.expected_quantity || order.avatarCount || 1;
        console.log(`[dispatchToAllAvatars] 订单需要分身数量: expectedQuantity=${order.expectedQuantity}, expected_quantity=${order.expected_quantity}, requiredCount=${requiredCount}`);
        const allAvatarRows = await db.query(`
      SELECT a.*, u.phone AS user_phone 
      FROM avatars a 
      LEFT JOIN users u ON a.user_id = u.id 
      WHERE a.is_hosted = 1 AND a.status = 'active'`);
        const allAvatars = allAvatarRows || [];
        const avatarIdsList = allAvatars.map(a => a.id || a.avatarId);
        const avatarSkillsMap = {};
        if (avatarIdsList.length > 0) {
            const skillRows = await db.query(`SELECT as2.avatar_id, as2.skill_id FROM avatar_skills as2 WHERE as2.avatar_id IN (?)`, [avatarIdsList]);
            for (const sr of skillRows) {
                const aid = sr.avatarId || sr.avatarId;
                if (!avatarSkillsMap[aid])
                    avatarSkillsMap[aid] = [];
                avatarSkillsMap[aid].push(sr.skillId || sr.skill_id);
            }
        }
        const scoredAvatars = allAvatars.map(avatar => {
            const aid = avatar.id || avatar.avatarId;
            const skillsFromTable = avatarSkillsMap[aid] || [];
            const avatarWithSkills = { ...avatar, _skillsFromTable: skillsFromTable };
            const { score, details } = this.calculateMatchScore(avatarWithSkills, order);
            return { ...avatar, matchScore: score, matchDetails: details };
        });
        scoredAvatars.sort((a, b) => b.matchScore - a.matchScore);
        const avatars = scoredAvatars.slice(0, requiredCount);
        if (avatars.length === 0) {
            return { count: 0, avatarIds: [], smsSentCount: 0 };
        }
        const avatarIds = [];
        let smsSentCount = 0;
        for (const avatar of avatars) {
            const id = crypto.randomUUID();
            const existingDispatchRows = await db.query('SELECT id FROM order_dispatch_requests WHERE order_id = ? AND avatar_id = ?', [orderId, avatar.id]);
            if (existingDispatchRows && existingDispatchRows.length > 0) {
                console.log(`[dispatchToAllAvatars] 分身 ${avatar.name} 已有派单记录，跳过`);
                continue;
            }
            const insertResult = await db.insert('order_dispatch_requests', {
                id,
                order_id: orderId,
                avatar_id: avatar.id,
                user_id: avatar.userId || avatar.userPhone,
                platform: 'auto',
                status: 'pending',
                expires_at: new Date(Date.now() + 30 * 60 * 1000),
                created_at: new Date(),
                updated_at: new Date()
            });
            if (insertResult.error) {
                console.error('[dispatchToAllAvatars] 创建派发记录失败:', insertResult.error);
                continue;
            }
            avatarIds.push(avatar.id);
            this.eventService.recordEvent({
                orderId,
                dispatchId: id,
                avatarId: avatar.id,
                userId: avatar.userId,
                eventType: 'dispatched',
                source: 'system',
                avatarName: avatar.name,
                eventData: { matchScore: avatar.matchScore, matchDetails: avatar.matchDetails },
            }).catch(err => console.warn('[事件] dispatched 记录失败:', err.message));
            const userPhone = avatar.userPhone || avatar.phone;
            console.log('[dispatchToAllAvatars] 分身手机号检查:', avatar.name, avatar.user_phone, avatar.phone, userPhone);
            if (userPhone) {
                const smsContent = `${order?.title || '内容创作'}`;
                try {
                    const smsResult = await this.smsService.sendSms(userPhone, 'SMS_505555078', { name: avatar.name });
                    if (smsResult) {
                        smsSentCount++;
                        console.log(`[SMS] 成功发送给分身 ${avatar.name} (用户手机: ${userPhone})`);
                    }
                }
                catch (err) {
                    console.error(`[SMS] 发送给 ${avatar.name} 失败:`, err);
                }
                const notifId = crypto.randomUUID();
                const notifResult = await db.insert('avatar_notifications', {
                    id: notifId,
                    avatar_id: avatar.id,
                    notification_type: 'order_assigned',
                    title: '新订单分配',
                    content: smsContent,
                    is_read: 0,
                    data: JSON.stringify({ orderId }),
                    created_at: new Date()
                });
                if (notifResult.error) {
                    console.error('[dispatchToAllAvatars] 创建分身通知记录失败:', notifResult.error);
                }
            }
        }
        if (avatars.length > 0) {
            try {
                await this.notificationService.createNotification({
                    user_id: order.userId,
                    type: 'order_dispatched',
                    title: '订单已分配',
                    content: `已将订单"${order.title || '内容创作'}"分配给 ${avatars.length} 个分身，已发送短信通知。`,
                    metadata: {
                        orderId,
                        avatarIds,
                        count: avatars.length
                    }
                });
            }
            catch (err) {
                console.error('[dispatchToAllAvatars] 创建用户通知失败:', err);
            }
        }
        return { count: avatars.length, avatarIds, smsSentCount };
    }
    async acceptOrder(avatarId, orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        let request = null;
        if (!avatarId || avatarId === 'undefined') {
            const acceptRows1 = await db.query(`
        SELECT r.*, o.title as order_title, o.user_id as owner_user_id, o.description, o.platforms, o.budget, o.expected_quantity, o.quantity_per_avatar, o.target_audience
        FROM order_dispatch_requests r 
        LEFT JOIN orders o ON r.order_id = o.id 
        WHERE r.order_id = ? AND r.status = 'pending' 
        LIMIT 1`, [orderId]);
            request = acceptRows1?.[0];
        }
        else {
            const acceptRows2 = await db.query(`
        SELECT r.*, o.title as order_title, o.user_id as owner_user_id, o.description, o.platforms, o.budget, o.expected_quantity, o.quantity_per_avatar, o.target_audience
        FROM order_dispatch_requests r 
        LEFT JOIN orders o ON r.order_id = o.id 
        WHERE r.avatar_id = ? AND r.order_id = ? AND r.status = 'pending'`, [avatarId, orderId]);
            request = acceptRows2?.[0];
            if (request)
                request._isMatchedAvatar = true;
        }
        if (!request) {
            console.log(`[acceptOrder] 无分派记录，尝试直接从 orders 查找: orderId=${orderId}, avatarId=${avatarId}`);
            const acceptOrderRows = await db.query(`
        SELECT id, title, user_id as owner_user_id, description, platforms, budget, expected_quantity, quantity_per_avatar, target_audience, status
        FROM orders WHERE id = ?`, [orderId]);
            const order = acceptOrderRows?.[0];
            if (!order) {
                throw new Error('订单不存在');
            }
            const acceptablStatuses = ['pending', 'pending_payment', 'open', 'created', 'assigned', 'pending_acceptance', 'pending_dispatch'];
            if (!acceptablStatuses.includes(order.status)) {
                throw new Error(`订单已${order.status === 'in_progress' ? '进行中' : order.status === 'completed' ? '完成' : '处理'}, 无法接单`);
            }
            if (avatarId) {
                const existingDispatchRows = await db.query('SELECT id, status FROM order_dispatch_requests WHERE order_id = ? AND avatar_id = ?', [orderId, avatarId]);
                const existingDispatch = existingDispatchRows?.[0];
                if (existingDispatch) {
                    throw new Error(`该分身已接单（状态：${existingDispatch.status}），不能重复接单`);
                }
            }
            const dispatchId = 'odr-' + Date.now() + '-' + Math.random().toString(36).substring(2, 8);
            const insertResult = await db.insert('order_dispatch_requests', {
                id: dispatchId,
                order_id: orderId,
                avatar_id: avatarId || null,
                user_id: order.ownerUserId || null,
                platform: Array.isArray(order.platforms) ? order.platforms[0] : (order.platforms || 'general'),
                status: 'pending',
            });
            if (insertResult.error) {
                console.error('[acceptOrder] 创建分派记录失败:', insertResult.error);
                throw new Error('创建分派记录失败: ' + (insertResult.error.message || JSON.stringify(insertResult.error)));
            }
            console.log(`[acceptOrder] 自动创建分派记录成功: ${dispatchId}`);
            request = {
                id: dispatchId,
                order_id: orderId,
                avatar_id: avatarId || null,
                user_id: order.ownerUserId || null,
                platform: Array.isArray(order.platforms) ? order.platforms[0] : (order.platforms || 'general'),
                status: 'pending',
                order_title: order.title,
                owner_user_id: order.ownerUserId,
                description: order.description,
                platforms: order.platforms,
                budget: order.budget,
                expectedQuantity: order.expectedQuantity || order.expected_quantity,
                expected_quantity: order.expectedQuantity || order.expected_quantity,
                quantity_per_avatar: order.quantityPerAvatar,
                target_audience: order.targetAudience,
            };
        }
        const actualAvatarId = request.avatarId || avatarId;
        if (actualAvatarId) {
            const avatarCheckRows = await db.query('SELECT id, status FROM avatars WHERE id = ?', [actualAvatarId]);
            const avatarCheck = avatarCheckRows || [];
            if (avatarCheck.length === 0 || avatarCheck[0].status !== 'active') {
                throw new Error('分身不存在或已失效，无法接单');
            }
        }
        await db.updateWhere('order_dispatch_requests', { id: request.id }, {
            status: 'accepted',
            responded_at: new Date(),
            updated_at: new Date()
        });
        const requiredCount = request.avatarCount || request.avatar_count || 1;
        console.log(`[acceptOrder] 检查接单进度: avatarCount=${request.avatarCount}, avatar_count=${request.avatar_count}, requiredCount=${requiredCount}`);
        const acceptedCountRows = await db.query('SELECT COUNT(*) as count FROM order_dispatch_requests WHERE order_id = ? AND status = ?', [orderId, 'accepted']);
        const acceptedCount = acceptedCountRows?.[0]?.count || 0;
        const isMatchedAvatar = request._isMatchedAvatar === true;
        const matchedPendingRows = await db.query(`SELECT COUNT(*) as count FROM order_dispatch_requests WHERE order_id = ? AND status = 'pending'`, [orderId]);
        const matchedPendingCount = matchedPendingRows?.[0]?.count || 0;
        const shouldKick = !isMatchedAvatar && (acceptedCount + matchedPendingCount) >= requiredCount;
        console.log(`[acceptOrder] 踢人判断: isMatched=${isMatchedAvatar}, accepted=${acceptedCount}, pending=${matchedPendingCount}, required=${requiredCount}, shouldKick=${shouldKick}`);
        if (shouldKick) {
            const pendingDispatches = await db.query(`SELECT d.id, d.avatar_id, d.user_id, d.match_score 
         FROM order_dispatch_requests d
         WHERE d.order_id = ? AND d.status = 'pending' 
         ORDER BY d.match_score ASC, d.created_at ASC LIMIT 1`, [orderId]);
            const kickedDispatch = pendingDispatches?.[0];
            if (kickedDispatch) {
                const kickedAvatarId = kickedDispatch.avatarId || kickedDispatch.avatar_id;
                const kickedUserId = kickedDispatch.userId || kickedDispatch.user_id;
                await db.updateWhere('order_dispatch_requests', { id: kickedDispatch.id }, {
                    status: 'kicked',
                    reject_reason: '订单已被其他分身抢先接单，名额已满',
                    updated_at: new Date()
                });
                console.log(`[acceptOrder] 踢出未接单匹配分身(匹配度最低): avatarId=${kickedAvatarId}, matchScore=${kickedDispatch.matchScore || kickedDispatch.match_score}, dispatchId=${kickedDispatch.id}`);
                let kickedAvatarName = '分身';
                try {
                    const avatarInfo = await db.query('SELECT name FROM avatars WHERE id = ?', [kickedAvatarId]);
                    kickedAvatarName = avatarInfo?.[0]?.name || '分身';
                }
                catch { }
                try {
                    await this.notificationService.createNotification({
                        user_id: kickedUserId,
                        type: 'order_snatched',
                        title: '订单被抢',
                        content: `你的分身"${kickedAvatarName}"的订单"${request.orderTitle || request.order_title || '内容创作'}"已被其他分身抢先接单，你太慢了！`,
                        metadata: {
                            avatarId: kickedAvatarId,
                            orderId,
                            dispatchRequestId: kickedDispatch.id,
                            kickedReason: 'order_snatched'
                        }
                    });
                    console.log(`[acceptOrder] 已通知被踢分身用户: userId=${kickedUserId}`);
                }
                catch (err) {
                    console.error('[acceptOrder] 创建被踢通知失败:', err);
                }
            }
        }
        if (acceptedCount >= requiredCount) {
            await db.updateWhere('orders', { id: orderId }, {
                status: 'in_progress',
                updated_at: new Date()
            });
            console.log(`[acceptOrder] 所有分身已接单(${acceptedCount}/${requiredCount})，订单状态更新为 in_progress`);
        }
        else {
            console.log(`[acceptOrder] 分身接单进度: ${acceptedCount}/${requiredCount}，等待其他分身接单`);
        }
        let acceptedAvatarName = '分身';
        try {
            const avatarInfo = await db.query('SELECT name FROM avatars WHERE id = ?', [actualAvatarId]);
            acceptedAvatarName = avatarInfo?.[0]?.name || '分身';
        }
        catch { }
        this.eventService.recordEvent({
            orderId,
            dispatchId: request.id,
            avatarId: actualAvatarId,
            userId: request.ownerUserId,
            eventType: 'accepted',
            source: 'avatar',
            avatarName: acceptedAvatarName,
            eventData: { respondedAt: new Date().toISOString() },
        }).catch(err => console.warn('[事件] accepted 记录失败:', err.message));
        try {
            await this.notificationService.createNotification({
                user_id: request.ownerUserId,
                type: 'avatar_accepted_order',
                title: '分身已接受订单',
                content: `分身"${request.avatar_name || '未知'}"已接受订单"${request.order_title || '内容创作'}"`,
                metadata: {
                    avatarId: actualAvatarId,
                    orderId,
                    dispatchRequestId: request.id
                }
            });
        }
        catch (err) {
            console.error('[acceptOrder] 创建通知失败:', err);
        }
        this.startContentGeneration(orderId, actualAvatarId, request).catch(err => {
            console.error('[acceptOrder] 启动内容生成失败:', err);
        });
        const processingRecord = await this.waitForProcessingRecord(orderId, actualAvatarId);
        return {
            success: true,
            orderId,
            avatarId: actualAvatarId,
            dispatchId: request.id,
            requestId: processingRecord?.id || processingRecord?.requestId || '',
        };
    }
    async waitForProcessingRecord(orderId, avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const maxAttempts = 5;
        for (let attempt = 0; attempt < maxAttempts; attempt++) {
            const waitRows = await db.query(`SELECT id, order_id, avatar_id
         FROM content_generation_requests
         WHERE order_id = ? AND avatar_id = ?
         ORDER BY created_at DESC
         LIMIT 1`, [orderId, avatarId]);
            if (waitRows?.[0]) {
                return waitRows[0];
            }
            await new Promise((resolve) => setTimeout(resolve, 150));
        }
        return null;
    }
    async declineOrder(dispatchId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const declineRows = await db.query('SELECT * FROM order_dispatch_requests WHERE id = ?', [dispatchId]);
        const request = declineRows?.[0];
        if (!request) {
            throw new Error('分派记录不存在');
        }
        await db.updateWhere('order_dispatch_requests', { id: dispatchId }, {
            status: 'declined',
            responded_at: new Date(),
            updated_at: new Date()
        });
        let declinedAvatarName = '分身';
        try {
            const avatarInfo = await db.query('SELECT name FROM avatars WHERE id = ?', [request.avatarId]);
            declinedAvatarName = avatarInfo?.[0]?.name || '分身';
        }
        catch { }
        this.eventService.recordEvent({
            orderId: request.orderId,
            dispatchId,
            avatarId: request.avatarId,
            eventType: 'rejected',
            source: 'avatar',
            avatarName: declinedAvatarName,
        }).catch(err => console.warn('[事件] rejected 记录失败:', err.message));
        console.log(`[declineOrder] 已婉拒: dispatchId=${dispatchId}`);
        return { success: true };
    }
    async startContentGeneration(orderId, avatarId, request) {
        const MAX_RETRIES = 3;
        let lastError = null;
        for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                await this._doStartContentGeneration(orderId, avatarId, request);
                return;
            }
            catch (err) {
                lastError = err;
                console.warn(`[startContentGeneration] 第${attempt}次尝试失败: ${err.message}`);
                if (attempt < MAX_RETRIES) {
                    await new Promise(r => setTimeout(r, 2000 * attempt));
                }
            }
        }
        console.error(`[startContentGeneration] ${MAX_RETRIES}次重试全部失败，创建兜底 failed 记录: orderId=${orderId}`);
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            const requestId = `req_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
            await db.insert('content_generation_requests', {
                id: requestId,
                order_id: orderId,
                avatar_id: avatarId,
                content_type: 'image_text',
                content_quantity: 1,
                status: 'failed',
                error_message: `内容生成启动失败(${MAX_RETRIES}次重试): ${lastError?.message || '未知错误'}`,
                order_title: request?.order_title || '',
                created_at: new Date(),
                updated_at: new Date(),
            });
        }
        catch (fallbackErr) {
            console.error('[startContentGeneration] 创建兜底记录也失败:', fallbackErr.message);
        }
    }
    async _doStartContentGeneration(orderId, avatarId, request) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const order = await this.getOrderById(orderId);
        if (!order) {
            throw new Error(`订单不存在: ${orderId}`);
        }
        const platforms = order.platforms ? JSON.parse(order.platforms) : ['wechat'];
        const normalizedPlatforms = platforms.map((p) => p === 'general' ? 'wechat' : p);
        let avatarName;
        let avatarPersonality;
        let avatarSkills = [];
        let contentStyles = [];
        let nicheTags = [];
        if (avatarId) {
            try {
                const avatarRows = await db.query('SELECT name, personality, content_styles, niche_tags FROM avatars WHERE id = ? AND status = \'active\'', [avatarId]);
                const avatar = avatarRows?.[0];
                if (avatar) {
                    avatarName = avatar.name;
                    avatarPersonality = avatar.personality;
                    contentStyles = typeof avatar.contentStyles === 'string' ? JSON.parse(avatar.contentStyles) : (avatar.contentStyles || []);
                    nicheTags = typeof avatar.nicheTags === 'string' ? JSON.parse(avatar.nicheTags) : (avatar.nicheTags || []);
                }
                const skillRows = await db.query('SELECT skill_id FROM avatar_skills WHERE avatar_id = ?', [avatarId]);
                avatarSkills = skillRows?.map((s) => s.skillId || s.skill_id) || [];
            }
            catch (err) {
                console.warn('[startContentGeneration] 获取分身信息失败:', err.message);
            }
        }
        let preferredStyles = [];
        let industryTags = [];
        try {
            preferredStyles = order.preferredStyles
                ? (typeof order.preferredStyles === 'string' ? JSON.parse(order.preferredStyles) : order.preferredStyles)
                : [];
            industryTags = order.industryTags
                ? (typeof order.industryTags === 'string' ? JSON.parse(order.industryTags) : order.industryTags)
                : [];
        }
        catch (_) { }
        await this.contentGenerationService.generateContent({
            orderId,
            avatarId,
            orderTitle: request.order_title || order.title || '内容生成',
            orderDescription: request.description || order.description || '',
            platforms: normalizedPlatforms,
            contentType: order.contentType || order.content_type || 'image_text',
            targetAudience: request.target_audience || order.targetAudience || '年轻用户',
            contentQuantity: request.quantityPerAvatar || request.quantity_per_avatar || order.quantityPerAvatar || order.quantity_per_avatar || 1,
            avatarName,
            avatarPersonality,
            avatarSkills,
            contentStyles,
            nicheTags,
            preferredStyles,
            industryTags,
        });
        console.log(`[startContentGeneration] 内容生成已启动: orderId=${orderId}, avatarId=${avatarId}, skills=${avatarSkills.join(',')}`);
    }
    async getOrderById(orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const orderRows3 = await db.query('SELECT * FROM orders WHERE id = ?', [orderId]);
        return orderRows3?.[0] || null;
    }
    async cancelDispatch(orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        await db.updateWhere('order_dispatch_requests', { order_id: orderId, status: 'pending' }, {
            status: 'cancelled',
            updated_at: new Date()
        });
        return { success: true };
    }
    async getAvatarAcceptedOrders(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const avatarCheckRows2 = await db.query('SELECT id FROM avatars WHERE id = ? AND status = \'active\'', [avatarId]);
        if (!avatarCheckRows2 || avatarCheckRows2.length === 0)
            return [];
        const acceptedRows = await db.query(`
      SELECT r.*, o.title, o.status as order_status, o.budget, o.created_at as order_created_at
      FROM order_dispatch_requests r
      INNER JOIN orders o ON r.order_id = o.id
      WHERE r.avatar_id = ? AND r.status = 'accepted'
      ORDER BY r.updated_at DESC
    `, [avatarId]);
        return acceptedRows || [];
    }
    async getUserAcceptedOrders(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const userAcceptedRows = await db.query(`
      SELECT r.*, o.title, o.status as order_status, o.budget, o.created_at as order_created_at, a.name as avatar_name
      FROM order_dispatch_requests r
      INNER JOIN orders o ON r.order_id = o.id
      INNER JOIN avatars a ON r.avatar_id = a.id AND a.status = 'active'
      WHERE r.user_id = ? AND r.status = 'accepted'
      ORDER BY r.updated_at DESC
    `, [userId]);
        return userAcceptedRows || [];
    }
    async hasAcceptedRequest(orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const countRows = await db.query(`
      SELECT COUNT(*) as count 
      FROM order_dispatch_requests 
      WHERE order_id = ? AND status = 'accepted'
    `, [orderId]);
        return (countRows?.[0]?.count || 0) > 0;
    }
    async getOrderAcceptors(orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const acceptorRows = await db.query(`
      SELECT a.*, r.id as dispatch_request_id
      FROM order_dispatch_requests r
      INNER JOIN avatars a ON r.avatar_id = a.id AND a.status = 'active'
      WHERE r.order_id = ? AND r.status = 'accepted'
    `, [orderId]);
        return acceptorRows || [];
    }
    async notifyAvatars(orderId, avatarIds, customMessage) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const notifyOrderRows = await db.query('SELECT * FROM orders WHERE id = ?', [orderId]);
        const order = notifyOrderRows?.[0];
        if (!order) {
            throw new Error('订单不存在');
        }
        let notifiedCount = 0;
        let smsSentCount = 0;
        for (const avatarId of avatarIds) {
            const notifyAvatarRows = await db.query(`
        SELECT a.*, u.phone AS user_phone 
        FROM avatars a 
        LEFT JOIN users u ON a.user_id = u.id 
        WHERE a.id = ? AND a.status = 'active'`, [avatarId]);
            const avatar = notifyAvatarRows?.[0];
            if (!avatar)
                continue;
            const message = customMessage || `您有新的订单任务：${order.title || '内容创作'}，请及时查收并完成。`;
            const smsContent = `【莫瑞拉】${message}`;
            const notifId = crypto.randomUUID();
            const notifResult = await db.insert('avatar_notifications', {
                id: notifId,
                avatar_id: avatarId,
                notification_type: 'order_assigned',
                title: '新订单分配',
                content: message,
                is_read: 0,
                data: JSON.stringify({ orderId }),
                created_at: new Date()
            });
            if (notifResult.error) {
                console.error('[dispatchToAllAvatars] 创建分身通知记录失败:', notifResult.error);
            }
            const userPhone = avatar.userPhone || avatar.phone;
            console.log('[dispatchToAllAvatars] 分身手机号检查:', avatar.name, avatar.user_phone, avatar.phone, userPhone);
            if (userPhone) {
                try {
                    const smsResult = await this.smsService.sendSms(userPhone, 'SMS_505555078', { name: avatar.name });
                    if (smsResult) {
                        smsSentCount++;
                        console.log(`[SMS] 通知短信发送给 ${avatar.name} (用户手机: ${userPhone}) 成功`);
                    }
                }
                catch (err) {
                    console.error(`[SMS] 发送给 ${avatar.name} 失败:`, err);
                }
            }
            else {
                console.log(`[SMS] 分身 ${avatar.name} 的账号未绑定手机号，跳过短信发送`);
            }
            notifiedCount++;
        }
        return { count: notifiedCount, smsSentCount };
    }
};
exports.OrderDispatchService = OrderDispatchService;
exports.OrderDispatchService = OrderDispatchService = OrderDispatchService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)((0, common_1.forwardRef)(() => sms_service_1.SmsService))),
    __param(1, (0, common_1.Inject)((0, common_1.forwardRef)(() => notification_service_1.NotificationService))),
    __param(2, (0, common_1.Inject)((0, common_1.forwardRef)(() => content_generation_service_1.ContentGenerationService))),
    __param(3, (0, common_1.Inject)((0, common_1.forwardRef)(() => order_service_1.OrderService))),
    __param(4, (0, common_1.Inject)((0, common_1.forwardRef)(() => order_event_service_1.OrderEventService))),
    __metadata("design:paramtypes", [sms_service_1.SmsService,
        notification_service_1.NotificationService,
        content_generation_service_1.ContentGenerationService,
        order_service_1.OrderService,
        order_event_service_1.OrderEventService])
], OrderDispatchService);
