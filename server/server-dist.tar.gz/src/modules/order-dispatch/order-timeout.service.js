"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var OrderTimeoutService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderTimeoutService = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const uuid_1 = require("uuid");
const mysql_client_1 = require("../../storage/database/mysql-client");
const notification_service_1 = require("../notification/notification.service");
let OrderTimeoutService = OrderTimeoutService_1 = class OrderTimeoutService {
    constructor() {
        this.logger = new common_1.Logger(OrderTimeoutService_1.name);
        this.DISPATCH_TIMEOUT = 30 * 60;
        this.CONTENT_TIMEOUT = 2 * 3600;
        this.PUBLISH_TIMEOUT = 24 * 3600;
        this.ACCEPTANCE_REMIND_TIMEOUT = 6 * 3600;
        this.MAX_RETRIES = 3;
        this.lastAcceptanceRemindAt = new Map();
        this.eventService = null;
    }
    async getEventService() {
        if (!this.eventService) {
            try {
                const { OrderEventService } = await Promise.resolve().then(() => require('./order-event.service'));
                this.eventService = new OrderEventService();
                this.logger.log('OrderEventService 加载成功');
            }
            catch (err) {
                this.logger.warn(`OrderEventService 加载失败: ${err.message}`);
            }
        }
        return this.eventService;
    }
    async handleTimeoutOrders() {
        const result = { dispatch: 0, content: 0, publish: 0, acceptance: 0, total: 0 };
        try {
            result.dispatch = await this.checkDispatchTimeouts();
            result.content = await this.checkContentTimeouts();
            result.publish = await this.checkPublishTimeouts();
            result.acceptance = await this.checkAcceptanceTimeouts();
            result.total = result.dispatch + result.content + result.publish + result.acceptance;
        }
        catch (error) {
            this.logger.error(`定时任务执行失败: ${error.message}`);
        }
        return result;
    }
    async checkAcceptanceTimeouts() {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const timeoutTime = new Date(Date.now() - this.ACCEPTANCE_REMIND_TIMEOUT * 1000);
        const orders = await client.query(`SELECT id, user_id, title, updated_at
       FROM orders
       WHERE status = 'awaiting_acceptance'
       AND updated_at < ?
       ORDER BY updated_at ASC
       LIMIT 200`, [timeoutTime]);
        if (!orders || orders.length === 0)
            return 0;
        let reminded = 0;
        const notificationService = new notification_service_1.NotificationService();
        for (const order of orders) {
            const orderId = order.id || order.orderId;
            const userId = order.userId || order.user_id;
            if (!orderId || !userId)
                continue;
            const lastAt = this.lastAcceptanceRemindAt.get(orderId) || 0;
            if (lastAt && Date.now() - lastAt < this.ACCEPTANCE_REMIND_TIMEOUT * 1000)
                continue;
            try {
                const orderTitle = order.title || '订单';
                await notificationService.createTemplateNotification(userId, 'acceptance_overdue', { orderTitle }, { orderId });
                this.lastAcceptanceRemindAt.set(orderId, Date.now());
                reminded += 1;
            }
            catch (error) {
                this.logger.warn(`验收超时提醒发送失败: orderId=${orderId}`);
            }
        }
        return reminded;
    }
    async checkDispatchTimeouts() {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const timeoutTime = new Date(Date.now() - this.DISPATCH_TIMEOUT * 1000);
        const dispatches = await client.query(`SELECT od.id, od.order_id, od.target_avatar_id as avatar_id, o.status as order_status
       FROM order_dispatch_requests od
       JOIN orders o ON od.order_id = o.id
       WHERE od.status = 'pending' 
       AND od.target_avatar_id IS NOT NULL
       AND od.created_at < ?
       AND o.status IN ('pending_acceptance', 'awaiting_acceptance')`, [timeoutTime]);
        if (!dispatches || dispatches.length === 0)
            return 0;
        this.logger.log(`发现 ${dispatches.length} 个派单超时`);
        for (const dispatch of dispatches) {
            await this.handleDispatchTimeout(dispatch);
        }
        return dispatches.length;
    }
    async handleDispatchTimeout(dispatch) {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const logId = (0, uuid_1.v4)();
        let result = null;
        try {
            await client.query('START TRANSACTION');
            await client.query(`UPDATE order_dispatch_requests SET status = 'expired', responded_at = NOW() WHERE id = ? AND status = 'pending'`, [dispatch.id]);
            const orders = await client.query(`SELECT retry_count, max_retries, status FROM orders WHERE id = ?`, [dispatch.orderId]);
            const order = orders?.[0];
            if (!order) {
                await client.query('ROLLBACK');
                return;
            }
            let avatarName = '分身';
            try {
                const a = await client.query('SELECT name FROM avatars WHERE id = ?', [dispatch.avatarId]);
                avatarName = a?.[0]?.name || '分身';
            }
            catch { }
            if (order.retryCount >= (order.maxRetries || this.MAX_RETRIES)) {
                await client.query(`UPDATE orders SET status = 'auto_cancelled', auto_cancel_at = NOW() WHERE id = ?`, [dispatch.orderId]);
                await client.query(`INSERT INTO order_timeout_logs (id, order_id, dispatch_id, avatar_id, event_type, old_status, new_status, notes)
           VALUES (?, ?, ?, ?, 'auto_cancel', ?, 'auto_cancelled', ?)`, [logId, dispatch.orderId, dispatch.id, dispatch.avatarId, order.status,
                    `已重试${order.retryCount}次，无分身接单，自动取消`]);
                result = { action: 'auto_cancel', orderId: dispatch.orderId, dispatchId: dispatch.id, avatarId: dispatch.avatarId, avatarName, retryCount: order.retryCount };
                this.logger.warn(`订单 ${dispatch.orderId} 已自动取消（重试${order.retryCount}次无人接单）`);
            }
            else {
                await client.query(`UPDATE orders SET retry_count = retry_count + 1, status = 'awaiting_acceptance' WHERE id = ?`, [dispatch.orderId]);
                await client.query(`INSERT INTO order_timeout_logs (id, order_id, dispatch_id, avatar_id, event_type, old_status, new_status, notes)
           VALUES (?, ?, ?, ?, 'dispatch_timeout', ?, 'awaiting_acceptance', ?)`, [logId, dispatch.orderId, dispatch.id, dispatch.avatarId, order.status,
                    `分身${avatarName}超时未接单，准备重新派单(第${order.retryCount + 1}次)`]);
                result = { action: 'reassign', orderId: dispatch.orderId, dispatchId: dispatch.id, avatarId: dispatch.avatarId, avatarName, retryCount: order.retryCount + 1 };
                this.logger.log(`订单 ${dispatch.orderId} 派单超时，准备重新派单(第${order.retryCount + 1}次)`);
            }
            await client.query('COMMIT');
        }
        catch (error) {
            await client.query('ROLLBACK');
            this.logger.error(`处理派单超时失败: ${error.message}`);
            return;
        }
        if (result) {
            const evtSvc = await this.getEventService();
            if (evtSvc) {
                try {
                    if (result.action === 'auto_cancel') {
                        await evtSvc.recordEvent({
                            orderId: result.orderId, dispatchId: result.dispatchId, avatarId: result.avatarId,
                            eventType: 'auto_cancel', source: 'system', visibility: 'both',
                            title: `订单已自动取消（${result.avatarName}超时未接单，已重试${result.retryCount}次）`,
                            avatarName: result.avatarName,
                        });
                    }
                    else {
                        await evtSvc.recordEvent({
                            orderId: result.orderId, dispatchId: result.dispatchId, avatarId: result.avatarId,
                            eventType: 'expired', source: 'system', visibility: 'both',
                            title: `${result.avatarName}超时未接单`,
                            avatarName: result.avatarName,
                            content: `准备重新派单(第${result.retryCount}次)`,
                        });
                        await evtSvc.recordEvent({
                            orderId: result.orderId, avatarId: result.avatarId,
                            eventType: 'reassign', source: 'system', visibility: 'both',
                            title: `订单已重新派单`,
                            avatarName: result.avatarName,
                            content: `${result.avatarName}超时未接单，正在重新分配分身(第${result.retryCount}次)`,
                        });
                    }
                }
                catch (e) {
                    this.logger.warn(`事件记录失败: ${e.message}`);
                }
            }
        }
        try {
            await this.applyDispatchTimeoutGovernance(dispatch.avatarId || dispatch.avatar_id, dispatch.orderId || dispatch.order_id);
        }
        catch (e) {
            this.logger.warn(`派单超时治理处理失败: ${e.message}`);
        }
    }
    async applyDispatchTimeoutGovernance(avatarId, orderId) {
        if (!avatarId)
            return;
        const client = await (0, mysql_client_1.getMySQLClient)();
        const rows = await client.query(`SELECT COUNT(*) as cnt
       FROM order_dispatch_requests
       WHERE avatar_id = ?
       AND status = 'expired'
       AND updated_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)`, [avatarId]);
        const cnt = Number(rows?.[0]?.cnt || 0);
        if (cnt < 3)
            return;
        const existing = await client.query(`SELECT id FROM avatar_notifications
       WHERE avatar_id = ?
       AND type = 'hosting_auto_paused'
       AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
       LIMIT 1`, [avatarId]);
        if (existing && existing.length > 0)
            return;
        let paused = false;
        for (const field of ['trust_enabled', 'hosting_enabled', 'is_hosted']) {
            try {
                await client.query(`UPDATE avatars SET ${field} = 0 WHERE id = ?`, [avatarId]);
                paused = true;
                break;
            }
            catch { }
        }
        if (!paused)
            return;
        await client.insert('avatar_notifications', {
            id: (0, uuid_1.v4)(),
            avatar_id: avatarId,
            order_id: orderId || null,
            type: 'hosting_auto_paused',
            title: '托管已自动暂停',
            content: `24小时内派单超时达到${cnt}次，已自动暂停托管，请检查接单设置`,
            status: 'unread',
            created_at: new Date(),
            updated_at: new Date(),
        });
    }
    async checkContentTimeouts() {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const timeoutTime = new Date(Date.now() - this.CONTENT_TIMEOUT * 1000);
        const orders = await client.query(`SELECT o.id, o.status, o.assigned_to, o.retry_count, o.max_retries,
              (SELECT COUNT(*) FROM generated_content gc WHERE gc.order_id = o.id AND gc.status = 'completed') as completed_content
       FROM orders o
       WHERE o.status = 'in_progress'
       AND o.updated_at < ?
       AND NOT EXISTS (
         SELECT 1 FROM generated_content gc 
         WHERE gc.order_id = o.id AND gc.status = 'completed'
       )`, [timeoutTime]);
        if (!orders || orders.length === 0)
            return 0;
        this.logger.log(`发现 ${orders.length} 个内容生成超时订单`);
        for (const order of orders) {
            await this.handleContentTimeout(order);
        }
        return orders.length;
    }
    async handleContentTimeout(order) {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const logId = (0, uuid_1.v4)();
        let result = null;
        try {
            await client.query('START TRANSACTION');
            const processing = await client.query(`SELECT COUNT(*) as cnt FROM generated_content WHERE order_id = ? AND status = 'processing'`, [order.id]);
            if (processing?.[0]?.cnt > 0) {
                this.logger.log(`订单 ${order.id} 还有处理中的内容，暂不超时`);
                await client.query('ROLLBACK');
                return;
            }
            let avatarName = '分身';
            try {
                const a = await client.query('SELECT name FROM avatars WHERE id = ?', [order.assignedTo]);
                avatarName = a?.[0]?.name || '分身';
            }
            catch { }
            await client.query(`UPDATE order_dispatch_requests SET status = 'timeout' 
         WHERE order_id = ? AND avatar_id = ? AND status = 'accepted'`, [order.id, order.assignedTo]);
            if (order.retryCount >= (order.maxRetries || this.MAX_RETRIES)) {
                await client.query(`UPDATE orders SET status = 'auto_cancelled', auto_cancel_at = NOW() WHERE id = ?`, [order.id]);
                await client.query(`INSERT INTO order_timeout_logs (id, order_id, avatar_id, event_type, old_status, new_status, notes)
           VALUES (?, ?, ?, 'auto_cancel', 'in_progress', 'auto_cancelled', ?)`, [logId, order.id, order.assignedTo,
                    `${avatarName}接单后超时未产出内容，已重试${order.retryCount}次，自动取消`]);
                result = { action: 'auto_cancel', orderId: order.id, avatarId: order.assignedTo, retryCount: order.retryCount };
            }
            else {
                await client.query(`UPDATE orders SET status = 'awaiting_acceptance', retry_count = retry_count + 1, assigned_to = NULL WHERE id = ?`, [order.id]);
                await client.query(`INSERT INTO order_timeout_logs (id, order_id, avatar_id, event_type, old_status, new_status, notes)
           VALUES (?, ?, ?, 'auto_reassign', 'in_progress', 'awaiting_acceptance', ?)`, [logId, order.id, order.assignedTo,
                    `${avatarName}接单后超时未产出内容，重新派单(第${order.retryCount + 1}次)`]);
                result = { action: 'reassign', orderId: order.id, avatarId: order.assignedTo, retryCount: order.retryCount + 1 };
            }
            await client.query('COMMIT');
        }
        catch (error) {
            await client.query('ROLLBACK');
            this.logger.error(`处理内容超时失败: ${error.message}`);
            return;
        }
        if (result) {
            const evtSvc = await this.getEventService();
            if (evtSvc) {
                try {
                    if (result.action === 'auto_cancel') {
                        await evtSvc.recordEvent({
                            orderId: result.orderId, avatarId: result.avatarId,
                            eventType: 'auto_cancel', source: 'system', visibility: 'both',
                            title: `订单已自动取消（分身接单后超时未产出内容，已重试${result.retryCount}次）`,
                            avatarName: '分身',
                        });
                    }
                    else {
                        await evtSvc.recordEvent({
                            orderId: result.orderId, avatarId: result.avatarId,
                            eventType: 'timeout', source: 'system', visibility: 'both',
                            title: `分身接单后超时未产出内容`,
                            avatarName: '分身',
                            content: `准备重新派单(第${result.retryCount}次)`,
                        });
                    }
                }
                catch (e) {
                    this.logger.warn(`事件记录失败: ${e.message}`);
                }
            }
        }
    }
    async checkPublishTimeouts() {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const timeoutTime = new Date(Date.now() - this.PUBLISH_TIMEOUT * 1000);
        const orders = await client.query(`SELECT o.id, o.status, o.assigned_to
       FROM orders o
       WHERE o.status = 'content_generated'
       AND o.updated_at < ?`, [timeoutTime]);
        if (!orders || orders.length === 0)
            return 0;
        for (const order of orders) {
            const logId = (0, uuid_1.v4)();
            try {
                let avatarName = '分身';
                try {
                    const a = await client.query('SELECT name FROM avatars WHERE id = ?', [order.assignedTo]);
                    avatarName = a?.[0]?.name || '分身';
                }
                catch { }
                await client.query(`UPDATE orders SET status = 'publish_timeout' WHERE id = ?`, [order.id]);
                await client.query(`INSERT INTO order_timeout_logs (id, order_id, avatar_id, event_type, old_status, new_status, notes)
           VALUES (?, ?, ?, 'publish_timeout', 'content_generated', 'publish_timeout', ?)`, [logId, order.id, order.assignedTo,
                    `${avatarName}内容已生成但超过24小时未发布`]);
                this.logger.warn(`订单 ${order.id} 发布超时`);
                const evtSvc = await this.getEventService();
                if (evtSvc) {
                    try {
                        await evtSvc.recordEvent({
                            orderId: order.id, avatarId: order.assignedTo,
                            eventType: 'timeout_warning', source: 'system', visibility: 'both',
                            title: `${avatarName}内容已生成但超时未发布`,
                            avatarName,
                            content: '内容已生成超过24小时未发布，需要人工介入',
                        });
                    }
                    catch (e) {
                        this.logger.warn(`事件记录失败: ${e.message}`);
                    }
                }
            }
            catch (error) {
                this.logger.error(`处理发布超时失败: ${error.message}`);
            }
        }
        return orders.length;
    }
    async createDispatchWithExpiry(orderId, avatarId, userId) {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const dispatchId = (0, uuid_1.v4)();
        const expiresAt = new Date(Date.now() + this.DISPATCH_TIMEOUT * 1000);
        await client.query(`INSERT INTO order_dispatch_requests (id, order_id, avatar_id, user_id, status, expires_at)
       VALUES (?, ?, ?, ?, 'pending', ?)`, [dispatchId, orderId, avatarId, userId, expiresAt]);
        return dispatchId;
    }
    async acceptDispatch(dispatchId) {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const result = await client.query(`UPDATE order_dispatch_requests SET status = 'accepted', responded_at = NOW() 
       WHERE id = ? AND status = 'pending'`, [dispatchId]);
        return result.affectedRows > 0;
    }
    async rejectDispatch(dispatchId, reason) {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const result = await client.query(`UPDATE order_dispatch_requests SET status = 'rejected', responded_at = NOW(), reject_reason = ? 
       WHERE id = ? AND status = 'pending'`, [reason || '', dispatchId]);
        return result.affectedRows > 0;
    }
    async verifyPublish(orderId, proofUrl, publishUrl) {
        const client = await (0, mysql_client_1.getMySQLClient)();
        try {
            await client.query('START TRANSACTION');
            await client.query(`UPDATE orders SET publish_proof_url = ?, publish_verified = 1, status = 'completed' WHERE id = ?`, [proofUrl, orderId]);
            await client.query(`UPDATE generated_content SET publish_url = ?, verification_status = 'verified', verified_at = NOW()
         WHERE order_id = ?`, [publishUrl || '', orderId]);
            await client.query('COMMIT');
            return true;
        }
        catch (error) {
            await client.query('ROLLBACK');
            this.logger.error(`验证发布失败: ${error.message}`);
            return false;
        }
    }
    async getOrderTimeline(orderId) {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const logs = await client.query(`SELECT event_type, old_status, new_status, notes, created_at 
       FROM order_timeout_logs 
       WHERE order_id = ? 
       ORDER BY created_at ASC`, [orderId]);
        return logs || [];
    }
    async getAvatarPerformance(avatarId) {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const dispatchStats = await client.query(`SELECT 
         COUNT(*) as total_dispatched,
         SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) as accepted_count,
         SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_count,
         SUM(CASE WHEN status = 'expired' THEN 1 ELSE 0 END) as expired_count,
         SUM(CASE WHEN status = 'timeout' THEN 1 ELSE 0 END) as timeout_count,
         ROUND(AVG(CASE WHEN status = 'accepted' AND responded_at IS NOT NULL 
           THEN TIMESTAMPDIFF(SECOND, created_at, responded_at) ELSE NULL END)) as avg_response_seconds
       FROM order_dispatch_requests 
       WHERE target_avatar_id = ?`, [avatarId]);
        const contentStats = await client.query(`SELECT 
         COUNT(DISTINCT o.id) as total_accepted_orders,
         SUM(CASE WHEN o.status IN ('content_generated', 'published', 'completed') THEN 1 ELSE 0 END) as delivered_count,
         SUM(CASE WHEN o.status = 'auto_cancelled' THEN 1 ELSE 0 END) as failed_count
       FROM orders o
       WHERE o.assigned_to = ?`, [avatarId]);
        return {
            dispatch: dispatchStats?.[0] || {},
            content: contentStats?.[0] || {},
        };
    }
    async reassignOrder(orderId, reason) {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const orders = await client.query(`SELECT id, status, assigned_to, retry_count, max_retries FROM orders WHERE id = ?`, [orderId]);
        const order = orders?.[0];
        if (!order) {
            return { success: false, message: '订单不存在' };
        }
        if (order.retryCount >= order.maxRetries) {
            await client.query(`UPDATE orders SET status = 'auto_cancelled', auto_cancel_at = NOW() WHERE id = ?`, [orderId]);
            await this.logTimeout(orderId, null, order.assignedTo, 'auto_cancel', order.status, 'auto_cancelled', '超过最大重试次数，自动取消');
            return { success: false, message: '超过最大重试次数，订单已自动取消' };
        }
        if (order.assignedTo) {
            await client.query(`UPDATE order_dispatch_requests SET status = 'expired' WHERE order_id = ? AND avatar_id = ? AND status IN ('pending', 'accepted')`, [orderId, order.assignedTo]);
        }
        await client.query(`UPDATE orders SET 
        status = 'awaiting_acceptance',
        assigned_to = NULL,
        retry_count = retry_count + 1,
        deadline_at = DATE_ADD(NOW(), INTERVAL 30 MINUTE)
      WHERE id = ?`, [orderId]);
        await this.logTimeout(orderId, null, order.assignedTo, 'auto_reassign', order.status, 'awaiting_acceptance', reason || '手动转派');
        return { success: true, message: '订单已重新分配', retryCount: order.retryCount + 1 };
    }
    async logTimeout(orderId, dispatchId, avatarId, eventType, oldStatus, newStatus, notes) {
        const client = (0, mysql_client_1.getMySQLClient)();
        const id = 'otl_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);
        await client.query(`INSERT INTO order_timeout_logs (id, order_id, dispatch_id, avatar_id, event_type, old_status, new_status, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, [id, orderId, dispatchId, avatarId, eventType, oldStatus, newStatus, notes]);
    }
};
exports.OrderTimeoutService = OrderTimeoutService;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_MINUTE),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OrderTimeoutService.prototype, "handleTimeoutOrders", null);
exports.OrderTimeoutService = OrderTimeoutService = OrderTimeoutService_1 = __decorate([
    (0, common_1.Injectable)()
], OrderTimeoutService);
