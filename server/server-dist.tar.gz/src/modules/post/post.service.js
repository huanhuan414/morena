"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
let PostService = class PostService {
    async createPost(data) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const id = crypto.randomUUID();
        await db.insert('posts', {
            id,
            user_id: data.user_id,
            avatar_id: data.avatar_id || null,
            content: data.content,
            media_urls: JSON.stringify(data.media_urls || []),
            platform: data.platform || 'local',
            status: 'published',
            likes_count: 0,
            comments_count: 0,
            shares_count: 0,
            created_at: new Date(),
            updated_at: new Date()
        });
        return { id };
    }
    async getPosts(userId, page = 1, pageSize = 20) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const filters = {};
        if (userId) {
            filters.user_id = userId;
        }
        const posts = await db.query('posts', filters);
        const total = posts?.length || 0;
        const offset = (page - 1) * pageSize;
        return {
            list: posts?.slice(offset, offset + pageSize) || [],
            total,
            page,
            pageSize
        };
    }
    async getPost(postId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        return await db.queryOne('posts', { id: postId });
    }
    async deletePost(postId, userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const post = await db.queryOne('posts', { id: postId });
        if (!post) {
            throw new Error('帖子不存在');
        }
        if (post.user_id !== userId) {
            throw new Error('无权限删除此帖子');
        }
        await db.delete('posts', { id: postId });
        return { success: true };
    }
};
exports.PostService = PostService;
exports.PostService = PostService = __decorate([
    (0, common_1.Injectable)()
], PostService);
const crypto = require("crypto");
