"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImageGenService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const crypto = require("crypto");
let ImageGenService = class ImageGenService {
    constructor() {
        this.baseUrl = process.env.IMAGE_GEN_API_BASE_URL || 'https://api.aaigc.top';
        this.apiKey = process.env.IMAGE_GEN_API_KEY || 'sk-z1CFQbVdKI6x7ciJLwQkp1vPJPp8P9lQWW0jJGQWUdkSuQsK';
        this.model = process.env.IMAGE_GEN_MODEL || 'gpt-image-2-all';
    }
    async generate(params) {
        const { userId, prompt, style = 'realistic', size = '1024x1536', n = 1 } = params;
        console.log(`[ImageGenService] generate: userId=${userId}, prompt="${prompt.slice(0, 50)}", style=${style}, size=${size}`);
        const apiUrl = `${this.baseUrl}/v1/images/generations`;
        console.log(`[ImageGenService] calling API: ${apiUrl}, model: ${this.model}`);
        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.apiKey}`,
                'Accept': 'application/json',
            },
            body: JSON.stringify({
                model: this.model,
                prompt,
                n,
                size,
            }),
        });
        if (!response.ok) {
            const errorText = await response.text();
            console.error(`[ImageGenService] API error: ${response.status} ${errorText}`);
            throw new Error(`图片生成API错误: ${response.status} ${errorText.slice(0, 200)}`);
        }
        const result = await response.json();
        console.log(`[ImageGenService] API response:`, JSON.stringify(result).slice(0, 300));
        let imageUrl = '';
        if (result.data && Array.isArray(result.data) && result.data.length > 0) {
            const firstItem = result.data[0];
            if (firstItem.url) {
                imageUrl = firstItem.url;
            }
            else if (firstItem.b64_json) {
                imageUrl = `data:image/png;base64,${firstItem.b64_json}`;
            }
        }
        if (!imageUrl) {
            throw new Error('图片生成返回数据为空');
        }
        console.log(`[ImageGenService] 图片生成成功, url: ${imageUrl.slice(0, 80)}...`);
        const recordId = crypto.randomUUID();
        try {
            const pool = (0, mysql_client_1.getPool)();
            await pool.query(`INSERT INTO generated_content (id, user_id, avatar_id, task_id, type, order_id, content_type, prompt, result, images, video_url, status, metadata, created_at)
         VALUES (?, ?, NULL, NULL, ?, NULL, ?, ?, ?, ?, NULL, ?, ?, NOW())`, [
                recordId,
                userId,
                'image',
                'image',
                prompt,
                JSON.stringify({ url: imageUrl, style, size, model: this.model }),
                imageUrl,
                'completed',
                JSON.stringify({ style, size, model: this.model, apiResponse: { created: result.created } }),
            ]);
            console.log('[ImageGenService] 保存记录成功, id:', recordId);
        }
        catch (dbError) {
            console.error('[ImageGenService] 保存记录失败:', dbError.message);
        }
        return {
            id: recordId,
            url: imageUrl,
            prompt,
            style,
            size,
            createdAt: new Date().toISOString(),
        };
    }
    async getHistory(userId, page = 1, pageSize = 20) {
        const offset = (page - 1) * pageSize;
        const pool = (0, mysql_client_1.getPool)();
        const [rows] = await pool.query(`SELECT id, prompt, images, content_type, metadata, status, created_at 
       FROM generated_content 
       WHERE user_id = ? AND content_type = 'image' 
       ORDER BY created_at DESC 
       LIMIT ? OFFSET ?`, [userId, pageSize, offset]);
        const [countRows] = await pool.query(`SELECT COUNT(*) as total FROM generated_content WHERE user_id = ? AND content_type = 'image'`, [userId]);
        const countData = countRows;
        const total = countData[0]?.total || 0;
        return {
            list: (Array.isArray(rows) ? rows : []).map((r) => {
                let meta = r.metadata;
                if (typeof meta === 'string') {
                    try {
                        meta = JSON.parse(meta);
                    }
                    catch {
                        meta = {};
                    }
                }
                return {
                    id: r.id,
                    prompt: r.prompt,
                    url: r.images,
                    style: meta?.style,
                    size: meta?.size,
                    status: r.status,
                    createdAt: r.created_at,
                };
            }),
            total,
            page,
            pageSize,
        };
    }
    async getById(id, userId) {
        const pool = (0, mysql_client_1.getPool)();
        const [rows] = await pool.query(`SELECT id, prompt, images, result, metadata, status, created_at FROM generated_content WHERE id = ? AND user_id = ?`, [id, userId]);
        const record = Array.isArray(rows) ? rows[0] : null;
        if (!record) {
            return null;
        }
        let meta = record.metadata;
        if (typeof meta === 'string') {
            try {
                meta = JSON.parse(meta);
            }
            catch {
                meta = {};
            }
        }
        let resultData = record.result;
        if (typeof resultData === 'string') {
            try {
                resultData = JSON.parse(resultData);
            }
            catch {
                resultData = {};
            }
        }
        return {
            id: record.id,
            prompt: record.prompt,
            url: record.images,
            result: resultData,
            metadata: meta,
            status: record.status,
            createdAt: record.created_at,
        };
    }
    async delete(id, userId) {
        const pool = (0, mysql_client_1.getPool)();
        await pool.query('DELETE FROM generated_content WHERE id = ? AND user_id = ?', [id, userId]);
        return true;
    }
};
exports.ImageGenService = ImageGenService;
exports.ImageGenService = ImageGenService = __decorate([
    (0, common_1.Injectable)()
], ImageGenService);
