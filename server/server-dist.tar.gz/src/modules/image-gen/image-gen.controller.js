"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImageGenController = void 0;
const common_1 = require("@nestjs/common");
const image_gen_service_1 = require("./image-gen.service");
let ImageGenController = class ImageGenController {
    constructor(imageGenService) {
        this.imageGenService = imageGenService;
    }
    async generate(body, req) {
        const userId = req.headers['x-user-id'];
        if (!userId) {
            return { code: 401, msg: '请先登录', data: null };
        }
        if (!body.prompt || body.prompt.trim().length === 0) {
            return { code: 400, msg: '请输入图片描述', data: null };
        }
        console.log(`[ImageGenController] generate: userId=${userId}, prompt="${body.prompt.slice(0, 50)}"`);
        try {
            const result = await this.imageGenService.generate({
                userId,
                prompt: body.prompt.trim(),
                style: body.style || 'realistic',
                size: body.size || '1024x1024',
            });
            return { code: 200, msg: '生成成功', data: result };
        }
        catch (error) {
            console.error('[ImageGenController] generate error:', error.message);
            return { code: 500, msg: error.message || '图片生成失败', data: null };
        }
    }
    async getHistory(page, pageSize, req) {
        const userId = req.headers['x-user-id'];
        if (!userId) {
            return { code: 401, msg: '请先登录', data: null };
        }
        try {
            const result = await this.imageGenService.getHistory(userId, parseInt(page || '1', 10), parseInt(pageSize || '20', 10));
            return { code: 200, msg: 'success', data: result };
        }
        catch (error) {
            console.error('[ImageGenController] getHistory error:', error.message);
            return { code: 500, msg: error.message || '获取历史失败', data: null };
        }
    }
    async getById(id, req) {
        const userId = req.headers['x-user-id'];
        if (!userId) {
            return { code: 401, msg: '请先登录', data: null };
        }
        try {
            const result = await this.imageGenService.getById(id, userId);
            if (!result) {
                return { code: 404, msg: '记录不存在', data: null };
            }
            return { code: 200, msg: 'success', data: result };
        }
        catch (error) {
            console.error('[ImageGenController] getById error:', error.message);
            return { code: 500, msg: error.message || '获取详情失败', data: null };
        }
    }
    async delete(id, req) {
        const userId = req.headers['x-user-id'];
        if (!userId) {
            return { code: 401, msg: '请先登录', data: null };
        }
        try {
            await this.imageGenService.delete(id, userId);
            return { code: 200, msg: '删除成功', data: null };
        }
        catch (error) {
            console.error('[ImageGenController] delete error:', error.message);
            return { code: 500, msg: error.message || '删除失败', data: null };
        }
    }
};
exports.ImageGenController = ImageGenController;
__decorate([
    (0, common_1.Post)('generate'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ImageGenController.prototype, "generate", null);
__decorate([
    (0, common_1.Get)('history'),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('pageSize')),
    __param(2, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], ImageGenController.prototype, "getHistory", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ImageGenController.prototype, "getById", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ImageGenController.prototype, "delete", null);
exports.ImageGenController = ImageGenController = __decorate([
    (0, common_1.Controller)('image-gen'),
    __param(0, (0, common_1.Inject)(image_gen_service_1.ImageGenService)),
    __metadata("design:paramtypes", [image_gen_service_1.ImageGenService])
], ImageGenController);
