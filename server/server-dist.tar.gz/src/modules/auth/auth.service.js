"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const crypto = require("crypto");
const mysql_client_1 = require("../../storage/database/mysql-client");
const sms_service_1 = require("./sms.service");
let AuthService = class AuthService {
    constructor(smsService) {
        this.smsService = smsService;
        this.codeCache = new Map();
        this.accessTokenCache = null;
    }
    async sendVerificationCode(phone) {
        if (!/^1[3-9]\d{9}$/.test(phone)) {
            throw new common_1.BadRequestException("请输入正确的手机号");
        }
        const cached = this.codeCache.get(phone);
        if (cached && cached.expiresAt > Date.now() + 4 * 60 * 1000) {
            const remainingTime = Math.ceil((cached.expiresAt - 4 * 60 * 1000 - Date.now()) / 1000);
            if (remainingTime > 0) {
                throw new common_1.BadRequestException(`${remainingTime}秒后可重新发送`);
            }
        }
        const code = this.smsService.generateCode();
        this.codeCache.set(phone, {
            code,
            expiresAt: Date.now() + 5 * 60 * 1000,
        });
        const result = await this.smsService.sendVerificationCode(phone, code);
        console.log(`[验证码] 手机号: ${phone}, 验证码: ${code}`);
        if (result.success && result.isDev) {
            return { ...result, code };
        }
        return result;
    }
    async phoneLogin(phone, code, nickname, referralCode) {
        if (!/^1[3-9]\d{9}$/.test(phone)) {
            throw new common_1.BadRequestException("请输入正确的手机号");
        }
        const cached = this.codeCache.get(phone);
        if (!cached) {
            throw new common_1.BadRequestException("请先获取验证码");
        }
        if (cached.expiresAt < Date.now()) {
            this.codeCache.delete(phone);
            throw new common_1.BadRequestException("验证码已过期，请重新获取");
        }
        if (cached.code !== code) {
            throw new common_1.BadRequestException("验证码错误");
        }
        this.codeCache.delete(phone);
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.query("users", { phone });
        const existingUser = Array.isArray(result)
            ? result[0]
            : result?.data?.[0];
        if (existingUser) {
            return {
                user: existingUser,
                isNewUser: false,
                token: this.generateToken(existingUser.id),
            };
        }
        const userId = require("uuid").v4();
        const newUserData = {
            id: userId,
            phone,
            openid: `phone_${phone}`,
            nickname: nickname || `用户${phone.slice(-4)}`,
            avatar: "",
            level: 1,
            exp: 0,
            credits: 100,
            referral_code: this.generateReferralCode(),
            created_at: new Date().toISOString().slice(0, 19).replace("T", " "),
            updated_at: new Date().toISOString().slice(0, 19).replace("T", " "),
        };
        const insertResult = await db.insert("users", newUserData);
        if (insertResult.error) {
            throw new Error(`创建用户失败: ${insertResult.error.message}`);
        }
        const newUserResult = await db.query("users", { phone });
        const newUser = Array.isArray(newUserResult)
            ? newUserResult[0]
            : newUserResult?.data?.[0];
        if (!newUser) {
            throw new Error("创建用户失败：未返回用户数据");
        }
        let referralReward = 0;
        if (referralCode && newUser) {
            console.log("[AuthService] 开始处理邀请码, referralCode:", referralCode, "newUser.id:", newUser.id);
            try {
                const referralResult = await this.processReferral(newUser.id, referralCode);
                referralReward = referralResult.reward;
                console.log("[AuthService] 邀请码处理成功, reward:", referralReward);
            }
            catch (error) {
                console.error("[AuthService] 处理邀请码失败:", error.message);
            }
        }
        else {
            console.log("[AuthService] 跳过邀请码处理, referralCode:", referralCode, "newUser:", !!newUser);
        }
        return {
            user: newUser,
            isNewUser: true,
            token: this.generateToken(newUser.id),
            referralReward,
        };
    }
    async processReferral(inviteeId, referralCode) {
        const db = (0, mysql_client_1.getMySQLClient)();
        console.log("[processReferral] 查找邀请人, referralCode:", referralCode);
        const inviterResult = await db.query("users", {
            referral_code: referralCode,
        });
        const inviter = Array.isArray(inviterResult)
            ? inviterResult[0]
            : inviterResult?.data?.[0];
        console.log("[processReferral] 查询结果 inviter:", inviter ? { id: inviter.id, phone: inviter.phone } : null);
        if (!inviter) {
            throw new Error("邀请码无效");
        }
        if (inviter.id === inviteeId) {
            throw new Error("不能使用自己的邀请码");
        }
        const existingReferralResult = await db.query("referrals", {
            referred_id: inviteeId,
        });
        const existingReferral = Array.isArray(existingReferralResult)
            ? existingReferralResult[0]
            : existingReferralResult?.data?.[0];
        if (existingReferral) {
            throw new Error("您已被邀请过");
        }
        const DAILY_INVITE_LIMIT = 20;
        try {
            const dailyCountResult = await db.query(`SELECT COUNT(*) as count FROM referrals WHERE referrer_id = ? AND DATE(created_at) = CURDATE()`, [inviter.id]);
            const dailyCount = dailyCountResult?.data?.[0]?.count ??
                (Array.isArray(dailyCountResult) ? dailyCountResult[0]?.count : 0) ??
                0;
            if (Number(dailyCount) >= DAILY_INVITE_LIMIT) {
                throw new Error("今日邀请已达上限");
            }
        }
        catch (e) {
            console.error("[processReferral] daily limit check failed:", e?.message || e);
        }
        const INVITER_REWARD = 5;
        console.log("[processReferral] 创建邀请记录, referrer_id:", inviter.id, "referred_id:", inviteeId);
        const referralId = require("uuid").v4();
        const insertResult = await db.insert("referrals", {
            id: referralId,
            referrer_id: inviter.id,
            referred_id: inviteeId,
            status: "pending",
            reward_amount: INVITER_REWARD,
            created_at: new Date().toISOString().slice(0, 19).replace("T", " "),
        });
        console.log("[processReferral] insert 结果:", JSON.stringify(insertResult));
        if (insertResult.error) {
            throw new Error(`创建邀请记录失败: ${insertResult.error.message || JSON.stringify(insertResult.error)}`);
        }
        return { inviterId: inviter.id, reward: 0 };
    }
    async wechatPhoneLogin(code, phoneCode, nickname, avatar, referralCode) {
        const wxAppId = process.env.WX_APP_ID;
        const wxAppSecret = process.env.WX_APP_SECRET;
        if (!wxAppId || !wxAppSecret) {
            throw new Error("微信配置未设置");
        }
        const wxUrl = `https://api.weixin.qq.com/sns/jscode2session?appid=${wxAppId}&secret=${wxAppSecret}&js_code=${code}&grant_type=authorization_code`;
        try {
            const wxResponse = await fetch(wxUrl);
            const wxData = await wxResponse.json();
            if (wxData.errcode) {
                throw new Error(`微信登录失败: ${wxData.errmsg}`);
            }
            const openid = wxData.openid;
            const accessToken = await this.getWechatAccessToken();
            const phone = await this.getWechatPhoneNumber(accessToken, phoneCode);
            if (!phone) {
                throw new Error("获取手机号失败");
            }
            const db = (0, mysql_client_1.getMySQLClient)();
            const result = await db.query("users", { phone });
            const existingUser = Array.isArray(result)
                ? result[0]
                : result?.data?.[0];
            if (existingUser) {
                const updateData = {};
                if (!existingUser.openid || existingUser.openid.startsWith("phone_")) {
                    updateData.openid = openid;
                }
                if (nickname && !existingUser.nickname) {
                    updateData.nickname = nickname;
                }
                if (avatar && !existingUser.avatar) {
                    updateData.avatar = avatar;
                }
                if (Object.keys(updateData).length > 0) {
                    await db.update("users", existingUser.id, updateData);
                    const updatedResult = await db.query("users", {
                        id: existingUser.id,
                    });
                    const updatedUser = Array.isArray(updatedResult)
                        ? updatedResult[0]
                        : updatedResult?.data?.[0];
                    return {
                        user: updatedUser || existingUser,
                        isNewUser: false,
                        token: this.generateToken(existingUser.id),
                    };
                }
                return {
                    user: existingUser,
                    isNewUser: false,
                    token: this.generateToken(existingUser.id),
                };
            }
            const userId = require("uuid").v4();
            const newUserData = {
                id: userId,
                openid,
                phone,
                nickname: nickname || `用户${phone.slice(-4)}`,
                avatar: avatar || "",
                level: 1,
                exp: 0,
                credits: 100,
                referral_code: this.generateReferralCode(),
                created_at: new Date().toISOString().slice(0, 19).replace("T", " "),
                updated_at: new Date().toISOString().slice(0, 19).replace("T", " "),
            };
            const insertResult = await db.insert("users", newUserData);
            if (insertResult.error) {
                throw new Error(`创建用户失败: ${insertResult.error.message}`);
            }
            const newUserResult = await db.query("users", { phone });
            const newUser = Array.isArray(newUserResult)
                ? newUserResult[0]
                : newUserResult?.data?.[0];
            if (!newUser) {
                throw new Error("创建用户失败：未返回用户数据");
            }
            let referralReward = 0;
            if (referralCode && newUser) {
                console.log("[AuthService] 微信手机号登录-处理邀请码, referralCode:", referralCode, "newUser.id:", newUser.id);
                try {
                    const referralResult = await this.processReferral(newUser.id, referralCode);
                    referralReward = referralResult.reward;
                }
                catch (error) {
                    console.error("[AuthService] 微信手机号登录-处理邀请码失败:", error.message);
                }
            }
            return {
                user: newUser,
                isNewUser: true,
                token: this.generateToken(newUser.id),
                referralReward,
            };
        }
        catch (error) {
            throw new Error(`微信手机号登录失败: ${error.message}`);
        }
    }
    async getWechatAccessToken() {
        const wxAppId = process.env.WX_APP_ID;
        const wxAppSecret = process.env.WX_APP_SECRET;
        const now = Date.now();
        const cached = this.accessTokenCache;
        if (cached && cached.expiresAt > now) {
            return cached.token;
        }
        const url = `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${wxAppId}&secret=${wxAppSecret}`;
        const res = await fetch(url);
        const data = await res.json();
        if (data.errcode) {
            throw new Error(`获取access_token失败: ${data.errmsg}`);
        }
        this.accessTokenCache = {
            token: data.access_token,
            expiresAt: now + (data.expires_in - 300) * 1000,
        };
        return data.access_token;
    }
    async getWechatPhoneNumber(accessToken, phoneCode) {
        const url = `https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token=${accessToken}`;
        const res = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ code: phoneCode }),
        });
        const data = await res.json();
        if (data.errcode !== 0) {
            console.error("[getWechatPhoneNumber] 获取手机号失败:", data);
            return null;
        }
        return (data.phone_info?.phoneNumber || data.phone_info?.purePhoneNumber || null);
    }
    async wechatLogin(code) {
        const wxAppId = process.env.WX_APP_ID;
        const wxAppSecret = process.env.WX_APP_SECRET;
        if (!wxAppId || !wxAppSecret) {
            throw new Error("微信配置未设置");
        }
        const wxUrl = `https://api.weixin.qq.com/sns/jscode2session?appid=${wxAppId}&secret=${wxAppSecret}&js_code=${code}&grant_type=authorization_code`;
        try {
            const wxResponse = await fetch(wxUrl);
            const wxData = await wxResponse.json();
            if (wxData.errcode) {
                throw new Error(`微信登录失败: ${wxData.errmsg}`);
            }
            const openid = wxData.openid;
            const sessionKey = wxData.session_key;
            return await this.createOrGetUser(openid);
        }
        catch (error) {
            throw new Error(`微信登录失败: ${error.message}`);
        }
    }
    async createOrGetUser(openid, nickname, avatar) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.query("users", { openid });
        const existingUser = Array.isArray(result)
            ? result[0]
            : result?.data?.[0];
        if (existingUser) {
            return {
                user: existingUser,
                token: this.generateToken(existingUser.id),
                isNewUser: false,
            };
        }
        const userId = require("uuid").v4();
        const newUserData = {
            id: userId,
            openid,
            nickname: nickname || "微信用户",
            avatar: avatar || "",
            level: 1,
            exp: 0,
            credits: 100,
            referral_code: this.generateReferralCode(),
            created_at: new Date().toISOString().slice(0, 19).replace("T", " "),
            updated_at: new Date().toISOString().slice(0, 19).replace("T", " "),
        };
        await db.insert("users", newUserData);
        const newUserResult = await db.query("users", { openid });
        const newUser = newUserResult?.data?.[0];
        if (!newUser) {
            throw new Error("创建用户失败");
        }
        return {
            user: newUser,
            token: this.generateToken(newUser.id),
            isNewUser: true,
        };
    }
    async getCurrentUser(authHeader) {
        const token = this.extractAuthorizationToken(authHeader);
        if (!token) {
            throw new common_1.UnauthorizedException("请先登录");
        }
        const userId = this.verifyToken(token);
        if (!userId) {
            throw new common_1.UnauthorizedException("登录已过期");
        }
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.query("users", { id: userId });
        const user = Array.isArray(result) ? result[0] : result?.data?.[0];
        if (!user) {
            throw new common_1.UnauthorizedException("用户不存在");
        }
        return { user };
    }
    extractAuthorizationToken(authHeader) {
        if (!authHeader) {
            return null;
        }
        const normalized = authHeader.trim();
        if (!normalized) {
            return null;
        }
        const matched = normalized.match(/^Bearer\s+(.+)$/i);
        if (matched) {
            return matched[1].trim();
        }
        return normalized;
    }
    async getUserById(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.query("users", { id: userId });
        return Array.isArray(result) ? result[0] : result?.data?.[0];
    }
    generateToken(userId) {
        const payload = { userId, iat: Date.now() };
        const secret = process.env.JWT_SECRET || "morena-secret-key";
        const encoded = Buffer.from(JSON.stringify(payload)).toString("base64");
        const signature = crypto
            .createHmac("sha256", secret)
            .update(encoded)
            .digest("hex");
        return `${encoded}.${signature}`;
    }
    verifyToken(token) {
        try {
            const [encoded, signature] = token.split(".");
            const secret = process.env.JWT_SECRET || "morena-secret-key";
            const expectedSignature = crypto
                .createHmac("sha256", secret)
                .update(encoded)
                .digest("hex");
            if (signature !== expectedSignature) {
                return null;
            }
            const payload = JSON.parse(Buffer.from(encoded, "base64").toString());
            if (Date.now() - payload.iat > 7 * 24 * 60 * 60 * 1000) {
                return null;
            }
            return payload.userId;
        }
        catch {
            return null;
        }
    }
    generateReferralCode() {
        return crypto.randomBytes(4).toString("hex").toUpperCase();
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)("AUTH_SMS_SERVICE")),
    __metadata("design:paramtypes", [sms_service_1.AuthSmsService])
], AuthService);
