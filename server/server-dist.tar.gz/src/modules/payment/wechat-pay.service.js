"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var WechatPayService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WechatPayService = void 0;
const common_1 = require("@nestjs/common");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const mysql_client_1 = require("../../storage/database/mysql-client");
let WechatPayService = WechatPayService_1 = class WechatPayService {
    constructor(orderService) {
        this.orderService = orderService;
        this.logger = new common_1.Logger(WechatPayService_1.name);
        this.appId = process.env.WECHAT_PAY_APPID || '';
        this.mchId = process.env.WECHAT_PAY_MCHID || '';
        this.apiKeyV2 = process.env.WECHAT_PAY_APIV2_KEY || process.env.WECHAT_PAY_APIV3_KEY || '';
        this.notifyUrl = process.env.WECHAT_PAY_NOTIFY_URL || '';
        const privateKeyPath = process.env.WECHAT_PAY_PRIVATE_KEY_PATH;
        if (privateKeyPath && fs.existsSync(path.resolve(privateKeyPath))) {
            this.privateKey = fs.readFileSync(path.resolve(privateKeyPath));
            this.logger.log('从文件加载商户私钥成功');
        }
        else {
            this.logger.error('商户私钥文件不存在，请检查 WECHAT_PAY_PRIVATE_KEY_PATH 配置');
        }
        this.logger.log(`微信支付(V2)初始化 - AppID: ${this.appId}, MchID: ${this.mchId}`);
    }
    async createOrder(params) {
        return this.createMiniProgramOrder({
            ...params,
            orderType: 'subscription',
        });
    }
    async createMiniProgramOrder(params) {
        const { userId, openid, planId, description, amount, orderType } = params;
        const outTradeNo = `MRL${Date.now()}${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
        const orderId = crypto.randomUUID();
        const db = (0, mysql_client_1.getMySQLClient)();
        await db.query(`INSERT INTO payment_orders (id, out_trade_no, plan_id, user_id, openid, order_type, amount, currency, payment_method, status, metadata, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'CNY', 'wechat', 'pending', ?, NOW(), NOW())`, [
            orderId,
            outTradeNo,
            planId,
            userId,
            openid,
            orderType,
            amount,
            JSON.stringify({ planId, description }),
        ]);
        this.logger.log(`创建本地支付订单: ${orderId}, outTradeNo: ${outTradeNo}, 金额: ${amount}元`);
        const amountInFen = Math.round(amount * 100);
        const unifiedOrderParams = {
            appid: this.appId,
            mch_id: this.mchId,
            nonce_str: crypto.randomUUID().replace(/-/g, '').substring(0, 32),
            body: description,
            out_trade_no: outTradeNo,
            total_fee: String(amountInFen),
            spbill_create_ip: '127.0.0.1',
            notify_url: this.notifyUrl,
            trade_type: 'JSAPI',
            openid: openid,
        };
        unifiedOrderParams.sign = this.signMd5(unifiedOrderParams);
        const xmlBody = this.buildXml(unifiedOrderParams);
        this.logger.log(`调用微信V2统一下单: outTradeNo=${outTradeNo}, amount=${amountInFen}分`);
        let prepayId;
        try {
            const axios = require('axios');
            const response = await axios.post('https://api.mch.weixin.qq.com/pay/unifiedorder', xmlBody, {
                headers: { 'Content-Type': 'application/xml' },
                timeout: 15000,
            });
            const result = this.parseXml(response.data);
            const returnCode = result.return_code;
            const resultCode = result.result_code;
            this.logger.log(`微信V2统一下单返回: return_code=${returnCode}, result_code=${resultCode}`);
            if (returnCode !== 'SUCCESS' || resultCode !== 'SUCCESS') {
                const errMsg = result.err_code_des || result.return_msg || '下单失败';
                const errCode = result.err_code || '';
                this.logger.error(`微信统一下单失败: err_code=${errCode}, err_msg=${errMsg}`);
                const db2 = (0, mysql_client_1.getMySQLClient)();
                await db2.query(`UPDATE payment_orders SET status = 'failed', metadata = JSON_SET(COALESCE(metadata, '{}'), '$.error', ?) WHERE id = ?`, [`${errCode}: ${errMsg}`, orderId]);
                throw new Error(`微信下单失败: ${errMsg}(${errCode})`);
            }
            prepayId = result.prepay_id;
            this.logger.log(`✅ 微信统一下单成功: prepay_id=${prepayId}`);
        }
        catch (error) {
            if (error.message.startsWith('微信下单失败:')) {
                throw error;
            }
            this.logger.error(`微信统一下单请求异常: ${error.message}`);
            const db2 = (0, mysql_client_1.getMySQLClient)();
            await db2.query(`UPDATE payment_orders SET status = 'failed', metadata = JSON_SET(COALESCE(metadata, '{}'), '$.error', ?) WHERE id = ?`, [error.message, orderId]);
            throw new Error(`微信下单请求失败: ${error.message}`);
        }
        const payParams = this.generateMiniProgramPayParams(prepayId);
        return {
            orderId,
            outTradeNo,
            prepayId,
            ...payParams,
        };
    }
    generateMiniProgramPayParams(prepayId) {
        const timeStamp = Math.floor(Date.now() / 1000).toString();
        const nonceStr = crypto.randomUUID().replace(/-/g, '');
        const packageStr = `prepay_id=${prepayId}`;
        const signParams = {
            appId: this.appId,
            nonceStr,
            package: packageStr,
            signType: 'MD5',
            timeStamp,
        };
        const paySign = this.signMd5(signParams);
        this.logger.log(`生成支付参数 - appId: ${this.appId}, timeStamp: ${timeStamp}, prepayId: ${prepayId}, signType: MD5`);
        return {
            appId: this.appId,
            timeStamp,
            nonceStr,
            packageValue: packageStr,
            signType: 'MD5',
            paySign,
        };
    }
    signMd5(params) {
        const sortedKeys = Object.keys(params).filter(k => params[k] !== undefined && params[k] !== '').sort();
        const stringA = sortedKeys.map(k => `${k}=${params[k]}`).join('&');
        const stringSignTemp = `${stringA}&key=${this.apiKeyV2}`;
        return crypto.createHash('md5').update(stringSignTemp, 'utf8').digest('hex').toUpperCase();
    }
    buildXml(params) {
        const xmlParts = Object.entries(params).map(([k, v]) => `<${k}><![CDATA[${v}]]></${k}>`);
        return `<xml>${xmlParts.join('')}</xml>`;
    }
    parseXml(xml) {
        const result = {};
        const regex = /<(\w+)>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?<\/\1>/g;
        let match;
        while ((match = regex.exec(xml)) !== null) {
            if (match[1] !== 'xml') {
                result[match[1]] = match[2];
            }
        }
        return result;
    }
    verifyNotifySign(params) {
        const sign = params.sign;
        if (!sign)
            return false;
        const paramsWithoutSign = { ...params };
        delete paramsWithoutSign.sign;
        delete paramsWithoutSign.sign_type;
        const expectedSign = this.signMd5(paramsWithoutSign);
        return sign === expectedSign;
    }
    async handlePaymentNotify(body, headers) {
        this.logger.log(`收到支付回调通知`);
        try {
            const result = this.parseXml(body);
            if (!this.verifyNotifySign(result)) {
                this.logger.error('回调通知签名验证失败');
                return { code: 'FAIL', message: '签名验证失败' };
            }
            const returnCode = result.return_code;
            const resultCode = result.result_code;
            const outTradeNo = result.out_trade_no;
            const transactionId = result.transaction_id;
            if (returnCode !== 'SUCCESS' || resultCode !== 'SUCCESS') {
                this.logger.warn(`交易状态非成功: return_code=${returnCode}, result_code=${resultCode}`);
                return this.buildNotifySuccessXml();
            }
            const db = (0, mysql_client_1.getMySQLClient)();
            const orders = await db.query(`SELECT * FROM payment_orders WHERE out_trade_no = ?`, [outTradeNo]);
            if (!orders || orders.length === 0) {
                this.logger.error(`未找到订单: outTradeNo=${outTradeNo}`);
                return { code: 'FAIL', message: '订单不存在' };
            }
            const order = orders[0];
            if (order.status === 'paid') {
                this.logger.log(`订单已处理过: ${outTradeNo}`);
                return this.buildNotifySuccessXml();
            }
            const totalFee = Number(result.total_fee || 0);
            await db.query(`UPDATE payment_orders SET status = 'paid', transaction_id = ?, paid_at = NOW(), metadata = JSON_SET(COALESCE(metadata, '{}'), '$.wechatTransactionId', ?, '$.paidAmount', ?) WHERE out_trade_no = ?`, [transactionId, transactionId, totalFee / 100, outTradeNo]);
            this.logger.log(`订单支付成功: outTradeNo=${outTradeNo}, transactionId=${transactionId}`);
            if (order.orderType === 'order' || order.order_type === 'order') {
                await this.activateOrder(order, transactionId);
            }
            else {
                await this.activateSubscription(order);
            }
            await this.uploadShippingInfo(transactionId, order);
            return this.buildNotifySuccessXml();
        }
        catch (error) {
            this.logger.error(`处理支付回调失败: ${error.message}`, error.stack);
            return { code: 'FAIL', message: error.message };
        }
    }
    buildNotifySuccessXml() {
        return '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>';
    }
    async uploadShippingInfo(transactionId, order) {
        try {
            const accessToken = await this.getMiniProgramAccessToken();
            if (!accessToken) {
                this.logger.warn('获取access_token失败，跳过发货信息上报');
                return;
            }
            const isOrderPayment = order.orderType === 'order' || order.order_type === 'order';
            const shippingData = {
                order_key: {
                    order_number_type: 2,
                    transaction_id: transactionId,
                },
                delivery_mode: 1,
                shipping_list: [
                    {
                        item_desc: isOrderPayment ? 'Morena AI 内容创作服务' : 'Morena AI 订阅服务',
                    },
                ],
                upload_time: new Date().toISOString().replace(/\.\d{3}Z$/, '+08:00'),
                payer: {
                    openid: order.openid || order.openId,
                },
            };
            const axios = require('axios');
            const response = await axios.post(`https://api.weixin.qq.com/wxa/sec/order/upload_shipping_info?access_token=${accessToken}`, shippingData, { timeout: 10000 });
            if (response.data?.errcode === 0) {
                this.logger.log(`✅ 发货信息上报成功: transactionId=${transactionId}`);
            }
            else {
                this.logger.warn(`⚠️ 发货信息上报失败: errcode=${response.data?.errcode}, errmsg=${response.data?.errmsg}`);
            }
        }
        catch (error) {
            this.logger.warn(`发货信息上报异常(不影响支付): ${error.message}`);
        }
    }
    async getMiniProgramAccessToken() {
        try {
            const appId = process.env.WX_APP_ID || this.appId;
            const appSecret = process.env.WX_APP_SECRET;
            if (!appId || !appSecret) {
                this.logger.warn('缺少WX_APP_ID或WX_APP_SECRET配置');
                return null;
            }
            const axios = require('axios');
            const response = await axios.get(`https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${appId}&secret=${appSecret}`, { timeout: 10000 });
            if (response.data?.access_token) {
                return response.data.access_token;
            }
            this.logger.warn(`获取access_token失败: ${JSON.stringify(response.data)}`);
            return null;
        }
        catch (error) {
            this.logger.warn(`获取access_token异常: ${error.message}`);
            return null;
        }
    }
    async activateOrder(order, transactionId) {
        try {
            const orderId = order.planId || order.plan_id;
            if (!orderId) {
                this.logger.error('订单支付回调: planId(orderId)为空，无法激活');
                return;
            }
            this.logger.log(`激活订单: orderId=${orderId}, transactionId=${transactionId}`);
            await this.orderService.handlePaymentSuccess(orderId, transactionId);
            this.logger.log(`✅ 订单激活成功: orderId=${orderId}`);
        }
        catch (error) {
            this.logger.error(`激活订单失败: ${error.message}`, error.stack);
        }
    }
    async activateSubscription(order) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const metadata = typeof order.metadata === 'string' ? JSON.parse(order.metadata) : (order.metadata || {});
        const planId = metadata.planId || order.planId;
        this.logger.log(`激活订阅: userId=${order.userId}, planId=${planId}`);
        const plans = await db.query(`SELECT * FROM subscription_plans WHERE id = ?`, [planId]);
        if (!plans || plans.length === 0) {
            this.logger.error(`订阅计划不存在: ${planId}`);
            return;
        }
        const plan = plans[0];
        const durationDays = plan.durationDays || 30;
        const now = new Date();
        const endDate = new Date(now.getTime() + durationDays * 24 * 60 * 60 * 1000);
        const maxAvatars = plan.maxAvatars || 1;
        const canReceiveOrders = plan.canReceiveOrders || 0;
        const existing = await db.query(`SELECT * FROM user_subscriptions WHERE user_id = ? AND status = 'active' ORDER BY end_date DESC LIMIT 1`, [order.userId]);
        if (existing && existing.length > 0) {
            const currentEnd = new Date(existing[0].endDate);
            const newEndDate = currentEnd > now
                ? new Date(currentEnd.getTime() + durationDays * 24 * 60 * 60 * 1000)
                : endDate;
            await db.query(`UPDATE user_subscriptions SET plan_id = ?, end_date = ?, max_avatars = ?, can_receive_orders = ?, updated_at = NOW() WHERE id = ?`, [planId, newEndDate, maxAvatars, canReceiveOrders, existing[0].id]);
            this.logger.log(`续订成功: userId=${order.userId}, 新到期日=${newEndDate}`);
        }
        else {
            await db.query(`INSERT INTO user_subscriptions (id, user_id, plan_id, status, start_date, end_date, max_avatars, can_receive_orders, created_at, updated_at)
         VALUES (?, ?, ?, 'active', ?, ?, ?, ?, NOW(), NOW())`, [
                crypto.randomUUID(),
                order.userId,
                planId,
                now,
                endDate,
                maxAvatars,
                canReceiveOrders,
            ]);
            this.logger.log(`新订阅激活: userId=${order.userId}, planId=${planId}, 到期日=${endDate}`);
        }
    }
    async queryOrderStatus(orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const orders = await db.query(`SELECT * FROM payment_orders WHERE id = ?`, [orderId]);
        return orders?.[0] || null;
    }
    async getUserOrders(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        return await db.query(`SELECT * FROM payment_orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 20`, [userId]);
    }
    async queryWechatOrderStatus(outTradeNo) {
        try {
            const params = {
                appid: this.appId,
                mch_id: this.mchId,
                out_trade_no: outTradeNo,
                nonce_str: crypto.randomUUID().replace(/-/g, '').substring(0, 32),
            };
            params.sign = this.signMd5(params);
            const xmlBody = this.buildXml(params);
            const axios = require('axios');
            const response = await axios.post('https://api.mch.weixin.qq.com/pay/orderquery', xmlBody, {
                headers: { 'Content-Type': 'application/xml' },
                timeout: 15000,
            });
            const result = this.parseXml(response.data);
            this.logger.log(`微信V2订单查询结果: trade_state=${result.trade_state}, out_trade_no=${outTradeNo}`);
            return result;
        }
        catch (error) {
            this.logger.error(`微信订单查询失败: ${error.message}`);
            throw error;
        }
    }
    async closeOrder(outTradeNo) {
        try {
            const params = {
                appid: this.appId,
                mch_id: this.mchId,
                out_trade_no: outTradeNo,
                nonce_str: crypto.randomUUID().replace(/-/g, '').substring(0, 32),
            };
            params.sign = this.signMd5(params);
            const xmlBody = this.buildXml(params);
            const axios = require('axios');
            const response = await axios.post('https://api.mch.weixin.qq.com/pay/closeorder', xmlBody, {
                headers: { 'Content-Type': 'application/xml' },
                timeout: 15000,
            });
            const result = this.parseXml(response.data);
            this.logger.log(`关闭订单结果: return_code=${result.return_code}, out_trade_no=${outTradeNo}`);
            const db = (0, mysql_client_1.getMySQLClient)();
            await db.query(`UPDATE payment_orders SET status = 'closed', updated_at = NOW() WHERE out_trade_no = ? AND status = 'pending'`, [outTradeNo]);
            return result;
        }
        catch (error) {
            this.logger.error(`关闭订单失败: ${error.message}`);
            throw error;
        }
    }
};
exports.WechatPayService = WechatPayService;
exports.WechatPayService = WechatPayService = WechatPayService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)((0, common_1.forwardRef)(() => 'ORDER_SERVICE'))),
    __metadata("design:paramtypes", [Object])
], WechatPayService);
