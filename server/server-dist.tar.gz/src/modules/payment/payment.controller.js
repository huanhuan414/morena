"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var PaymentController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentController = void 0;
const common_1 = require("@nestjs/common");
const wechat_pay_service_1 = require("./wechat-pay.service");
const mysql_client_1 = require("../../storage/database/mysql-client");
let PaymentController = PaymentController_1 = class PaymentController {
    constructor(wechatPayService) {
        this.wechatPayService = wechatPayService;
        this.logger = new common_1.Logger(PaymentController_1.name);
    }
    async createPayment(body) {
        const { userId, openid, planId } = body;
        this.logger.log(`创建支付请求 - userId: ${userId}, planId: ${planId}, openid: ${openid ? '***' : 'missing'}`);
        if (!userId || !planId) {
            return { code: 400, msg: '缺少必要参数: userId, planId', data: null };
        }
        if (!openid) {
            return { code: 400, msg: '缺少openid，请先登录小程序获取openid', data: null };
        }
        try {
            const db = await (0, mysql_client_1.getMySQLClient)();
            const plans = await db.query(`SELECT * FROM subscription_plans WHERE plan_id = ?`, [planId]);
            if (!plans || plans.length === 0) {
                return { code: 404, msg: '订阅计划不存在', data: null };
            }
            const plan = plans[0];
            if (plan.price === 0) {
                return { code: 400, msg: '免费计划无需支付', data: null };
            }
            const result = await this.wechatPayService.createMiniProgramOrder({
                userId,
                openid,
                planId,
                description: `${plan.name} - Morena AI订阅`,
                amount: Number(plan.price),
                orderType: 'subscription',
            });
            this.logger.log(`支付订单创建成功: orderId=${result.orderId}`);
            return {
                code: 200,
                msg: '订单创建成功',
                data: {
                    orderId: result.orderId,
                    outTradeNo: result.outTradeNo,
                    timeStamp: result.timeStamp,
                    nonceStr: result.nonceStr,
                    packageValue: result.packageValue,
                    signType: result.signType,
                    paySign: result.paySign,
                },
            };
        }
        catch (error) {
            this.logger.error(`创建支付订单失败: ${error.message}`, error.stack);
            return { code: 500, msg: `创建订单失败: ${error.message}`, data: null };
        }
    }
    async wechatNotify(req, res) {
        this.logger.log(`收到微信支付回调通知`);
        try {
            let rawBody = '';
            if (typeof req.body === 'string') {
                rawBody = req.body;
            }
            else if (req.body && typeof req.body === 'object') {
                rawBody = JSON.stringify(req.body);
            }
            if (!rawBody) {
                rawBody = req.rawBody || '';
            }
            const result = await this.wechatPayService.handlePaymentNotify(rawBody, req.headers);
            if (typeof result === 'string') {
                res.setHeader('Content-Type', 'application/xml');
                return res.send(result);
            }
            else {
                if (result.code === 'SUCCESS') {
                    res.setHeader('Content-Type', 'application/xml');
                    return res.send('<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>');
                }
                else {
                    res.setHeader('Content-Type', 'application/xml');
                    return res.send(`<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[${result.message || '处理失败'}]]></return_msg></xml>`);
                }
            }
        }
        catch (error) {
            this.logger.error(`处理回调异常: ${error.message}`, error.stack);
            res.setHeader('Content-Type', 'application/xml');
            return res.send('<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[内部错误]]></return_msg></xml>');
        }
    }
    async getOrderStatus(orderId) {
        try {
            const order = await this.wechatPayService.queryOrderStatus(orderId);
            if (!order) {
                return { code: 404, msg: '订单不存在', data: null };
            }
            return {
                code: 200,
                msg: '查询成功',
                data: {
                    orderId: order.id,
                    outTradeNo: order.outTradeNo,
                    status: order.status,
                    amount: order.amount,
                    planId: order.planId,
                    paidAt: order.paidAt,
                    createdAt: order.createdAt,
                },
            };
        }
        catch (error) {
            this.logger.error(`查询订单失败: ${error.message}`);
            return { code: 500, msg: '查询失败', data: null };
        }
    }
    async getUserOrders(userId) {
        if (!userId) {
            return { code: 400, msg: '缺少userId参数', data: null };
        }
        try {
            const orders = await this.wechatPayService.getUserOrders(userId);
            return { code: 200, msg: '查询成功', data: orders };
        }
        catch (error) {
            this.logger.error(`查询订单列表失败: ${error.message}`);
            return { code: 500, msg: '查询失败', data: null };
        }
    }
    async getPlans() {
        try {
            const db = await (0, mysql_client_1.getMySQLClient)();
            const plans = await db.query(`SELECT * FROM subscription_plans ORDER BY price ASC`);
            return { code: 200, msg: '查询成功', data: plans };
        }
        catch (error) {
            this.logger.error(`查询订阅计划失败: ${error.message}`);
            return { code: 500, msg: '查询失败', data: null };
        }
    }
    async getSubscription(userId) {
        if (!userId) {
            return { code: 400, msg: '缺少userId参数', data: null };
        }
        try {
            const db = await (0, mysql_client_1.getMySQLClient)();
            const subs = await db.query(`SELECT us.*, sp.name as plan_name, sp.max_avatars, sp.can_receive_orders 
         FROM user_subscriptions us 
         LEFT JOIN subscription_plans sp ON us.plan_id = sp.plan_id 
         WHERE us.user_id = ? AND us.status = 'active' 
         ORDER BY us.end_date DESC LIMIT 1`, [userId]);
            if (!subs || subs.length === 0) {
                return { code: 200, msg: '无活跃订阅', data: { status: 'free', planId: 'plan_free' } };
            }
            return { code: 200, msg: '查询成功', data: subs[0] };
        }
        catch (error) {
            this.logger.error(`查询订阅失败: ${error.message}`);
            return { code: 500, msg: '查询失败', data: null };
        }
    }
    async syncOrderStatus(outTradeNo) {
        try {
            const wechatResult = await this.wechatPayService.queryWechatOrderStatus(outTradeNo);
            const tradeState = wechatResult?.trade_state;
            if (tradeState === 'SUCCESS') {
                const mockNotify = {
                    resource: wechatResult.resource || null,
                };
                const db = await (0, mysql_client_1.getMySQLClient)();
                await db.query(`UPDATE payment_orders SET status = 'paid', transaction_id = ?, paid_at = NOW() WHERE out_trade_no = ? AND status = 'pending'`, [wechatResult.transaction_id || '', outTradeNo]);
                const orders = await db.query(`SELECT * FROM payment_orders WHERE out_trade_no = ?`, [outTradeNo]);
                if (orders && orders.length > 0) {
                    const payOrder = orders[0];
                    if (payOrder.orderType === 'order' || payOrder.order_type === 'order') {
                        await this.wechatPayService['activateOrder'](payOrder, wechatResult.transaction_id || '');
                    }
                    else {
                        await this.wechatPayService['activateSubscription'](payOrder);
                    }
                }
                return { code: 200, msg: '同步成功，订单已支付', data: { tradeState } };
            }
            return { code: 200, msg: `订单状态: ${tradeState}`, data: wechatResult };
        }
        catch (error) {
            this.logger.error(`同步订单失败: ${error.message}`);
            return { code: 500, msg: '同步失败', data: null };
        }
    }
    async uploadShipping(body) {
        const { outTradeNo } = body;
        if (!outTradeNo) {
            return { code: 400, msg: '缺少outTradeNo参数', data: null };
        }
        try {
            const db = await (0, mysql_client_1.getMySQLClient)();
            const orders = await db.query(`SELECT * FROM payment_orders WHERE out_trade_no = ? AND status = 'paid'`, [outTradeNo]);
            if (!orders || orders.length === 0) {
                return { code: 404, msg: '未找到已支付订单', data: null };
            }
            const order = orders[0];
            const transactionId = order.transactionId || order.transaction_id;
            if (!transactionId) {
                return { code: 400, msg: '订单缺少微信支付单号', data: null };
            }
            await this.wechatPayService['uploadShippingInfo'](transactionId, order);
            return { code: 200, msg: '发货信息上报已触发', data: { outTradeNo, transactionId } };
        }
        catch (error) {
            this.logger.error(`上报发货信息失败: ${error.message}`);
            return { code: 500, msg: '上报失败', data: null };
        }
    }
};
exports.PaymentController = PaymentController;
__decorate([
    (0, common_1.Post)('wechat/create'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "createPayment", null);
__decorate([
    (0, common_1.Post)('wechat/notify'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "wechatNotify", null);
__decorate([
    (0, common_1.Get)('order/:orderId/status'),
    __param(0, (0, common_1.Param)('orderId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "getOrderStatus", null);
__decorate([
    (0, common_1.Get)('orders'),
    __param(0, (0, common_1.Query)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "getUserOrders", null);
__decorate([
    (0, common_1.Get)('plans'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "getPlans", null);
__decorate([
    (0, common_1.Get)('subscription'),
    __param(0, (0, common_1.Query)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "getSubscription", null);
__decorate([
    (0, common_1.Post)('sync/:outTradeNo'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('outTradeNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "syncOrderStatus", null);
__decorate([
    (0, common_1.Post)('shipping/upload'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "uploadShipping", null);
exports.PaymentController = PaymentController = PaymentController_1 = __decorate([
    (0, common_1.Controller)('payment'),
    __param(0, (0, common_1.Inject)(wechat_pay_service_1.WechatPayService)),
    __metadata("design:paramtypes", [wechat_pay_service_1.WechatPayService])
], PaymentController);
