"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AsrController = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const coze_coding_dev_sdk_2 = require("coze-coding-dev-sdk");
class AsrRequestDto {
}
class AsrResponseDto {
}
let AsrController = class AsrController {
    async recognize(body, req) {
        try {
            console.log('[ASR] 语音识别请求:', { audioUrl: body.audioUrl, uid: body.uid });
            const customHeaders = coze_coding_dev_sdk_2.HeaderUtils.extractForwardHeaders(req.headers);
            const config = new coze_coding_dev_sdk_1.Config();
            const asrClient = new coze_coding_dev_sdk_1.ASRClient(config, customHeaders);
            const result = await asrClient.recognize({
                uid: body.uid || 'guest',
                url: body.audioUrl,
            });
            console.log('[ASR] 语音识别成功:', {
                text: result.text,
                duration: result.duration,
            });
            return {
                code: 200,
                msg: '识别成功',
                data: {
                    text: result.text,
                    duration: result.duration,
                },
            };
        }
        catch (error) {
            console.error('[ASR] 语音识别失败:', error);
            return {
                code: 500,
                msg: error instanceof Error ? error.message : '识别失败',
            };
        }
    }
};
exports.AsrController = AsrController;
__decorate([
    (0, common_1.Post)('recognize'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [AsrRequestDto, Object]),
    __metadata("design:returntype", Promise)
], AsrController.prototype, "recognize", null);
exports.AsrController = AsrController = __decorate([
    (0, common_1.Controller)('asr')
], AsrController);
