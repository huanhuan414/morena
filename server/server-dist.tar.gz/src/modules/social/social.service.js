"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
let SocialService = class SocialService {
    async getSocialFeed(userId, page = 1, pageSize = 20) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const posts = await db.query('posts', {});
        const offset = (page - 1) * pageSize;
        return {
            list: posts?.slice(offset, offset + pageSize) || [],
            page,
            pageSize
        };
    }
    async like(userId, targetId, targetType) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const existingLike = await db.queryOne('likes', {
            user_id: userId,
            target_id: targetId,
            target_type: targetType
        });
        if (existingLike) {
            await db.delete('likes', { id: existingLike.id });
            const table = targetType === 'post' ? 'posts' : 'comments';
            const target = await db.queryOne(table, { id: targetId });
            if (target) {
                await db.updateWhere(table, { id: targetId }, {
                    likes_count: Math.max(0, (target.likes_count || 0) - 1)
                });
            }
            return { liked: false };
        }
        const id = crypto.randomUUID();
        await db.insert('likes', {
            id,
            user_id: userId,
            target_id: targetId,
            target_type: targetType,
            created_at: new Date()
        });
        const table = targetType === 'post' ? 'posts' : 'comments';
        const target = await db.queryOne(table, { id: targetId });
        if (target) {
            await db.updateWhere(table, { id: targetId }, {
                likes_count: (target.likes_count || 0) + 1
            });
        }
        return { liked: true };
    }
    async follow(followerId, followingId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const existingFollow = await db.queryOne('follows', {
            follower_id: followerId,
            following_id: followingId
        });
        if (existingFollow) {
            await db.delete('follows', { id: existingFollow.id });
            return { followed: false };
        }
        const id = crypto.randomUUID();
        await db.insert('follows', {
            id,
            follower_id: followerId,
            following_id: followingId,
            created_at: new Date()
        });
        return { followed: true };
    }
    async getAvatarTotalStats(userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const avatars = await db.query('avatars', {
            user_id: userId
        });
        const avatarCount = avatars?.length || 0;
        const avatarIds = avatars?.map((a) => a.id) || [];
        let totalPosts = 0;
        let totalFollowers = 0;
        let totalLikes = 0;
        if (avatarIds.length > 0) {
            for (const avatarId of avatarIds) {
                const posts = await db.query('posts', {
                    avatar_id: avatarId
                });
                totalPosts += posts?.length || 0;
                const followers = await db.query('avatar_follows', {
                    following_id: avatarId
                });
                totalFollowers += followers?.length || 0;
                const avatarPosts = await db.query('posts', {
                    avatar_id: avatarId
                });
                const postIds = avatarPosts?.map((p) => p.id) || [];
                if (postIds.length > 0) {
                    for (const postId of postIds) {
                        const likes = await db.query('likes', {
                            target_id: postId,
                            target_type: 'post'
                        });
                        totalLikes += likes?.length || 0;
                    }
                }
            }
        }
        return {
            avatarCount,
            totalPosts,
            totalFollowers,
            totalLikes
        };
    }
    async getComments(targetId, page = 1, pageSize = 20) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const comments = await db.query('comments', {
            target_id: targetId
        });
        const offset = (page - 1) * pageSize;
        return {
            list: comments?.slice(offset, offset + pageSize) || [],
            page,
            pageSize
        };
    }
    async addComment(data) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const id = crypto.randomUUID();
        await db.insert('comments', {
            id,
            user_id: data.user_id,
            target_id: data.target_id,
            target_type: 'post',
            content: data.content,
            likes_count: 0,
            created_at: new Date(),
            updated_at: new Date()
        });
        const post = await db.queryOne('posts', { id: data.target_id });
        if (post) {
            await db.updateWhere('posts', { id: data.target_id }, {
                comments_count: (post.comments_count || 0) + 1
            });
        }
        return { id };
    }
};
exports.SocialService = SocialService;
exports.SocialService = SocialService = __decorate([
    (0, common_1.Injectable)()
], SocialService);
const crypto = require("crypto");
