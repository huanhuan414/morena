"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialController = void 0;
const common_1 = require("@nestjs/common");
const social_service_1 = require("./social.service");
let SocialController = class SocialController {
    constructor(socialService) {
        this.socialService = socialService;
    }
    async getFollowersAndFollowing(userId) {
        const result = await this.socialService.getFollowersAndFollowing(userId);
        return {
            code: 200,
            data: result,
            message: '获取成功'
        };
    }
    async createPost(userId, postData) {
        const post = await this.socialService.createPost(userId, postData);
        return {
            code: 200,
            data: post,
            message: '发布成功'
        };
    }
    async getAvatarRelatedPosts(userId, page, pageSize) {
        const result = await this.socialService.getAvatarRelatedPosts(userId, page ? parseInt(page) : 1, pageSize ? parseInt(pageSize) : 20);
        return {
            code: 200,
            data: result,
            message: '获取成功'
        };
    }
    async getAvatarTodayStats(userId) {
        const result = await this.socialService.getAvatarTodayStats(userId);
        return {
            code: 200,
            data: result,
            message: '获取成功'
        };
    }
    async getAvatarTotalStats(userId) {
        const result = await this.socialService.getAvatarTotalStats(userId);
        return {
            code: 200,
            data: result,
            message: '获取成功'
        };
    }
    async getPosts(userId, page, pageSize) {
        const result = await this.socialService.getPosts(page ? parseInt(page) : 1, pageSize ? parseInt(pageSize) : 20, userId);
        return {
            code: 200,
            data: result,
            message: '获取成功'
        };
    }
    async getPost(postId) {
        const post = await this.socialService.getPostById(postId);
        return {
            code: 200,
            data: post,
            message: '获取成功'
        };
    }
    async getPostsByAvatar(avatarId, limit) {
        const posts = await this.socialService.getPostsByAvatar(avatarId, limit ? parseInt(limit) : 10);
        return {
            code: 200,
            data: posts,
            message: '获取成功'
        };
    }
    async deletePost(postId, userId) {
        await this.socialService.deletePost(postId, userId);
        return {
            code: 200,
            data: null,
            message: '删除成功'
        };
    }
    async likePost(postId, userId, avatarId) {
        const result = await this.socialService.likePost(userId, postId, avatarId);
        return {
            code: 200,
            data: result,
            message: result.liked ? '点赞成功' : '取消点赞'
        };
    }
    async createComment(postId, userId, content, parentId, avatarId) {
        const comment = await this.socialService.createComment(userId, postId, content, parentId, avatarId);
        return {
            code: 200,
            data: comment,
            message: '评论成功'
        };
    }
    async getComments(postId, page, pageSize) {
        const comments = await this.socialService.getComments(postId, page ? parseInt(page) : 1, pageSize ? parseInt(pageSize) : 20);
        return {
            code: 200,
            data: comments,
            message: '获取成功'
        };
    }
    async getLikes(postId, page, pageSize) {
        const likes = await this.socialService.getLikes(postId, page ? parseInt(page) : 1, pageSize ? parseInt(pageSize) : 20);
        return {
            code: 200,
            data: likes,
            message: '获取成功'
        };
    }
    async followUser(targetUserId, userId) {
        const result = await this.socialService.followUser(userId, targetUserId);
        return {
            code: 200,
            data: result,
            message: result.following ? '关注成功' : '取消关注'
        };
    }
    async getUserPosts(userId, page, pageSize) {
        const posts = await this.socialService.getUserPosts(userId, page ? parseInt(page) : 1, pageSize ? parseInt(pageSize) : 20);
        return {
            code: 200,
            data: posts,
            message: '获取成功'
        };
    }
    async sharePost(postId, userId) {
        const result = await this.socialService.sharePost(userId, postId);
        return {
            code: 200,
            data: result,
            message: '分享成功'
        };
    }
    async getAllPosts(page, pageSize, sort, filter) {
        const result = await this.socialService.getAllPosts(page ? parseInt(page) : 1, pageSize ? parseInt(pageSize) : 20, sort, filter);
        return {
            code: 200,
            data: result,
            message: '获取成功'
        };
    }
    async getRelatedPosts(userId, page, pageSize) {
        if (!userId) {
            return {
                code: 401,
                message: '请先登录',
                data: { posts: [], total: 0 }
            };
        }
        const result = await this.socialService.getRelatedPosts(userId, page ? parseInt(page) : 1, pageSize ? parseInt(pageSize) : 20);
        return {
            code: 200,
            data: result,
            message: '获取成功'
        };
    }
};
exports.SocialController = SocialController;
__decorate([
    (0, common_1.Get)('followers'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getFollowersAndFollowing", null);
__decorate([
    (0, common_1.Post)('post'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "createPost", null);
__decorate([
    (0, common_1.Get)('avatar-posts'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getAvatarRelatedPosts", null);
__decorate([
    (0, common_1.Get)('today-stats'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getAvatarTodayStats", null);
__decorate([
    (0, common_1.Get)('total-stats'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getAvatarTotalStats", null);
__decorate([
    (0, common_1.Get)('posts'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getPosts", null);
__decorate([
    (0, common_1.Get)('post/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getPost", null);
__decorate([
    (0, common_1.Get)('posts/avatar/:avatarId'),
    __param(0, (0, common_1.Param)('avatarId')),
    __param(1, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getPostsByAvatar", null);
__decorate([
    (0, common_1.Delete)('post/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "deletePost", null);
__decorate([
    (0, common_1.Post)('post/:id/like'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __param(2, (0, common_1.Body)('avatar_id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "likePost", null);
__decorate([
    (0, common_1.Post)('post/:id/comment'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __param(2, (0, common_1.Body)('content')),
    __param(3, (0, common_1.Body)('parent_id')),
    __param(4, (0, common_1.Body)('avatar_id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "createComment", null);
__decorate([
    (0, common_1.Get)('post/:id/comments'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getComments", null);
__decorate([
    (0, common_1.Get)('post/:id/likes'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getLikes", null);
__decorate([
    (0, common_1.Post)('follow/:userId'),
    __param(0, (0, common_1.Param)('userId')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "followUser", null);
__decorate([
    (0, common_1.Get)('user/:userId/posts'),
    __param(0, (0, common_1.Param)('userId')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getUserPosts", null);
__decorate([
    (0, common_1.Post)('post/:id/share'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "sharePost", null);
__decorate([
    (0, common_1.Get)('all-posts'),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('pageSize')),
    __param(2, (0, common_1.Query)('sort')),
    __param(3, (0, common_1.Query)('filter')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getAllPosts", null);
__decorate([
    (0, common_1.Get)('related-posts'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], SocialController.prototype, "getRelatedPosts", null);
exports.SocialController = SocialController = __decorate([
    (0, common_1.Controller)('social'),
    __param(0, (0, common_1.Inject)('SOCIAL_SERVICE')),
    __metadata("design:paramtypes", [social_service_1.SocialService])
], SocialController);
