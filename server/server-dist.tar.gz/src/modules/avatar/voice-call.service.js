"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var VoiceCallService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.VoiceCallService = void 0;
const common_1 = require("@nestjs/common");
const coze_coding_dev_sdk_1 = require("coze-coding-dev-sdk");
const mysql_client_1 = require("../../storage/database/mysql-client");
let VoiceCallService = VoiceCallService_1 = class VoiceCallService {
    constructor() {
        this.logger = new common_1.Logger(VoiceCallService_1.name);
    }
    async generateGreeting(avatarId, friendAvatarId, userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const friendResult = await db.queryOne('avatars', { id: friendAvatarId });
        const friendAvatar = friendResult?.data;
        if (!friendAvatar) {
            throw new Error('好友分身不存在');
        }
        const friendshipResult = await db.query('avatar_friends', {
            avatar_id: avatarId,
            friend_avatar_id: friendAvatarId
        });
        const friendship = friendshipResult?.data?.[0];
        const config = new coze_coding_dev_sdk_1.Config();
        const llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
        const greetingPrompt = `你是${friendAvatar.name || 'AI分身'}，一个AI分身。你的朋友（另一个AI分身）正在和你进行语音通话。
请用简短、友好自然的方式打招呼，表达你们成为朋友后的感受，并引导对话开始。

你的性格：${friendAvatar.personality || '友好开朗'}
交友原因：${friendship?.match_reason || '性格互补'}

要求：
1. 问候语要自然亲切，像朋友间的对话
2. 不要太长，控制在30字以内
3. 可以适当加入语气词让对话更生动
4. 直接输出问候语内容，不要加引号或其他格式`;
        const response = await llmClient.invoke([
            { role: 'system', content: '你是一个友好的AI分身，正在和朋友进行语音通话。请用自然、亲切的方式交流。' },
            { role: 'user', content: greetingPrompt }
        ], {
            model: 'doubao-seed-1-8-251228',
            temperature: 0.9
        });
        const ttsClient = new coze_coding_dev_sdk_1.TTSClient(config);
        const speaker = this.selectVoiceByPersonality(friendAvatar.personality);
        const ttsResponse = await ttsClient.synthesize({
            uid: userId,
            text: response.content,
            speaker,
            audioFormat: 'mp3',
            sampleRate: 24000,
        });
        this.logger.log(`[语音通话] 问候语生成成功: ${response.content}`);
        return {
            text: response.content,
            audioUrl: ttsResponse.audioUrl || ttsResponse.url || ttsResponse.audioUri
        };
    }
    async generateReply(avatarId, friendAvatarId, messages, userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const avatarResult = await db.queryOne('avatars', { id: avatarId });
        const avatar = avatarResult?.data;
        const friendResult = await db.queryOne('avatars', { id: friendAvatarId });
        const friendAvatar = friendResult?.data;
        if (!avatar || !friendAvatar) {
            throw new Error('分身不存在');
        }
        const config = new coze_coding_dev_sdk_1.Config();
        const llmClient = new coze_coding_dev_sdk_1.LLMClient(config);
        const systemPrompt = `你是${avatar.name || 'AI分身'}，一个AI分身。你正在和朋友进行语音通话。
你的性格：${avatar.personality || '友好开朗'}
你的说话风格：${avatar.speaking_style || '自然流畅'}

请根据对话历史，用自然、流畅的方式回复。`;
        const conversationHistory = messages.map(m => `${m.role}: ${m.content}`).join('\n');
        const response = await llmClient.invoke([
            { role: 'system', content: systemPrompt },
            { role: 'user', content: conversationHistory }
        ], {
            model: 'doubao-seed-1-8-251228',
            temperature: 0.9
        });
        const ttsClient = new coze_coding_dev_sdk_1.TTSClient(config);
        const speaker = this.selectVoiceByPersonality(avatar.personality);
        const ttsResponse = await ttsClient.synthesize({
            uid: userId,
            text: response.content,
            speaker,
            audioFormat: 'mp3',
            sampleRate: 24000,
        });
        return {
            text: response.content,
            audioUrl: ttsResponse.audioUrl || ttsResponse.url || ttsResponse.audioUri
        };
    }
    selectVoiceByPersonality(personality) {
        if (personality?.includes('温柔') || personality?.includes('内向')) {
            return 'female-qingxin';
        }
        if (personality?.includes('活泼') || personality?.includes('开朗')) {
            return 'female-qingyin';
        }
        if (personality?.includes('成熟') || personality?.includes('稳重')) {
            return 'male-qingfeng';
        }
        return 'female-qingxin';
    }
};
exports.VoiceCallService = VoiceCallService;
exports.VoiceCallService = VoiceCallService = VoiceCallService_1 = __decorate([
    (0, common_1.Injectable)()
], VoiceCallService);
