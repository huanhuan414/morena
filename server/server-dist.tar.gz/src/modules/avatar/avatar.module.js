"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarModule = void 0;
const common_1 = require("@nestjs/common");
const avatar_controller_1 = require("./avatar.controller");
const avatar_service_1 = require("./avatar.service");
const learning_service_1 = require("./learning.service");
const hosting_service_1 = require("./hosting.service");
const friendship_service_1 = require("./friendship.service");
const voice_call_gateway_1 = require("./voice-call.gateway");
const voice_call_service_1 = require("./voice-call.service");
const reverse_geocoding_service_1 = require("../../services/reverse-geocoding.service");
const subscription_module_1 = require("../subscription/subscription.module");
const tikhub_module_1 = require("../tikhub/tikhub.module");
const referral_module_1 = require("../referral/referral.module");
let AvatarModule = class AvatarModule {
};
exports.AvatarModule = AvatarModule;
exports.AvatarModule = AvatarModule = __decorate([
    (0, common_1.Module)({
        imports: [subscription_module_1.SubscriptionModule, tikhub_module_1.TikHubModule, referral_module_1.ReferralModule],
        controllers: [avatar_controller_1.AvatarController],
        providers: [
            avatar_service_1.AvatarService,
            learning_service_1.LearningService,
            hosting_service_1.HostingService,
            friendship_service_1.FriendshipService,
            voice_call_gateway_1.VoiceCallGateway,
            voice_call_service_1.VoiceCallService,
            reverse_geocoding_service_1.ReverseGeocodingService,
            {
                provide: 'AVATAR_SERVICE',
                useClass: avatar_service_1.AvatarService
            },
            {
                provide: 'AVATAR_LEARNING_SERVICE',
                useClass: learning_service_1.LearningService
            },
            {
                provide: 'AVATAR_HOSTING_SERVICE',
                useClass: hosting_service_1.HostingService
            }
        ],
        exports: [avatar_service_1.AvatarService, learning_service_1.LearningService, hosting_service_1.HostingService, friendship_service_1.FriendshipService, voice_call_service_1.VoiceCallService]
    })
], AvatarModule);
