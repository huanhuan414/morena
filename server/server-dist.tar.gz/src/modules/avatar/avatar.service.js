"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const shared_cache_1 = require("../../common/shared-cache");
const reverse_geocoding_service_1 = require("../../services/reverse-geocoding.service");
const user_stats_service_1 = require("../user-stats/user-stats.service");
const referral_service_1 = require("../referral/referral.service");
const TEST_USER_IDS = ['dev_user', 'test_user', 'guest-user-id', 'anonymous'];
let AvatarService = class AvatarService {
    constructor(reverseGeocodingService, referralService) {
        this.reverseGeocodingService = reverseGeocodingService;
        this.referralService = referralService;
        this.avatarColumnsCache = null;
    }
    hasOwnKey(obj, key) {
        return Object.prototype.hasOwnProperty.call(obj || {}, key);
    }
    parseBoolean(value) {
        if (typeof value === 'boolean')
            return value;
        if (typeof value === 'number')
            return value === 1;
        if (typeof value === 'string') {
            const normalized = value.trim().toLowerCase();
            return normalized === '1' || normalized === 'true';
        }
        return false;
    }
    resolveTrustEnabled(avatar) {
        return this.parseBoolean(avatar?.isHosted
            ?? avatar?.is_hosted
            ?? avatar?.trustEnabled
            ?? avatar?.trust_enabled);
    }
    async getAvatarTableColumns() {
        if (this.avatarColumnsCache) {
            return this.avatarColumnsCache;
        }
        const db = (0, mysql_client_1.getMySQLClient)();
        const rows = await db.query(`
      SELECT COLUMN_NAME
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'avatars'
    `);
        this.avatarColumnsCache = new Set((rows || [])
            .map((row) => String(row.columnName || row.COLUMN_NAME || row.column_name || '').toLowerCase())
            .filter(Boolean));
        return this.avatarColumnsCache;
    }
    async buildHostingTrustUpdate(trustEnabled) {
        const columns = await this.getAvatarTableColumns();
        const updateData = {};
        const hostingFlag = trustEnabled ? 1 : 0;
        if (columns.has('is_hosted')) {
            updateData.is_hosted = hostingFlag;
        }
        if (columns.has('trust_enabled')) {
            updateData.trust_enabled = hostingFlag;
        }
        if (Object.keys(updateData).length === 0) {
            throw new Error('avatars 表缺少托管状态字段，请先补齐 is_hosted 或 trust_enabled 列');
        }
        return updateData;
    }
    safeParseJson(value, fallback) {
        if (value === null || value === undefined)
            return fallback;
        if (typeof value === 'object')
            return value;
        if (typeof value !== 'string')
            return fallback;
        try {
            return JSON.parse(value);
        }
        catch {
            return fallback;
        }
    }
    async createAvatar(userId, avatarData) {
        const effectiveUserId = userId && !TEST_USER_IDS.includes(userId) ? userId : userId;
        const isTestUser = effectiveUserId && TEST_USER_IDS.includes(effectiveUserId);
        if (!effectiveUserId) {
            console.warn('[AvatarService] 创建分身时userId为空，使用默认测试ID');
        }
        const id = `avatar_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const now = new Date().toISOString();
        const newAvatar = {
            id,
            user_id: effectiveUserId || 'dev_user',
            name: avatarData.name,
            description: avatarData.description || '',
            avatar_url: avatarData.photo || avatarData.avatar_url || '',
            personality: JSON.stringify({ tags: avatarData.tags || [], abilities: avatarData.abilities || {} }),
            skills: JSON.stringify(avatarData.selectedSkills || []),
            content_styles: JSON.stringify(avatarData.contentStyles || []),
            niche_tags: JSON.stringify(avatarData.nicheTags || []),
            config: '{}',
            voice_id: avatarData.preset_voice_id || avatarData.voice_type || 'preset',
            status: avatarData.voice_type === 'clone' ? 'training' : 'active',
            created_at: now,
            updated_at: now
        };
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            let isFirstAvatar = false;
            try {
                const countResult = await db.query('SELECT COUNT(*) as count FROM avatars WHERE user_id = ?', [effectiveUserId || 'dev_user']);
                const row = countResult?.data?.[0] || (Array.isArray(countResult) ? countResult[0] : null);
                const count = Number(row?.count ?? row?.['COUNT(*)'] ?? 0);
                isFirstAvatar = count === 0;
            }
            catch { }
            const insertData = {
                id,
                user_id: effectiveUserId || 'dev_user',
                name: avatarData.name,
                description: '',
                avatar_url: avatarData.photo || '',
                personality: JSON.stringify({ tags: avatarData.tags || [], abilities: avatarData.abilities || {} }),
                skills: JSON.stringify(avatarData.selectedSkills || []),
                content_styles: JSON.stringify(avatarData.contentStyles || []),
                niche_tags: JSON.stringify(avatarData.nicheTags || []),
                config: '{}',
                voice_id: avatarData.preset_voice_id || avatarData.voice_type || 'preset',
                status: avatarData.voice_type === 'clone' ? 'training' : 'active',
            };
            const columns = await this.getAvatarTableColumns();
            const filteredInsertData = Object.fromEntries(Object.entries(insertData)
                .filter(([key, value]) => value !== undefined && columns.has(String(key).toLowerCase())));
            console.log('[AvatarService] 创建分身，用户ID:', effectiveUserId, '数据:', filteredInsertData);
            const result = await db.insert('avatars', filteredInsertData);
            console.log('[AvatarService] 插入结果:', result);
            if (result.error) {
                if (isTestUser) {
                    console.warn('[AvatarService] 测试用户数据库插入失败，使用内存缓存:', result.error.message);
                    const userAvatars = user_stats_service_1.sharedMemoryAvatars.get(effectiveUserId) || [];
                    userAvatars.unshift(newAvatar);
                    user_stats_service_1.sharedMemoryAvatars.set(effectiveUserId, userAvatars);
                    const sharedCache = (0, shared_cache_1.getSharedCache)();
                    const cacheKey = `avatars_${effectiveUserId}`;
                    const cachedAvatars = sharedCache.get(cacheKey) || [];
                    cachedAvatars.unshift(newAvatar);
                    sharedCache.set(cacheKey, cachedAvatars);
                    return { success: true, id, data: newAvatar };
                }
                console.warn('[AvatarService] 数据库插入失败:', result.error.message);
                return { success: false, error: result.error.message || '创建分身失败', data: null };
            }
            if (result?.data?.affectedRows > 0) {
                const userAvatars = user_stats_service_1.sharedMemoryAvatars.get(effectiveUserId) || [];
                userAvatars.unshift(newAvatar);
                user_stats_service_1.sharedMemoryAvatars.set(effectiveUserId, userAvatars);
                const sharedCache = (0, shared_cache_1.getSharedCache)();
                const cacheKey = `avatars_${effectiveUserId}`;
                const cachedAvatars = sharedCache.get(cacheKey) || [];
                cachedAvatars.unshift(newAvatar);
                sharedCache.set(cacheKey, cachedAvatars);
                try {
                    if (isFirstAvatar && this.referralService?.settleReferralOnFirstAvatar) {
                        await this.referralService.settleReferralOnFirstAvatar(effectiveUserId);
                    }
                }
                catch (e) {
                    console.error('[AvatarService] settleReferralOnFirstAvatar failed:', e?.message || e);
                }
                return { success: true, id: result?.data?.insertId, data: newAvatar };
            }
            return { success: false, error: '创建分身失败' };
        }
        catch (error) {
            if (isTestUser) {
                console.warn('[AvatarService] 测试用户数据库不可用，使用内存缓存:', error.message);
                const userAvatars = user_stats_service_1.sharedMemoryAvatars.get(effectiveUserId) || [];
                userAvatars.unshift(newAvatar);
                user_stats_service_1.sharedMemoryAvatars.set(effectiveUserId, userAvatars);
                const sharedCache = (0, shared_cache_1.getSharedCache)();
                const cacheKey = `avatars_${effectiveUserId}`;
                const cachedAvatars = sharedCache.get(cacheKey) || [];
                cachedAvatars.unshift(newAvatar);
                sharedCache.set(cacheKey, cachedAvatars);
                return { success: true, id, data: newAvatar };
            }
            console.warn('[AvatarService] 数据库不可用:', error.message);
            return { success: false, error: error.message || '创建分身失败', data: null };
        }
    }
    async getUserAvatars(userId) {
        let rows = [];
        const isTestUser = userId && TEST_USER_IDS.includes(userId);
        const hasValidUserId = userId && userId.trim() && !isTestUser;
        try {
            const db = (0, mysql_client_1.getMySQLClient)();
            if (hasValidUserId) {
                console.log('[AvatarService] 查询用户分身，userId:', userId);
                const result = await db.query(`SELECT * FROM avatars WHERE user_id = ? AND status = 'active' ORDER BY created_at DESC`, [userId]);
                rows = Array.isArray(result) ? result : (result?.data || []);
            }
            else if (isTestUser) {
                console.log('[AvatarService] 测试用户，返回所有分身');
                const result = await db.query(`SELECT * FROM avatars WHERE status = 'active' ORDER BY created_at DESC LIMIT 50`);
                rows = Array.isArray(result) ? result : (result?.data || []);
            }
            else {
                rows = [];
            }
            if (hasValidUserId && userId) {
                user_stats_service_1.sharedMemoryAvatars.set(userId, rows);
            }
        }
        catch (error) {
            console.warn('[AvatarService] 数据库不可用，使用内存缓存');
            if (hasValidUserId && userId) {
                rows = user_stats_service_1.sharedMemoryAvatars.get(userId) || [];
            }
            else {
                rows = [];
            }
        }
        const avatarIds = rows.map((a) => a.id || a.avatarId);
        let earningsMap = {};
        console.log('[AvatarService] 分身ID列表:', avatarIds);
        if (avatarIds.length > 0) {
            try {
                const db = (0, mysql_client_1.getMySQLClient)();
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                const idList = avatarIds.map(id => `'${id}'`).join(', ');
                console.log('[AvatarService] SQL查询条件 - idList:', idList);
                console.log('[AvatarService] SQL查询条件 - today:', today);
                const earningsRows = await db.query(`SELECT 
            avatar_id,
            SUM(amount) as total_earnings,
            SUM(CASE WHEN created_at >= ? THEN amount ELSE 0 END) as today_earnings
           FROM earnings 
           WHERE avatar_id IN (${idList}) AND status IN ('settled', 'completed')
           GROUP BY avatar_id`, [today]);
                console.log('[AvatarService] 收益查询结果:', earningsRows);
                const earningsData = Array.isArray(earningsRows) ? earningsRows : (earningsRows?.data || []);
                for (const e of earningsData) {
                    const avatarId = e.avatarId || e.avatar_id;
                    earningsMap[avatarId] = {
                        total: Number(e.totalEarnings || e.total_earnings) || 0,
                        today: Number(e.todayEarnings || e.today_earnings) || 0
                    };
                }
            }
            catch (error) {
                console.warn('[AvatarService] 查询收益失败:', error);
            }
        }
        const avatars = rows.map((avatar) => {
            const personality = this.safeParseJson(avatar.personality, {});
            const config = this.safeParseJson(avatar.config, {});
            const trustEnabled = this.resolveTrustEnabled(avatar);
            const avatarId = avatar.id || avatar.avatarId;
            const earnings = earningsMap[avatarId] || { total: 0, today: 0 };
            const defaultAvatarUrl = avatar.avatarUrl || avatar.avatar_url || avatar.photo || process.env.DEFAULT_AVATAR_URL || '';
            return {
                ...avatar,
                config,
                avatar_url: defaultAvatarUrl,
                photo: defaultAvatarUrl,
                avatarUrl: defaultAvatarUrl,
                tags: personality.tags || [],
                abilities: personality.abilities || {},
                trust_enabled: trustEnabled,
                is_hosted: trustEnabled,
                isHosted: trustEnabled,
                location_text: avatar.locationText || avatar.location_text || '',
                locationText: avatar.locationText || avatar.location_text || '',
                latitude: avatar.latitude ?? null,
                longitude: avatar.longitude ?? null,
                voice_type: avatar.voiceType || 'preset',
                voice_url: avatar.voiceUrl || '',
                totalEarnings: earnings.total,
                todayEarnings: earnings.today
            };
        });
        return { success: true, data: avatars };
    }
    async getAvatarById(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.queryOne('avatars', { id: avatarId });
        if (!result?.data) {
            return { success: false, error: '分身不存在' };
        }
        const avatar = result.data;
        const personality = this.safeParseJson(avatar.personality, {});
        const config = this.safeParseJson(avatar.config, {});
        const trustEnabled = this.resolveTrustEnabled(avatar);
        return {
            success: true,
            data: {
                ...avatar,
                config,
                avatar_url: avatar.avatarUrl || avatar.avatar_url || avatar.photo || process.env.DEFAULT_AVATAR_URL || '',
                photo: avatar.avatarUrl || avatar.avatar_url || avatar.photo || process.env.DEFAULT_AVATAR_URL || '',
                avatarUrl: avatar.avatarUrl || avatar.avatar_url || avatar.photo || process.env.DEFAULT_AVATAR_URL || '',
                tags: personality.tags || [],
                abilities: personality.abilities || {},
                trust_enabled: trustEnabled,
                is_hosted: trustEnabled,
                isHosted: trustEnabled,
                location_text: avatar.locationText || avatar.location_text || '',
                locationText: avatar.locationText || avatar.location_text || '',
                latitude: avatar.latitude ?? null,
                longitude: avatar.longitude ?? null,
                voice_type: avatar.voiceType || 'preset',
                voice_url: avatar.voiceUrl || ''
            }
        };
    }
    async updateAvatar(avatarId, updateData) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const existing = await db.queryOne('avatars', { id: avatarId });
        if (!existing?.data) {
            return { success: false, error: '分身不存在', data: null };
        }
        const existingRow = existing.data;
        const formattedData = {};
        if (this.hasOwnKey(updateData, 'name'))
            formattedData.name = updateData.name;
        if (this.hasOwnKey(updateData, 'avatarUrl') || this.hasOwnKey(updateData, 'photo') || this.hasOwnKey(updateData, 'avatar_url')) {
            formattedData.avatar_url = updateData.avatarUrl || updateData.photo || updateData.avatar_url || '';
        }
        if (this.hasOwnKey(updateData, 'description'))
            formattedData.description = updateData.description;
        if (this.hasOwnKey(updateData, 'config')) {
            const existingConfig = this.safeParseJson(existingRow.config, {});
            const incomingConfig = this.safeParseJson(updateData.config, {});
            formattedData.config = JSON.stringify({
                ...existingConfig,
                ...incomingConfig
            });
        }
        if (this.hasOwnKey(updateData, 'personality')) {
            formattedData.personality = typeof updateData.personality === 'string'
                ? updateData.personality
                : JSON.stringify(updateData.personality || {});
        }
        if (this.hasOwnKey(updateData, 'tags') || this.hasOwnKey(updateData, 'abilities')) {
            const existingPersonality = this.safeParseJson(existingRow.personality, {});
            const mergedPersonality = {
                ...existingPersonality
            };
            if (this.hasOwnKey(updateData, 'tags')) {
                mergedPersonality.tags = updateData.tags;
            }
            if (this.hasOwnKey(updateData, 'abilities')) {
                mergedPersonality.abilities = updateData.abilities;
            }
            formattedData.personality = JSON.stringify(mergedPersonality);
        }
        const hasLatitude = this.hasOwnKey(updateData, 'latitude');
        const hasLongitude = this.hasOwnKey(updateData, 'longitude');
        const hasLocationText = this.hasOwnKey(updateData, 'location_text') || this.hasOwnKey(updateData, 'locationText');
        if (hasLatitude)
            formattedData.latitude = updateData.latitude;
        if (hasLongitude)
            formattedData.longitude = updateData.longitude;
        if (hasLocationText) {
            formattedData.location_text = updateData.location_text || updateData.locationText || '';
        }
        else if (hasLatitude && hasLongitude && Number.isFinite(Number(updateData.latitude)) && Number.isFinite(Number(updateData.longitude))) {
            try {
                const geo = await this.reverseGeocodingService.reverseGeocode(Number(updateData.latitude), Number(updateData.longitude));
                formattedData.location_text = geo.formatted_address || geo.full_location_text || '';
            }
            catch (error) {
                console.warn('[AvatarService] 逆地理编码失败，回退为经纬度文本:', error?.message || error);
                formattedData.location_text = `${Number(updateData.latitude).toFixed(6)}, ${Number(updateData.longitude).toFixed(6)}`;
            }
        }
        if (Object.keys(formattedData).length === 0) {
            return { success: true, data: null };
        }
        const result = await db.updateWhere('avatars', { id: avatarId }, formattedData);
        const success = result?.data?.affectedRows > 0;
        return {
            success,
            data: success
                ? {
                    id: avatarId,
                    ...formattedData
                }
                : null
        };
    }
    async deleteAvatar(avatarId, userId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const avatars = await db.query('SELECT id FROM avatars WHERE id = ? AND user_id = ?', [avatarId, userId]);
        if (avatars.length === 0) {
            return { success: false, error: '分身不存在或无权删除' };
        }
        try {
            await db.query(`UPDATE order_dispatch_requests SET status = 'cancelled', updated_at = NOW() WHERE avatar_id = ? AND status = 'pending'`, [avatarId]);
            console.log('[AvatarService] 已取消分身的所有待接单dispatch:', avatarId);
        }
        catch (e) {
            console.warn('[AvatarService] 取消待接单dispatch失败:', e.message);
        }
        try {
            await db.query('DELETE FROM avatar_skills WHERE avatar_id = ?', [avatarId]);
            console.log('[AvatarService] 已删除分身技能:', avatarId);
        }
        catch (e) {
            console.warn('[AvatarService] 删除分身技能失败:', e.message);
        }
        try {
            await db.query('DELETE FROM avatar_notifications WHERE avatar_id = ?', [avatarId]);
            console.log('[AvatarService] 已删除分身通知:', avatarId);
        }
        catch (e) {
            console.warn('[AvatarService] 删除分身通知失败:', e.message);
        }
        try {
            await db.query('DELETE FROM avatar_memories WHERE avatar_id = ?', [avatarId]);
            console.log('[AvatarService] 已删除分身记忆:', avatarId);
        }
        catch (e) {
            console.warn('[AvatarService] 删除分身记忆失败:', e.message);
        }
        const userAvatars = user_stats_service_1.sharedMemoryAvatars.get(userId) || [];
        user_stats_service_1.sharedMemoryAvatars.set(userId, userAvatars.filter(a => a.id !== avatarId));
        const result = await db.delete('avatars', { id: avatarId, user_id: userId });
        const affectedRows = result?.data?.affectedRows || 0;
        if (affectedRows === 0) {
            console.error('[AvatarService] 分身删除失败，未匹配到记录:', avatarId, 'userId:', userId);
            return { success: false, error: '分身删除失败，请重试' };
        }
        console.log('[AvatarService] 分身删除完成:', avatarId);
        return { success: true };
    }
    async addSkill(avatarId, skillData) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.insert('avatar_skills', {
            avatar_id: avatarId,
            skill_name: skillData.skill_name,
            skill_description: skillData.skill_description,
            skill_config: skillData.skill_config || '{}',
            status: 'active',
            created_at: new Date()
        });
        return { success: result?.data?.affectedRows > 0, id: result?.data?.insertId };
    }
    async getSkills(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.select('avatar_skills', { avatar_id: avatarId });
        return { success: true, data: result.data || [] };
    }
    async deleteSkill(skillId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.delete('avatar_skills', { id: skillId });
        return { success: result?.data?.affectedRows > 0 };
    }
    async addMemory(avatarId, memoryData) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.insert('avatar_memories', {
            avatar_id: avatarId,
            memory_type: memoryData.memory_type,
            memory_content: memoryData.memory_content,
            importance: memoryData.importance || 5,
            created_at: new Date()
        });
        return { success: result?.data?.affectedRows > 0, id: result?.data?.insertId };
    }
    async getMemories(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.select('avatar_memories', { avatar_id: avatarId });
        return { success: true, data: result.data || [] };
    }
    async deleteMemory(memoryId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.delete('avatar_memories', { id: memoryId });
        return { success: result?.data?.affectedRows > 0 };
    }
    async getStats(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const [fans, posts, likes, comments] = await Promise.all([
            db.count('follows', { avatar_id: avatarId }),
            db.count('posts', { avatar_id: avatarId }),
            db.count('likes', { avatar_id: avatarId }),
            db.count('comments', { avatar_id: avatarId })
        ]);
        return {
            success: true,
            data: {
                fans_count: fans || 0,
                posts_count: posts || 0,
                likes_count: likes || 0,
                comments_count: comments || 0
            }
        };
    }
    async getVoiceCloneStatus(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.queryOne('avatars', { id: avatarId });
        if (!result?.data) {
            return { success: false, error: '分身不存在' };
        }
        const avatar = result.data;
        return {
            success: true,
            data: {
                avatar_id: avatarId,
                status: avatar.status,
                voice_type: avatar.voice_type,
                is_cloning: avatar.voice_type === 'clone' && avatar.status === 'training'
            }
        };
    }
    async getAvatarList(params) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const { page = 1, pageSize = 10, gender, ageGroup, search } = params;
        const offset = (page - 1) * pageSize;
        let where = '1=1';
        const values = [];
        if (gender) {
            where += ' AND gender = ?';
            values.push(gender);
        }
        if (search) {
            where += ' AND (name LIKE ? OR description LIKE ?)';
            values.push(`%${search}%`, `%${search}%`);
        }
        const countResult = await db.query(`SELECT COUNT(*) as total FROM avatars WHERE ${where}`, values);
        const countArray = Array.isArray(countResult) ? countResult : (countResult?.data || []);
        const total = countArray[0]?.total || 0;
        const listResult = await db.query(`SELECT * FROM avatars WHERE ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`, [...values, pageSize, offset]);
        const listArray = Array.isArray(listResult) ? listResult : (listResult?.data || []);
        return {
            success: true,
            data: {
                list: listArray,
                total,
                page,
                pageSize
            }
        };
    }
    async searchAvatars(keyword) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.query(`SELECT * FROM avatars WHERE name LIKE ? OR description LIKE ? LIMIT 20`, [`%${keyword}%`, `%${keyword}%`]);
        return { success: true, data: result.data || [] };
    }
    async updateTrust(avatarId, trustEnabled) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const avatar = await db.query(`SELECT * FROM avatars WHERE id = ?`, [avatarId]);
        const avatars = Array.isArray(avatar) ? avatar : (avatar?.data || []);
        if (avatars.length === 0) {
            throw new Error('分身不存在');
        }
        const updateData = await this.buildHostingTrustUpdate(trustEnabled);
        await db.updateWhere('avatars', { id: avatarId }, updateData);
        return { success: true };
    }
    async enableAllTrust(userId, trustEnabled) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const isTestUser = userId && TEST_USER_IDS.includes(userId);
        const hasValidUserId = userId && userId.trim() && !isTestUser;
        if (!hasValidUserId) {
            throw new Error('无效的用户ID');
        }
        const updateData = await this.buildHostingTrustUpdate(trustEnabled);
        await db.updateWhere('avatars', { user_id: userId }, updateData);
        return { success: true };
    }
    async updateHostingSettings(avatarId, settings) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const existing = await db.queryOne('avatars', { id: avatarId });
        if (!existing?.data) {
            throw new Error('分身不存在');
        }
        const existingConfig = this.safeParseJson(existing.data.config, {});
        const currentHostingSettings = this.safeParseJson(existingConfig.hosting_settings, {});
        const mergedHostingSettings = {
            ...currentHostingSettings,
            ...settings
        };
        const mergedConfig = {
            ...existingConfig,
            hosting_settings: mergedHostingSettings
        };
        const result = await db.updateWhere('avatars', { id: avatarId }, {
            config: JSON.stringify(mergedConfig)
        });
        return {
            success: result?.data?.affectedRows > 0,
            data: {
                id: avatarId,
                hosting_settings: mergedHostingSettings,
                config: mergedConfig
            }
        };
    }
    async getHostingSettings(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const existing = await db.queryOne('avatars', { id: avatarId });
        if (!existing?.data) {
            throw new Error('分身不存在');
        }
        const config = this.safeParseJson(existing.data.config, {});
        const trustEnabled = this.resolveTrustEnabled(existing.data);
        return {
            success: true,
            data: {
                id: avatarId,
                trust_enabled: trustEnabled,
                is_hosted: trustEnabled,
                isHosted: trustEnabled,
                hosting_settings: this.safeParseJson(config.hosting_settings, {})
            }
        };
    }
    async getAccounts(avatarId) {
        const db = await (0, mysql_client_1.getMySQLClient)();
        const results = await db.query('avatar_accounts', { avatar_id: avatarId });
        if (!results || results.length === 0)
            return [];
        return results.map(r => this.normalizeAccount(r));
    }
    async createAccount(data) {
        const db = await (0, mysql_client_1.getMySQLClient)();
        const id = `acct_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
        const record = {
            id,
            avatar_id: data.avatar_id || '',
            platform: data.platform || '',
            account_name: data.account_name || '',
            followers: data.followers || 0,
            total_exposure: data.total_exposure || 0,
            total_works: data.total_works || 0,
            avg_likes_per_work: data.avg_likes_per_work || 0,
            avg_comments_per_work: data.avg_comments_per_work || 0,
            avg_shares_per_work: data.avg_shares_per_work || 0,
            appid: data.appid || null,
            appkey: data.appkey || null,
            account_url: data.account_url || null,
            extra_info: data.extra_info || null,
            platform_user_id: data.platform_user_id || null,
            status: 'active',
        };
        await db.insert('avatar_accounts', record);
        return this.normalizeAccount(record);
    }
    async updateAccount(id, data) {
        const db = await (0, mysql_client_1.getMySQLClient)();
        const updateData = { updated_at: new Date() };
        const updatableFields = [
            'platform', 'account_name', 'followers', 'total_exposure', 'total_works',
            'avg_likes_per_work', 'avg_comments_per_work', 'avg_shares_per_work',
            'appid', 'appkey', 'account_url', 'extra_info', 'platform_user_id', 'status',
        ];
        for (const field of updatableFields) {
            if (data[field] !== undefined) {
                updateData[field] = data[field];
            }
        }
        await db.update('avatar_accounts', id, updateData);
        const results = await db.query('avatar_accounts', { id });
        if (results && results.length > 0) {
            return this.normalizeAccount(results[0]);
        }
        return { id, ...updateData };
    }
    async deleteAccount(id) {
        const db = await (0, mysql_client_1.getMySQLClient)();
        await db.delete('avatar_accounts', id);
        return { success: true };
    }
    normalizeAccount(record) {
        if (!record)
            return null;
        return {
            id: record.id,
            avatarId: record.avatar_id || record.avatarId,
            avatar_id: record.avatar_id || record.avatarId,
            platform: record.platform,
            accountName: record.account_name || record.accountName || '',
            account_name: record.account_name || record.accountName || '',
            followers: record.followers || 0,
            totalExposure: record.total_exposure || record.totalExposure || 0,
            total_exposure: record.total_exposure || record.totalExposure || 0,
            totalWorks: record.total_works || record.totalWorks || 0,
            total_works: record.total_works || record.totalWorks || 0,
            avgLikesPerWork: record.avg_likes_per_work || record.avgLikesPerWork || 0,
            avg_likes_per_work: record.avg_likes_per_work || record.avgLikesPerWork || 0,
            avgCommentsPerWork: record.avg_comments_per_work || record.avgCommentsPerWork || 0,
            avg_comments_per_work: record.avg_comments_per_work || record.avgCommentsPerWork || 0,
            avgSharesPerWork: record.avg_shares_per_work || record.avgSharesPerWork || 0,
            avg_shares_per_work: record.avg_shares_per_work || record.avgSharesPerWork || 0,
            appid: record.appid || '',
            appkey: record.appkey || '',
            accountUrl: record.account_url || record.accountUrl || '',
            account_url: record.account_url || record.accountUrl || '',
            extraInfo: record.extra_info || record.extraInfo || '',
            extra_info: record.extra_info || record.extraInfo || '',
            status: record.status || 'active',
            createdAt: record.created_at || record.createdAt,
            updatedAt: record.updated_at || record.updatedAt,
        };
    }
    async publishWechatDraft(params) {
        const { accountId, title, content, imageUrls = [], digest } = params;
        const db = await (0, mysql_client_1.getMySQLClient)();
        const accounts = await db.query('avatar_accounts', { id: accountId });
        if (!accounts || accounts.length === 0) {
            throw new Error('账号不存在');
        }
        const account = accounts[0];
        const appid = account.appid;
        const appsecret = account.appkey;
        if (!appid || !appsecret) {
            throw new Error('缺少 AppID 或 AppSecret，请先完善公众号配置');
        }
        console.log(`[微信发布] 开始发布，appid: ${appid}, title: ${title}`);
        const tokenUrl = `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${appid}&secret=${appsecret}`;
        const tokenRes = await fetch(tokenUrl);
        const tokenData = await tokenRes.json();
        if (tokenData.errcode) {
            console.error('[微信发布] 获取access_token失败:', tokenData);
            throw new Error(`获取access_token失败: ${tokenData.errmsg} (errcode: ${tokenData.errcode})`);
        }
        const accessToken = tokenData.access_token;
        console.log(`[微信发布] access_token 获取成功`);
        let thumbMediaId = '';
        let processedContent = content;
        if (imageUrls.length > 0) {
            try {
                const thumbResult = await this.uploadWechatMedia(accessToken, imageUrls[0], 'thumb');
                thumbMediaId = thumbResult.media_id;
                console.log(`[微信发布] 封面上传成功, thumb_media_id: ${thumbMediaId}`);
            }
            catch (err) {
                console.error('[微信发布] 封面上传失败:', err.message);
            }
            for (let i = 0; i < imageUrls.length; i++) {
                try {
                    const imgResult = await this.uploadWechatMedia(accessToken, imageUrls[i], 'image');
                    if (imgResult.url) {
                        processedContent = processedContent.replace(imageUrls[i], imgResult.url);
                        console.log(`[微信发布] 图片${i + 1}上传成功, 微信URL: ${imgResult.url.substring(0, 80)}`);
                    }
                }
                catch (err) {
                    console.error(`[微信发布] 图片${i + 1}上传失败:`, err.message);
                }
            }
        }
        if (!thumbMediaId) {
            try {
                console.log('[微信发布] 无封面图，生成默认封面');
                const defaultThumb = await this.generateDefaultThumb(accessToken, title);
                thumbMediaId = defaultThumb;
                console.log(`[微信发布] 默认封面上传成功, thumb_media_id: ${thumbMediaId}`);
            }
            catch (err) {
                console.error('[微信发布] 默认封面生成失败:', err.message);
            }
        }
        processedContent = this.convertToWechatHtml(processedContent);
        const draftUrl = `https://api.weixin.qq.com/cgi-bin/draft/add?access_token=${accessToken}`;
        const draftBody = {
            articles: [{
                    title: title || '无标题',
                    author: '',
                    digest: digest || title || '',
                    content: processedContent,
                    thumb_media_id: thumbMediaId,
                    need_open_comment: 0,
                    only_fans_can_comment: 0,
                }]
        };
        const draftRes = await fetch(draftUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(draftBody),
        });
        const draftData = await draftRes.json();
        if (draftData.errcode && draftData.errcode !== 0) {
            console.error('[微信发布] 创建草稿失败:', draftData);
            throw new Error(`创建草稿失败: ${draftData.errmsg} (errcode: ${draftData.errcode})`);
        }
        const mediaId = draftData.media_id;
        console.log(`[微信发布] 草稿创建成功, media_id: ${mediaId}`);
        return {
            mediaId,
            thumbMediaId,
            message: '已成功发布到公众号草稿箱',
        };
    }
    async uploadWechatMedia(accessToken, imageUrl, type) {
        console.log(`[微信发布] 下载图片: ${imageUrl.substring(0, 80)}`);
        const imgRes = await fetch(imageUrl);
        if (!imgRes.ok) {
            throw new Error(`下载图片失败: HTTP ${imgRes.status}`);
        }
        const imgBuffer = await imgRes.arrayBuffer();
        const contentType = imgRes.headers.get('content-type') || 'image/jpeg';
        const uploadUrl = `https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=${accessToken}&type=${type}`;
        const filename = type === 'thumb' ? 'thumb.jpg' : 'image.jpg';
        const formData = new FormData();
        const blob = new Blob([imgBuffer], { type: contentType });
        formData.append('media', blob, filename);
        const uploadRes = await fetch(uploadUrl, {
            method: 'POST',
            body: formData,
        });
        const uploadData = await uploadRes.json();
        if (uploadData.errcode) {
            throw new Error(`上传素材失败: ${uploadData.errmsg}`);
        }
        return uploadData;
    }
    convertToWechatHtml(text) {
        if (!text)
            return '';
        let html = text;
        html = html.replace(/^### (.+)$/gm, '<h3 style="font-size:16px;font-weight:bold;margin:20px 0 10px;color:#333">$1</h3>');
        html = html.replace(/^## (.+)$/gm, '<h2 style="font-size:18px;font-weight:bold;margin:24px 0 12px;color:#333">$1</h2>');
        html = html.replace(/^# (.+)$/gm, '<h1 style="font-size:22px;font-weight:bold;margin:28px 0 14px;color:#333">$1</h1>');
        html = html.replace(/\*\*(.+?)\*\*/g, '<strong style="font-weight:bold;color:#333">$1</strong>');
        html = html.replace(/\*(.+?)\*/g, '<em style="font-style:italic">$1</em>');
        html = html.replace(/^- (.+)$/gm, '<p style="padding-left:20px;margin:6px 0;color:#555">• $1</p>');
        html = html.replace(/^\d+\. (.+)$/gm, '<p style="padding-left:20px;margin:6px 0;color:#555">$1</p>');
        html = html.replace(/^---$/gm, '<hr style="border:none;border-top:1px solid #eee;margin:20px 0"/>');
        html = html.replace(/\n\n/g, '</p><p style="margin:12px 0;line-height:1.8;color:#555">');
        html = html.replace(/\n/g, '<br/>');
        html = `<section style="padding:10px;font-size:15px;line-height:1.8;color:#555"><p style="margin:12px 0;line-height:1.8;color:#555">${html}</p></section>`;
        html = html.replace(/\[IMG_\d+\]/g, '');
        html = html.replace(/\[IMG\d+\]/g, '');
        return html;
    }
    async generateDefaultThumb(accessToken, title) {
        try {
            const imageApiKey = process.env.IMAGE_API_KEY || 'sk-z1CFQbVdKI6x7ciJLwQkp1vPJPp8P9lQWW0jJGQWUdkSuQsK';
            const imageApiUrl = process.env.IMAGE_API_URL || 'https://api.aaigc.top/v1/images/generations';
            const imageModel = process.env.IMAGE_MODEL || 'gpt-image-2-all';
            const prompt = `微信公众号文章封面图，简约大气的设计风格，渐变蓝色背景，中央有装饰性几何图形，无文字，尺寸900x383像素，专业杂志风格`;
            console.log(`[微信发布] 使用图片API生成封面, prompt: ${prompt.substring(0, 80)}`);
            const imgRes = await fetch(imageApiUrl, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${imageApiKey}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    model: imageModel,
                    prompt: prompt,
                    n: 1,
                    size: '1024x1024',
                }),
            });
            const imgData = await imgRes.json();
            if (imgData.data && imgData.data[0]) {
                const imageUrl = imgData.data[0].url || (imgData.data[0].b64_json ? `data:image/png;base64,${imgData.data[0].b64_json}` : null);
                if (imageUrl) {
                    const uploadResult = await this.uploadWechatMedia(accessToken, imageUrl, 'thumb');
                    return uploadResult.media_id;
                }
            }
        }
        catch (err) {
            console.error('[微信发布] 图片API生成封面失败:', err.message);
        }
        try {
            const minimalPng = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64');
            const blob = new Blob([minimalPng], { type: 'image/png' });
            const formData = new FormData();
            formData.append('media', blob, 'thumb.png');
            const uploadUrl = `https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=${accessToken}&type=thumb`;
            const uploadRes = await fetch(uploadUrl, {
                method: 'POST',
                body: formData,
            });
            const uploadData = await uploadRes.json();
            if (uploadData.media_id) {
                return uploadData.media_id;
            }
            throw new Error(uploadData.errmsg || '上传默认封面失败');
        }
        catch (err) {
            console.error('[微信发布] 上传默认封面失败:', err.message);
            throw err;
        }
    }
};
exports.AvatarService = AvatarService;
exports.AvatarService = AvatarService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(reverse_geocoding_service_1.ReverseGeocodingService)),
    __param(1, (0, common_1.Inject)(referral_service_1.ReferralService)),
    __metadata("design:paramtypes", [reverse_geocoding_service_1.ReverseGeocodingService,
        referral_service_1.ReferralService])
], AvatarService);
