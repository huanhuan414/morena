"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LearningService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
let LearningService = class LearningService {
    async analyzeInteraction(avatarId, interactionData) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.insert('learning_analyses', {
            id: Date.now().toString(),
            avatar_id: avatarId,
            interaction_type: interactionData.type,
            interaction_data: JSON.stringify(interactionData.data || {}),
            analysis_result: JSON.stringify({ insights: [] }),
            created_at: new Date()
        });
        return { success: result.affectedRows > 0 };
    }
    async getInsights(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.select('learning_analyses', { avatar_id: avatarId });
        return result.data?.map((item) => ({
            id: item.id,
            type: item.interaction_type,
            data: JSON.parse(item.analysis_result || '{}'),
            createdAt: item.created_at
        })) || [];
    }
    async analyzeAndUpdate(avatarId, interactionData) {
        const db = (0, mysql_client_1.getMySQLClient)();
        await db.insert('learning_analyses', {
            id: Date.now().toString(),
            avatar_id: avatarId,
            interaction_type: interactionData.type || 'general',
            interaction_data: JSON.stringify(interactionData.data || {}),
            analysis_result: JSON.stringify({ insights: [], updated: true }),
            created_at: new Date()
        });
        return { insights: [], updated: true };
    }
};
exports.LearningService = LearningService;
exports.LearningService = LearningService = __decorate([
    (0, common_1.Injectable)()
], LearningService);
