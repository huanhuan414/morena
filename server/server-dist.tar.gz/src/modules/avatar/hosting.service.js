"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HostingService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
let HostingService = class HostingService {
    async startHosting(avatarId, settings) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.updateWhere('avatars', { id: parseInt(avatarId) }, {
            hosting_enabled: true,
            hosting_settings: JSON.stringify(settings),
            updated_at: new Date()
        });
        return { success: result.affectedRows > 0 };
    }
    async stopHosting(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.updateWhere('avatars', { id: parseInt(avatarId) }, {
            hosting_enabled: false,
            updated_at: new Date()
        });
        return { success: result.affectedRows > 0 };
    }
    async getHostingStatus(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.queryOne('avatars', { id: parseInt(avatarId) });
        return {
            enabled: result?.data?.hosting_enabled || false,
            settings: result?.data?.hosting_settings || {}
        };
    }
    async updateSettings(avatarId, settings) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.updateWhere('avatars', { id: parseInt(avatarId) }, {
            hosting_settings: JSON.stringify(settings),
            updated_at: new Date()
        });
        return { success: result.affectedRows > 0 };
    }
    async getHostingLogs(avatarId, limit = 50) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.select('hosting_logs', { avatar_id: avatarId }, {
            orderBy: 'created_at',
            orderDirection: 'desc',
            limit
        });
        return result.data || [];
    }
};
exports.HostingService = HostingService;
exports.HostingService = HostingService = __decorate([
    (0, common_1.Injectable)()
], HostingService);
