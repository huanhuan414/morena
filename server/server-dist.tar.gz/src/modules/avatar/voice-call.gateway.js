"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var VoiceCallGateway_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.VoiceCallGateway = void 0;
const websockets_1 = require("@nestjs/websockets");
const socket_io_1 = require("socket.io");
const common_1 = require("@nestjs/common");
const voice_call_service_1 = require("./voice-call.service");
let VoiceCallGateway = VoiceCallGateway_1 = class VoiceCallGateway {
    constructor(voiceCallService) {
        this.voiceCallService = voiceCallService;
        this.logger = new common_1.Logger(VoiceCallGateway_1.name);
        this.callSessions = new Map();
        this.socketCallMap = new Map();
    }
    handleConnection(client) {
        const userId = client.handshake.query.userId;
        this.logger.log(`[语音通话] 用户 ${userId} 连接, socket: ${client.id}`);
    }
    handleDisconnect(client) {
        const callId = this.socketCallMap.get(client.id);
        if (callId) {
            this.doEndCall(client, callId);
        }
        this.logger.log(`[语音通话] Socket ${client.id} 断开`);
    }
    doEndCall(client, callId) {
        const session = this.callSessions.get(callId);
        if (session) {
            session.status = 'ended';
            this.logger.log(`[语音通话] 通话结束: ${callId}, 消息数: ${session.messages.length}`);
            client.emit('call-ended', {
                callId,
                duration: Date.now() - session.createdAt.getTime(),
                messageCount: session.messages.length
            });
            this.callSessions.delete(callId);
            this.socketCallMap.delete(client.id);
            client.leave(callId);
        }
    }
    async handleStartCall(client, payload) {
        const { avatarId, friendAvatarId, userId } = payload;
        const callId = `call_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        this.logger.log(`[语音通话] 发起通话: ${callId}, 用户: ${userId}, 分身: ${avatarId}, 好友: ${friendAvatarId}`);
        const session = {
            callId,
            avatarId,
            friendAvatarId,
            userId,
            status: 'connecting',
            messages: [],
            createdAt: new Date()
        };
        this.callSessions.set(callId, session);
        this.socketCallMap.set(client.id, callId);
        client.join(callId);
        try {
            const greeting = await this.voiceCallService.generateGreeting(avatarId, friendAvatarId, userId);
            session.status = 'active';
            session.messages.push({ role: 'assistant', content: greeting.text, audioUrl: greeting.audioUrl });
            client.emit('call-started', {
                callId,
                greeting: greeting.text,
                audioUrl: greeting.audioUrl
            });
            return { success: true, callId, greeting };
        }
        catch (error) {
            this.logger.error(`[语音通话] 发起通话失败: ${error.message}`);
            this.callSessions.delete(callId);
            this.socketCallMap.delete(client.id);
            return { success: false, error: error.message };
        }
    }
    async handleSendAudio(client, payload) {
        const { callId, audioUrl } = payload;
        const session = this.callSessions.get(callId);
        if (!session || session.status !== 'active') {
            return { success: false, error: '通话不存在或已结束' };
        }
        this.logger.log(`[语音通话] 收到语音: ${callId}`);
        try {
            client.emit('processing', { callId });
            session.messages.push({ role: 'user', content: '用户语音消息' });
            const reply = await this.voiceCallService.generateReply(session.avatarId, session.friendAvatarId, session.messages, session.userId);
            session.messages.push({ role: 'assistant', content: reply.text, audioUrl: reply.audioUrl });
            client.emit('receive-reply', {
                callId,
                replyText: reply.text,
                audioUrl: reply.audioUrl
            });
            return { success: true, replyText: reply.text, audioUrl: reply.audioUrl };
        }
        catch (error) {
            this.logger.error(`[语音通话] 处理语音失败: ${error.message}`);
            return { success: false, error: error.message };
        }
    }
    async handleSendText(client, payload) {
        const { callId, text } = payload;
        const session = this.callSessions.get(callId);
        if (!session || session.status !== 'active') {
            return { success: false, error: '通话不存在或已结束' };
        }
        this.logger.log(`[语音通话] 收到文本: ${text}`);
        try {
            client.emit('processing', { callId });
            session.messages.push({ role: 'user', content: text });
            const reply = await this.voiceCallService.generateReply(session.avatarId, session.friendAvatarId, session.messages, session.userId);
            session.messages.push({ role: 'assistant', content: reply.text, audioUrl: reply.audioUrl });
            client.emit('receive-reply', {
                callId,
                userText: text,
                replyText: reply.text,
                audioUrl: reply.audioUrl
            });
            return { success: true, replyText: reply.text, audioUrl: reply.audioUrl };
        }
        catch (error) {
            this.logger.error(`[语音通话] 处理文本失败: ${error.message}`);
            return { success: false, error: error.message };
        }
    }
    handleEndCall(client, payload) {
        this.doEndCall(client, payload.callId);
        return { success: true };
    }
    handleGetCallStatus(client, payload) {
        const { callId } = payload;
        const session = this.callSessions.get(callId);
        if (!session) {
            return { success: false, error: '通话不存在' };
        }
        return {
            success: true,
            status: session.status,
            messageCount: session.messages.length,
            duration: Date.now() - session.createdAt.getTime()
        };
    }
};
exports.VoiceCallGateway = VoiceCallGateway;
__decorate([
    (0, websockets_1.WebSocketServer)(),
    __metadata("design:type", socket_io_1.Server)
], VoiceCallGateway.prototype, "server", void 0);
__decorate([
    (0, websockets_1.SubscribeMessage)('start-call'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], VoiceCallGateway.prototype, "handleStartCall", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('send-audio'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], VoiceCallGateway.prototype, "handleSendAudio", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('send-text'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], VoiceCallGateway.prototype, "handleSendText", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('end-call'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", void 0)
], VoiceCallGateway.prototype, "handleEndCall", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('get-call-status'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", void 0)
], VoiceCallGateway.prototype, "handleGetCallStatus", null);
exports.VoiceCallGateway = VoiceCallGateway = VoiceCallGateway_1 = __decorate([
    (0, common_1.Injectable)(),
    (0, websockets_1.WebSocketGateway)({
        cors: {
            origin: '*',
            credentials: true
        },
        namespace: '/voice-call'
    }),
    __metadata("design:paramtypes", [voice_call_service_1.VoiceCallService])
], VoiceCallGateway);
