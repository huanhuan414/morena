"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FriendshipService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
let FriendshipService = class FriendshipService {
    async getFriends(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.select('avatar_friends', { avatar_id: avatarId });
        return result.data || [];
    }
    async addFriend(avatarId, friendAvatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.insert('avatar_friends', {
            id: Date.now().toString(),
            avatar_id: avatarId,
            friend_avatar_id: friendAvatarId,
            status: 'active',
            created_at: new Date()
        });
        return { success: result.affectedRows > 0 };
    }
    async removeFriend(avatarId, friendAvatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.delete('avatar_friends', {
            avatar_id: avatarId,
            friend_avatar_id: friendAvatarId
        });
        return { success: result.affectedRows > 0 };
    }
    async getRequests(avatarId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.select('friend_requests', {
            target_avatar_id: avatarId,
            status: 'pending'
        });
        return result.data || [];
    }
    async sendRequest(fromAvatarId, toAvatarId, message) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.insert('friend_requests', {
            id: Date.now().toString(),
            from_avatar_id: fromAvatarId,
            target_avatar_id: toAvatarId,
            message: message || '',
            status: 'pending',
            created_at: new Date()
        });
        return { success: result.affectedRows > 0 };
    }
    async acceptRequest(requestId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.updateWhere('friend_requests', { id: requestId }, {
            status: 'accepted',
            updated_at: new Date()
        });
        return { success: result.affectedRows > 0 };
    }
    async rejectRequest(requestId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const result = await db.updateWhere('friend_requests', { id: requestId }, {
            status: 'rejected',
            updated_at: new Date()
        });
        return { success: result.affectedRows > 0 };
    }
};
exports.FriendshipService = FriendshipService;
exports.FriendshipService = FriendshipService = __decorate([
    (0, common_1.Injectable)()
], FriendshipService);
