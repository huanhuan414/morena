"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AvatarController = void 0;
const common_1 = require("@nestjs/common");
const avatar_service_1 = require("./avatar.service");
let AvatarController = class AvatarController {
    constructor(avatarService) {
        this.avatarService = avatarService;
    }
    async createAvatar(userId, body) {
        try {
            const avatar = await this.avatarService.createAvatar(userId, {
                name: body.name,
                photo: body.photo || body.avatar_url || '',
                tags: body.tags || [],
                voice_type: body.voice_type || 'preset',
                voice_url: body.voice_url,
                preset_voice_id: body.preset_voice_id,
                abilities: body.abilities || { chat: true, reading: true, analysis: false },
                description: body.description || '',
                gender: body.gender,
                age: body.age
            });
            return { code: 200, msg: 'success', data: avatar };
        }
        catch (err) {
            console.error('创建分身失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: null };
        }
    }
    async getAllAvatars(userId) {
        try {
            const avatars = await this.avatarService.getUserAvatars(userId);
            return { code: 200, msg: 'success', data: avatars.data || [] };
        }
        catch (err) {
            console.error('获取分身列表失败:', err);
            return { code: 500, msg: '服务器错误', data: [] };
        }
    }
    async getAvatarList(userId, page = '1', pageSize = '10', gender, ageGroup, search) {
        try {
            const pageNum = parseInt(page) || 1;
            const size = parseInt(pageSize) || 10;
            const result = await this.avatarService.getAvatarList({ page: pageNum, pageSize: size, gender, ageGroup, search });
            return { code: 200, msg: 'success', data: result };
        }
        catch (err) {
            console.error('获取分身列表失败:', err);
            return { code: 500, msg: '服务器错误', data: null };
        }
    }
    async searchAvatars(keyword) {
        try {
            const result = await this.avatarService.searchAvatars(keyword);
            return { code: 200, msg: 'success', data: result };
        }
        catch (err) {
            console.error('搜索分身失败:', err);
            return { code: 500, msg: '服务器错误', data: [] };
        }
    }
    async getAvatarDetail(id) {
        try {
            const avatar = await this.avatarService.getAvatarById(id);
            return { code: 200, msg: 'success', data: avatar?.data ?? null };
        }
        catch (err) {
            console.error('获取分身详情失败:', err);
            return { code: 500, msg: '服务器错误', data: null };
        }
    }
    async getVoiceCloneStatus(id) {
        try {
            const status = await this.avatarService.getVoiceCloneStatus(id);
            return { code: 200, msg: 'success', data: status };
        }
        catch (err) {
            console.error('获取声音复刻状态失败:', err);
            return { code: 500, msg: '服务器错误', data: null };
        }
    }
    async updateAvatar(id, body) {
        try {
            await this.avatarService.updateAvatar(id, {
                name: body.name,
                photo: body.photo || body.avatar_url,
                tags: body.tags,
                abilities: body.abilities,
                description: body.description,
                config: body.config,
                personality: body.personality,
                latitude: body.latitude,
                longitude: body.longitude,
                location_text: body.location_text || body.locationText
            });
            return { code: 200, msg: 'success', data: null };
        }
        catch (err) {
            console.error('更新分身失败:', err);
            return { code: 500, msg: '服务器错误', data: null };
        }
    }
    async deleteAvatar(id, userId) {
        try {
            const result = await this.avatarService.deleteAvatar(id, userId);
            if (!result.success) {
                return { code: 400, msg: result.error || '删除失败', data: null };
            }
            return { code: 200, msg: 'success', data: null };
        }
        catch (err) {
            console.error('删除分身失败:', err);
            return { code: 500, msg: '服务器错误', data: null };
        }
    }
    async getSkills(id) {
        try {
            const skills = await this.avatarService.getSkills(id);
            return { code: 200, msg: 'success', data: skills };
        }
        catch (err) {
            return { code: 500, msg: '服务器错误', data: [] };
        }
    }
    async addSkill(id, body) {
        try {
            const skill = await this.avatarService.addSkill(id, body);
            return { code: 200, msg: 'success', data: skill };
        }
        catch (err) {
            return { code: 500, msg: '服务器错误', data: null };
        }
    }
    async deleteSkill(skillId) {
        try {
            await this.avatarService.deleteSkill(parseInt(skillId));
            return { code: 200, msg: 'success', data: null };
        }
        catch (err) {
            return { code: 500, msg: '服务器错误', data: null };
        }
    }
    async getMemories(id) {
        try {
            const memories = await this.avatarService.getMemories(id);
            return { code: 200, msg: 'success', data: memories };
        }
        catch (err) {
            return { code: 500, msg: '服务器错误', data: [] };
        }
    }
    async addMemory(id, body) {
        try {
            const memory = await this.avatarService.addMemory(id, body);
            return { code: 200, msg: 'success', data: memory };
        }
        catch (err) {
            return { code: 500, msg: '服务器错误', data: null };
        }
    }
    async deleteMemory(memoryId) {
        try {
            await this.avatarService.deleteMemory(parseInt(memoryId));
            return { code: 200, msg: 'success', data: null };
        }
        catch (err) {
            return { code: 500, msg: '服务器错误', data: null };
        }
    }
    async getStats(id) {
        try {
            const stats = await this.avatarService.getStats(id);
            return { code: 200, msg: 'success', data: stats };
        }
        catch (err) {
            return { code: 500, msg: '服务器错误', data: null };
        }
    }
    async updateTrust(id, body) {
        try {
            await this.avatarService.updateTrust(id, body.trust_enabled);
            return { code: 200, msg: 'success', data: null };
        }
        catch (err) {
            console.error('更新托管状态失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: null };
        }
    }
    async enableAllTrust(userId, body) {
        try {
            await this.avatarService.enableAllTrust(userId, body.trust_enabled);
            return { code: 200, msg: 'success', data: null };
        }
        catch (err) {
            console.error('批量更新托管状态失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: null };
        }
    }
    async updateHostingSettings(id, body) {
        try {
            const result = await this.avatarService.updateHostingSettings(id, body || {});
            return { code: 200, msg: 'success', data: result?.data || null };
        }
        catch (err) {
            console.error('更新托管设置失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: null };
        }
    }
    async getAccounts(avatarId) {
        try {
            const accounts = await this.avatarService.getAccounts(avatarId);
            return { code: 200, msg: 'success', data: accounts };
        }
        catch (err) {
            console.error('获取账号列表失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: [] };
        }
    }
    async createAccount(body) {
        try {
            const account = await this.avatarService.createAccount(body);
            return { code: 200, msg: 'success', data: account };
        }
        catch (err) {
            console.error('创建账号失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: null };
        }
    }
    async updateAccount(id, body) {
        try {
            const account = await this.avatarService.updateAccount(id, body);
            return { code: 200, msg: 'success', data: account };
        }
        catch (err) {
            console.error('更新账号失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: null };
        }
    }
    async deleteAccount(id) {
        try {
            await this.avatarService.deleteAccount(id);
            return { code: 200, msg: 'success', data: null };
        }
        catch (err) {
            console.error('删除账号失败:', err);
            return { code: 500, msg: err.message || '服务器错误', data: null };
        }
    }
    async publishWechatDraft(body) {
        try {
            const result = await this.avatarService.publishWechatDraft(body);
            return { code: 200, msg: 'success', data: result };
        }
        catch (err) {
            console.error('发布公众号草稿失败:', err);
            return { code: 500, msg: err.message || '发布失败', data: null };
        }
    }
};
exports.AvatarController = AvatarController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "createAvatar", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getAllAvatars", null);
__decorate([
    (0, common_1.Get)('list'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('pageSize')),
    __param(3, (0, common_1.Query)('gender')),
    __param(4, (0, common_1.Query)('ageGroup')),
    __param(5, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getAvatarList", null);
__decorate([
    (0, common_1.Get)('search'),
    __param(0, (0, common_1.Query)('keyword')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "searchAvatars", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getAvatarDetail", null);
__decorate([
    (0, common_1.Get)(':id/voice-status'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getVoiceCloneStatus", null);
__decorate([
    (0, common_1.Put)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "updateAvatar", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "deleteAvatar", null);
__decorate([
    (0, common_1.Get)(':id/skills'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getSkills", null);
__decorate([
    (0, common_1.Post)(':id/skills'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "addSkill", null);
__decorate([
    (0, common_1.Delete)(':id/skills/:skillId'),
    __param(0, (0, common_1.Param)('skillId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "deleteSkill", null);
__decorate([
    (0, common_1.Get)(':id/memories'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getMemories", null);
__decorate([
    (0, common_1.Post)(':id/memories'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "addMemory", null);
__decorate([
    (0, common_1.Delete)(':id/memories/:memoryId'),
    __param(0, (0, common_1.Param)('memoryId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "deleteMemory", null);
__decorate([
    (0, common_1.Get)(':id/stats'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getStats", null);
__decorate([
    (0, common_1.Put)(':id/trust'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "updateTrust", null);
__decorate([
    (0, common_1.Put)('trust/all'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "enableAllTrust", null);
__decorate([
    (0, common_1.Post)(':id/hosting/settings'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "updateHostingSettings", null);
__decorate([
    (0, common_1.Get)(':avatarId/accounts'),
    __param(0, (0, common_1.Param)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "getAccounts", null);
__decorate([
    (0, common_1.Post)('accounts'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "createAccount", null);
__decorate([
    (0, common_1.Put)('accounts/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "updateAccount", null);
__decorate([
    (0, common_1.Delete)('accounts/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "deleteAccount", null);
__decorate([
    (0, common_1.Post)('publish/wechat-draft'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AvatarController.prototype, "publishWechatDraft", null);
exports.AvatarController = AvatarController = __decorate([
    (0, common_1.Controller)('avatar'),
    __param(0, (0, common_1.Inject)('AVATAR_SERVICE')),
    __metadata("design:paramtypes", [avatar_service_1.AvatarService])
], AvatarController);
