"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderController = void 0;
const common_1 = require("@nestjs/common");
const order_service_1 = require("./order.service");
const order_dispatch_service_1 = require("../order-dispatch/order-dispatch.service");
let OrderController = class OrderController {
    constructor(orderService, dispatchService) {
        this.orderService = orderService;
        this.dispatchService = dispatchService;
    }
    async create(userId, orderData) {
        console.log('[OrderController] 创建订单，用户ID:', userId, '订单数据:', orderData);
        const result = await this.orderService.createOrder(userId, orderData);
        return {
            code: 200,
            data: result,
            message: result.payment ? '创建成功，请完成支付' : '创建成功'
        };
    }
    async update(orderId, updateData) {
        const order = await this.orderService.updateOrder(orderId, updateData);
        return { code: 200, data: order, message: '更新成功' };
    }
    async list(userId, status, avatarId) {
        console.log('[OrderController] list 被调用, userId:', userId, 'status:', status, 'avatarId:', avatarId);
        const filters = {};
        if (status) {
            filters.status = status;
        }
        if (avatarId) {
            filters.avatar_id = avatarId;
        }
        const orders = await this.orderService.getOrders(userId, filters);
        return { code: 200, data: orders, message: '获取成功' };
    }
    async getOpenOrders(page, pageSize, platform) {
        const result = await this.orderService.getOpenOrders(page ? parseInt(page) : 1, pageSize ? parseInt(pageSize) : 20, platform);
        return { code: 200, data: result, message: '获取成功' };
    }
    async stats(userId) {
        console.log('[OrderController] stats 被调用, userId:', userId);
        const stats = await this.orderService.getOrderStats(userId || '');
        return { code: 200, data: stats, message: '获取成功' };
    }
    async get(orderId) {
        console.log('[OrderController] get 被调用, orderId:', orderId);
        const order = await this.orderService.getOrderById(orderId);
        return { code: 200, data: order, message: '获取成功' };
    }
    async getFeedback(orderId) {
        const feedback = await this.orderService.getOrderFeedback(orderId);
        return { code: 200, data: feedback, message: '获取成功' };
    }
    async getRating(orderId) {
        const rating = await this.orderService.getOrderRating(orderId);
        return { code: 200, data: rating, message: '获取成功' };
    }
    async getDispatchStatus(orderId) {
        const status = await this.dispatchService.getDispatchStatus(orderId);
        return { code: 200, data: status, message: '获取成功' };
    }
    async updateStatus(orderId, status, avatarId) {
        const order = await this.orderService.updateOrderStatus(orderId, status, avatarId);
        return { code: 200, data: order, message: '更新成功' };
    }
    async acceptOrder(orderId, avatarId, userId) {
        const order = await this.orderService.acceptOrder(orderId, avatarId || userId);
        return { code: 200, data: order, message: '接单成功' };
    }
    async submitResult(orderId, result) {
        const order = await this.orderService.submitOrderResult(orderId, result);
        return { code: 200, data: order, message: '结果提交成功' };
    }
    async delete(orderId, userId) {
        const result = await this.orderService.deleteOrder(orderId, userId || '');
        return { code: 200, data: result, message: '删除成功' };
    }
    async cancel(orderId, userId) {
        const result = await this.orderService.cancelOrder(orderId, userId || '');
        return { code: 200, data: result, message: '取消成功' };
    }
    async repay(orderId, userId, body) {
        const openid = body.openid;
        if (!openid) {
            return { code: 400, data: null, message: '缺少openid参数' };
        }
        try {
            const paymentParams = await this.orderService.repayOrder(orderId, userId, openid);
            return { code: 200, data: { payment: paymentParams }, message: '支付订单创建成功' };
        }
        catch (err) {
            console.error('[OrderController] 重新支付失败:', err.message);
            return { code: 500, data: null, message: err.message || '创建支付订单失败' };
        }
    }
};
exports.OrderController = OrderController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "update", null);
__decorate([
    (0, common_1.Get)('list'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __param(1, (0, common_1.Query)('status')),
    __param(2, (0, common_1.Query)('avatar_id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('open'),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('pageSize')),
    __param(2, (0, common_1.Query)('platform')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "getOpenOrders", null);
__decorate([
    (0, common_1.Get)('stats'),
    __param(0, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "stats", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "get", null);
__decorate([
    (0, common_1.Get)(':id/feedback'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "getFeedback", null);
__decorate([
    (0, common_1.Get)(':id/rating'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "getRating", null);
__decorate([
    (0, common_1.Get)(':id/dispatch-status'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "getDispatchStatus", null);
__decorate([
    (0, common_1.Put)(':id/status'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('status')),
    __param(2, (0, common_1.Body)('avatar_id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Put)(':id/accept'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('avatar_id')),
    __param(2, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "acceptOrder", null);
__decorate([
    (0, common_1.Put)(':id/result'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('result')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "submitResult", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "delete", null);
__decorate([
    (0, common_1.Post)(':id/cancel'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "cancel", null);
__decorate([
    (0, common_1.Post)(':id/repay'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], OrderController.prototype, "repay", null);
exports.OrderController = OrderController = __decorate([
    (0, common_1.Controller)('order'),
    __param(0, (0, common_1.Inject)('ORDER_SERVICE')),
    __param(1, (0, common_1.Inject)('ORDER_DISPATCH_SERVICE')),
    __metadata("design:paramtypes", [order_service_1.OrderService,
        order_dispatch_service_1.OrderDispatchService])
], OrderController);
