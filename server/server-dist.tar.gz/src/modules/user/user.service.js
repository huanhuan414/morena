"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const TEST_USER_IDS = ['dev_user', 'test_user', 'guest-user-id', 'anonymous'];
let UserService = class UserService {
    getCurrentUserId(userIdFromHeader) {
        if (userIdFromHeader && !TEST_USER_IDS.includes(userIdFromHeader)) {
            return userIdFromHeader;
        }
        if (userIdFromHeader && TEST_USER_IDS.includes(userIdFromHeader)) {
            console.log(`[UserService] 使用测试用户ID: ${userIdFromHeader}`);
            return userIdFromHeader;
        }
        return 'dev_user';
    }
    isLoggedIn(userId) {
        if (!userId)
            return false;
        return !TEST_USER_IDS.includes(userId);
    }
    async getUserProfile(userId) {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const [rows] = await client.execute('SELECT id, nickname, avatar_url, phone, bio, level, exp, credits, created_at, updated_at FROM users WHERE id = ?', [userId]);
        const user = rows[0];
        if (!user) {
            return { id: userId, nickname: '探索者', avatar: '', level: 1, exp: 0, credits: 0 };
        }
        return {
            id: user.id,
            nickname: user.nickname || '探索者',
            avatar: user.avatar_url || '',
            phone: user.phone || '',
            bio: user.bio || '',
            level: user.level || 1,
            exp: user.exp || 0,
            credits: user.credits || 0,
            created_at: user.created_at,
            updated_at: user.updated_at
        };
    }
    async updateUserProfile(userId, updates) {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const allowedFields = ['nickname', 'avatar_url', 'phone', 'bio'];
        const setClauses = [];
        const values = [];
        for (const field of allowedFields) {
            if (updates[field] !== undefined) {
                setClauses.push(`${field} = ?`);
                values.push(updates[field]);
            }
        }
        if (setClauses.length === 0) {
            return this.getUserProfile(userId);
        }
        values.push(userId);
        await client.execute(`UPDATE users SET ${setClauses.join(', ')}, updated_at = NOW() WHERE id = ?`, values);
        return this.getUserProfile(userId);
    }
    async getUserStats(userId) {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const [avatarRows] = await client.execute('SELECT COUNT(*) as count FROM avatars WHERE user_id = ?', [userId]);
        const avatarCount = avatarRows[0]?.count || 0;
        const [orderRows] = await client.execute('SELECT COUNT(*) as count FROM orders WHERE user_id = ?', [userId]);
        const taskCount = orderRows[0]?.count || 0;
        const [postRows] = await client.execute('SELECT COUNT(*) as count FROM social_posts WHERE user_id = ?', [userId]);
        const postCount = postRows[0]?.count || 0;
        const [friendRows] = await client.execute('SELECT COUNT(*) as count FROM friendships WHERE (user_id = ? OR friend_id = ?) AND status = ?', [userId, userId, 'accepted']);
        const friendCount = friendRows[0]?.count || 0;
        const [userRows] = await client.execute('SELECT level, exp FROM users WHERE id = ?', [userId]);
        const level = userRows[0]?.level || 1;
        const totalXp = userRows[0]?.exp || 0;
        return {
            avatarCount,
            taskCount,
            postCount,
            friendCount,
            totalXp,
            level
        };
    }
    async getLearningProgress(userId) {
        const profile = await this.getUserProfile(userId);
        return {
            level: profile.level,
            exp: profile.exp,
            nextLevelExp: (profile.level || 1) * 100,
            progress: Math.min(100, ((profile.exp || 0) / ((profile.level || 1) * 100)) * 100)
        };
    }
    async getSecurityStatus(userId) {
        const profile = await this.getUserProfile(userId);
        return {
            hasPassword: true,
            hasPhone: !!profile.phone,
            phone: profile.phone ? profile.phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2') : '',
            twoFactorEnabled: false
        };
    }
    async changePassword(userId, oldPassword, newPassword) {
        const client = await (0, mysql_client_1.getMySQLClient)();
        const [rows] = await client.execute('SELECT password_hash FROM users WHERE id = ?', [userId]);
        if (!rows[0]) {
            throw new common_1.UnauthorizedException('用户不存在');
        }
        await client.execute('UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?', [newPassword, userId]);
        return { success: true };
    }
};
exports.UserService = UserService;
exports.UserService = UserService = __decorate([
    (0, common_1.Injectable)()
], UserService);
