"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var LinkValidationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LinkValidationService = void 0;
const common_1 = require("@nestjs/common");
let LinkValidationService = LinkValidationService_1 = class LinkValidationService {
    constructor() {
        this.logger = new common_1.Logger(LinkValidationService_1.name);
    }
    async validateLink(url, orderId, avatarId) {
        try {
            if (!url || typeof url !== 'string') {
                return {
                    success: false,
                    platform: 'unknown',
                    error: '链接不能为空'
                };
            }
            this.logger.log(`[LinkValidation] 开始验证链接: ${url}`);
            const platform = this.detectPlatform(url);
            if (!platform) {
                return {
                    success: false,
                    platform: 'unknown',
                    error: '无法识别链接所属平台'
                };
            }
            this.logger.log(`[LinkValidation] 识别到平台: ${platform}`);
            switch (platform) {
                case 'douyin':
                    return await this.validateDouyin(url);
                case 'xiaohongshu':
                    return await this.validateXiaohongshu(url);
                case 'wechat':
                    return await this.validateWechat(url);
                default:
                    return {
                        success: false,
                        platform,
                        error: '暂不支持该平台'
                    };
            }
        }
        catch (error) {
            this.logger.error(`[LinkValidation] 验证失败: ${error.message}`);
            return {
                success: false,
                platform: 'unknown',
                error: error.message
            };
        }
    }
    detectPlatform(url) {
        if (url.includes('douyin.com') || url.includes('iesdouyin.com')) {
            return 'douyin';
        }
        if (url.includes('xiaohongshu.com') || url.includes('xhslink.com')) {
            return 'xiaohongshu';
        }
        if (url.includes('mp.weixin.qq.com') || url.includes('weixin://')) {
            return 'wechat';
        }
        if (url.includes('bilibili.com')) {
            return 'bilibili';
        }
        if (url.includes('weibo.com')) {
            return 'weibo';
        }
        return null;
    }
    async validateDouyin(url) {
        return {
            success: true,
            platform: 'douyin',
            data: {
                url,
                title: '抖音作品',
                description: '抖音内容'
            }
        };
    }
    async validateXiaohongshu(url) {
        return {
            success: true,
            platform: 'xiaohongshu',
            data: {
                url,
                title: '小红书笔记',
                description: '小红书内容'
            }
        };
    }
    async validateWechat(url) {
        return {
            success: true,
            platform: 'wechat',
            data: {
                url,
                title: '微信公众号文章',
                description: '微信内容'
            }
        };
    }
};
exports.LinkValidationService = LinkValidationService;
exports.LinkValidationService = LinkValidationService = LinkValidationService_1 = __decorate([
    (0, common_1.Injectable)()
], LinkValidationService);
