"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderProcessingController = void 0;
const common_1 = require("@nestjs/common");
const order_processing_service_1 = require("./order-processing.service");
const link_validation_service_1 = require("./link-validation.service");
let OrderProcessingController = class OrderProcessingController {
    constructor(processingService, linkValidationService) {
        this.processingService = processingService;
        this.linkValidationService = linkValidationService;
    }
    async getStatus(id) {
        try {
            let status = await this.processingService.getProcessingStatus(id);
            if (!status) {
                status = await this.processingService.getProcessingByRequestId(id);
            }
            return {
                code: 200,
                data: status,
                message: status ? '获取成功' : '暂无生成记录'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '获取失败'
            };
        }
    }
    async validateLink(url, orderId, avatarId) {
        try {
            const result = await this.linkValidationService.validateLink(url, orderId, avatarId);
            return {
                code: 200,
                data: result,
                message: result.success ? '验证成功' : '验证失败'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: {
                    success: false,
                    platform: 'unknown',
                    error: error.message || '验证失败'
                },
                message: error.message || '验证失败'
            };
        }
    }
    async createProcessing(body, userId) {
        try {
            const result = await this.processingService.createProcessingOrder({
                order_id: body.order_id,
                avatar_id: body.avatar_id,
                user_id: userId,
                config: body.config
            });
            return {
                code: 200,
                data: result,
                message: '创建成功'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '创建失败'
            };
        }
    }
    async confirmContent(id, content) {
        try {
            const result = await this.processingService.confirmProcessing(id, content);
            return {
                code: 200,
                data: result,
                message: result ? '确认成功' : '记录不存在'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '确认失败'
            };
        }
    }
    async publishContent(id, platforms) {
        try {
            const result = await this.processingService.publishProcessing(id, platforms);
            return {
                code: 200,
                data: result,
                message: result ? '发布成功' : '记录不存在'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '发布失败'
            };
        }
    }
    async submitFeedback(id, feedback) {
        try {
            const result = await this.processingService.submitFeedback(id, feedback || {});
            return {
                code: 200,
                data: result,
                message: result ? '反馈提交成功' : '记录不存在'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '反馈提交失败'
            };
        }
    }
    async acceptContent(id) {
        console.log(`[OrderProcessingController] 验收请求: id=${id}`);
        try {
            const result = await this.processingService.acceptProcessing(id);
            console.log(`[OrderProcessingController] 验收结果:`, JSON.stringify(result));
            return {
                code: 200,
                data: result,
                message: result ? '验收成功' : '记录不存在'
            };
        }
        catch (error) {
            console.error(`[OrderProcessingController] 验收失败:`, error);
            return {
                code: 500,
                data: null,
                message: error.message || '验收失败'
            };
        }
    }
    async openDispute(id, reason, evidence) {
        try {
            const result = await this.processingService.createDispute(id, { reason, evidence });
            return {
                code: 200,
                data: result,
                message: result ? '已发起争议' : '记录不存在'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '发起争议失败'
            };
        }
    }
    async listDisputes(status = 'open', limit = 50) {
        try {
            const result = await this.processingService.listDisputes(status, Number(limit) || 50);
            return {
                code: 200,
                data: result,
                message: 'success'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '获取争议列表失败'
            };
        }
    }
    async resolveDispute(disputeId, resolution, note) {
        try {
            const result = await this.processingService.resolveDispute(disputeId, { resolution, note });
            return {
                code: 200,
                data: result,
                message: result ? '已处理' : '争议不存在'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '处理争议失败'
            };
        }
    }
    async urgeAcceptance(id) {
        try {
            const result = await this.processingService.urgeAcceptance(id);
            if (!result) {
                return {
                    code: 200,
                    data: null,
                    message: '记录不存在'
                };
            }
            if (!result.success) {
                return {
                    code: 200,
                    data: result,
                    message: result.cooldownRemainingMs ? '催促过于频繁，请稍后再试' : '催促失败'
                };
            }
            return {
                code: 200,
                data: result,
                message: '已催促发单者验收'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '催促失败'
            };
        }
    }
    async requestRevision(id, feedback) {
        try {
            const result = await this.processingService.requestRevision(id, feedback || {});
            return {
                code: 200,
                data: result,
                message: result ? '已发起修改' : '记录不存在'
            };
        }
        catch (error) {
            return {
                code: 500,
                data: null,
                message: error.message || '发起修改失败'
            };
        }
    }
};
exports.OrderProcessingController = OrderProcessingController;
__decorate([
    (0, common_1.Get)('status/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "getStatus", null);
__decorate([
    (0, common_1.Post)('validate-link'),
    __param(0, (0, common_1.Body)('url')),
    __param(1, (0, common_1.Body)('orderId')),
    __param(2, (0, common_1.Body)('avatarId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "validateLink", null);
__decorate([
    (0, common_1.Post)('create'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "createProcessing", null);
__decorate([
    (0, common_1.Post)('confirm/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('content')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "confirmContent", null);
__decorate([
    (0, common_1.Post)('publish/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('platforms')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Array]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "publishContent", null);
__decorate([
    (0, common_1.Post)('feedback/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('feedback')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "submitFeedback", null);
__decorate([
    (0, common_1.Put)('accept/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "acceptContent", null);
__decorate([
    (0, common_1.Post)('dispute/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('reason')),
    __param(2, (0, common_1.Body)('evidence')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "openDispute", null);
__decorate([
    (0, common_1.Get)('disputes'),
    __param(0, (0, common_1.Query)('status')),
    __param(1, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "listDisputes", null);
__decorate([
    (0, common_1.Post)('disputes/resolve'),
    __param(0, (0, common_1.Body)('dispute_id')),
    __param(1, (0, common_1.Body)('resolution')),
    __param(2, (0, common_1.Body)('note')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "resolveDispute", null);
__decorate([
    (0, common_1.Post)('urge-acceptance/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "urgeAcceptance", null);
__decorate([
    (0, common_1.Post)('revision/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('feedback')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OrderProcessingController.prototype, "requestRevision", null);
exports.OrderProcessingController = OrderProcessingController = __decorate([
    (0, common_1.Controller)('order-processing'),
    __param(0, (0, common_1.Inject)(order_processing_service_1.OrderProcessingService)),
    __param(1, (0, common_1.Inject)(link_validation_service_1.LinkValidationService)),
    __metadata("design:paramtypes", [order_processing_service_1.OrderProcessingService,
        link_validation_service_1.LinkValidationService])
], OrderProcessingController);
