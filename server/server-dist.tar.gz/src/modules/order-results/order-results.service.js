"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderResultsService = void 0;
const common_1 = require("@nestjs/common");
const mysql_client_1 = require("../../storage/database/mysql-client");
const crypto = require("crypto");
let OrderResultsService = class OrderResultsService {
    async createOrderResult(data) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const id = crypto.randomUUID();
        const insertResult = await db.insert('order_results', {
            id,
            order_id: data.order_id,
            avatar_id: data.avatar_id,
            platform: 'auto',
            task_description: data.description || data.link_url || '',
            actual_exposure: data.exposure || 0,
            actual_likes: data.likes || 0,
            actual_comments: data.comments || 0,
            actual_shares: data.shares || 0,
            quality_score: 0,
            notes: data.link_url || '',
            created_at: new Date(),
            screenshots: typeof data.screenshots === 'string' ? data.screenshots : JSON.stringify(data.screenshots || []),
        });
        if (insertResult.error) {
            console.error('[OrderResultsService] createOrderResult 失败:', insertResult.error);
        }
        return { id };
    }
    async getOrderResult(orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        return await db.queryOne('order_results', { order_id: orderId });
    }
    async getOrderResultsByOrder(orderId) {
        const db = (0, mysql_client_1.getMySQLClient)();
        const pool = db._pool || db.pool;
        if (pool) {
            const [rows] = await pool.query('SELECT * FROM order_results WHERE order_id = ? ORDER BY created_at DESC', [orderId]);
            return rows;
        }
        return [];
    }
};
exports.OrderResultsService = OrderResultsService;
exports.OrderResultsService = OrderResultsService = __decorate([
    (0, common_1.Injectable)()
], OrderResultsService);
