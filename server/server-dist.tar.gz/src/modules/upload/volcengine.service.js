"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var VolcengineService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.VolcengineService = void 0;
const common_1 = require("@nestjs/common");
const imagex_openapi_1 = require("@volcengine/imagex-openapi");
let VolcengineService = VolcengineService_1 = class VolcengineService {
    constructor() {
        this.logger = new common_1.Logger(VolcengineService_1.name);
        this.FULL_SERVICE_ID = 'tos-cn-i-699z2ac540';
        this.SHORT_ID = '699z2ac540';
        this.CUSTOM_DOMAIN = 'voic.51webjs.com';
        this.VIDEO_SHORT_ID = '4rj1sb5o2t';
        this.client = new imagex_openapi_1.ImageXClient({
            accessKey: process.env.VOLC_ACCESS_KEY || '',
            secretKey: process.env.VOLC_SECRET_KEY || '',
            region: 'cn-north-1',
            host: 'imagex.volcengineapi.com',
        });
    }
    async uploadImage(file) {
        this.logger.log(`[VolcengineService] 开始上传图片: ${file.originalname}, MIME: ${file.mimetype}`);
        try {
            let originalname = file.originalname;
            if (!originalname || originalname.startsWith('.') || !originalname.includes('.')) {
                originalname = `image_${Date.now()}.png`;
            }
            else {
                originalname = originalname.replace(/\.[^.]+$/, '.png');
            }
            const storeKey = this.generateStoreKey(originalname);
            this.logger.log(`[VolcengineService] StoreKey: ${storeKey}`);
            const applyRes = await this.client.ApplyImageUpload({
                ServiceId: this.SHORT_ID,
                UploadNum: 1,
                StoreKeys: [storeKey],
            });
            this.logger.log(`[VolcengineService] ApplyImageUpload 响应:`, JSON.stringify(applyRes, null, 2));
            if (applyRes.ResponseMetadata?.Error) {
                throw new Error(`获取上传凭证失败: ${applyRes.ResponseMetadata.Error.Message}`);
            }
            if (!applyRes.Result?.UploadAddress?.StoreInfos?.length) {
                throw new Error('上传凭证响应格式错误');
            }
            const uploadAddress = applyRes.Result.UploadAddress;
            if (!file.buffer || file.buffer.length === 0) {
                throw new Error('文件内容为空');
            }
            this.logger.log(`[VolcengineService] 开始上传文件，大小: ${file.buffer.length} bytes`);
            await this.client.DoUpload([file.buffer], uploadAddress.UploadHosts[0], uploadAddress.StoreInfos);
            this.logger.log(`[VolcengineService] 文件上传成功`);
            const commitRes = await this.client.CommitImageUpload({
                ServiceId: this.SHORT_ID,
                SessionKey: uploadAddress.SessionKey,
            });
            this.logger.log(`[VolcengineService] CommitImageUpload 响应:`, JSON.stringify(commitRes, null, 2));
            if (commitRes.ResponseMetadata?.Error) {
                throw new Error(`确认上传失败: ${commitRes.ResponseMetadata.Error.Message}`);
            }
            if (!commitRes.Result?.Results?.length) {
                throw new Error('确认上传响应中没有结果');
            }
            const result = commitRes.Result.Results[0];
            this.logger.log(`[VolcengineService] 上传结果详情:`, JSON.stringify(result, null, 2));
            if (!result.Uri) {
                throw new Error('上传结果中没有URI');
            }
            const uri = result.Uri;
            const encodedUri = uri.replace('user/', 'user%2F');
            const url = `https://${this.CUSTOM_DOMAIN}/${encodedUri}~tplv-${this.SHORT_ID}-image.png`;
            this.logger.log(`[VolcengineService] 构建的URL: ${url}`);
            this.logger.log(`[VolcengineService] 原始URI: ${uri}`);
            return { url };
        }
        catch (error) {
            this.logger.error(`[VolcengineService] 上传失败:`, error);
            this.logger.error(`[VolcengineService] Error properties:`, Object.getOwnPropertyNames(error || {}));
            this.logger.error(`[VolcengineService] Error keys:`, Object.keys(error || {}));
            this.logger.error(`[VolcengineService] Error string:`, error?.toString());
            this.logger.error(`[VolcengineService] Error stack:`, error?.stack);
            throw new Error(`上传图片失败: ${error.message}`);
        }
    }
    generateStoreKey(originalName) {
        const ext = originalName.split('.').pop() || 'png';
        let hash = '';
        for (let i = 0; i < 8; i++) {
            hash += Math.random().toString(16).substring(2, 6);
        }
        hash = hash.substring(0, 32);
        return `user/${hash}.${ext}`;
    }
    getExtensionFromMime(mimetype, filename) {
        return 'png';
    }
    async uploadVideo(videoBuffer, fileName) {
        this.logger.log(`[VolcengineService] 开始上传视频，大小: ${videoBuffer.length} bytes`);
        try {
            const name = fileName || `video_${Date.now()}.mp4`;
            const storeKey = this.generateVideoStoreKey(name);
            this.logger.log(`[VolcengineService] Video StoreKey: ${storeKey}`);
            const applyRes = await this.client.ApplyImageUpload({
                ServiceId: this.VIDEO_SHORT_ID,
                UploadNum: 1,
                StoreKeys: [storeKey],
            });
            if (applyRes.ResponseMetadata?.Error) {
                throw new Error(`获取视频上传凭证失败: ${applyRes.ResponseMetadata.Error.Message}`);
            }
            if (!applyRes.Result?.UploadAddress?.StoreInfos?.length) {
                throw new Error('视频上传凭证响应格式错误');
            }
            const uploadAddress = applyRes.Result.UploadAddress;
            await this.client.DoUpload([videoBuffer], uploadAddress.UploadHosts[0], uploadAddress.StoreInfos);
            this.logger.log(`[VolcengineService] 视频文件上传成功`);
            const commitRes = await this.client.CommitImageUpload({
                ServiceId: this.VIDEO_SHORT_ID,
                SessionKey: uploadAddress.SessionKey,
            });
            if (commitRes.ResponseMetadata?.Error) {
                throw new Error(`确认视频上传失败: ${commitRes.ResponseMetadata.Error.Message}`);
            }
            if (!commitRes.Result?.Results?.length) {
                throw new Error('确认视频上传响应中没有结果');
            }
            const result = commitRes.Result.Results[0];
            if (!result.Uri) {
                throw new Error('视频上传结果中没有URI');
            }
            const uri = result.Uri;
            const encodedUri = uri.replace('user/', 'user%2F');
            const url = `https://${this.CUSTOM_DOMAIN}/${encodedUri}~tplv-${this.VIDEO_SHORT_ID}-video.mp4`;
            this.logger.log(`[VolcengineService] 视频URL: ${url}`);
            return { url };
        }
        catch (error) {
            this.logger.error(`[VolcengineService] 视频上传失败: ${error.message}`);
            throw new Error(`上传视频失败: ${error.message}`);
        }
    }
    generateVideoStoreKey(originalName) {
        const ext = originalName.split('.').pop() || 'mp4';
        let hash = '';
        for (let i = 0; i < 8; i++) {
            hash += Math.random().toString(16).substring(2, 6);
        }
        hash = hash.substring(0, 32);
        return `user/${hash}.${ext}`;
    }
};
exports.VolcengineService = VolcengineService;
exports.VolcengineService = VolcengineService = VolcengineService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], VolcengineService);
