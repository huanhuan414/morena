"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var UploadService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadService = void 0;
const common_1 = require("@nestjs/common");
const volcengine_service_1 = require("./volcengine.service");
const storage_service_1 = require("../storage/storage.service");
let UploadService = UploadService_1 = class UploadService {
    constructor(volcengineService, storageService) {
        this.volcengineService = volcengineService;
        this.storageService = storageService;
        this.logger = new common_1.Logger(UploadService_1.name);
        this.logger.log('初始化上传服务');
    }
    async uploadOrderScreenshot(file) {
        return this.volcengineService.uploadImage(file);
    }
    async uploadAvatarImage(file) {
        return this.volcengineService.uploadImage(file);
    }
    async uploadImage(file) {
        return this.volcengineService.uploadImage(file);
    }
    async uploadVideo(file) {
        this.logger.log(`[UploadService] 上传视频到对象存储: ${file.originalname}, 大小: ${file.size} bytes`);
        try {
            if (!file.buffer || file.buffer.length === 0) {
                throw new Error('文件内容为空');
            }
            const url = await this.storageService.uploadVideo(file.buffer, file.originalname);
            this.logger.log(`[UploadService] 视频上传成功: ${url.substring(0, 60)}`);
            return { url };
        }
        catch (error) {
            this.logger.error('[UploadService] 视频上传失败:', error);
            throw new Error(`视频上传失败: ${error.message}`);
        }
    }
    async uploadAudio(file) {
        this.logger.log(`[UploadService] 上传音频到对象存储: ${file.originalname}`);
        try {
            const url = await this.storageService.uploadAudio(file.buffer, file.originalname);
            this.logger.log(`[UploadService] 音频上传成功: ${url.substring(0, 60)}`);
            return { url };
        }
        catch (error) {
            this.logger.error('[UploadService] 音频上传失败:', error);
            throw error;
        }
    }
};
exports.UploadService = UploadService;
exports.UploadService = UploadService = UploadService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(volcengine_service_1.VolcengineService)),
    __metadata("design:paramtypes", [volcengine_service_1.VolcengineService,
        storage_service_1.StorageService])
], UploadService);
