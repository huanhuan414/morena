"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = require("dotenv");
const path_1 = require("path");
const envPaths = [
    path_1.default.resolve(process.cwd(), '.env'),
    path_1.default.resolve(process.cwd(), 'server/.env'),
    path_1.default.resolve(__dirname, '../.env'),
];
for (const envPath of envPaths) {
    const result = dotenv_1.default.config({ path: envPath });
    if (!result.error) {
        console.log('[preload-env] Successfully loaded .env from:', envPath, 'MYSQL_PORT:', process.env.MYSQL_PORT);
        break;
    }
}
require("./main");
