"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const app_controller_1 = require("./app.controller");
const app_service_1 = require("./app.service");
const order_module_1 = require("./modules/order/order.module");
const chat_module_1 = require("./modules/chat/chat.module");
const auth_module_1 = require("./modules/auth/auth.module");
const avatar_module_1 = require("./modules/avatar/avatar.module");
const user_module_1 = require("./modules/user/user.module");
const task_module_1 = require("./modules/task/task.module");
const social_module_1 = require("./modules/social/social.module");
const agent_module_1 = require("./modules/agent/agent.module");
const avatar_agent_module_1 = require("./modules/avatar-agent/avatar-agent.module");
const audio_module_1 = require("./modules/audio/audio.module");
const storage_module_1 = require("./modules/storage/storage.module");
const notification_module_1 = require("./modules/notification/notification.module");
const order_dispatch_module_1 = require("./modules/order-dispatch/order-dispatch.module");
const order_results_module_1 = require("./modules/order-results/order-results.module");
const referral_module_1 = require("./modules/referral/referral.module");
const subscription_module_1 = require("./modules/subscription/subscription.module");
const media_module_1 = require("./modules/media/media.module");
const content_generation_module_1 = require("./modules/content-generation/content-generation.module");
const upload_module_1 = require("./modules/upload/upload.module");
const asr_module_1 = require("./modules/asr/asr.module");
const video_module_1 = require("./modules/video/video.module");
const vision_module_1 = require("./modules/vision/vision.module");
const voice_clone_module_1 = require("./modules/voice-clone/voice-clone.module");
const dashboard_module_1 = require("./modules/dashboard/dashboard.module");
const order_processing_module_1 = require("./modules/order-processing/order-processing.module");
const admin_module_1 = require("./modules/admin/admin.module");
const tikhub_module_1 = require("./modules/tikhub/tikhub.module");
const palm_reading_module_1 = require("./modules/palm-reading/palm-reading.module");
const earnings_module_1 = require("./modules/earnings/earnings.module");
const activities_module_1 = require("./modules/activities/activities.module");
const user_stats_module_1 = require("./modules/user-stats/user-stats.module");
const ai_module_1 = require("./modules/ai/ai.module");
const skill_module_1 = require("./modules/skill/skill.module");
const payment_module_1 = require("./modules/payment/payment.module");
const image_gen_module_1 = require("./modules/image-gen/image-gen.module");
const ai_skill_module_1 = require("./modules/ai-skill/ai-skill.module");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            schedule_1.ScheduleModule.forRoot(),
            storage_module_1.StorageModule,
            order_module_1.OrderModule,
            chat_module_1.ChatModule,
            auth_module_1.AuthModule,
            avatar_module_1.AvatarModule,
            user_module_1.UserModule,
            task_module_1.TaskModule,
            social_module_1.SocialModule,
            agent_module_1.AgentModule,
            avatar_agent_module_1.AvatarAgentModule,
            audio_module_1.AudioModule,
            notification_module_1.NotificationModule,
            order_dispatch_module_1.OrderDispatchModule,
            order_results_module_1.OrderResultsModule,
            referral_module_1.ReferralModule,
            subscription_module_1.SubscriptionModule,
            media_module_1.MediaModule,
            content_generation_module_1.ContentGenerationModule,
            upload_module_1.UploadModule,
            asr_module_1.AsrModule,
            video_module_1.VideoModule,
            vision_module_1.VisionModule,
            voice_clone_module_1.VoiceCloneModule,
            dashboard_module_1.DashboardModule,
            tikhub_module_1.TikHubModule,
            order_processing_module_1.OrderProcessingModule,
            admin_module_1.AdminModule,
            palm_reading_module_1.PalmReadingModule,
            earnings_module_1.EarningsModule,
            activities_module_1.ActivitiesModule,
            user_stats_module_1.UserStatsModule,
            ai_module_1.AiModule,
            skill_module_1.SkillModule,
            payment_module_1.PaymentModule,
            image_gen_module_1.ImageGenModule,
            ai_skill_module_1.AiSkillModule
        ],
        controllers: [app_controller_1.AppController],
        providers: [app_service_1.AppService],
    })
], AppModule);
