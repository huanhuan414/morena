"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.publishedWorksRelations = exports.avatarLearningRecordsRelations = exports.avatarAgentConfigsRelations = exports.avatarContextsRelations = exports.avatarMemoriesRelations = exports.subscriptionPlansRelations = exports.userSubscriptionsRelations = exports.agentTaskLogsRelations = exports.avatarFriendsRelations = exports.avatarSkillsRelations = exports.avatarAccountsRelations = exports.platformConfigsRelations = exports.referralsRelations = exports.withdrawalsRelations = exports.earningsRelations = exports.orderExecutionsRelations = exports.notificationsRelations = exports.likesRelations = exports.avatarEvolutionRelations = exports.followsRelations = exports.ordersRelations = exports.orderResultsRelations = exports.messagesRelations = exports.conversationsRelations = exports.avatarsRelations = exports.usersRelations = exports.postsRelations = exports.commentsRelations = void 0;
const relations_1 = require("drizzle-orm/relations");
const schema_1 = require("./schema");
exports.commentsRelations = (0, relations_1.relations)(schema_1.comments, ({ one, many }) => ({
    post: one(schema_1.posts, {
        fields: [schema_1.comments.postId],
        references: [schema_1.posts.id]
    }),
    user: one(schema_1.users, {
        fields: [schema_1.comments.userId],
        references: [schema_1.users.id]
    }),
    comment: one(schema_1.comments, {
        fields: [schema_1.comments.parentId],
        references: [schema_1.comments.id],
        relationName: "comments_parentId_comments_id"
    }),
    comments: many(schema_1.comments, {
        relationName: "comments_parentId_comments_id"
    }),
    avatar: one(schema_1.avatars, {
        fields: [schema_1.comments.avatarId],
        references: [schema_1.avatars.id]
    }),
}));
exports.postsRelations = (0, relations_1.relations)(schema_1.posts, ({ one, many }) => ({
    comments: many(schema_1.comments),
    user: one(schema_1.users, {
        fields: [schema_1.posts.userId],
        references: [schema_1.users.id]
    }),
    avatar: one(schema_1.avatars, {
        fields: [schema_1.posts.avatarId],
        references: [schema_1.avatars.id]
    }),
}));
exports.usersRelations = (0, relations_1.relations)(schema_1.users, ({ one, many }) => ({
    comments: many(schema_1.comments),
    conversations: many(schema_1.conversations),
    user: one(schema_1.users, {
        fields: [schema_1.users.invitedBy],
        references: [schema_1.users.id],
        relationName: "users_invitedBy_users_id"
    }),
    users: many(schema_1.users, {
        relationName: "users_invitedBy_users_id"
    }),
    follows_followerId: many(schema_1.follows, {
        relationName: "follows_followerId_users_id"
    }),
    follows_followingId: many(schema_1.follows, {
        relationName: "follows_followingId_users_id"
    }),
    posts: many(schema_1.posts),
    orders: many(schema_1.orders),
    likes: many(schema_1.likes),
    notifications: many(schema_1.notifications),
    earnings: many(schema_1.earnings),
    withdrawals: many(schema_1.withdrawals),
    referrals_inviterId: many(schema_1.referrals, {
        relationName: "referrals_inviterId_users_id"
    }),
    referrals_inviteeId: many(schema_1.referrals, {
        relationName: "referrals_inviteeId_users_id"
    }),
    platformConfigs: many(schema_1.platformConfigs),
}));
exports.avatarsRelations = (0, relations_1.relations)(schema_1.avatars, ({ many }) => ({
    comments: many(schema_1.comments),
    conversations: many(schema_1.conversations),
    orderResults: many(schema_1.orderResults),
    avatarEvolutions: many(schema_1.avatarEvolution),
    posts: many(schema_1.posts),
    orders: many(schema_1.orders),
    orderExecutions: many(schema_1.orderExecutions),
    earnings: many(schema_1.earnings),
    avatarAccounts: many(schema_1.avatarAccounts),
    avatarSkills: many(schema_1.avatarSkills),
    avatarFriends_avatarId: many(schema_1.avatarFriends, {
        relationName: "avatarFriends_avatarId_avatars_id"
    }),
    avatarFriends_friendAvatarId: many(schema_1.avatarFriends, {
        relationName: "avatarFriends_friendAvatarId_avatars_id"
    }),
    agentTaskLogs: many(schema_1.agentTaskLogs),
    avatarMemories: many(schema_1.avatarMemories),
    avatarContexts: many(schema_1.avatarContexts),
    avatarAgentConfigs: many(schema_1.avatarAgentConfigs),
    avatarLearningRecords: many(schema_1.avatarLearningRecords),
    publishedWorks: many(schema_1.publishedWorks),
}));
exports.conversationsRelations = (0, relations_1.relations)(schema_1.conversations, ({ one, many }) => ({
    user: one(schema_1.users, {
        fields: [schema_1.conversations.userId],
        references: [schema_1.users.id]
    }),
    avatar: one(schema_1.avatars, {
        fields: [schema_1.conversations.avatarId],
        references: [schema_1.avatars.id]
    }),
    messages: many(schema_1.messages),
}));
exports.messagesRelations = (0, relations_1.relations)(schema_1.messages, ({ one }) => ({
    conversation: one(schema_1.conversations, {
        fields: [schema_1.messages.conversationId],
        references: [schema_1.conversations.id]
    }),
}));
exports.orderResultsRelations = (0, relations_1.relations)(schema_1.orderResults, ({ one }) => ({
    order: one(schema_1.orders, {
        fields: [schema_1.orderResults.orderId],
        references: [schema_1.orders.id]
    }),
    avatar: one(schema_1.avatars, {
        fields: [schema_1.orderResults.avatarId],
        references: [schema_1.avatars.id]
    }),
}));
exports.ordersRelations = (0, relations_1.relations)(schema_1.orders, ({ one, many }) => ({
    orderResults: many(schema_1.orderResults),
    user: one(schema_1.users, {
        fields: [schema_1.orders.userId],
        references: [schema_1.users.id]
    }),
    avatar: one(schema_1.avatars, {
        fields: [schema_1.orders.avatarId],
        references: [schema_1.avatars.id]
    }),
    orderExecutions: many(schema_1.orderExecutions),
    earnings: many(schema_1.earnings),
    publishedWorks: many(schema_1.publishedWorks),
}));
exports.followsRelations = (0, relations_1.relations)(schema_1.follows, ({ one }) => ({
    user_followerId: one(schema_1.users, {
        fields: [schema_1.follows.followerId],
        references: [schema_1.users.id],
        relationName: "follows_followerId_users_id"
    }),
    user_followingId: one(schema_1.users, {
        fields: [schema_1.follows.followingId],
        references: [schema_1.users.id],
        relationName: "follows_followingId_users_id"
    }),
}));
exports.avatarEvolutionRelations = (0, relations_1.relations)(schema_1.avatarEvolution, ({ one }) => ({
    avatar: one(schema_1.avatars, {
        fields: [schema_1.avatarEvolution.avatarId],
        references: [schema_1.avatars.id]
    }),
}));
exports.likesRelations = (0, relations_1.relations)(schema_1.likes, ({ one }) => ({
    user: one(schema_1.users, {
        fields: [schema_1.likes.userId],
        references: [schema_1.users.id]
    }),
}));
exports.notificationsRelations = (0, relations_1.relations)(schema_1.notifications, ({ one }) => ({
    user: one(schema_1.users, {
        fields: [schema_1.notifications.userId],
        references: [schema_1.users.id]
    }),
}));
exports.orderExecutionsRelations = (0, relations_1.relations)(schema_1.orderExecutions, ({ one }) => ({
    order: one(schema_1.orders, {
        fields: [schema_1.orderExecutions.orderId],
        references: [schema_1.orders.id]
    }),
    avatar: one(schema_1.avatars, {
        fields: [schema_1.orderExecutions.avatarId],
        references: [schema_1.avatars.id]
    }),
}));
exports.earningsRelations = (0, relations_1.relations)(schema_1.earnings, ({ one }) => ({
    user: one(schema_1.users, {
        fields: [schema_1.earnings.userId],
        references: [schema_1.users.id]
    }),
    avatar: one(schema_1.avatars, {
        fields: [schema_1.earnings.avatarId],
        references: [schema_1.avatars.id]
    }),
    order: one(schema_1.orders, {
        fields: [schema_1.earnings.orderId],
        references: [schema_1.orders.id]
    }),
}));
exports.withdrawalsRelations = (0, relations_1.relations)(schema_1.withdrawals, ({ one }) => ({
    user: one(schema_1.users, {
        fields: [schema_1.withdrawals.userId],
        references: [schema_1.users.id]
    }),
}));
exports.referralsRelations = (0, relations_1.relations)(schema_1.referrals, ({ one }) => ({
    user_inviterId: one(schema_1.users, {
        fields: [schema_1.referrals.inviterId],
        references: [schema_1.users.id],
        relationName: "referrals_inviterId_users_id"
    }),
    user_inviteeId: one(schema_1.users, {
        fields: [schema_1.referrals.inviteeId],
        references: [schema_1.users.id],
        relationName: "referrals_inviteeId_users_id"
    }),
}));
exports.platformConfigsRelations = (0, relations_1.relations)(schema_1.platformConfigs, ({ one }) => ({
    user: one(schema_1.users, {
        fields: [schema_1.platformConfigs.userId],
        references: [schema_1.users.id]
    }),
}));
exports.avatarAccountsRelations = (0, relations_1.relations)(schema_1.avatarAccounts, ({ one }) => ({
    avatar: one(schema_1.avatars, {
        fields: [schema_1.avatarAccounts.avatarId],
        references: [schema_1.avatars.id]
    }),
}));
exports.avatarSkillsRelations = (0, relations_1.relations)(schema_1.avatarSkills, ({ one }) => ({
    avatar: one(schema_1.avatars, {
        fields: [schema_1.avatarSkills.avatarId],
        references: [schema_1.avatars.id]
    }),
}));
exports.avatarFriendsRelations = (0, relations_1.relations)(schema_1.avatarFriends, ({ one }) => ({
    avatar_avatarId: one(schema_1.avatars, {
        fields: [schema_1.avatarFriends.avatarId],
        references: [schema_1.avatars.id],
        relationName: "avatarFriends_avatarId_avatars_id"
    }),
    avatar_friendAvatarId: one(schema_1.avatars, {
        fields: [schema_1.avatarFriends.friendAvatarId],
        references: [schema_1.avatars.id],
        relationName: "avatarFriends_friendAvatarId_avatars_id"
    }),
}));
exports.agentTaskLogsRelations = (0, relations_1.relations)(schema_1.agentTaskLogs, ({ one }) => ({
    avatar: one(schema_1.avatars, {
        fields: [schema_1.agentTaskLogs.avatarId],
        references: [schema_1.avatars.id]
    }),
}));
exports.userSubscriptionsRelations = (0, relations_1.relations)(schema_1.userSubscriptions, ({ one }) => ({
    subscriptionPlan: one(schema_1.subscriptionPlans, {
        fields: [schema_1.userSubscriptions.planId],
        references: [schema_1.subscriptionPlans.id]
    }),
}));
exports.subscriptionPlansRelations = (0, relations_1.relations)(schema_1.subscriptionPlans, ({ many }) => ({
    userSubscriptions: many(schema_1.userSubscriptions),
}));
exports.avatarMemoriesRelations = (0, relations_1.relations)(schema_1.avatarMemories, ({ one }) => ({
    avatar: one(schema_1.avatars, {
        fields: [schema_1.avatarMemories.avatarId],
        references: [schema_1.avatars.id]
    }),
}));
exports.avatarContextsRelations = (0, relations_1.relations)(schema_1.avatarContexts, ({ one }) => ({
    avatar: one(schema_1.avatars, {
        fields: [schema_1.avatarContexts.avatarId],
        references: [schema_1.avatars.id]
    }),
}));
exports.avatarAgentConfigsRelations = (0, relations_1.relations)(schema_1.avatarAgentConfigs, ({ one }) => ({
    avatar: one(schema_1.avatars, {
        fields: [schema_1.avatarAgentConfigs.avatarId],
        references: [schema_1.avatars.id]
    }),
}));
exports.avatarLearningRecordsRelations = (0, relations_1.relations)(schema_1.avatarLearningRecords, ({ one }) => ({
    avatar: one(schema_1.avatars, {
        fields: [schema_1.avatarLearningRecords.avatarId],
        references: [schema_1.avatars.id]
    }),
}));
exports.publishedWorksRelations = (0, relations_1.relations)(schema_1.publishedWorks, ({ one }) => ({
    order: one(schema_1.orders, {
        fields: [schema_1.publishedWorks.orderId],
        references: [schema_1.orders.id]
    }),
    avatar: one(schema_1.avatars, {
        fields: [schema_1.publishedWorks.avatarId],
        references: [schema_1.avatars.id]
    }),
}));
