"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MysqlClient = void 0;
exports.getPool = getPool;
exports.usersTable = usersTable;
exports.avatarsTable = avatarsTable;
exports.avatarSkillsTable = avatarSkillsTable;
exports.avatarMemoriesTable = avatarMemoriesTable;
exports.avatarFriendsTable = avatarFriendsTable;
exports.postsTable = postsTable;
exports.likesTable = likesTable;
exports.commentsTable = commentsTable;
exports.followsTable = followsTable;
exports.ordersTable = ordersTable;
exports.orderResultsTable = orderResultsTable;
exports.orderDispatchRequestsTable = orderDispatchRequestsTable;
exports.earningsTable = earningsTable;
exports.transactionsTable = transactionsTable;
exports.withdrawalsTable = withdrawalsTable;
exports.subscriptionPlansTable = subscriptionPlansTable;
exports.userSubscriptionsTable = userSubscriptionsTable;
exports.notificationsTable = notificationsTable;
exports.skillsTable = skillsTable;
exports.referralsTable = referralsTable;
exports.recommendationsTable = recommendationsTable;
exports.conversationsTable = conversationsTable;
exports.messagesTable = messagesTable;
exports.tasksTable = tasksTable;
exports.avatarAccountsTable = avatarAccountsTable;
exports.publishedWorksTable = publishedWorksTable;
exports.paymentOrdersTable = paymentOrdersTable;
exports.avatarHostingConfigsTable = avatarHostingConfigsTable;
exports.avatarHostingLogsTable = avatarHostingLogsTable;
exports.verificationCodesTable = verificationCodesTable;
exports.deleteRow = deleteRow;
exports.getMySQLClient = getMySQLClient;
const promise_1 = require("mysql2/promise");
let pool = null;
function getPool() {
    if (!pool) {
        pool = (0, promise_1.createPool)({
            host: process.env.MYSQL_HOST || '127.0.0.1',
            port: parseInt(process.env.MYSQL_PORT || '3306'),
            user: process.env.MYSQL_USER || 'mrl',
            password: process.env.MYSQL_PASSWORD || 'SYDPHJB8aGBn83Eh',
            database: process.env.MYSQL_DATABASE || 'mrl',
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0,
            decimalNumbers: true,
        });
    }
    return pool;
}
function toSnakeCase(str) {
    return str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
}
function toCamelCase(str) {
    return str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
}
function convertKeysToCamel(obj) {
    if (obj === null || obj === undefined)
        return obj;
    if (Array.isArray(obj)) {
        return obj.map(convertKeysToCamel);
    }
    if (obj instanceof Date) {
        return obj.toISOString();
    }
    if (typeof obj === 'object' && obj !== null && typeof obj.toFixed === 'function') {
        return Number(obj);
    }
    if (typeof obj === 'object') {
        const result = {};
        for (const key in obj) {
            result[toCamelCase(key)] = convertKeysToCamel(obj[key]);
        }
        return result;
    }
    return obj;
}
function convertKeysToSnake(obj) {
    if (obj === null || obj === undefined)
        return obj;
    if (Array.isArray(obj)) {
        return obj.map(convertKeysToSnake);
    }
    if (obj instanceof Date) {
        return obj;
    }
    if (typeof obj === 'object') {
        const result = {};
        for (const key in obj) {
            if (/^[a-z]+(_[a-z]+)+$/.test(key)) {
                result[key] = convertKeysToSnake(obj[key]);
            }
            else {
                result[toSnakeCase(key)] = convertKeysToSnake(obj[key]);
            }
        }
        return result;
    }
    return obj;
}
class MysqlClient {
    constructor(table, jsonFields = []) {
        this.jsonFields = [];
        this._table = table;
        this.jsonFields = jsonFields;
    }
    table(tableName) {
        return new MysqlClient(tableName, this.jsonFields);
    }
    from(tableName) {
        return new MysqlClient(tableName, this.jsonFields);
    }
    select(tableName, conditions) {
        return this.query(tableName, conditions);
    }
    where(conditions) {
        return this;
    }
    whereIn(field, values) {
        return this;
    }
    async insert(tableOrData, data) {
        const table = typeof tableOrData === 'string' ? tableOrData : this._table;
        const insertData = typeof tableOrData === 'string' ? data : tableOrData;
        if (!insertData)
            return { data: undefined, error: 'No data provided' };
        try {
            const pool = getPool();
            const keys = Object.keys(insertData);
            const values = Object.values(convertKeysToSnake(insertData));
            const columns = keys.map(k => toSnakeCase(k)).join(', ');
            const placeholders = keys.map(() => '?').join(', ');
            const sql = `INSERT INTO ${table} (${columns}) VALUES (${placeholders})`;
            const [result] = await pool.query(sql, values);
            return { data: { insertId: result.insertId, affectedRows: result.affectedRows }, error: null };
        }
        catch (error) {
            return { data: undefined, error };
        }
    }
    async insertMany(items) {
        if (!items.length)
            return { data: undefined, error: null };
        try {
            const pool = getPool();
            const keys = Object.keys(convertKeysToSnake(items[0]));
            const columns = keys.join(', ');
            const placeholders = items.map(() => `(${keys.map(() => '?').join(', ')})`).join(', ');
            const values = [];
            for (const item of items) {
                const row = Object.values(convertKeysToSnake(item));
                values.push(...row);
            }
            const sql = `INSERT INTO ${this._table} (${columns}) VALUES ${placeholders}`;
            const [result] = await pool.query(sql, values);
            return { data: { affectedRows: result.affectedRows }, error: null };
        }
        catch (error) {
            return { data: undefined, error };
        }
    }
    async update(idOrTable, dataOrId, data) {
        if (typeof idOrTable === 'string' && typeof dataOrId !== 'object') {
            const table = idOrTable;
            const id = dataOrId;
            const updateData = data;
            try {
                const pool = getPool();
                const keys = Object.keys(updateData).map(k => `${toSnakeCase(k)} = ?`);
                const values = [...Object.values(convertKeysToSnake(updateData)), id];
                const sql = `UPDATE ${table} SET ${keys.join(', ')} WHERE id = ?`;
                const [result] = await pool.query(sql, values);
                return { data: { affectedRows: result.affectedRows }, error: null };
            }
            catch (error) {
                return { data: undefined, error };
            }
        }
        const id = idOrTable;
        const updateData = dataOrId;
        try {
            const pool = getPool();
            const keys = Object.keys(updateData).map(k => `${toSnakeCase(k)} = ?`);
            const values = [...Object.values(convertKeysToSnake(updateData)), id];
            const sql = `UPDATE ${this._table} SET ${keys.join(', ')} WHERE id = ?`;
            const [result] = await pool.query(sql, values);
            return { data: { affectedRows: result.affectedRows }, error: null };
        }
        catch (error) {
            return { data: undefined, error };
        }
    }
    async updateWhere(tableOrConditions, conditionsOrData, data) {
        let table;
        let conditions;
        let updateData;
        if (typeof tableOrConditions === 'string') {
            table = tableOrConditions;
            conditions = conditionsOrData;
            updateData = data;
        }
        else {
            table = this._table;
            conditions = tableOrConditions;
            updateData = conditionsOrData;
        }
        try {
            const pool = getPool();
            const setKeys = Object.keys(updateData).map(k => `${toSnakeCase(k)} = ?`);
            const whereKeys = Object.keys(conditions).map(k => `${toSnakeCase(k)} = ?`);
            const values = [...Object.values(convertKeysToSnake(updateData)), ...Object.values(conditions)];
            const sql = `UPDATE ${table} SET ${setKeys.join(', ')} WHERE ${whereKeys.join(' AND ')}`;
            const [result] = await pool.query(sql, values);
            return { data: { affectedRows: result.affectedRows }, error: null };
        }
        catch (error) {
            return { data: undefined, error };
        }
    }
    async delete(tableOrConditions, conditions) {
        let table;
        let deleteConditions;
        if (typeof tableOrConditions === 'string') {
            table = tableOrConditions;
            deleteConditions = conditions;
        }
        else {
            table = this._table;
            deleteConditions = tableOrConditions;
        }
        try {
            const pool = getPool();
            const keys = Object.keys(deleteConditions).map(k => `${toSnakeCase(k)} = ?`);
            const values = Object.values(deleteConditions);
            const sql = `DELETE FROM ${table} WHERE ${keys.join(' AND ')}`;
            const [result] = await pool.query(sql, values);
            return { data: { affectedRows: result.affectedRows }, error: null };
        }
        catch (error) {
            return { data: undefined, error };
        }
    }
    async deleteRow(table, conditions) {
        return new MysqlClient(table).delete(conditions);
    }
    async findOne(conditions) {
        try {
            const pool = getPool();
            const keys = Object.keys(conditions).map(k => `${toSnakeCase(k)} = ?`);
            const values = Object.values(conditions);
            const sql = `SELECT * FROM ${this._table} WHERE ${keys.join(' AND ')} LIMIT 1`;
            const [rows] = await pool.query(sql, values);
            if (rows.length === 0)
                return null;
            return convertKeysToCamel(rows[0]);
        }
        catch (error) {
            throw error;
        }
    }
    async findMany(conditions, options) {
        try {
            const pool = getPool();
            let sql = `SELECT * FROM ${this._table}`;
            let values = [];
            if (conditions && Object.keys(conditions).length > 0) {
                const keys = Object.keys(conditions).map(k => `${toSnakeCase(k)} = ?`);
                sql += ` WHERE ${keys.join(' AND ')}`;
                values = Object.values(conditions);
            }
            if (options?.orderBy) {
                sql += ` ORDER BY ${toSnakeCase(options.orderBy)}`;
            }
            if (options?.limit) {
                sql += ` LIMIT ${options.limit}`;
            }
            if (options?.offset) {
                sql += ` OFFSET ${options.offset}`;
            }
            const [rows] = await pool.query(sql, values);
            return rows.map((row) => convertKeysToCamel(row));
        }
        catch (error) {
            throw error;
        }
    }
    async query(sqlOrTable, paramsOrConditions) {
        if (paramsOrConditions && typeof paramsOrConditions === 'object' && !Array.isArray(paramsOrConditions)) {
            const conditions = paramsOrConditions;
            const keys = Object.keys(conditions).map(k => `${toSnakeCase(k)} = ?`);
            const values = Object.values(conditions);
            if (keys.length === 0) {
                return this.query(`SELECT * FROM ${sqlOrTable}`, []);
            }
            return this.query(`SELECT * FROM ${sqlOrTable} WHERE ${keys.join(' AND ')}`, values);
        }
        try {
            const pool = getPool();
            const [rows] = await pool.query(sqlOrTable, paramsOrConditions || []);
            if (!Array.isArray(rows)) {
                return rows;
            }
            return rows.map((row) => convertKeysToCamel(row));
        }
        catch (error) {
            throw error;
        }
    }
    async findById(id) {
        return this.findOne({ id });
    }
    async count(conditions) {
        try {
            const pool = getPool();
            let sql = `SELECT COUNT(*) as count FROM ${this._table}`;
            let params = [];
            if (conditions && Object.keys(conditions).length > 0) {
                const keys = Object.keys(conditions).map(k => `${toSnakeCase(k)} = ?`);
                sql += ` WHERE ${keys.join(' AND ')}`;
                params = Object.values(conditions);
            }
            const [rows] = await pool.query(sql, params);
            return rows[0]?.count || 0;
        }
        catch (error) {
            return 0;
        }
    }
    async countWhere(tableOrConditions, whereSql) {
        if (typeof tableOrConditions === 'object') {
            return this.count(tableOrConditions);
        }
        const table = tableOrConditions;
        try {
            const pool = getPool();
            let sql = `SELECT COUNT(*) as count FROM ${table}`;
            const values = [];
            if (whereSql) {
                sql += ` WHERE ${whereSql}`;
            }
            const [rows] = await pool.query(sql, values);
            return rows[0]?.count || 0;
        }
        catch (error) {
            return 0;
        }
    }
    async queryOne(tableOrConditions, conditions) {
        if (typeof tableOrConditions === 'string') {
            return new MysqlClient(tableOrConditions).findOne(conditions || {});
        }
        return this.findOne(tableOrConditions);
    }
    async queryWhere(tableOrConditions, whereOrOptions, options) {
        if (typeof tableOrConditions === 'object') {
            return this.findMany(tableOrConditions);
        }
        const table = tableOrConditions;
        const whereSql = whereOrOptions;
        const opt = options || {};
        try {
            const pool = getPool();
            let sql = `SELECT * FROM ${table}`;
            const values = [];
            if (whereSql) {
                sql += ` WHERE ${whereSql}`;
            }
            if (opt.orderBy) {
                sql += ` ORDER BY ${toSnakeCase(opt.orderBy)}`;
                if (opt.orderDirection) {
                    sql += ` ${opt.orderDirection}`;
                }
            }
            if (opt.limit) {
                sql += ` LIMIT ${opt.limit}`;
            }
            if (opt.offset) {
                sql += ` OFFSET ${opt.offset}`;
            }
            const [rows] = await pool.query(sql, values);
            return rows.map((row) => convertKeysToCamel(row));
        }
        catch (error) {
            throw error;
        }
    }
    buildWhereClause(conditions) {
        const keys = Object.keys(conditions).map(k => `${toSnakeCase(k)} = ?`);
        return {
            sql: keys.join(' AND '),
            params: Object.values(conditions)
        };
    }
    async exists(conditions) {
        const count = await this.count(conditions);
        return count > 0;
    }
    async findIn(column, values) {
        if (!values.length)
            return [];
        try {
            const pool = getPool();
            const placeholders = values.map(() => '?').join(', ');
            const sql = `SELECT * FROM ${this._table} WHERE ${toSnakeCase(column)} IN (${placeholders})`;
            const [rows] = await pool.query(sql, values);
            return rows.map((row) => convertKeysToCamel(row));
        }
        catch (error) {
            throw error;
        }
    }
    async upsert(data, uniqueKey = 'id') {
        try {
            const pool = getPool();
            const keys = Object.keys(data);
            const columns = keys.map(k => toSnakeCase(k)).join(', ');
            const placeholders = keys.map(() => '?').join(', ');
            const updateColumns = keys.filter(k => k !== uniqueKey).map(k => `${toSnakeCase(k)} = VALUES(${toSnakeCase(k)})`).join(', ');
            const values = Object.values(convertKeysToSnake(data));
            let sql;
            if (updateColumns) {
                sql = `INSERT INTO ${this._table} (${columns}) VALUES (${placeholders}) ON DUPLICATE KEY UPDATE ${updateColumns}`;
            }
            else {
                sql = `INSERT INTO ${this._table} (${columns}) VALUES (${placeholders})`;
            }
            const [result] = await pool.query(sql, values);
            return { data: { insertId: result.insertId, affectedRows: result.affectedRows }, error: null };
        }
        catch (error) {
            return { data: undefined, error };
        }
    }
    eq(column, value) {
        const self = this;
        return {
            then(resolve) {
                Promise.resolve(self.findMany({ [column]: value })).then(resolve);
            },
            select() {
                return self.findMany({ [column]: value });
            }
        };
    }
}
exports.MysqlClient = MysqlClient;
function usersTable() {
    return new MysqlClient('users', ['settings', 'preferences']);
}
function avatarsTable() {
    return new MysqlClient('avatars', ['profile', 'settings', 'styles', 'voiceSettings', 'personalityConfig', 'contentStyles', 'nicheTags']);
}
function avatarSkillsTable() {
    return new MysqlClient('avatar_skills');
}
function avatarMemoriesTable() {
    return new MysqlClient('avatar_memories', ['memoryData']);
}
function avatarFriendsTable() {
    return new MysqlClient('avatar_friends');
}
function postsTable() {
    return new MysqlClient('posts', ['mediaUrls', 'mentions', 'locationData']);
}
function likesTable() {
    return new MysqlClient('likes');
}
function commentsTable() {
    return new MysqlClient('comments');
}
function followsTable() {
    return new MysqlClient('follows');
}
function ordersTable() {
    return new MysqlClient('orders', ['orderDetails', 'metadata', 'preferredStyles', 'industryTags']);
}
function orderResultsTable() {
    return new MysqlClient('order_results', ['resultData']);
}
function orderDispatchRequestsTable() {
    return new MysqlClient('order_dispatch_requests', ['requestData']);
}
function earningsTable() {
    return new MysqlClient('earnings', ['earningsData']);
}
function transactionsTable() {
    return new MysqlClient('transactions', ['transactionData']);
}
function withdrawalsTable() {
    return new MysqlClient('withdrawals');
}
function subscriptionPlansTable() {
    return new MysqlClient('subscription_plans', ['features', 'limitations']);
}
function userSubscriptionsTable() {
    return new MysqlClient('user_subscriptions', ['subscriptionData']);
}
function notificationsTable() {
    return new MysqlClient('notifications', ['data']);
}
function skillsTable() {
    return new MysqlClient('skills', ['config', 'capabilities']);
}
function referralsTable() {
    return new MysqlClient('referrals');
}
function recommendationsTable() {
    return new MysqlClient('recommendations', ['recommendationData']);
}
function conversationsTable() {
    return new MysqlClient('conversations', ['contextData']);
}
function messagesTable() {
    return new MysqlClient('messages', ['metadata']);
}
function tasksTable() {
    return new MysqlClient('tasks', ['taskData', 'result']);
}
function avatarAccountsTable() {
    return new MysqlClient('avatar_accounts', ['accountData', 'platformConfig']);
}
function publishedWorksTable() {
    return new MysqlClient('published_works', ['mediaUrls']);
}
function paymentOrdersTable() {
    return new MysqlClient('payment_orders', ['metadata']);
}
function avatarHostingConfigsTable() {
    return new MysqlClient('avatar_hosting_configs', ['behaviorRules', 'scheduleConfig']);
}
function avatarHostingLogsTable() {
    return new MysqlClient('avatar_hosting_logs');
}
function verificationCodesTable() {
    return new MysqlClient('verification_codes');
}
async function deleteRow(table, conditions) {
    return new MysqlClient(table).delete(conditions);
}
function getMySQLClient(table) {
    return new MysqlClient(table || 'users');
}
