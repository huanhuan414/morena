"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSharedCache = getSharedCache;
exports.setCache = setCache;
exports.getCache = getCache;
exports.deleteCache = deleteCache;
exports.clearCache = clearCache;
if (!global.__sharedCache) {
    global.__sharedCache = new Map();
    global.__sharedCacheInitialized = true;
    console.log('[SharedCache] 全局缓存初始化');
}
const sharedCache = global.__sharedCache;
function getSharedCache() {
    console.log('[SharedCache] getSharedCache 被调用, 当前缓存大小:', sharedCache.size);
    return sharedCache;
}
function setCache(key, data) {
    console.log('[SharedCache] setCache 被调用, key:', key);
    sharedCache.set(key, data);
    console.log('[SharedCache] 缓存设置后大小:', sharedCache.size);
    setTimeout(() => {
        sharedCache.delete(key);
    }, 3600000);
}
function getCache(key) {
    const result = sharedCache.get(key);
    console.log('[SharedCache] getCache, key:', key, '结果:', result ? '存在' : '不存在');
    return result;
}
function deleteCache(key) {
    sharedCache.delete(key);
}
function clearCache() {
    sharedCache.clear();
}
