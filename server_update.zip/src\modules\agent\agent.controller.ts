/**
 * Agent 控制器
 * 提供 Agent 相关的 API 接口
 */

import { Controller, Get, Post, Delete, Body, Param, Headers, Query, Sse, Req, Inject } from '@nestjs/common'
import { Request } from 'express'
import { Observable, from, of } from 'rxjs'
import { map, catchError } from 'rxjs/operators'
import { AgentService } from './agent.service'
import { PlatformType } from './agent.types'
import { ProgressCacheService } from './progress-cache.service'

@Controller('agent')
export class AgentController {
  constructor(
    @Inject(AgentService) private readonly agentService: AgentService,
    @Inject(ProgressCacheService) private readonly progressCache: ProgressCacheService
  ) {}

  /**
   * 获取所有可用工具
   */
  @Get('tools')
  async getTools() {
    const tools = this.agentService.getAvailableTools()
    return {
      code: 200,
      data: tools,
      message: '获取成功'
    }
  }

  /**
   * 获取任务进度
   */
  @Get('progress')
  async getProgress(
    @Headers('x-user-id') userId: string,
    @Query('taskId') taskId?: string
  ) {
    const progress = this.progressCache.getProgress(userId, taskId)
    const latestProgress = this.progressCache.getLatestProgress(userId, taskId)
    
    return {
      code: 200,
      data: {
        progress,
        latest: latestProgress,
        count: progress.length
      },
      message: '获取成功'
    }
  }

  /**
   * 获取任务结果
   */
  @Get('result/:taskId')
  async getTaskResult(
    @Headers('x-user-id') userId: string,
    @Param('taskId') taskId: string
  ) {
    const result = this.progressCache.getTaskResult(userId, taskId)
    
    if (!result) {
      return {
        code: 404,
        data: null,
        message: '任务不存在或已过期'
      }
    }
    
    return {
      code: 200,
      data: result,
      message: '获取成功'
    }
  }

  /**
   * 执行 Agent 任务（异步模式，立即返回 taskId）
   * 解决 HTTP 请求超时问题
   */
  @Post('execute')
  async executeTask(
    @Headers('x-user-id') userId: string,
    @Body() body: {
      avatar_id: string
      task_description: string
      conversation_id?: string
      task_id?: string
      conversation_history?: Array<{ role: string; content: string }>
      attachments?: {
        images?: string[]
        videos?: string[]
      }
    }
  ) {
    // 生成任务ID
    const taskId = body.task_id || `task-${Date.now()}`

    // 创建任务记录
    this.progressCache.createTask(userId, taskId)

    // 异步执行任务（不等待结果）
    this.agentService.executeTaskAsync(
      userId,
      body.avatar_id,
      body.task_description,
      {
        conversationId: body.conversation_id,
        taskId,
        conversationHistory: body.conversation_history as any,
        uploadedImages: body.attachments?.images || [], // 新增：上传的图片
        uploadedVideos: body.attachments?.videos || []  // 新增：上传的视频
      }
    ).catch(err => {
      console.error(`[AgentController] 任务执行失败: ${taskId}`, err)
      this.progressCache.updateTaskStatus(userId, taskId, 'failed', null, err.message)
    })

    // 立即返回 taskId
    return {
      code: 200,
      data: {
        taskId,
        status: 'pending'
      },
      message: '任务已提交，请通过轮询获取进度和结果'
    }
  }

  /**
   * 检查平台配置状态
   */
  @Get('platform-config/:platform')
  async checkPlatformConfig(
    @Headers('x-user-id') userId: string,
    @Param('platform') platform: PlatformType
  ) {
    const result = await this.agentService.checkPlatformConfig(userId, platform)
    
    return {
      code: 200,
      data: result,
      message: '查询成功'
    }
  }

  /**
   * 获取用户的所有平台配置
   */
  @Get('platform-configs')
  async getUserPlatformConfigs(@Headers('x-user-id') userId: string) {
    const configs = await this.agentService.getUserPlatformConfigs(userId)
    
    // 隐藏敏感信息
    const safeConfigs = configs.map(config => ({
      ...config,
      config_data: Object.keys(config.config_data).reduce((acc, key) => {
        acc[key] = '******'
        return acc
      }, {} as Record<string, string>)
    }))

    return {
      code: 200,
      data: safeConfigs,
      message: '获取成功'
    }
  }

  /**
   * 保存平台配置
   */
  @Post('platform-config/:platform')
  async savePlatformConfig(
    @Headers('x-user-id') userId: string,
    @Param('platform') platform: PlatformType,
    @Body() configData: Record<string, any>
  ) {
    const result = await this.agentService.savePlatformConfig(userId, platform, configData)
    
    return {
      code: result.success ? 200 : 400,
      data: null,
      message: result.message
    }
  }

  /**
   * 验证平台配置（保存前先验证配置是否正确）
   */
  @Post('platform-config/:platform/validate')
  async validatePlatformConfig(
    @Param('platform') platform: PlatformType,
    @Body() configData: Record<string, any>
  ) {
    const result = await this.agentService.validatePlatformConfig(platform, configData)
    
    return {
      code: 200,
      data: result,
      message: result.valid ? '验证成功' : '验证失败'
    }
  }

  /**
   * 删除平台配置
   */
  @Delete('platform-config/:platform')
  async deletePlatformConfig(
    @Headers('x-user-id') userId: string,
    @Param('platform') platform: PlatformType
  ) {
    await this.agentService.deletePlatformConfig(userId, platform)
    
    return {
      code: 200,
      data: null,
      message: '删除成功'
    }
  }

  /**
   * 获取分身技能列表
   */
  @Get('skills/:avatarId')
  async getAvatarSkills(@Param('avatarId') avatarId: string) {
    const skills = await this.agentService.getAvatarSkills(avatarId)
    
    return {
      code: 200,
      data: skills,
      message: '获取成功'
    }
  }

  /**
   * 为分身添加技能
   */
  @Post('skills/:avatarId')
  async addAvatarSkill(
    @Param('avatarId') avatarId: string,
    @Body() body: { skill_type: string; metadata?: Record<string, any> }
  ) {
    const result = await this.agentService.addAvatarSkill(
      avatarId,
      body.skill_type,
      body.metadata
    )
    
    return {
      code: 200,
      data: null,
      message: '技能添加成功'
    }
  }

  /**
   * 发布内容到平台
   * 统一的发布接口，支持多平台
   */
  @Post('publish/:platform')
  async publishContent(
    @Headers('x-user-id') userId: string,
    @Param('platform') platform: PlatformType,
    @Body() body: {
      title?: string
      content?: string
      cover_url?: string
      images?: string[]
      tags?: string[]
    }
  ) {
    const result = await this.agentService.publishContent(userId, platform, body)
    
    return {
      code: result.success ? 200 : 400,
      data: result.data,
      message: result.message || (result.success ? '发布成功' : '发布失败')
    }
  }

  /**
   * 生成图片
   * 使用豆包 Seedream 模型生成图片
   */
  @Post('images/generations')
  async generateImage(@Body() body: {
    prompt: string
    size?: string
    style?: string
  }) {
    try {
      const axios = require('axios')
      const apiUrl = 'https://ark.cn-beijing.volces.com/api/v3/images/generations'
      const apiKey = process.env.VOLC_VIDEO_API_KEY || '0a6405d5-b7ae-4afa-88e3-c707ae379a47'

      const response = await axios.post(apiUrl, {
        model: 'doubao-seedream-4-0-250828',
        prompt: body.prompt,
        sequential_image_generation: 'disabled',
        response_format: 'url',
        size: body.size || '2K',
        stream: false,
        watermark: false
      }, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        timeout: 120000 // 2分钟超时
      })


      if (response.status !== 200) {
        const errorMsg = response.data?.error?.message || response.data?.message || '图片生成失败'
        return {
          code: 400,
          msg: errorMsg
        }
      }

      return {
        code: 200,
        data: {
          url: response.data.data?.[0]?.url || response.data.url,
          revised_prompt: response.data.data?.[0]?.revised_prompt
        }
      }
    } catch (error: any) {
      console.error('[AgentController] 图片生成失败:', error.message)
      return {
        code: 500,
        msg: `图片生成失败: ${error.message}`
      }
    }
  }
}
